#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/DS1337_RTC_LCD_Keypad.c"
#line 63 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/DS1337_RTC_LCD_Keypad.c"
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;


sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;


const char keymap[4][4] = {
 {'1','2','3','A'},
 {'4','5','6','B'},
 {'7','8','9','C'},
 {'*','0','#','D'}
};



unsigned short rtc_buf[7];
char rtc_digits[13];
unsigned short rtc_pos;




void delayMs(unsigned int n) {
 unsigned int i;
 for(; n > 0; n--) {
 for(i = 0; i < 3195; i++) {
 asm nop;
 }
 }
}




unsigned short DecToBcd(unsigned short val) {
 return ((val / 10) << 4) | (val % 10);
}

unsigned short BcdToDec(unsigned short val) {
 return ((val >> 4) * 10) + (val & 0x0F);
}

unsigned short Parse2Digits(char high, char low) {
 return ((high - '0') * 10) + (low - '0');
}

unsigned short ValidateDateTime(unsigned short day,
 unsigned short month,
 unsigned short year,
 unsigned short hour,
 unsigned short minute,
 unsigned short second) {
 if(day < 1 || day > 31) return 0;
 if(month < 1 || month > 12) return 0;
 if(hour > 23) return 0;
 if(minute > 59) return 0;
 if(second > 59) return 0;
 return 1;
}




void Keypad_AllColumns_Low() {
 GPIOC_ODR.B12 = 0;
 GPIOC_ODR.B1 = 0;
 GPIOB_ODR.B2 = 0;
 GPIOD_ODR.B2 = 0;
}

void Keypad_SelectColumn(unsigned short col) {
 Keypad_AllColumns_Low();

 switch(col) {
 case 0: GPIOC_ODR.B12 = 1; break;
 case 1: GPIOC_ODR.B1 = 1; break;
 case 2: GPIOB_ODR.B2 = 1; break;
 case 3: GPIOD_ODR.B2 = 1; break;
 }
}

unsigned short Keypad_ReadRow() {
 if(GPIOC_IDR.B7 == 1) return 0;
 if(GPIOC_IDR.B13 == 1) return 1;
 if(GPIOA_IDR.B9 == 1) return 2;
 if(GPIOA_IDR.B10 == 1) return 3;

 return 255;
}

char Keypad_GetKey() {
 unsigned short row, col;

 for(col = 0; col < 4; col++) {
 Keypad_SelectColumn(col);
 Delay_ms(1);

 row = Keypad_ReadRow();
 if(row != 255) {
 Keypad_AllColumns_Low();
 return keymap[row][col];
 }
 }

 Keypad_AllColumns_Low();
 return 0;
}

char Keypad_GetKey_Click() {
 char key;

 while(1) {
 key = Keypad_GetKey();

 if(key != 0) {
 Delay_ms(20);

 if(Keypad_GetKey() == key) {
 while(Keypad_GetKey() != 0) {
 Delay_ms(10);
 }
 Delay_ms(20);
 return key;
 }
 }
 }
}




void I2C1_HW_Init() {
 RCC_AHB1ENR |= 0x00000002;
 RCC_APB1ENR |= 0x00200000;


 GPIOB_AFRH &= ~0x000000FF;
 GPIOB_AFRH |= 0x00000044;


 GPIOB_MODER &= ~0x000F0000;
 GPIOB_MODER |= 0x000A0000;


 GPIOB_OTYPER |= 0x00000300;


 GPIOB_PUPDR &= ~0x000F0000;
 GPIOB_PUPDR |= 0x00050000;


 I2C1_CR1 = 0x8000;
 I2C1_CR1 &= ~0x8000;


 I2C1_CR2 = 16;


 I2C1_CCR = 80;


 I2C1_TRISE = 17;


 I2C1_CR1 |= 0x0001;
}

void I2C1_WriteByte_Reg(unsigned short saddr,
 unsigned short reg_addr,
 unsigned short value) {
 volatile unsigned int tmp;

 while(I2C1_SR2 & 2);

 I2C1_CR1 |= 0x0100;
 while(!(I2C1_SR1 & 1));

 I2C1_DR = saddr << 1;
 while(!(I2C1_SR1 & 2));
 tmp = I2C1_SR2;

 while(!(I2C1_SR1 & 0x80));
 I2C1_DR = reg_addr;
 while(!(I2C1_SR1 & 0x80));
 I2C1_DR = value;
 while(!(I2C1_SR1 & 0x80));

 I2C1_CR1 |= 0x0200;
}

void I2C1_BurstWrite(unsigned short saddr,
 unsigned short start_reg,
 unsigned short count,
 unsigned short data_buf[]) {
 volatile unsigned int tmp;
 unsigned short i;

 while(I2C1_SR2 & 2);

 I2C1_CR1 |= 0x0100;
 while(!(I2C1_SR1 & 1));

 I2C1_DR = saddr << 1;
 while(!(I2C1_SR1 & 2));
 tmp = I2C1_SR2;

 while(!(I2C1_SR1 & 0x80));
 I2C1_DR = start_reg;

 for(i = 0; i < count; i++) {
 while(!(I2C1_SR1 & 0x80));
 I2C1_DR = data_buf[i];
 }

 while(!(I2C1_SR1 & 0x80));
 I2C1_CR1 |= 0x0200;
}

void I2C1_BurstRead(unsigned short saddr,
 unsigned short start_reg,
 unsigned short count,
 unsigned short data_buf[]) {
 volatile unsigned int tmp;
 unsigned short i;

 while(I2C1_SR2 & 2);

 I2C1_CR1 &= ~0x0800;
 I2C1_CR1 |= 0x0100;
 while(!(I2C1_SR1 & 1));

 I2C1_DR = saddr << 1;
 while(!(I2C1_SR1 & 2));
 tmp = I2C1_SR2;

 while(!(I2C1_SR1 & 0x80));
 I2C1_DR = start_reg;
 while(!(I2C1_SR1 & 0x80));

 I2C1_CR1 |= 0x0100;
 while(!(I2C1_SR1 & 1));

 I2C1_DR = (saddr << 1) | 1;
 while(!(I2C1_SR1 & 2));
 tmp = I2C1_SR2;

 I2C1_CR1 |= 0x0400;

 for(i = 0; i < count; i++) {
 if(i == (count - 1)) {
 I2C1_CR1 &= ~0x0400;
 I2C1_CR1 |= 0x0200;
 }

 while(!(I2C1_SR1 & 0x40));
 data_buf[i] = I2C1_DR;
 }
}




void DS1337_Init() {

 I2C1_WriteByte_Reg( 0x68 , 0x0E, 0x00);


 I2C1_WriteByte_Reg( 0x68 , 0x0F, 0x00);
}

void DS1337_SetDateTime(unsigned short day,
 unsigned short month,
 unsigned short year,
 unsigned short hour,
 unsigned short minute,
 unsigned short second) {
 unsigned short wr[7];

 wr[0] = DecToBcd(second);
 wr[1] = DecToBcd(minute);
 wr[2] = DecToBcd(hour);
 wr[3] = 0x01;
 wr[4] = DecToBcd(day);
 wr[5] = DecToBcd(month);
 wr[6] = DecToBcd(year);

 I2C1_BurstWrite( 0x68 , 0x00, 7, wr);
}

void DS1337_GetDateTime(unsigned short *day,
 unsigned short *month,
 unsigned short *year,
 unsigned short *hour,
 unsigned short *minute,
 unsigned short *second) {
 I2C1_BurstRead( 0x68 , 0x00, 7, rtc_buf);

 *second = BcdToDec(rtc_buf[0] & 0x7F);
 *minute = BcdToDec(rtc_buf[1] & 0x7F);
 *hour = BcdToDec(rtc_buf[2] & 0x3F);
 *day = BcdToDec(rtc_buf[4] & 0x3F);
 *month = BcdToDec(rtc_buf[5] & 0x1F);
 *year = BcdToDec(rtc_buf[6]);
}




void ShowMainMenu() {
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "A:Adjust D:Show");
 Lcd_Out(2, 1, "Select option");
}

void BuildAdjustScreen() {
 char line1[17];
 char line2[17];
 unsigned short i;

 for(i = 0; i < 16; i++) {
 line1[i] = ' ';
 line2[i] = ' ';
 }
 line1[16] = 0;
 line2[16] = 0;


 line1[0] = 'D';
 line1[1] = ':';
 line1[2] = rtc_digits[0] ? rtc_digits[0] : '_';
 line1[3] = rtc_digits[1] ? rtc_digits[1] : '_';
 line1[4] = '/';
 line1[5] = rtc_digits[2] ? rtc_digits[2] : '_';
 line1[6] = rtc_digits[3] ? rtc_digits[3] : '_';
 line1[7] = '/';
 line1[8] = rtc_digits[4] ? rtc_digits[4] : '_';
 line1[9] = rtc_digits[5] ? rtc_digits[5] : '_';


 line2[0] = 'T';
 line2[1] = ':';
 line2[2] = rtc_digits[6] ? rtc_digits[6] : '_';
 line2[3] = rtc_digits[7] ? rtc_digits[7] : '_';
 line2[4] = ':';
 line2[5] = rtc_digits[8] ? rtc_digits[8] : '_';
 line2[6] = rtc_digits[9] ? rtc_digits[9] : '_';
 line2[7] = ':';
 line2[8] = rtc_digits[10] ? rtc_digits[10] : '_';
 line2[9] = rtc_digits[11] ? rtc_digits[11] : '_';

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, line1);
 Lcd_Out(2, 1, line2);
}

void AdjustMode() {
 char key;
 unsigned short day, month, year, hour, minute, second;
 unsigned short i;

 for(i = 0; i < 12; i++) rtc_digits[i] = 0;
 rtc_digits[12] = 0;
 rtc_pos = 0;

 BuildAdjustScreen();

 while(1) {
 key = Keypad_GetKey_Click();

 if((key >= '0') && (key <= '9')) {
 if(rtc_pos < 12) {
 rtc_digits[rtc_pos] = key;
 rtc_pos++;
 BuildAdjustScreen();
 }
 }
 else if(key == '*') {
 if(rtc_pos > 0) {
 rtc_pos--;
 rtc_digits[rtc_pos] = 0;
 BuildAdjustScreen();
 }
 }
 else if(key == 'B') {
 return;
 }
 else if(key == '#') {
 if(rtc_pos == 12) {
 day = Parse2Digits(rtc_digits[0], rtc_digits[1]);
 month = Parse2Digits(rtc_digits[2], rtc_digits[3]);
 year = Parse2Digits(rtc_digits[4], rtc_digits[5]);
 hour = Parse2Digits(rtc_digits[6], rtc_digits[7]);
 minute = Parse2Digits(rtc_digits[8], rtc_digits[9]);
 second = Parse2Digits(rtc_digits[10], rtc_digits[11]);

 if(ValidateDateTime(day, month, year, hour, minute, second)) {
 DS1337_SetDateTime(day, month, year, hour, minute, second);

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Saved OK");
 Lcd_Out(2, 1, "B:Back");
 }
 else {
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Invalid DateTime");
 Lcd_Out(2, 1, "B:Back");
 }

 while(1) {
 key = Keypad_GetKey_Click();
 if(key == 'B') return;
 }
 }
 else {
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Need 12 digits");
 Lcd_Out(2, 1, "# retry B back");

 while(1) {
 key = Keypad_GetKey_Click();
 if(key == 'B') return;
 if(key == '#') {
 BuildAdjustScreen();
 break;
 }
 }
 }
 }
 }
}

void DisplayMode() {
 unsigned short day, month, year, hour, minute, second;
 char key;
 char line1[17];
 char line2[17];

 while(1) {
 DS1337_GetDateTime(&day, &month, &year, &hour, &minute, &second);

 line1[0] = (day / 10) + '0';
 line1[1] = (day % 10) + '0';
 line1[2] = '/';
 line1[3] = (month / 10) + '0';
 line1[4] = (month % 10) + '0';
 line1[5] = '/';
 line1[6] = (year / 10) + '0';
 line1[7] = (year % 10) + '0';
 line1[8] = 0;

 line2[0] = (hour / 10) + '0';
 line2[1] = (hour % 10) + '0';
 line2[2] = ':';
 line2[3] = (minute / 10) + '0';
 line2[4] = (minute % 10) + '0';
 line2[5] = ':';
 line2[6] = (second / 10) + '0';
 line2[7] = (second % 10) + '0';
 line2[8] = 0;

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, line1);
 Lcd_Out(2, 1, line2);

 key = Keypad_GetKey();
 if(key == 'B') {
 Delay_ms(20);
 if(Keypad_GetKey() == 'B') {
 while(Keypad_GetKey() != 0) Delay_ms(10);
 return;
 }
 }

 Delay_ms(250);
 }
}




void main() {
 char key;


 GPIO_Digital_Output(&GPIOC_BASE,
 _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
 _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
 _GPIO_PINMASK_8 | _GPIO_PINMASK_9);


 GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
 GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);


 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
 GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);

 Keypad_AllColumns_Low();


 Lcd_Init();
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Cmd(_LCD_CURSOR_OFF);

 Lcd_Out(1, 1, "RTC SYSTEM");
 Lcd_Out(2, 1, "Initializing...");
 delayMs(1000);


 I2C1_HW_Init();


 DS1337_Init();

 while(1) {
 ShowMainMenu();
 key = Keypad_GetKey_Click();

 if(key == 'A') {
 AdjustMode();
 }
 else if(key == 'D') {
 DisplayMode();
 }
 }
}
