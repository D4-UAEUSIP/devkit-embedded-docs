_delayMs:
;DS1337_RTC_LCD_Keypad.c,95 :: 		void delayMs(unsigned int n) {
; n start address is: 0 (R0)
SUB	SP, SP, #4
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,97 :: 		for(; n > 0; n--) {
L_delayMs0:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs1
;DS1337_RTC_LCD_Keypad.c,98 :: 		for(i = 0; i < 3195; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs3:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
MOVW	R1, #3195
CMP	R2, R1
IT	CS
BCS	L_delayMs4
;DS1337_RTC_LCD_Keypad.c,99 :: 		asm nop;
NOP
;DS1337_RTC_LCD_Keypad.c,98 :: 		for(i = 0; i < 3195; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;DS1337_RTC_LCD_Keypad.c,100 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs3
L_delayMs4:
;DS1337_RTC_LCD_Keypad.c,97 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;DS1337_RTC_LCD_Keypad.c,101 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs0
L_delayMs1:
;DS1337_RTC_LCD_Keypad.c,102 :: 		}
L_end_delayMs:
ADD	SP, SP, #4
BX	LR
; end of _delayMs
_DecToBcd:
;DS1337_RTC_LCD_Keypad.c,107 :: 		unsigned short DecToBcd(unsigned short val) {
; val start address is: 0 (R0)
SUB	SP, SP, #4
; val end address is: 0 (R0)
; val start address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,108 :: 		return ((val / 10) << 4) | (val % 10);
MOVS	R1, #10
UDIV	R1, R0, R1
UXTB	R1, R1
LSLS	R3, R1, #4
UXTH	R3, R3
MOVS	R2, #10
UDIV	R1, R0, R2
MLS	R1, R2, R1, R0
UXTB	R1, R1
; val end address is: 0 (R0)
ORR	R1, R3, R1, LSL #0
UXTB	R0, R1
;DS1337_RTC_LCD_Keypad.c,109 :: 		}
L_end_DecToBcd:
ADD	SP, SP, #4
BX	LR
; end of _DecToBcd
_BcdToDec:
;DS1337_RTC_LCD_Keypad.c,111 :: 		unsigned short BcdToDec(unsigned short val) {
; val start address is: 0 (R0)
SUB	SP, SP, #4
; val end address is: 0 (R0)
; val start address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,112 :: 		return ((val >> 4) * 10) + (val & 0x0F);
LSRS	R2, R0, #4
UXTB	R2, R2
MOVS	R1, #10
SXTH	R1, R1
MULS	R2, R1, R2
SXTH	R2, R2
AND	R1, R0, #15
UXTB	R1, R1
; val end address is: 0 (R0)
ADDS	R1, R2, R1
UXTB	R0, R1
;DS1337_RTC_LCD_Keypad.c,113 :: 		}
L_end_BcdToDec:
ADD	SP, SP, #4
BX	LR
; end of _BcdToDec
_Parse2Digits:
;DS1337_RTC_LCD_Keypad.c,115 :: 		unsigned short Parse2Digits(char high, char low) {
; low start address is: 4 (R1)
; high start address is: 0 (R0)
SUB	SP, SP, #4
; low end address is: 4 (R1)
; high end address is: 0 (R0)
; high start address is: 0 (R0)
; low start address is: 4 (R1)
;DS1337_RTC_LCD_Keypad.c,116 :: 		return ((high - '0') * 10) + (low - '0');
SUBW	R3, R0, #48
SXTH	R3, R3
; high end address is: 0 (R0)
MOVS	R2, #10
SXTH	R2, R2
MULS	R3, R2, R3
SXTH	R3, R3
SUBW	R2, R1, #48
SXTH	R2, R2
; low end address is: 4 (R1)
ADDS	R2, R3, R2
UXTB	R0, R2
;DS1337_RTC_LCD_Keypad.c,117 :: 		}
L_end_Parse2Digits:
ADD	SP, SP, #4
BX	LR
; end of _Parse2Digits
_ValidateDateTime:
;DS1337_RTC_LCD_Keypad.c,124 :: 		unsigned short second) {
; hour start address is: 12 (R3)
; month start address is: 4 (R1)
; day start address is: 0 (R0)
SUB	SP, SP, #4
; hour end address is: 12 (R3)
; month end address is: 4 (R1)
; day end address is: 0 (R0)
; day start address is: 0 (R0)
; month start address is: 4 (R1)
; hour start address is: 12 (R3)
; minute start address is: 8 (R2)
LDRB	R2, [SP, #4]
; second start address is: 20 (R5)
LDRB	R5, [SP, #8]
;DS1337_RTC_LCD_Keypad.c,125 :: 		if(day < 1 || day > 31) return 0;
CMP	R0, #1
IT	CC
BCC	L__ValidateDateTime164
CMP	R0, #31
IT	HI
BHI	L__ValidateDateTime163
; day end address is: 0 (R0)
IT	AL
BAL	L_ValidateDateTime8
; month end address is: 4 (R1)
; hour end address is: 12 (R3)
; minute end address is: 8 (R2)
; second end address is: 20 (R5)
L__ValidateDateTime164:
L__ValidateDateTime163:
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime8:
;DS1337_RTC_LCD_Keypad.c,126 :: 		if(month < 1 || month > 12) return 0;
; second start address is: 20 (R5)
; minute start address is: 8 (R2)
; hour start address is: 12 (R3)
; month start address is: 4 (R1)
CMP	R1, #1
IT	CC
BCC	L__ValidateDateTime166
CMP	R1, #12
IT	HI
BHI	L__ValidateDateTime165
; month end address is: 4 (R1)
IT	AL
BAL	L_ValidateDateTime11
; hour end address is: 12 (R3)
; minute end address is: 8 (R2)
; second end address is: 20 (R5)
L__ValidateDateTime166:
L__ValidateDateTime165:
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime11:
;DS1337_RTC_LCD_Keypad.c,127 :: 		if(hour > 23) return 0;
; second start address is: 20 (R5)
; minute start address is: 8 (R2)
; hour start address is: 12 (R3)
CMP	R3, #23
IT	LS
BLS	L_ValidateDateTime12
; hour end address is: 12 (R3)
; minute end address is: 8 (R2)
; second end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime12:
;DS1337_RTC_LCD_Keypad.c,128 :: 		if(minute > 59) return 0;
; second start address is: 20 (R5)
; minute start address is: 8 (R2)
CMP	R2, #59
IT	LS
BLS	L_ValidateDateTime13
; minute end address is: 8 (R2)
; second end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime13:
;DS1337_RTC_LCD_Keypad.c,129 :: 		if(second > 59) return 0;
; second start address is: 20 (R5)
CMP	R5, #59
IT	LS
BLS	L_ValidateDateTime14
; second end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime14:
;DS1337_RTC_LCD_Keypad.c,130 :: 		return 1;
MOVS	R0, #1
;DS1337_RTC_LCD_Keypad.c,131 :: 		}
L_end_ValidateDateTime:
ADD	SP, SP, #4
BX	LR
; end of _ValidateDateTime
_Keypad_AllColumns_Low:
;DS1337_RTC_LCD_Keypad.c,136 :: 		void Keypad_AllColumns_Low() {
SUB	SP, SP, #4
;DS1337_RTC_LCD_Keypad.c,137 :: 		GPIOC_ODR.B12 = 0;   // C1
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;DS1337_RTC_LCD_Keypad.c,138 :: 		GPIOC_ODR.B1  = 0;   // C2
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;DS1337_RTC_LCD_Keypad.c,139 :: 		GPIOB_ODR.B2  = 0;   // C3
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;DS1337_RTC_LCD_Keypad.c,140 :: 		GPIOD_ODR.B2  = 0;   // C4
MOVW	R0, #lo_addr(GPIOD_ODR+0)
MOVT	R0, #hi_addr(GPIOD_ODR+0)
_SX	[R0, ByteOffset(GPIOD_ODR+0)]
;DS1337_RTC_LCD_Keypad.c,141 :: 		}
L_end_Keypad_AllColumns_Low:
ADD	SP, SP, #4
BX	LR
; end of _Keypad_AllColumns_Low
_Keypad_SelectColumn:
;DS1337_RTC_LCD_Keypad.c,143 :: 		void Keypad_SelectColumn(unsigned short col) {
; col start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R2, R0
; col end address is: 0 (R0)
; col start address is: 8 (R2)
;DS1337_RTC_LCD_Keypad.c,144 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;DS1337_RTC_LCD_Keypad.c,146 :: 		switch(col) {
IT	AL
BAL	L_Keypad_SelectColumn15
; col end address is: 8 (R2)
;DS1337_RTC_LCD_Keypad.c,147 :: 		case 0: GPIOC_ODR.B12 = 1; break;   // C1
L_Keypad_SelectColumn17:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn16
;DS1337_RTC_LCD_Keypad.c,148 :: 		case 1: GPIOC_ODR.B1  = 1; break;   // C2
L_Keypad_SelectColumn18:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn16
;DS1337_RTC_LCD_Keypad.c,149 :: 		case 2: GPIOB_ODR.B2  = 1; break;   // C3
L_Keypad_SelectColumn19:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
_SX	[R1, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn16
;DS1337_RTC_LCD_Keypad.c,150 :: 		case 3: GPIOD_ODR.B2  = 1; break;   // C4
L_Keypad_SelectColumn20:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOD_ODR+0)
MOVT	R1, #hi_addr(GPIOD_ODR+0)
_SX	[R1, ByteOffset(GPIOD_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn16
;DS1337_RTC_LCD_Keypad.c,151 :: 		}
L_Keypad_SelectColumn15:
; col start address is: 8 (R2)
CMP	R2, #0
IT	EQ
BEQ	L_Keypad_SelectColumn17
CMP	R2, #1
IT	EQ
BEQ	L_Keypad_SelectColumn18
CMP	R2, #2
IT	EQ
BEQ	L_Keypad_SelectColumn19
CMP	R2, #3
IT	EQ
BEQ	L_Keypad_SelectColumn20
; col end address is: 8 (R2)
L_Keypad_SelectColumn16:
;DS1337_RTC_LCD_Keypad.c,152 :: 		}
L_end_Keypad_SelectColumn:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_SelectColumn
_Keypad_ReadRow:
;DS1337_RTC_LCD_Keypad.c,154 :: 		unsigned short Keypad_ReadRow() {
SUB	SP, SP, #4
;DS1337_RTC_LCD_Keypad.c,155 :: 		if(GPIOC_IDR.B7  == 1) return 0;   // R1
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow21
MOVS	R0, #0
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow21:
;DS1337_RTC_LCD_Keypad.c,156 :: 		if(GPIOC_IDR.B13 == 1) return 1;   // R2
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow22
MOVS	R0, #1
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow22:
;DS1337_RTC_LCD_Keypad.c,157 :: 		if(GPIOA_IDR.B9  == 1) return 2;   // R3
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow23
MOVS	R0, #2
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow23:
;DS1337_RTC_LCD_Keypad.c,158 :: 		if(GPIOA_IDR.B10 == 1) return 3;   // R4
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow24
MOVS	R0, #3
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow24:
;DS1337_RTC_LCD_Keypad.c,160 :: 		return 255;
MOVS	R0, #255
;DS1337_RTC_LCD_Keypad.c,161 :: 		}
L_end_Keypad_ReadRow:
ADD	SP, SP, #4
BX	LR
; end of _Keypad_ReadRow
_Keypad_GetKey:
;DS1337_RTC_LCD_Keypad.c,163 :: 		char Keypad_GetKey() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;DS1337_RTC_LCD_Keypad.c,166 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
MOVS	R3, #0
; col end address is: 12 (R3)
L_Keypad_GetKey25:
; col start address is: 12 (R3)
CMP	R3, #4
IT	CS
BCS	L_Keypad_GetKey26
;DS1337_RTC_LCD_Keypad.c,167 :: 		Keypad_SelectColumn(col);
UXTB	R0, R3
BL	_Keypad_SelectColumn+0
;DS1337_RTC_LCD_Keypad.c,168 :: 		Delay_ms(1);
MOVW	R7, #7998
MOVT	R7, #0
NOP
NOP
L_Keypad_GetKey28:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey28
NOP
NOP
NOP
;DS1337_RTC_LCD_Keypad.c,170 :: 		row = Keypad_ReadRow();
BL	_Keypad_ReadRow+0
; row start address is: 8 (R2)
UXTB	R2, R0
;DS1337_RTC_LCD_Keypad.c,171 :: 		if(row != 255) {
CMP	R0, #255
IT	EQ
BEQ	L_Keypad_GetKey30
;DS1337_RTC_LCD_Keypad.c,172 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;DS1337_RTC_LCD_Keypad.c,173 :: 		return keymap[row][col];
LSLS	R1, R2, #2
; row end address is: 8 (R2)
MOVW	R0, #lo_addr(_keymap+0)
MOVT	R0, #hi_addr(_keymap+0)
ADDS	R0, R0, R1
ADDS	R0, R0, R3
; col end address is: 12 (R3)
LDRB	R0, [R0, #0]
IT	AL
BAL	L_end_Keypad_GetKey
;DS1337_RTC_LCD_Keypad.c,174 :: 		}
L_Keypad_GetKey30:
;DS1337_RTC_LCD_Keypad.c,166 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
ADDS	R3, R3, #1
UXTB	R3, R3
;DS1337_RTC_LCD_Keypad.c,175 :: 		}
; col end address is: 12 (R3)
IT	AL
BAL	L_Keypad_GetKey25
L_Keypad_GetKey26:
;DS1337_RTC_LCD_Keypad.c,177 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;DS1337_RTC_LCD_Keypad.c,178 :: 		return 0;
MOVS	R0, #0
;DS1337_RTC_LCD_Keypad.c,179 :: 		}
L_end_Keypad_GetKey:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_GetKey
_Keypad_GetKey_Click:
;DS1337_RTC_LCD_Keypad.c,181 :: 		char Keypad_GetKey_Click() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;DS1337_RTC_LCD_Keypad.c,184 :: 		while(1) {
L_Keypad_GetKey_Click31:
;DS1337_RTC_LCD_Keypad.c,185 :: 		key = Keypad_GetKey();
BL	_Keypad_GetKey+0
; key start address is: 16 (R4)
UXTB	R4, R0
;DS1337_RTC_LCD_Keypad.c,187 :: 		if(key != 0) {
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_GetKey_Click33
;DS1337_RTC_LCD_Keypad.c,188 :: 		Delay_ms(20);            // debounce
MOVW	R7, #28926
MOVT	R7, #2
NOP
NOP
L_Keypad_GetKey_Click34:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click34
NOP
NOP
NOP
;DS1337_RTC_LCD_Keypad.c,190 :: 		if(Keypad_GetKey() == key) {
BL	_Keypad_GetKey+0
CMP	R0, R4
IT	NE
BNE	L_Keypad_GetKey_Click36
; key end address is: 16 (R4)
;DS1337_RTC_LCD_Keypad.c,191 :: 		while(Keypad_GetKey() != 0) {
L_Keypad_GetKey_Click37:
; key start address is: 16 (R4)
BL	_Keypad_GetKey+0
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_GetKey_Click38
;DS1337_RTC_LCD_Keypad.c,192 :: 		Delay_ms(10);        // wait until release
MOVW	R7, #14462
MOVT	R7, #1
NOP
NOP
L_Keypad_GetKey_Click39:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click39
NOP
NOP
NOP
;DS1337_RTC_LCD_Keypad.c,193 :: 		}
IT	AL
BAL	L_Keypad_GetKey_Click37
L_Keypad_GetKey_Click38:
;DS1337_RTC_LCD_Keypad.c,194 :: 		Delay_ms(20);
MOVW	R7, #28926
MOVT	R7, #2
NOP
NOP
L_Keypad_GetKey_Click41:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click41
NOP
NOP
NOP
;DS1337_RTC_LCD_Keypad.c,195 :: 		return key;
UXTB	R0, R4
; key end address is: 16 (R4)
IT	AL
BAL	L_end_Keypad_GetKey_Click
;DS1337_RTC_LCD_Keypad.c,196 :: 		}
L_Keypad_GetKey_Click36:
;DS1337_RTC_LCD_Keypad.c,197 :: 		}
L_Keypad_GetKey_Click33:
;DS1337_RTC_LCD_Keypad.c,198 :: 		}
IT	AL
BAL	L_Keypad_GetKey_Click31
;DS1337_RTC_LCD_Keypad.c,199 :: 		}
L_end_Keypad_GetKey_Click:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_GetKey_Click
_I2C1_HW_Init:
;DS1337_RTC_LCD_Keypad.c,204 :: 		void I2C1_HW_Init() {
SUB	SP, SP, #4
;DS1337_RTC_LCD_Keypad.c,205 :: 		RCC_AHB1ENR |= 0x00000002;      // GPIOB clock enable
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,206 :: 		RCC_APB1ENR |= 0x00200000;      // I2C1 clock enable
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2097152
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,209 :: 		GPIOB_AFRH &= ~0x000000FF;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
AND	R1, R0, #0
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,210 :: 		GPIOB_AFRH |=  0x00000044;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #68
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,213 :: 		GPIOB_MODER &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,214 :: 		GPIOB_MODER |=  0x000A0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #655360
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,217 :: 		GPIOB_OTYPER |= 0x00000300;
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #768
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,220 :: 		GPIOB_PUPDR &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,221 :: 		GPIOB_PUPDR |=  0x00050000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #327680
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,224 :: 		I2C1_CR1 = 0x8000;
MOVW	R1, #32768
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,225 :: 		I2C1_CR1 &= ~0x8000;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R1, [R0, #0]
MOVW	R0, #32767
ANDS	R1, R0
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,228 :: 		I2C1_CR2 = 16;
MOVS	R1, #16
MOVW	R0, #lo_addr(I2C1_CR2+0)
MOVT	R0, #hi_addr(I2C1_CR2+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,231 :: 		I2C1_CCR = 80;
MOVS	R1, #80
MOVW	R0, #lo_addr(I2C1_CCR+0)
MOVT	R0, #hi_addr(I2C1_CCR+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,234 :: 		I2C1_TRISE = 17;
MOVS	R1, #17
MOVW	R0, #lo_addr(I2C1_TRISE+0)
MOVT	R0, #hi_addr(I2C1_TRISE+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,237 :: 		I2C1_CR1 |= 0x0001;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,238 :: 		}
L_end_I2C1_HW_Init:
ADD	SP, SP, #4
BX	LR
; end of _I2C1_HW_Init
_I2C1_WriteByte_Reg:
;DS1337_RTC_LCD_Keypad.c,242 :: 		unsigned short value) {
; reg_addr start address is: 4 (R1)
SUB	SP, SP, #12
STRB	R0, [SP, #4]
STRB	R2, [SP, #8]
; reg_addr end address is: 4 (R1)
; reg_addr start address is: 4 (R1)
; reg_addr end address is: 4 (R1)
;DS1337_RTC_LCD_Keypad.c,245 :: 		while(I2C1_SR2 & 2);            // wait while bus busy
L_I2C1_WriteByte_Reg43:
; reg_addr start address is: 4 (R1)
MOVW	R3, #lo_addr(I2C1_SR2+0)
MOVT	R3, #hi_addr(I2C1_SR2+0)
LDR	R3, [R3, #0]
AND	R3, R3, #2
CMP	R3, #0
IT	EQ
BEQ	L_I2C1_WriteByte_Reg44
IT	AL
BAL	L_I2C1_WriteByte_Reg43
L_I2C1_WriteByte_Reg44:
;DS1337_RTC_LCD_Keypad.c,247 :: 		I2C1_CR1 |= 0x0100;             // START
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #256
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
; reg_addr end address is: 4 (R1)
;DS1337_RTC_LCD_Keypad.c,248 :: 		while(!(I2C1_SR1 & 1));
L_I2C1_WriteByte_Reg45:
; reg_addr start address is: 4 (R1)
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #1
CMP	R3, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg46
IT	AL
BAL	L_I2C1_WriteByte_Reg45
L_I2C1_WriteByte_Reg46:
;DS1337_RTC_LCD_Keypad.c,250 :: 		I2C1_DR = saddr << 1;           // address + write
LDRB	R3, [SP, #4]
LSLS	R4, R3, #1
UXTH	R4, R4
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R4, [R3, #0]
; reg_addr end address is: 4 (R1)
;DS1337_RTC_LCD_Keypad.c,251 :: 		while(!(I2C1_SR1 & 2));
L_I2C1_WriteByte_Reg47:
; reg_addr start address is: 4 (R1)
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #2
CMP	R3, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg48
IT	AL
BAL	L_I2C1_WriteByte_Reg47
L_I2C1_WriteByte_Reg48:
;DS1337_RTC_LCD_Keypad.c,252 :: 		tmp = I2C1_SR2;                 // clear ADDR
MOVW	R3, #lo_addr(I2C1_SR2+0)
MOVT	R3, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R3, #0]
; reg_addr end address is: 4 (R1)
; tmp end address is: 0 (R0)
UXTB	R0, R1
;DS1337_RTC_LCD_Keypad.c,254 :: 		while(!(I2C1_SR1 & 0x80));
L_I2C1_WriteByte_Reg49:
; reg_addr start address is: 0 (R0)
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #128
CMP	R3, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg50
IT	AL
BAL	L_I2C1_WriteByte_Reg49
L_I2C1_WriteByte_Reg50:
;DS1337_RTC_LCD_Keypad.c,255 :: 		I2C1_DR = reg_addr;             // register
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R0, [R3, #0]
; reg_addr end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,256 :: 		while(!(I2C1_SR1 & 0x80));
L_I2C1_WriteByte_Reg51:
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #128
CMP	R3, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg52
IT	AL
BAL	L_I2C1_WriteByte_Reg51
L_I2C1_WriteByte_Reg52:
;DS1337_RTC_LCD_Keypad.c,257 :: 		I2C1_DR = value;                // data
LDRB	R4, [SP, #8]
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R4, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,258 :: 		while(!(I2C1_SR1 & 0x80));
L_I2C1_WriteByte_Reg53:
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #128
CMP	R3, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg54
IT	AL
BAL	L_I2C1_WriteByte_Reg53
L_I2C1_WriteByte_Reg54:
;DS1337_RTC_LCD_Keypad.c,260 :: 		I2C1_CR1 |= 0x0200;             // STOP
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #512
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,261 :: 		}
L_end_I2C1_WriteByte_Reg:
ADD	SP, SP, #12
BX	LR
; end of _I2C1_WriteByte_Reg
_I2C1_BurstWrite:
;DS1337_RTC_LCD_Keypad.c,266 :: 		unsigned short data_buf[]) {
SUB	SP, SP, #20
STRB	R0, [SP, #4]
STRB	R1, [SP, #8]
STRB	R2, [SP, #12]
STR	R3, [SP, #16]
;DS1337_RTC_LCD_Keypad.c,270 :: 		while(I2C1_SR2 & 2);
L_I2C1_BurstWrite55:
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	EQ
BEQ	L_I2C1_BurstWrite56
IT	AL
BAL	L_I2C1_BurstWrite55
L_I2C1_BurstWrite56:
;DS1337_RTC_LCD_Keypad.c,272 :: 		I2C1_CR1 |= 0x0100;             // START
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #256
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,273 :: 		while(!(I2C1_SR1 & 1));
L_I2C1_BurstWrite57:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstWrite58
IT	AL
BAL	L_I2C1_BurstWrite57
L_I2C1_BurstWrite58:
;DS1337_RTC_LCD_Keypad.c,275 :: 		I2C1_DR = saddr << 1;           // address + write
LDRB	R4, [SP, #4]
LSLS	R5, R4, #1
UXTH	R5, R5
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,276 :: 		while(!(I2C1_SR1 & 2));
L_I2C1_BurstWrite59:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstWrite60
IT	AL
BAL	L_I2C1_BurstWrite59
L_I2C1_BurstWrite60:
;DS1337_RTC_LCD_Keypad.c,277 :: 		tmp = I2C1_SR2;                 // clear ADDR
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R4, #0]
; tmp end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,279 :: 		while(!(I2C1_SR1 & 0x80));
L_I2C1_BurstWrite61:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #128
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstWrite62
IT	AL
BAL	L_I2C1_BurstWrite61
L_I2C1_BurstWrite62:
;DS1337_RTC_LCD_Keypad.c,280 :: 		I2C1_DR = start_reg;            // first register
LDRB	R5, [SP, #8]
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,282 :: 		for(i = 0; i < count; i++) {
; i start address is: 0 (R0)
MOVS	R0, #0
; i end address is: 0 (R0)
L_I2C1_BurstWrite63:
; i start address is: 0 (R0)
LDRB	R4, [SP, #12]
CMP	R0, R4
IT	CS
BCS	L_I2C1_BurstWrite64
; i end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,283 :: 		while(!(I2C1_SR1 & 0x80));
L_I2C1_BurstWrite66:
; i start address is: 0 (R0)
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #128
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstWrite67
IT	AL
BAL	L_I2C1_BurstWrite66
L_I2C1_BurstWrite67:
;DS1337_RTC_LCD_Keypad.c,284 :: 		I2C1_DR = data_buf[i];
LDR	R4, [SP, #16]
ADDS	R4, R4, R0
LDRB	R5, [R4, #0]
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,282 :: 		for(i = 0; i < count; i++) {
ADDS	R0, R0, #1
UXTB	R0, R0
;DS1337_RTC_LCD_Keypad.c,285 :: 		}
; i end address is: 0 (R0)
IT	AL
BAL	L_I2C1_BurstWrite63
L_I2C1_BurstWrite64:
;DS1337_RTC_LCD_Keypad.c,287 :: 		while(!(I2C1_SR1 & 0x80));
L_I2C1_BurstWrite68:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #128
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstWrite69
IT	AL
BAL	L_I2C1_BurstWrite68
L_I2C1_BurstWrite69:
;DS1337_RTC_LCD_Keypad.c,288 :: 		I2C1_CR1 |= 0x0200;             // STOP
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,289 :: 		}
L_end_I2C1_BurstWrite:
ADD	SP, SP, #20
BX	LR
; end of _I2C1_BurstWrite
_I2C1_BurstRead:
;DS1337_RTC_LCD_Keypad.c,294 :: 		unsigned short data_buf[]) {
SUB	SP, SP, #20
STRB	R0, [SP, #4]
STRB	R1, [SP, #8]
STRB	R2, [SP, #12]
STR	R3, [SP, #16]
;DS1337_RTC_LCD_Keypad.c,298 :: 		while(I2C1_SR2 & 2);            // wait while bus busy
L_I2C1_BurstRead70:
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	EQ
BEQ	L_I2C1_BurstRead71
IT	AL
BAL	L_I2C1_BurstRead70
L_I2C1_BurstRead71:
;DS1337_RTC_LCD_Keypad.c,300 :: 		I2C1_CR1 &= ~0x0800;            // disable POS
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #2048
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,301 :: 		I2C1_CR1 |=  0x0100;            // START
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #256
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,302 :: 		while(!(I2C1_SR1 & 1));         // SB
L_I2C1_BurstRead72:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead73
IT	AL
BAL	L_I2C1_BurstRead72
L_I2C1_BurstRead73:
;DS1337_RTC_LCD_Keypad.c,304 :: 		I2C1_DR = saddr << 1;           // address + write
LDRB	R4, [SP, #4]
LSLS	R5, R4, #1
UXTH	R5, R5
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,305 :: 		while(!(I2C1_SR1 & 2));         // ADDR
L_I2C1_BurstRead74:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead75
IT	AL
BAL	L_I2C1_BurstRead74
L_I2C1_BurstRead75:
;DS1337_RTC_LCD_Keypad.c,306 :: 		tmp = I2C1_SR2;                 // clear ADDR
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R4, #0]
; tmp end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,308 :: 		while(!(I2C1_SR1 & 0x80));      // TXE
L_I2C1_BurstRead76:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #128
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead77
IT	AL
BAL	L_I2C1_BurstRead76
L_I2C1_BurstRead77:
;DS1337_RTC_LCD_Keypad.c,309 :: 		I2C1_DR = start_reg;            // register address
LDRB	R5, [SP, #8]
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,310 :: 		while(!(I2C1_SR1 & 0x80));      // TXE
L_I2C1_BurstRead78:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #128
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead79
IT	AL
BAL	L_I2C1_BurstRead78
L_I2C1_BurstRead79:
;DS1337_RTC_LCD_Keypad.c,312 :: 		I2C1_CR1 |= 0x0100;             // repeated START
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #256
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,313 :: 		while(!(I2C1_SR1 & 1));         // SB
L_I2C1_BurstRead80:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead81
IT	AL
BAL	L_I2C1_BurstRead80
L_I2C1_BurstRead81:
;DS1337_RTC_LCD_Keypad.c,315 :: 		I2C1_DR = (saddr << 1) | 1;     // address + read
LDRB	R4, [SP, #4]
LSLS	R4, R4, #1
UXTH	R4, R4
ORR	R5, R4, #1
UXTH	R5, R5
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,316 :: 		while(!(I2C1_SR1 & 2));         // ADDR
L_I2C1_BurstRead82:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead83
IT	AL
BAL	L_I2C1_BurstRead82
L_I2C1_BurstRead83:
;DS1337_RTC_LCD_Keypad.c,317 :: 		tmp = I2C1_SR2;                 // clear ADDR
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R4, #0]
; tmp end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,319 :: 		I2C1_CR1 |= 0x0400;             // ACK enable
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #1024
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,321 :: 		for(i = 0; i < count; i++) {
; i start address is: 0 (R0)
MOVS	R0, #0
; i end address is: 0 (R0)
L_I2C1_BurstRead84:
; i start address is: 0 (R0)
LDRB	R4, [SP, #12]
CMP	R0, R4
IT	CS
BCS	L_I2C1_BurstRead85
;DS1337_RTC_LCD_Keypad.c,322 :: 		if(i == (count - 1)) {
LDRB	R4, [SP, #12]
SUBS	R4, R4, #1
SXTH	R4, R4
CMP	R0, R4
IT	NE
BNE	L_I2C1_BurstRead87
;DS1337_RTC_LCD_Keypad.c,323 :: 		I2C1_CR1 &= ~0x0400;        // ACK disable
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #1024
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,324 :: 		I2C1_CR1 |=  0x0200;        // STOP
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,325 :: 		}
L_I2C1_BurstRead87:
;DS1337_RTC_LCD_Keypad.c,327 :: 		while(!(I2C1_SR1 & 0x40));    // RXNE
L_I2C1_BurstRead88:
; i end address is: 0 (R0)
; i start address is: 0 (R0)
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #64
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead89
IT	AL
BAL	L_I2C1_BurstRead88
L_I2C1_BurstRead89:
;DS1337_RTC_LCD_Keypad.c,328 :: 		data_buf[i] = I2C1_DR;
LDR	R4, [SP, #16]
ADDS	R5, R4, R0
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
LDR	R4, [R4, #0]
STRB	R4, [R5, #0]
;DS1337_RTC_LCD_Keypad.c,321 :: 		for(i = 0; i < count; i++) {
ADDS	R0, R0, #1
UXTB	R0, R0
;DS1337_RTC_LCD_Keypad.c,329 :: 		}
; i end address is: 0 (R0)
IT	AL
BAL	L_I2C1_BurstRead84
L_I2C1_BurstRead85:
;DS1337_RTC_LCD_Keypad.c,330 :: 		}
L_end_I2C1_BurstRead:
ADD	SP, SP, #20
BX	LR
; end of _I2C1_BurstRead
_DS1337_Init:
;DS1337_RTC_LCD_Keypad.c,335 :: 		void DS1337_Init() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;DS1337_RTC_LCD_Keypad.c,337 :: 		I2C1_WriteByte_Reg(DS1337_ADDR, 0x0E, 0x00);
MOVS	R2, #0
MOVS	R1, #14
MOVS	R0, #104
BL	_I2C1_WriteByte_Reg+0
;DS1337_RTC_LCD_Keypad.c,340 :: 		I2C1_WriteByte_Reg(DS1337_ADDR, 0x0F, 0x00);
MOVS	R2, #0
MOVS	R1, #15
MOVS	R0, #104
BL	_I2C1_WriteByte_Reg+0
;DS1337_RTC_LCD_Keypad.c,341 :: 		}
L_end_DS1337_Init:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _DS1337_Init
_DS1337_SetDateTime:
;DS1337_RTC_LCD_Keypad.c,348 :: 		unsigned short second) {
; hour start address is: 12 (R3)
; year start address is: 8 (R2)
; month start address is: 4 (R1)
; day start address is: 0 (R0)
SUB	SP, SP, #16
STR	LR, [SP, #0]
UXTB	R7, R0
UXTB	R8, R1
UXTB	R9, R2
UXTB	R5, R3
; hour end address is: 12 (R3)
; year end address is: 8 (R2)
; month end address is: 4 (R1)
; day end address is: 0 (R0)
; day start address is: 28 (R7)
; month start address is: 32 (R8)
; year start address is: 36 (R9)
; hour start address is: 20 (R5)
; minute start address is: 24 (R6)
LDRB	R6, [SP, #16]
; second start address is: 0 (R0)
LDRB	R0, [SP, #20]
;DS1337_RTC_LCD_Keypad.c,351 :: 		wr[0] = DecToBcd(second);
ADD	R4, SP, #4
STR	R4, [SP, #12]
; second end address is: 0 (R0)
BL	_DecToBcd+0
LDR	R4, [SP, #12]
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,352 :: 		wr[1] = DecToBcd(minute);
ADD	R4, SP, #4
ADDS	R4, R4, #1
STR	R4, [SP, #12]
UXTB	R0, R6
; minute end address is: 24 (R6)
BL	_DecToBcd+0
LDR	R4, [SP, #12]
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,353 :: 		wr[2] = DecToBcd(hour);
ADD	R4, SP, #4
ADDS	R4, R4, #2
STR	R4, [SP, #12]
UXTB	R0, R5
; hour end address is: 20 (R5)
BL	_DecToBcd+0
LDR	R4, [SP, #12]
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,354 :: 		wr[3] = 0x01;                 // day of week
ADD	R6, SP, #4
ADDS	R5, R6, #3
MOVS	R4, #1
STRB	R4, [R5, #0]
;DS1337_RTC_LCD_Keypad.c,355 :: 		wr[4] = DecToBcd(day);
ADDS	R4, R6, #4
STR	R4, [SP, #12]
UXTB	R0, R7
; day end address is: 28 (R7)
BL	_DecToBcd+0
LDR	R4, [SP, #12]
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,356 :: 		wr[5] = DecToBcd(month);
ADD	R4, SP, #4
ADDS	R4, R4, #5
STR	R4, [SP, #12]
UXTB	R0, R8
; month end address is: 32 (R8)
BL	_DecToBcd+0
LDR	R4, [SP, #12]
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,357 :: 		wr[6] = DecToBcd(year);
ADD	R4, SP, #4
ADDS	R4, R4, #6
STR	R4, [SP, #12]
UXTB	R0, R9
; year end address is: 36 (R9)
BL	_DecToBcd+0
LDR	R4, [SP, #12]
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,359 :: 		I2C1_BurstWrite(DS1337_ADDR, 0x00, 7, wr);
ADD	R4, SP, #4
MOV	R3, R4
MOVS	R2, #7
MOVS	R1, #0
MOVS	R0, #104
BL	_I2C1_BurstWrite+0
;DS1337_RTC_LCD_Keypad.c,360 :: 		}
L_end_DS1337_SetDateTime:
LDR	LR, [SP, #0]
ADD	SP, SP, #16
BX	LR
; end of _DS1337_SetDateTime
_DS1337_GetDateTime:
;DS1337_RTC_LCD_Keypad.c,367 :: 		unsigned short *second) {
; hour start address is: 12 (R3)
; year start address is: 8 (R2)
; month start address is: 4 (R1)
; day start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
MOV	R8, R3
MOV	R3, R0
MOV	R6, R1
MOV	R7, R2
; hour end address is: 12 (R3)
; year end address is: 8 (R2)
; month end address is: 4 (R1)
; day end address is: 0 (R0)
; day start address is: 12 (R3)
; month start address is: 24 (R6)
; year start address is: 28 (R7)
; hour start address is: 32 (R8)
; minute start address is: 36 (R9)
LDR	R9, [SP, #8]
; second start address is: 40 (R10)
LDR	R10, [SP, #12]
;DS1337_RTC_LCD_Keypad.c,368 :: 		I2C1_BurstRead(DS1337_ADDR, 0x00, 7, rtc_buf);
STR	R3, [SP, #4]
MOVW	R3, #lo_addr(_rtc_buf+0)
MOVT	R3, #hi_addr(_rtc_buf+0)
MOVS	R2, #7
MOVS	R1, #0
MOVS	R0, #104
BL	_I2C1_BurstRead+0
LDR	R3, [SP, #4]
;DS1337_RTC_LCD_Keypad.c,370 :: 		*second = BcdToDec(rtc_buf[0] & 0x7F);
MOVW	R4, #lo_addr(_rtc_buf+0)
MOVT	R4, #hi_addr(_rtc_buf+0)
LDRB	R4, [R4, #0]
AND	R4, R4, #127
UXTB	R0, R4
BL	_BcdToDec+0
STRB	R0, [R10, #0]
; second end address is: 40 (R10)
;DS1337_RTC_LCD_Keypad.c,371 :: 		*minute = BcdToDec(rtc_buf[1] & 0x7F);
MOVW	R4, #lo_addr(_rtc_buf+1)
MOVT	R4, #hi_addr(_rtc_buf+1)
LDRB	R4, [R4, #0]
AND	R4, R4, #127
UXTB	R0, R4
BL	_BcdToDec+0
STRB	R0, [R9, #0]
; minute end address is: 36 (R9)
;DS1337_RTC_LCD_Keypad.c,372 :: 		*hour   = BcdToDec(rtc_buf[2] & 0x3F);
MOVW	R4, #lo_addr(_rtc_buf+2)
MOVT	R4, #hi_addr(_rtc_buf+2)
LDRB	R4, [R4, #0]
AND	R4, R4, #63
UXTB	R0, R4
BL	_BcdToDec+0
STRB	R0, [R8, #0]
; hour end address is: 32 (R8)
;DS1337_RTC_LCD_Keypad.c,373 :: 		*day    = BcdToDec(rtc_buf[4] & 0x3F);
MOVW	R4, #lo_addr(_rtc_buf+4)
MOVT	R4, #hi_addr(_rtc_buf+4)
LDRB	R4, [R4, #0]
AND	R4, R4, #63
UXTB	R0, R4
BL	_BcdToDec+0
STRB	R0, [R3, #0]
; day end address is: 12 (R3)
;DS1337_RTC_LCD_Keypad.c,374 :: 		*month  = BcdToDec(rtc_buf[5] & 0x1F);
MOVW	R4, #lo_addr(_rtc_buf+5)
MOVT	R4, #hi_addr(_rtc_buf+5)
LDRB	R4, [R4, #0]
AND	R4, R4, #31
UXTB	R0, R4
BL	_BcdToDec+0
STRB	R0, [R6, #0]
; month end address is: 24 (R6)
;DS1337_RTC_LCD_Keypad.c,375 :: 		*year   = BcdToDec(rtc_buf[6]);
MOVW	R4, #lo_addr(_rtc_buf+6)
MOVT	R4, #hi_addr(_rtc_buf+6)
LDRB	R4, [R4, #0]
UXTB	R0, R4
BL	_BcdToDec+0
STRB	R0, [R7, #0]
; year end address is: 28 (R7)
;DS1337_RTC_LCD_Keypad.c,376 :: 		}
L_end_DS1337_GetDateTime:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _DS1337_GetDateTime
_ShowMainMenu:
;DS1337_RTC_LCD_Keypad.c,381 :: 		void ShowMainMenu() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;DS1337_RTC_LCD_Keypad.c,382 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,383 :: 		Lcd_Out(1, 1, "A:Adjust D:Show");
MOVW	R0, #lo_addr(?lstr1_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr1_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,384 :: 		Lcd_Out(2, 1, "Select option");
MOVW	R0, #lo_addr(?lstr2_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr2_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,385 :: 		}
L_end_ShowMainMenu:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _ShowMainMenu
_BuildAdjustScreen:
;DS1337_RTC_LCD_Keypad.c,387 :: 		void BuildAdjustScreen() {
SUB	SP, SP, #40
STR	LR, [SP, #0]
;DS1337_RTC_LCD_Keypad.c,392 :: 		for(i = 0; i < 16; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
L_BuildAdjustScreen90:
; i start address is: 8 (R2)
CMP	R2, #16
IT	CS
BCS	L_BuildAdjustScreen91
;DS1337_RTC_LCD_Keypad.c,393 :: 		line1[i] = ' ';
ADD	R0, SP, #4
ADDS	R1, R0, R2
MOVS	R0, #32
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,394 :: 		line2[i] = ' ';
ADD	R0, SP, #21
ADDS	R1, R0, R2
MOVS	R0, #32
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,392 :: 		for(i = 0; i < 16; i++) {
ADDS	R2, R2, #1
UXTB	R2, R2
;DS1337_RTC_LCD_Keypad.c,395 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_BuildAdjustScreen90
L_BuildAdjustScreen91:
;DS1337_RTC_LCD_Keypad.c,396 :: 		line1[16] = 0;
ADD	R2, SP, #4
ADDW	R1, R2, #16
MOVS	R0, #0
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,397 :: 		line2[16] = 0;
ADD	R0, SP, #21
ADDW	R1, R0, #16
MOVS	R0, #0
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,400 :: 		line1[0] = 'D';
MOVS	R0, #68
STRB	R0, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,401 :: 		line1[1] = ':';
ADDS	R1, R2, #1
MOVS	R0, #58
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,402 :: 		line1[2] = rtc_digits[0]  ? rtc_digits[0]  : '_';
ADDS	R1, R2, #2
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen93
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
; ?FLOC___BuildAdjustScreen?T212 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T212 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen94
L_BuildAdjustScreen93:
; ?FLOC___BuildAdjustScreen?T212 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T212 end address is: 0 (R0)
L_BuildAdjustScreen94:
; ?FLOC___BuildAdjustScreen?T212 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T212 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,403 :: 		line1[3] = rtc_digits[1]  ? rtc_digits[1]  : '_';
ADD	R0, SP, #4
ADDS	R1, R0, #3
MOVW	R0, #lo_addr(_rtc_digits+1)
MOVT	R0, #hi_addr(_rtc_digits+1)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen95
MOVW	R0, #lo_addr(_rtc_digits+1)
MOVT	R0, #hi_addr(_rtc_digits+1)
; ?FLOC___BuildAdjustScreen?T218 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T218 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen96
L_BuildAdjustScreen95:
; ?FLOC___BuildAdjustScreen?T218 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T218 end address is: 0 (R0)
L_BuildAdjustScreen96:
; ?FLOC___BuildAdjustScreen?T218 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T218 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,404 :: 		line1[4] = '/';
ADD	R2, SP, #4
ADDS	R1, R2, #4
MOVS	R0, #47
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,405 :: 		line1[5] = rtc_digits[2]  ? rtc_digits[2]  : '_';
ADDS	R1, R2, #5
MOVW	R0, #lo_addr(_rtc_digits+2)
MOVT	R0, #hi_addr(_rtc_digits+2)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen97
MOVW	R0, #lo_addr(_rtc_digits+2)
MOVT	R0, #hi_addr(_rtc_digits+2)
; ?FLOC___BuildAdjustScreen?T227 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T227 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen98
L_BuildAdjustScreen97:
; ?FLOC___BuildAdjustScreen?T227 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T227 end address is: 0 (R0)
L_BuildAdjustScreen98:
; ?FLOC___BuildAdjustScreen?T227 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T227 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,406 :: 		line1[6] = rtc_digits[3]  ? rtc_digits[3]  : '_';
ADD	R0, SP, #4
ADDS	R1, R0, #6
MOVW	R0, #lo_addr(_rtc_digits+3)
MOVT	R0, #hi_addr(_rtc_digits+3)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen99
MOVW	R0, #lo_addr(_rtc_digits+3)
MOVT	R0, #hi_addr(_rtc_digits+3)
; ?FLOC___BuildAdjustScreen?T233 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T233 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen100
L_BuildAdjustScreen99:
; ?FLOC___BuildAdjustScreen?T233 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T233 end address is: 0 (R0)
L_BuildAdjustScreen100:
; ?FLOC___BuildAdjustScreen?T233 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T233 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,407 :: 		line1[7] = '/';
ADD	R2, SP, #4
ADDS	R1, R2, #7
MOVS	R0, #47
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,408 :: 		line1[8] = rtc_digits[4]  ? rtc_digits[4]  : '_';
ADDW	R1, R2, #8
MOVW	R0, #lo_addr(_rtc_digits+4)
MOVT	R0, #hi_addr(_rtc_digits+4)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen101
MOVW	R0, #lo_addr(_rtc_digits+4)
MOVT	R0, #hi_addr(_rtc_digits+4)
; ?FLOC___BuildAdjustScreen?T242 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T242 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen102
L_BuildAdjustScreen101:
; ?FLOC___BuildAdjustScreen?T242 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T242 end address is: 0 (R0)
L_BuildAdjustScreen102:
; ?FLOC___BuildAdjustScreen?T242 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T242 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,409 :: 		line1[9] = rtc_digits[5]  ? rtc_digits[5]  : '_';
ADD	R0, SP, #4
ADDW	R1, R0, #9
MOVW	R0, #lo_addr(_rtc_digits+5)
MOVT	R0, #hi_addr(_rtc_digits+5)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen103
MOVW	R0, #lo_addr(_rtc_digits+5)
MOVT	R0, #hi_addr(_rtc_digits+5)
; ?FLOC___BuildAdjustScreen?T248 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T248 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen104
L_BuildAdjustScreen103:
; ?FLOC___BuildAdjustScreen?T248 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T248 end address is: 0 (R0)
L_BuildAdjustScreen104:
; ?FLOC___BuildAdjustScreen?T248 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T248 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,412 :: 		line2[0] = 'T';
ADD	R2, SP, #21
MOVS	R0, #84
STRB	R0, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,413 :: 		line2[1] = ':';
ADDS	R1, R2, #1
MOVS	R0, #58
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,414 :: 		line2[2] = rtc_digits[6]  ? rtc_digits[6]  : '_';
ADDS	R1, R2, #2
MOVW	R0, #lo_addr(_rtc_digits+6)
MOVT	R0, #hi_addr(_rtc_digits+6)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen105
MOVW	R0, #lo_addr(_rtc_digits+6)
MOVT	R0, #hi_addr(_rtc_digits+6)
; ?FLOC___BuildAdjustScreen?T260 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T260 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen106
L_BuildAdjustScreen105:
; ?FLOC___BuildAdjustScreen?T260 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T260 end address is: 0 (R0)
L_BuildAdjustScreen106:
; ?FLOC___BuildAdjustScreen?T260 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T260 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,415 :: 		line2[3] = rtc_digits[7]  ? rtc_digits[7]  : '_';
ADD	R0, SP, #21
ADDS	R1, R0, #3
MOVW	R0, #lo_addr(_rtc_digits+7)
MOVT	R0, #hi_addr(_rtc_digits+7)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen107
MOVW	R0, #lo_addr(_rtc_digits+7)
MOVT	R0, #hi_addr(_rtc_digits+7)
; ?FLOC___BuildAdjustScreen?T266 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T266 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen108
L_BuildAdjustScreen107:
; ?FLOC___BuildAdjustScreen?T266 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T266 end address is: 0 (R0)
L_BuildAdjustScreen108:
; ?FLOC___BuildAdjustScreen?T266 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T266 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,416 :: 		line2[4] = ':';
ADD	R2, SP, #21
ADDS	R1, R2, #4
MOVS	R0, #58
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,417 :: 		line2[5] = rtc_digits[8]  ? rtc_digits[8]  : '_';
ADDS	R1, R2, #5
MOVW	R0, #lo_addr(_rtc_digits+8)
MOVT	R0, #hi_addr(_rtc_digits+8)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen109
MOVW	R0, #lo_addr(_rtc_digits+8)
MOVT	R0, #hi_addr(_rtc_digits+8)
; ?FLOC___BuildAdjustScreen?T275 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T275 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen110
L_BuildAdjustScreen109:
; ?FLOC___BuildAdjustScreen?T275 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T275 end address is: 0 (R0)
L_BuildAdjustScreen110:
; ?FLOC___BuildAdjustScreen?T275 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T275 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,418 :: 		line2[6] = rtc_digits[9]  ? rtc_digits[9]  : '_';
ADD	R0, SP, #21
ADDS	R1, R0, #6
MOVW	R0, #lo_addr(_rtc_digits+9)
MOVT	R0, #hi_addr(_rtc_digits+9)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen111
MOVW	R0, #lo_addr(_rtc_digits+9)
MOVT	R0, #hi_addr(_rtc_digits+9)
; ?FLOC___BuildAdjustScreen?T281 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T281 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen112
L_BuildAdjustScreen111:
; ?FLOC___BuildAdjustScreen?T281 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T281 end address is: 0 (R0)
L_BuildAdjustScreen112:
; ?FLOC___BuildAdjustScreen?T281 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T281 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,419 :: 		line2[7] = ':';
ADD	R2, SP, #21
ADDS	R1, R2, #7
MOVS	R0, #58
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,420 :: 		line2[8] = rtc_digits[10] ? rtc_digits[10] : '_';
ADDW	R1, R2, #8
MOVW	R0, #lo_addr(_rtc_digits+10)
MOVT	R0, #hi_addr(_rtc_digits+10)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen113
MOVW	R0, #lo_addr(_rtc_digits+10)
MOVT	R0, #hi_addr(_rtc_digits+10)
; ?FLOC___BuildAdjustScreen?T290 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T290 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen114
L_BuildAdjustScreen113:
; ?FLOC___BuildAdjustScreen?T290 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T290 end address is: 0 (R0)
L_BuildAdjustScreen114:
; ?FLOC___BuildAdjustScreen?T290 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T290 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,421 :: 		line2[9] = rtc_digits[11] ? rtc_digits[11] : '_';
ADD	R0, SP, #21
ADDW	R1, R0, #9
MOVW	R0, #lo_addr(_rtc_digits+11)
MOVT	R0, #hi_addr(_rtc_digits+11)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen115
MOVW	R0, #lo_addr(_rtc_digits+11)
MOVT	R0, #hi_addr(_rtc_digits+11)
; ?FLOC___BuildAdjustScreen?T296 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T296 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen116
L_BuildAdjustScreen115:
; ?FLOC___BuildAdjustScreen?T296 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T296 end address is: 0 (R0)
L_BuildAdjustScreen116:
; ?FLOC___BuildAdjustScreen?T296 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T296 end address is: 0 (R0)
;DS1337_RTC_LCD_Keypad.c,423 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,424 :: 		Lcd_Out(1, 1, line1);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,425 :: 		Lcd_Out(2, 1, line2);
ADD	R0, SP, #21
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,426 :: 		}
L_end_BuildAdjustScreen:
LDR	LR, [SP, #0]
ADD	SP, SP, #40
BX	LR
; end of _BuildAdjustScreen
_AdjustMode:
;DS1337_RTC_LCD_Keypad.c,428 :: 		void AdjustMode() {
SUB	SP, SP, #8
STR	LR, [SP, #0]
;DS1337_RTC_LCD_Keypad.c,433 :: 		for(i = 0; i < 12; i++) rtc_digits[i] = 0;
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
L_AdjustMode117:
; i start address is: 8 (R2)
CMP	R2, #12
IT	CS
BCS	L_AdjustMode118
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
ADDS	R1, R0, R2
MOVS	R0, #0
STRB	R0, [R1, #0]
ADDS	R2, R2, #1
UXTB	R2, R2
; i end address is: 8 (R2)
IT	AL
BAL	L_AdjustMode117
L_AdjustMode118:
;DS1337_RTC_LCD_Keypad.c,434 :: 		rtc_digits[12] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_rtc_digits+12)
MOVT	R0, #hi_addr(_rtc_digits+12)
STRB	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,435 :: 		rtc_pos = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
STRB	R1, [R0, #0]
;DS1337_RTC_LCD_Keypad.c,437 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;DS1337_RTC_LCD_Keypad.c,439 :: 		while(1) {
L_AdjustMode120:
;DS1337_RTC_LCD_Keypad.c,440 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
STRB	R0, [SP, #4]
;DS1337_RTC_LCD_Keypad.c,442 :: 		if((key >= '0') && (key <= '9')) {
CMP	R0, #48
IT	CC
BCC	L__AdjustMode169
LDRB	R0, [SP, #4]
CMP	R0, #57
IT	HI
BHI	L__AdjustMode168
L__AdjustMode167:
;DS1337_RTC_LCD_Keypad.c,443 :: 		if(rtc_pos < 12) {
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
LDRB	R0, [R0, #0]
CMP	R0, #12
IT	CS
BCS	L_AdjustMode125
;DS1337_RTC_LCD_Keypad.c,444 :: 		rtc_digits[rtc_pos] = key;
MOVW	R2, #lo_addr(_rtc_pos+0)
MOVT	R2, #hi_addr(_rtc_pos+0)
LDRB	R1, [R2, #0]
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
ADDS	R1, R0, R1
LDRB	R0, [SP, #4]
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,445 :: 		rtc_pos++;
MOV	R0, R2
LDRB	R0, [R0, #0]
ADDS	R0, R0, #1
STRB	R0, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,446 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;DS1337_RTC_LCD_Keypad.c,447 :: 		}
L_AdjustMode125:
;DS1337_RTC_LCD_Keypad.c,448 :: 		}
IT	AL
BAL	L_AdjustMode126
;DS1337_RTC_LCD_Keypad.c,442 :: 		if((key >= '0') && (key <= '9')) {
L__AdjustMode169:
L__AdjustMode168:
;DS1337_RTC_LCD_Keypad.c,449 :: 		else if(key == '*') {
LDRB	R0, [SP, #4]
CMP	R0, #42
IT	NE
BNE	L_AdjustMode127
;DS1337_RTC_LCD_Keypad.c,450 :: 		if(rtc_pos > 0) {
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	LS
BLS	L_AdjustMode128
;DS1337_RTC_LCD_Keypad.c,451 :: 		rtc_pos--;
MOVW	R2, #lo_addr(_rtc_pos+0)
MOVT	R2, #hi_addr(_rtc_pos+0)
LDRB	R0, [R2, #0]
SUBS	R1, R0, #1
UXTB	R1, R1
STRB	R1, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,452 :: 		rtc_digits[rtc_pos] = 0;
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
ADDS	R1, R0, R1
MOVS	R0, #0
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,453 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;DS1337_RTC_LCD_Keypad.c,454 :: 		}
L_AdjustMode128:
;DS1337_RTC_LCD_Keypad.c,455 :: 		}
IT	AL
BAL	L_AdjustMode129
L_AdjustMode127:
;DS1337_RTC_LCD_Keypad.c,456 :: 		else if(key == 'B') {
LDRB	R0, [SP, #4]
CMP	R0, #66
IT	NE
BNE	L_AdjustMode130
;DS1337_RTC_LCD_Keypad.c,457 :: 		return;
IT	AL
BAL	L_end_AdjustMode
;DS1337_RTC_LCD_Keypad.c,458 :: 		}
L_AdjustMode130:
;DS1337_RTC_LCD_Keypad.c,459 :: 		else if(key == '#') {
LDRB	R0, [SP, #4]
CMP	R0, #35
IT	NE
BNE	L_AdjustMode132
;DS1337_RTC_LCD_Keypad.c,460 :: 		if(rtc_pos == 12) {
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
LDRB	R0, [R0, #0]
CMP	R0, #12
IT	NE
BNE	L_AdjustMode133
;DS1337_RTC_LCD_Keypad.c,461 :: 		day    = Parse2Digits(rtc_digits[0],  rtc_digits[1]);
MOVW	R0, #lo_addr(_rtc_digits+1)
MOVT	R0, #hi_addr(_rtc_digits+1)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; day start address is: 24 (R6)
UXTB	R6, R0
;DS1337_RTC_LCD_Keypad.c,462 :: 		month  = Parse2Digits(rtc_digits[2],  rtc_digits[3]);
MOVW	R0, #lo_addr(_rtc_digits+3)
MOVT	R0, #hi_addr(_rtc_digits+3)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+2)
MOVT	R0, #hi_addr(_rtc_digits+2)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; month start address is: 28 (R7)
UXTB	R7, R0
;DS1337_RTC_LCD_Keypad.c,463 :: 		year   = Parse2Digits(rtc_digits[4],  rtc_digits[5]);
MOVW	R0, #lo_addr(_rtc_digits+5)
MOVT	R0, #hi_addr(_rtc_digits+5)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+4)
MOVT	R0, #hi_addr(_rtc_digits+4)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; year start address is: 32 (R8)
UXTB	R8, R0
;DS1337_RTC_LCD_Keypad.c,464 :: 		hour   = Parse2Digits(rtc_digits[6],  rtc_digits[7]);
MOVW	R0, #lo_addr(_rtc_digits+7)
MOVT	R0, #hi_addr(_rtc_digits+7)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+6)
MOVT	R0, #hi_addr(_rtc_digits+6)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; hour start address is: 36 (R9)
UXTB	R9, R0
;DS1337_RTC_LCD_Keypad.c,465 :: 		minute = Parse2Digits(rtc_digits[8],  rtc_digits[9]);
MOVW	R0, #lo_addr(_rtc_digits+9)
MOVT	R0, #hi_addr(_rtc_digits+9)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+8)
MOVT	R0, #hi_addr(_rtc_digits+8)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; minute start address is: 40 (R10)
UXTB	R10, R0
;DS1337_RTC_LCD_Keypad.c,466 :: 		second = Parse2Digits(rtc_digits[10], rtc_digits[11]);
MOVW	R0, #lo_addr(_rtc_digits+11)
MOVT	R0, #hi_addr(_rtc_digits+11)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+10)
MOVT	R0, #hi_addr(_rtc_digits+10)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; second start address is: 44 (R11)
UXTB	R11, R0
;DS1337_RTC_LCD_Keypad.c,468 :: 		if(ValidateDateTime(day, month, year, hour, minute, second)) {
UXTB	R1, R0
UXTB	R0, R10
PUSH	(R1)
PUSH	(R0)
UXTB	R3, R9
UXTB	R2, R8
UXTB	R1, R7
UXTB	R0, R6
BL	_ValidateDateTime+0
ADD	SP, SP, #8
CMP	R0, #0
IT	EQ
BEQ	L_AdjustMode134
;DS1337_RTC_LCD_Keypad.c,469 :: 		DS1337_SetDateTime(day, month, year, hour, minute, second);
UXTB	R1, R11
; second end address is: 44 (R11)
UXTB	R0, R10
; minute end address is: 40 (R10)
PUSH	(R1)
; hour end address is: 36 (R9)
PUSH	(R0)
UXTB	R3, R9
UXTB	R2, R8
; year end address is: 32 (R8)
UXTB	R1, R7
; month end address is: 28 (R7)
UXTB	R0, R6
; day end address is: 24 (R6)
BL	_DS1337_SetDateTime+0
ADD	SP, SP, #8
;DS1337_RTC_LCD_Keypad.c,471 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,472 :: 		Lcd_Out(1, 1, "Saved OK");
MOVW	R0, #lo_addr(?lstr3_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr3_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,473 :: 		Lcd_Out(2, 1, "B:Back");
MOVW	R0, #lo_addr(?lstr4_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr4_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,474 :: 		}
IT	AL
BAL	L_AdjustMode135
L_AdjustMode134:
;DS1337_RTC_LCD_Keypad.c,476 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,477 :: 		Lcd_Out(1, 1, "Invalid DateTime");
MOVW	R0, #lo_addr(?lstr5_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr5_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,478 :: 		Lcd_Out(2, 1, "B:Back");
MOVW	R0, #lo_addr(?lstr6_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr6_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,479 :: 		}
L_AdjustMode135:
;DS1337_RTC_LCD_Keypad.c,481 :: 		while(1) {
L_AdjustMode136:
;DS1337_RTC_LCD_Keypad.c,482 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
STRB	R0, [SP, #4]
;DS1337_RTC_LCD_Keypad.c,483 :: 		if(key == 'B') return;
CMP	R0, #66
IT	NE
BNE	L_AdjustMode138
IT	AL
BAL	L_end_AdjustMode
L_AdjustMode138:
;DS1337_RTC_LCD_Keypad.c,484 :: 		}
IT	AL
BAL	L_AdjustMode136
;DS1337_RTC_LCD_Keypad.c,485 :: 		}
L_AdjustMode133:
;DS1337_RTC_LCD_Keypad.c,487 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,488 :: 		Lcd_Out(1, 1, "Need 12 digits");
MOVW	R0, #lo_addr(?lstr7_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr7_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,489 :: 		Lcd_Out(2, 1, "# retry B back");
MOVW	R0, #lo_addr(?lstr8_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr8_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,491 :: 		while(1) {
L_AdjustMode140:
;DS1337_RTC_LCD_Keypad.c,492 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
STRB	R0, [SP, #4]
;DS1337_RTC_LCD_Keypad.c,493 :: 		if(key == 'B') return;
CMP	R0, #66
IT	NE
BNE	L_AdjustMode142
IT	AL
BAL	L_end_AdjustMode
L_AdjustMode142:
;DS1337_RTC_LCD_Keypad.c,494 :: 		if(key == '#') {
LDRB	R0, [SP, #4]
CMP	R0, #35
IT	NE
BNE	L_AdjustMode143
;DS1337_RTC_LCD_Keypad.c,495 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;DS1337_RTC_LCD_Keypad.c,496 :: 		break;
IT	AL
BAL	L_AdjustMode141
;DS1337_RTC_LCD_Keypad.c,497 :: 		}
L_AdjustMode143:
;DS1337_RTC_LCD_Keypad.c,498 :: 		}
IT	AL
BAL	L_AdjustMode140
L_AdjustMode141:
;DS1337_RTC_LCD_Keypad.c,500 :: 		}
L_AdjustMode132:
L_AdjustMode129:
L_AdjustMode126:
;DS1337_RTC_LCD_Keypad.c,501 :: 		}
IT	AL
BAL	L_AdjustMode120
;DS1337_RTC_LCD_Keypad.c,502 :: 		}
L_end_AdjustMode:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _AdjustMode
_DisplayMode:
;DS1337_RTC_LCD_Keypad.c,504 :: 		void DisplayMode() {
SUB	SP, SP, #44
STR	LR, [SP, #0]
;DS1337_RTC_LCD_Keypad.c,510 :: 		while(1) {
L_DisplayMode144:
;DS1337_RTC_LCD_Keypad.c,511 :: 		DS1337_GetDateTime(&day, &month, &year, &hour, &minute, &second);
ADD	R5, SP, #9
ADD	R4, SP, #8
ADD	R3, SP, #7
ADD	R2, SP, #6
ADD	R1, SP, #5
ADD	R0, SP, #4
PUSH	(R5)
PUSH	(R4)
BL	_DS1337_GetDateTime+0
ADD	SP, SP, #8
;DS1337_RTC_LCD_Keypad.c,513 :: 		line1[0] = (day / 10) + '0';
ADD	R4, SP, #10
LDRB	R1, [SP, #4]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,514 :: 		line1[1] = (day % 10) + '0';
ADDS	R3, R4, #1
LDRB	R2, [SP, #4]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,515 :: 		line1[2] = '/';
ADDS	R1, R4, #2
MOVS	R0, #47
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,516 :: 		line1[3] = (month / 10) + '0';
ADDS	R2, R4, #3
LDRB	R1, [SP, #5]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,517 :: 		line1[4] = (month % 10) + '0';
ADDS	R3, R4, #4
LDRB	R2, [SP, #5]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,518 :: 		line1[5] = '/';
ADDS	R1, R4, #5
MOVS	R0, #47
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,519 :: 		line1[6] = (year / 10) + '0';
ADDS	R2, R4, #6
LDRB	R1, [SP, #6]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,520 :: 		line1[7] = (year % 10) + '0';
ADDS	R3, R4, #7
LDRB	R2, [SP, #6]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,521 :: 		line1[8] = 0;
ADDW	R1, R4, #8
MOVS	R0, #0
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,523 :: 		line2[0] = (hour / 10) + '0';
ADD	R4, SP, #27
LDRB	R1, [SP, #7]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R4, #0]
;DS1337_RTC_LCD_Keypad.c,524 :: 		line2[1] = (hour % 10) + '0';
ADDS	R3, R4, #1
LDRB	R2, [SP, #7]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,525 :: 		line2[2] = ':';
ADDS	R1, R4, #2
MOVS	R0, #58
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,526 :: 		line2[3] = (minute / 10) + '0';
ADDS	R2, R4, #3
LDRB	R1, [SP, #8]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,527 :: 		line2[4] = (minute % 10) + '0';
ADDS	R3, R4, #4
LDRB	R2, [SP, #8]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,528 :: 		line2[5] = ':';
ADDS	R1, R4, #5
MOVS	R0, #58
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,529 :: 		line2[6] = (second / 10) + '0';
ADDS	R2, R4, #6
LDRB	R1, [SP, #9]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;DS1337_RTC_LCD_Keypad.c,530 :: 		line2[7] = (second % 10) + '0';
ADDS	R3, R4, #7
LDRB	R2, [SP, #9]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;DS1337_RTC_LCD_Keypad.c,531 :: 		line2[8] = 0;
ADDW	R1, R4, #8
MOVS	R0, #0
STRB	R0, [R1, #0]
;DS1337_RTC_LCD_Keypad.c,533 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,534 :: 		Lcd_Out(1, 1, line1);
ADD	R0, SP, #10
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,535 :: 		Lcd_Out(2, 1, line2);
ADD	R0, SP, #27
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,537 :: 		key = Keypad_GetKey();
BL	_Keypad_GetKey+0
;DS1337_RTC_LCD_Keypad.c,538 :: 		if(key == 'B') {
CMP	R0, #66
IT	NE
BNE	L_DisplayMode146
;DS1337_RTC_LCD_Keypad.c,539 :: 		Delay_ms(20);
MOVW	R7, #28926
MOVT	R7, #2
NOP
NOP
L_DisplayMode147:
SUBS	R7, R7, #1
BNE	L_DisplayMode147
NOP
NOP
NOP
;DS1337_RTC_LCD_Keypad.c,540 :: 		if(Keypad_GetKey() == 'B') {
BL	_Keypad_GetKey+0
CMP	R0, #66
IT	NE
BNE	L_DisplayMode149
;DS1337_RTC_LCD_Keypad.c,541 :: 		while(Keypad_GetKey() != 0) Delay_ms(10);
L_DisplayMode150:
BL	_Keypad_GetKey+0
CMP	R0, #0
IT	EQ
BEQ	L_DisplayMode151
MOVW	R7, #14462
MOVT	R7, #1
NOP
NOP
L_DisplayMode152:
SUBS	R7, R7, #1
BNE	L_DisplayMode152
NOP
NOP
NOP
IT	AL
BAL	L_DisplayMode150
L_DisplayMode151:
;DS1337_RTC_LCD_Keypad.c,542 :: 		return;
IT	AL
BAL	L_end_DisplayMode
;DS1337_RTC_LCD_Keypad.c,543 :: 		}
L_DisplayMode149:
;DS1337_RTC_LCD_Keypad.c,544 :: 		}
L_DisplayMode146:
;DS1337_RTC_LCD_Keypad.c,546 :: 		Delay_ms(250);
MOVW	R7, #33918
MOVT	R7, #30
NOP
NOP
L_DisplayMode154:
SUBS	R7, R7, #1
BNE	L_DisplayMode154
NOP
NOP
NOP
;DS1337_RTC_LCD_Keypad.c,547 :: 		}
IT	AL
BAL	L_DisplayMode144
;DS1337_RTC_LCD_Keypad.c,548 :: 		}
L_end_DisplayMode:
LDR	LR, [SP, #0]
ADD	SP, SP, #44
BX	LR
; end of _DisplayMode
_main:
;DS1337_RTC_LCD_Keypad.c,553 :: 		void main() {
SUB	SP, SP, #4
;DS1337_RTC_LCD_Keypad.c,560 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;DS1337_RTC_LCD_Keypad.c,557 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;DS1337_RTC_LCD_Keypad.c,560 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;DS1337_RTC_LCD_Keypad.c,563 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
MOVW	R1, #8320
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;DS1337_RTC_LCD_Keypad.c,564 :: 		GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);
MOVW	R1, #1536
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Input+0
;DS1337_RTC_LCD_Keypad.c,567 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
MOVW	R1, #4098
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;DS1337_RTC_LCD_Keypad.c,568 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;DS1337_RTC_LCD_Keypad.c,569 :: 		GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOD_BASE+0)
MOVT	R0, #hi_addr(GPIOD_BASE+0)
BL	_GPIO_Digital_Output+0
;DS1337_RTC_LCD_Keypad.c,571 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;DS1337_RTC_LCD_Keypad.c,574 :: 		Lcd_Init();
BL	_Lcd_Init+0
;DS1337_RTC_LCD_Keypad.c,575 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,576 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;DS1337_RTC_LCD_Keypad.c,578 :: 		Lcd_Out(1, 1, "RTC SYSTEM");
MOVW	R0, #lo_addr(?lstr9_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr9_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,579 :: 		Lcd_Out(2, 1, "Initializing...");
MOVW	R0, #lo_addr(?lstr10_DS1337_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr10_DS1337_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_RTC_LCD_Keypad.c,580 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;DS1337_RTC_LCD_Keypad.c,583 :: 		I2C1_HW_Init();
BL	_I2C1_HW_Init+0
;DS1337_RTC_LCD_Keypad.c,586 :: 		DS1337_Init();
BL	_DS1337_Init+0
;DS1337_RTC_LCD_Keypad.c,588 :: 		while(1) {
L_main156:
;DS1337_RTC_LCD_Keypad.c,589 :: 		ShowMainMenu();
BL	_ShowMainMenu+0
;DS1337_RTC_LCD_Keypad.c,590 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
; key start address is: 4 (R1)
UXTB	R1, R0
;DS1337_RTC_LCD_Keypad.c,592 :: 		if(key == 'A') {
CMP	R0, #65
IT	NE
BNE	L_main158
; key end address is: 4 (R1)
;DS1337_RTC_LCD_Keypad.c,593 :: 		AdjustMode();
BL	_AdjustMode+0
;DS1337_RTC_LCD_Keypad.c,594 :: 		}
IT	AL
BAL	L_main159
L_main158:
;DS1337_RTC_LCD_Keypad.c,595 :: 		else if(key == 'D') {
; key start address is: 4 (R1)
CMP	R1, #68
IT	NE
BNE	L_main160
; key end address is: 4 (R1)
;DS1337_RTC_LCD_Keypad.c,596 :: 		DisplayMode();
BL	_DisplayMode+0
;DS1337_RTC_LCD_Keypad.c,597 :: 		}
L_main160:
L_main159:
;DS1337_RTC_LCD_Keypad.c,598 :: 		}
IT	AL
BAL	L_main156
;DS1337_RTC_LCD_Keypad.c,599 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
