/*
   ------------------------------------------------------------
   ESP32 - UART0 to UART2 bridge for STM32 testing
   ------------------------------------------------------------

   UART connections from schematic:
     GPIO27 -> UART2 RX   (receive from STM32 TX)
     GPIO26 -> UART2 TX   (send to STM32 RX)

   UART0:
     Used for USB serial monitor
     TX0 -> U0TXD
     RX0 -> U0RXD

   Function:
     - Forward any Serial monitor data on UART0 to UART2
     - Print any received STM32 data from UART2 to Serial monitor
*/

HardwareSerial STM32_UART(2);   // use UART2 on ESP32

void setup() {
  // UART0 for monitor
  Serial.begin(9600);
  delay(5000);

  // UART2 for STM32 communication
  // baud, config, RX pin, TX pin
  STM32_UART.begin(9600, SERIAL_8N1, 27, 26);

  Serial.println("ESP32 UART bridge started");
  Serial.println("Serial Monitor <-> STM32 bridge is ready");
  Serial.println("UART2 RX from STM32 on GPIO27");
  Serial.println("UART2 TX to STM32 on GPIO26");
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    STM32_UART.write(c);   // forward UART0 data to STM32 on UART2
  }

  while (STM32_UART.available()) {
    char c = STM32_UART.read();
    Serial.write(c);   // send received data to UART0 / serial monitor
  }
}
