#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
#line 26 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
void delayMs(unsigned int n);
void USART2_Init_HW();
void USART2_WriteChar(char ch);
void USART2_WriteString(char *s);
char USART2_DataReady();
char USART2_ReadChar();
unsigned short USART2_ReadMessage(char *buffer, unsigned short maxLen);

void main() {
 char rxBuffer[ 64 ];
 unsigned short i;
 unsigned short receivedLength;

 USART2_Init_HW();

 for(i = 0; i < 10; i++) {
 USART2_WriteString("yes\r\n");
 delayMs(1000);
 }

 while(1) {
 receivedLength = USART2_ReadMessage(rxBuffer,  64 );

 if(receivedLength > 0) {
 USART2_WriteString("Received By STM32: ");
 USART2_WriteString(rxBuffer);
 USART2_WriteString("\r\n");
 }
 }
}
#line 60 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
void USART2_Init_HW() {

 RCC_AHB1ENR |= 0x00000001;


 RCC_APB1ENR |= 0x00020000;


 GPIOA_AFRL &= ~0x0000FF00;
 GPIOA_AFRL |= 0x00007700;

 GPIOA_MODER &= ~0x000000F0;
 GPIOA_MODER |= 0x000000A0;


 USART2_BRR = 0x0683;
 USART2_CR1 = 0x000C;
 USART2_CR2 = 0x0000;
 USART2_CR3 = 0x0000;
 USART2_CR1 |= 0x2000;
}
#line 85 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
void USART2_WriteChar(char ch) {
 while(!(USART2_SR & 0x0080)) {

 }

 USART2_DR = (ch & 0xFF);
}
#line 96 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
void USART2_WriteString(char *s) {
 while(*s) {
 USART2_WriteChar(*s++);
 }
}
#line 105 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
char USART2_DataReady() {
 return (USART2_SR & 0x0020) != 0;
}
#line 112 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
char USART2_ReadChar() {
 while(!USART2_DataReady()) {

 }

 return (char)(USART2_DR & 0x00FF);
}
#line 124 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
unsigned short USART2_ReadMessage(char *buffer, unsigned short maxLen) {
 unsigned short index = 0;
 unsigned long idleCounter;
 char ch;

 while(1) {
 ch = USART2_ReadChar();

 if((ch != '\r') && (ch != '\n')) {
 buffer[index++] = ch;
 break;
 }
 }

 while(index < (maxLen - 1)) {
 idleCounter = 0;

 while(!USART2_DataReady()) {
 idleCounter++;

 if(idleCounter >=  5000000UL ) {
 buffer[index] = 0;
 return index;
 }
 }

 ch = USART2_ReadChar();

 if((ch == '\r') || (ch == '\n')) {
 break;
 }

 buffer[index++] = ch;
 }

 buffer[index] = 0;
 return index;
}
#line 166 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/UART_Test.c"
void delayMs(unsigned int n) {
 unsigned int i;

 for(; n > 0; n--) {
 for(i = 0; i < 2000; i++) {
 asm nop;
 }
 }
}
