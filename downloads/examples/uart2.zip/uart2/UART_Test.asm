_main:
;UART_Test.c,34 :: 		void main() {
SUB	SP, SP, #64
;UART_Test.c,39 :: 		USART2_Init_HW();   // initialize USART2 TX/RX
BL	_USART2_Init_HW+0
;UART_Test.c,41 :: 		for(i = 0; i < 10; i++) {
; i start address is: 16 (R4)
MOVS	R4, #0
; i end address is: 16 (R4)
L_main0:
; i start address is: 16 (R4)
CMP	R4, #10
IT	CS
BCS	L_main1
;UART_Test.c,42 :: 		USART2_WriteString("yes\r\n");
MOVW	R0, #lo_addr(?lstr1_UART_Test+0)
MOVT	R0, #hi_addr(?lstr1_UART_Test+0)
BL	_USART2_WriteString+0
;UART_Test.c,43 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;UART_Test.c,41 :: 		for(i = 0; i < 10; i++) {
ADDS	R4, R4, #1
UXTB	R4, R4
;UART_Test.c,44 :: 		}
; i end address is: 16 (R4)
IT	AL
BAL	L_main0
L_main1:
;UART_Test.c,46 :: 		while(1) {
L_main3:
;UART_Test.c,47 :: 		receivedLength = USART2_ReadMessage(rxBuffer, RX_BUFFER_SIZE);
ADD	R0, SP, #0
MOVS	R1, #64
BL	_USART2_ReadMessage+0
;UART_Test.c,49 :: 		if(receivedLength > 0) {
CMP	R0, #0
IT	LS
BLS	L_main5
;UART_Test.c,50 :: 		USART2_WriteString("Received By STM32: ");
MOVW	R0, #lo_addr(?lstr2_UART_Test+0)
MOVT	R0, #hi_addr(?lstr2_UART_Test+0)
BL	_USART2_WriteString+0
;UART_Test.c,51 :: 		USART2_WriteString(rxBuffer);
ADD	R0, SP, #0
BL	_USART2_WriteString+0
;UART_Test.c,52 :: 		USART2_WriteString("\r\n");
MOVW	R0, #lo_addr(?lstr3_UART_Test+0)
MOVT	R0, #hi_addr(?lstr3_UART_Test+0)
BL	_USART2_WriteString+0
;UART_Test.c,53 :: 		}
L_main5:
;UART_Test.c,54 :: 		}
IT	AL
BAL	L_main3
;UART_Test.c,55 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
_USART2_Init_HW:
;UART_Test.c,60 :: 		void USART2_Init_HW() {
;UART_Test.c,62 :: 		RCC_AHB1ENR |= 0x00000001;
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;UART_Test.c,65 :: 		RCC_APB1ENR |= 0x00020000;
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #131072
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;UART_Test.c,68 :: 		GPIOA_AFRL &= ~0x0000FF00;
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
LDR	R0, [R0, #0]
AND	R1, R0, #255
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
STR	R1, [R0, #0]
;UART_Test.c,69 :: 		GPIOA_AFRL |=  0x00007700;   // AF7 for USART2 on PA2/PA3
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #30464
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
STR	R1, [R0, #0]
;UART_Test.c,71 :: 		GPIOA_MODER &= ~0x000000F0;
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
LDR	R0, [R0, #0]
AND	R1, R0, #15
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
STR	R1, [R0, #0]
;UART_Test.c,72 :: 		GPIOA_MODER |=  0x000000A0;  // alternate function mode for PA2/PA3
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #160
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
STR	R1, [R0, #0]
;UART_Test.c,75 :: 		USART2_BRR = 0x0683;         // 9600 baud @ 16 MHz
MOVW	R1, #1667
MOVW	R0, #lo_addr(USART2_BRR+0)
MOVT	R0, #hi_addr(USART2_BRR+0)
STR	R1, [R0, #0]
;UART_Test.c,76 :: 		USART2_CR1 = 0x000C;         // TE + RE = transmitter/receiver enable
MOVS	R1, #12
MOVW	R0, #lo_addr(USART2_CR1+0)
MOVT	R0, #hi_addr(USART2_CR1+0)
STR	R1, [R0, #0]
;UART_Test.c,77 :: 		USART2_CR2 = 0x0000;         // 1 stop bit
MOVS	R1, #0
MOVW	R0, #lo_addr(USART2_CR2+0)
MOVT	R0, #hi_addr(USART2_CR2+0)
STR	R1, [R0, #0]
;UART_Test.c,78 :: 		USART2_CR3 = 0x0000;         // no flow control
MOVS	R1, #0
MOVW	R0, #lo_addr(USART2_CR3+0)
MOVT	R0, #hi_addr(USART2_CR3+0)
STR	R1, [R0, #0]
;UART_Test.c,79 :: 		USART2_CR1 |= 0x2000;        // UE = USART enable
MOVW	R0, #lo_addr(USART2_CR1+0)
MOVT	R0, #hi_addr(USART2_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #8192
MOVW	R0, #lo_addr(USART2_CR1+0)
MOVT	R0, #hi_addr(USART2_CR1+0)
STR	R1, [R0, #0]
;UART_Test.c,80 :: 		}
L_end_USART2_Init_HW:
BX	LR
; end of _USART2_Init_HW
_USART2_WriteChar:
;UART_Test.c,85 :: 		void USART2_WriteChar(char ch) {
; ch start address is: 0 (R0)
; ch end address is: 0 (R0)
; ch start address is: 0 (R0)
; ch end address is: 0 (R0)
;UART_Test.c,86 :: 		while(!(USART2_SR & 0x0080)) {
L_USART2_WriteChar6:
; ch start address is: 0 (R0)
MOVW	R1, #lo_addr(USART2_SR+0)
MOVT	R1, #hi_addr(USART2_SR+0)
LDR	R1, [R1, #0]
AND	R1, R1, #128
CMP	R1, #0
IT	NE
BNE	L_USART2_WriteChar7
;UART_Test.c,88 :: 		}
IT	AL
BAL	L_USART2_WriteChar6
L_USART2_WriteChar7:
;UART_Test.c,90 :: 		USART2_DR = (ch & 0xFF);
AND	R2, R0, #255
UXTB	R2, R2
; ch end address is: 0 (R0)
MOVW	R1, #lo_addr(USART2_DR+0)
MOVT	R1, #hi_addr(USART2_DR+0)
STR	R2, [R1, #0]
;UART_Test.c,91 :: 		}
L_end_USART2_WriteChar:
BX	LR
; end of _USART2_WriteChar
_USART2_WriteString:
;UART_Test.c,96 :: 		void USART2_WriteString(char *s) {
; s start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; s end address is: 0 (R0)
; s start address is: 0 (R0)
MOV	R3, R0
; s end address is: 0 (R0)
;UART_Test.c,97 :: 		while(*s) {
L_USART2_WriteString8:
; s start address is: 12 (R3)
LDRB	R1, [R3, #0]
CMP	R1, #0
IT	EQ
BEQ	L_USART2_WriteString9
;UART_Test.c,98 :: 		USART2_WriteChar(*s++);
LDRB	R1, [R3, #0]
UXTB	R0, R1
BL	_USART2_WriteChar+0
ADDS	R3, R3, #1
;UART_Test.c,99 :: 		}
; s end address is: 12 (R3)
IT	AL
BAL	L_USART2_WriteString8
L_USART2_WriteString9:
;UART_Test.c,100 :: 		}
L_end_USART2_WriteString:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _USART2_WriteString
_USART2_DataReady:
;UART_Test.c,105 :: 		char USART2_DataReady() {
;UART_Test.c,106 :: 		return (USART2_SR & 0x0020) != 0;
MOVW	R0, #lo_addr(USART2_SR+0)
MOVT	R0, #hi_addr(USART2_SR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #32
CMP	R0, #0
MOVW	R0, #0
BEQ	L__USART2_DataReady44
MOVS	R0, #1
L__USART2_DataReady44:
UXTB	R0, R0
;UART_Test.c,107 :: 		}
L_end_USART2_DataReady:
BX	LR
; end of _USART2_DataReady
_USART2_ReadChar:
;UART_Test.c,112 :: 		char USART2_ReadChar() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;UART_Test.c,113 :: 		while(!USART2_DataReady()) {
L_USART2_ReadChar10:
BL	_USART2_DataReady+0
CMP	R0, #0
IT	NE
BNE	L_USART2_ReadChar11
;UART_Test.c,115 :: 		}
IT	AL
BAL	L_USART2_ReadChar10
L_USART2_ReadChar11:
;UART_Test.c,117 :: 		return (char)(USART2_DR & 0x00FF);
MOVW	R0, #lo_addr(USART2_DR+0)
MOVT	R0, #hi_addr(USART2_DR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #255
UXTB	R0, R0
;UART_Test.c,118 :: 		}
L_end_USART2_ReadChar:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _USART2_ReadChar
_USART2_ReadMessage:
;UART_Test.c,124 :: 		unsigned short USART2_ReadMessage(char *buffer, unsigned short maxLen) {
; maxLen start address is: 4 (R1)
; buffer start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
; maxLen end address is: 4 (R1)
; buffer end address is: 0 (R0)
; buffer start address is: 0 (R0)
; maxLen start address is: 4 (R1)
;UART_Test.c,125 :: 		unsigned short index = 0;
; index start address is: 16 (R4)
; index start address is: 16 (R4)
MOVS	R4, #0
; buffer end address is: 0 (R0)
; index end address is: 16 (R4)
MOV	R3, R0
;UART_Test.c,129 :: 		while(1) {
L_USART2_ReadMessage12:
;UART_Test.c,130 :: 		ch = USART2_ReadChar();
; buffer start address is: 12 (R3)
; index start address is: 16 (R4)
; index end address is: 16 (R4)
; maxLen start address is: 4 (R1)
; maxLen end address is: 4 (R1)
; buffer start address is: 12 (R3)
; buffer end address is: 12 (R3)
BL	_USART2_ReadChar+0
; ch start address is: 20 (R5)
UXTB	R5, R0
;UART_Test.c,132 :: 		if((ch != '\r') && (ch != '\n')) {
CMP	R0, #13
IT	EQ
BEQ	L__USART2_ReadMessage34
; index end address is: 16 (R4)
; buffer end address is: 12 (R3)
; maxLen end address is: 4 (R1)
; maxLen start address is: 4 (R1)
; buffer start address is: 12 (R3)
; index start address is: 16 (R4)
CMP	R5, #10
IT	EQ
BEQ	L__USART2_ReadMessage33
L__USART2_ReadMessage32:
;UART_Test.c,133 :: 		buffer[index++] = ch;
ADDS	R2, R3, R4
STRB	R5, [R2, #0]
; ch end address is: 20 (R5)
ADDS	R0, R4, #1
UXTB	R0, R0
; index end address is: 16 (R4)
; index start address is: 0 (R0)
;UART_Test.c,134 :: 		break;
IT	AL
BAL	L_USART2_ReadMessage13
; index end address is: 0 (R0)
;UART_Test.c,132 :: 		if((ch != '\r') && (ch != '\n')) {
L__USART2_ReadMessage34:
; index start address is: 16 (R4)
L__USART2_ReadMessage33:
;UART_Test.c,136 :: 		}
; index end address is: 16 (R4)
IT	AL
BAL	L_USART2_ReadMessage12
L_USART2_ReadMessage13:
;UART_Test.c,138 :: 		while(index < (maxLen - 1)) {
; index start address is: 0 (R0)
; maxLen end address is: 4 (R1)
; index end address is: 0 (R0)
L_USART2_ReadMessage17:
; buffer end address is: 12 (R3)
; index start address is: 0 (R0)
; buffer start address is: 12 (R3)
; maxLen start address is: 4 (R1)
SUBS	R2, R1, #1
SXTH	R2, R2
CMP	R0, R2
IT	GE
BGE	L__USART2_ReadMessage37
;UART_Test.c,139 :: 		idleCounter = 0;
MOVS	R2, #0
STR	R2, [SP, #4]
; buffer end address is: 12 (R3)
; maxLen end address is: 4 (R1)
; index end address is: 0 (R0)
UXTB	R5, R0
MOV	R4, R3
;UART_Test.c,141 :: 		while(!USART2_DataReady()) {
L_USART2_ReadMessage19:
; maxLen start address is: 4 (R1)
; buffer start address is: 16 (R4)
; index start address is: 20 (R5)
BL	_USART2_DataReady+0
CMP	R0, #0
IT	NE
BNE	L_USART2_ReadMessage20
;UART_Test.c,142 :: 		idleCounter++;
LDR	R2, [SP, #4]
ADDS	R3, R2, #1
STR	R3, [SP, #4]
;UART_Test.c,144 :: 		if(idleCounter >= RX_IDLE_LIMIT) {
MOVW	R2, #19264
MOVT	R2, #76
CMP	R3, R2
IT	CC
BCC	L_USART2_ReadMessage21
; maxLen end address is: 4 (R1)
;UART_Test.c,145 :: 		buffer[index] = 0;
ADDS	R3, R4, R5
; buffer end address is: 16 (R4)
MOVS	R2, #0
STRB	R2, [R3, #0]
;UART_Test.c,146 :: 		return index;
UXTB	R0, R5
; index end address is: 20 (R5)
IT	AL
BAL	L_end_USART2_ReadMessage
;UART_Test.c,147 :: 		}
L_USART2_ReadMessage21:
;UART_Test.c,148 :: 		}
; index start address is: 20 (R5)
; buffer start address is: 16 (R4)
; maxLen start address is: 4 (R1)
IT	AL
BAL	L_USART2_ReadMessage19
L_USART2_ReadMessage20:
;UART_Test.c,150 :: 		ch = USART2_ReadChar();
BL	_USART2_ReadChar+0
; ch start address is: 12 (R3)
UXTB	R3, R0
;UART_Test.c,152 :: 		if((ch == '\r') || (ch == '\n')) {
CMP	R0, #13
IT	EQ
BEQ	L__USART2_ReadMessage36
CMP	R3, #10
IT	EQ
BEQ	L__USART2_ReadMessage35
IT	AL
BAL	L_USART2_ReadMessage24
; maxLen end address is: 4 (R1)
; ch end address is: 12 (R3)
L__USART2_ReadMessage36:
L__USART2_ReadMessage35:
;UART_Test.c,153 :: 		break;
UXTB	R0, R5
MOV	R1, R4
IT	AL
BAL	L_USART2_ReadMessage18
;UART_Test.c,154 :: 		}
L_USART2_ReadMessage24:
;UART_Test.c,156 :: 		buffer[index++] = ch;
; ch start address is: 12 (R3)
; maxLen start address is: 4 (R1)
ADDS	R2, R4, R5
STRB	R3, [R2, #0]
; ch end address is: 12 (R3)
ADDS	R0, R5, #1
UXTB	R0, R0
; index end address is: 20 (R5)
; index start address is: 0 (R0)
;UART_Test.c,157 :: 		}
; maxLen end address is: 4 (R1)
; buffer end address is: 16 (R4)
; index end address is: 0 (R0)
MOV	R3, R4
IT	AL
BAL	L_USART2_ReadMessage17
L__USART2_ReadMessage37:
;UART_Test.c,138 :: 		while(index < (maxLen - 1)) {
MOV	R1, R3
;UART_Test.c,157 :: 		}
L_USART2_ReadMessage18:
;UART_Test.c,159 :: 		buffer[index] = 0;
; buffer start address is: 4 (R1)
; index start address is: 0 (R0)
ADDS	R3, R1, R0
; buffer end address is: 4 (R1)
MOVS	R2, #0
STRB	R2, [R3, #0]
;UART_Test.c,160 :: 		return index;
; index end address is: 0 (R0)
;UART_Test.c,161 :: 		}
L_end_USART2_ReadMessage:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _USART2_ReadMessage
_delayMs:
;UART_Test.c,166 :: 		void delayMs(unsigned int n) {
; n start address is: 0 (R0)
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;UART_Test.c,169 :: 		for(; n > 0; n--) {
L_delayMs25:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs26
;UART_Test.c,170 :: 		for(i = 0; i < 2000; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs28:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
CMP	R2, #2000
IT	CS
BCS	L_delayMs29
;UART_Test.c,171 :: 		asm nop;
NOP
;UART_Test.c,170 :: 		for(i = 0; i < 2000; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;UART_Test.c,172 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs28
L_delayMs29:
;UART_Test.c,169 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;UART_Test.c,173 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs25
L_delayMs26:
;UART_Test.c,174 :: 		}
L_end_delayMs:
BX	LR
; end of _delayMs
