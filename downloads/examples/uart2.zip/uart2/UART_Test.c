/*
   ------------------------------------------------------------
   STM32F446RE - USART2 Send/Receive Test
   mikroC PRO for ARM
   ------------------------------------------------------------

   USART2:
     PA2 -> USART2_TX   (AF7)
     PA3 -> USART2_RX   (AF7)

   Clock:
     Default 16 MHz

   Baud rate:
     9600

   Function:
     Send "yes" 10 times, then wait for received data.
     When data is received, send:
       Received By STM32: <received data>
*/

#define RX_BUFFER_SIZE 64
#define RX_IDLE_LIMIT 5000000UL

void delayMs(unsigned int n);
void USART2_Init_HW();
void USART2_WriteChar(char ch);
void USART2_WriteString(char *s);
char USART2_DataReady();
char USART2_ReadChar();
unsigned short USART2_ReadMessage(char *buffer, unsigned short maxLen);

void main() {
  char rxBuffer[RX_BUFFER_SIZE];
  unsigned short i;
  unsigned short receivedLength;

  USART2_Init_HW();   // initialize USART2 TX/RX

  for(i = 0; i < 10; i++) {
    USART2_WriteString("yes\r\n");
    delayMs(1000);
  }

  while(1) {
    receivedLength = USART2_ReadMessage(rxBuffer, RX_BUFFER_SIZE);

    if(receivedLength > 0) {
      USART2_WriteString("Received By STM32: ");
      USART2_WriteString(rxBuffer);
      USART2_WriteString("\r\n");
    }
  }
}

/*
   Initialize USART2 on PA2/PA3
*/
void USART2_Init_HW() {
  // Enable GPIOA clock
  RCC_AHB1ENR |= 0x00000001;

  // Enable USART2 clock
  RCC_APB1ENR |= 0x00020000;

  // Configure PA2 and PA3 as alternate function AF7
  GPIOA_AFRL &= ~0x0000FF00;
  GPIOA_AFRL |=  0x00007700;   // AF7 for USART2 on PA2/PA3

  GPIOA_MODER &= ~0x000000F0;
  GPIOA_MODER |=  0x000000A0;  // alternate function mode for PA2/PA3

  // USART2 configuration
  USART2_BRR = 0x0683;         // 9600 baud @ 16 MHz
  USART2_CR1 = 0x000C;         // TE + RE = transmitter/receiver enable
  USART2_CR2 = 0x0000;         // 1 stop bit
  USART2_CR3 = 0x0000;         // no flow control
  USART2_CR1 |= 0x2000;        // UE = USART enable
}

/*
   Write one character to USART2
*/
void USART2_WriteChar(char ch) {
  while(!(USART2_SR & 0x0080)) {
    // wait until TXE = transmit data register empty
  }

  USART2_DR = (ch & 0xFF);
}

/*
   Write a null-terminated string to USART2
*/
void USART2_WriteString(char *s) {
  while(*s) {
    USART2_WriteChar(*s++);
  }
}

/*
   Check if a byte has been received
*/
char USART2_DataReady() {
  return (USART2_SR & 0x0020) != 0;
}

/*
   Read one character from USART2
*/
char USART2_ReadChar() {
  while(!USART2_DataReady()) {
    // wait until RXNE = received data ready
  }

  return (char)(USART2_DR & 0x00FF);
}

/*
   Read one UART message.
   The message ends on CR/LF or after a short idle timeout.
*/
unsigned short USART2_ReadMessage(char *buffer, unsigned short maxLen) {
  unsigned short index = 0;
  unsigned long idleCounter;
  char ch;

  while(1) {
    ch = USART2_ReadChar();

    if((ch != '\r') && (ch != '\n')) {
      buffer[index++] = ch;
      break;
    }
  }

  while(index < (maxLen - 1)) {
    idleCounter = 0;

    while(!USART2_DataReady()) {
      idleCounter++;

      if(idleCounter >= RX_IDLE_LIMIT) {
        buffer[index] = 0;
        return index;
      }
    }

    ch = USART2_ReadChar();

    if((ch == '\r') || (ch == '\n')) {
      break;
    }

    buffer[index++] = ch;
  }

  buffer[index] = 0;
  return index;
}

/*
   Simple delay for 16 MHz clock
*/
void delayMs(unsigned int n) {
  unsigned int i;

  for(; n > 0; n--) {
    for(i = 0; i < 2000; i++) {
      asm nop;
    }
  }
}
