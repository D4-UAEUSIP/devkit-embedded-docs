/*
   ------------------------------------------------------------
   STM32F446RE - ADC Voltage and Percentage Display on LCD
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   SW19 : 2:ON   1 :off
   SW4 :  POT side
   VR1: adujest it till  you see the text on LCD
   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   Input:
     Variable resistor wiper -> PC0

   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5

   ADC assumptions:
     - PC0 = ADC channel 10
     - 12-bit ADC
     - Vref = 3.3V

   Display:
     Line 1 -> Voltage
     Line 2 -> Percentage 0..100%
*/

// LCD connections
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

// Direction declarations required by mikroC LCD library
sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

unsigned long adc_sum;
unsigned int adc_avg;
unsigned short i;

float voltage;
float percent_f;

const float ADC_REF_VOLTAGE       = 3.3;
const float ADC_FULL_SCALE_COUNTS = 4095.0;

unsigned int volt_int;
unsigned int volt_frac;

unsigned int pct_int;
unsigned int pct_frac;

char txt[16];

// ADC1_SMPR1 bits [2:0] control sampling time for channel 10 (PC0).
const unsigned long ADC_CH10_SAMPLE_MASK       = 0x00000007;
const unsigned long ADC_SAMPLE_84_CYCLES_CODE  = 0x00000004;
const unsigned long ADC_SAMPLE_112_CYCLES_CODE = 0x00000005;

void Set_ADC_Channel10_SampleTime_High() {
  ADC1_SMPR1 &= ~ADC_CH10_SAMPLE_MASK;
  ADC1_SMPR1 |= ADC_SAMPLE_112_CYCLES_CODE;
}

/*
   Read ADC channel 10 and average 16 samples
   to make the display more stable
*/
unsigned int Read_ADC_Average() {
  adc_sum = 0;

  for(i = 0; i < 16; i++) {
    adc_sum += ADC1_Get_Sample(10);
    Delay_ms(2);
  }

  return (unsigned int)(adc_sum / 16);
}

void main() {

  // Configure LCD pins as outputs
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  // Configure PC0 as analog input
  ADC_Set_Input_Channel(_ADC_CHANNEL_10);

  // Initialize ADC
  ADC1_Init();
  Set_ADC_Channel10_SampleTime_High();

  // Initialize LCD
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  while(1) {

    // Read averaged ADC value
    adc_avg = Read_ADC_Average();

    // Convert ADC to voltage using the true 12-bit full-scale count.
    voltage = (adc_avg * ADC_REF_VOLTAGE) / ADC_FULL_SCALE_COUNTS;

   // Percentage based on the same true 12-bit full-scale count.
   percent_f = (adc_avg * 100.0) / ADC_FULL_SCALE_COUNTS;

   // Clamp to 100%
   if(percent_f > 100.0)
     percent_f = 100.0;

    // Prepare voltage integer and fractional parts
    volt_int  = (unsigned int)voltage;
    volt_frac = (unsigned int)((voltage - volt_int) * 100.0);

    // Prepare percentage integer and fractional parts
    pct_int  = (unsigned int)percent_f;
    pct_frac = (unsigned int)((percent_f - pct_int) * 10.0);

    // -------- Line 1: Voltage --------
    Lcd_Out(1, 1, "V=");

    WordToStr(volt_int, txt);
    Ltrim(txt);
    Lcd_Out(1, 3, txt);

    Lcd_Chr(1, 3 + strlen(txt), '.');
    Lcd_Chr(1, 4 + strlen(txt), (volt_frac / 10) + '0');
    Lcd_Chr(1, 5 + strlen(txt), (volt_frac % 10) + '0');
    Lcd_Out(1, 7 + strlen(txt), "V   ");

    // -------- Line 2: Percentage --------
    Lcd_Out(2, 1, "P=");

    WordToStr(pct_int, txt);
    Ltrim(txt);
    Lcd_Out(2, 3, txt);

    Lcd_Chr(2, 3 + strlen(txt), '.');
    Lcd_Chr(2, 4 + strlen(txt), pct_frac + '0');
    Lcd_Out(2, 6 + strlen(txt), "%   ");

    Delay_ms(300);
  }
}