_Set_ADC_Channel10_SampleTime_High:
;POT_LCD.c,74 :: 		void Set_ADC_Channel10_SampleTime_High() {
;POT_LCD.c,75 :: 		ADC1_SMPR1 &= ~ADC_CH10_SAMPLE_MASK;
MOVW	R0, #lo_addr(ADC1_SMPR1+0)
MOVT	R0, #hi_addr(ADC1_SMPR1+0)
LDR	R1, [R0, #0]
MVN	R0, #7
ANDS	R1, R0
MOVW	R0, #lo_addr(ADC1_SMPR1+0)
MOVT	R0, #hi_addr(ADC1_SMPR1+0)
STR	R1, [R0, #0]
;POT_LCD.c,76 :: 		ADC1_SMPR1 |= ADC_SAMPLE_112_CYCLES_CODE;
MOVW	R0, #lo_addr(ADC1_SMPR1+0)
MOVT	R0, #hi_addr(ADC1_SMPR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #5
MOVW	R0, #lo_addr(ADC1_SMPR1+0)
MOVT	R0, #hi_addr(ADC1_SMPR1+0)
STR	R1, [R0, #0]
;POT_LCD.c,77 :: 		}
L_end_Set_ADC_Channel10_SampleTime_High:
BX	LR
; end of _Set_ADC_Channel10_SampleTime_High
_Read_ADC_Average:
;POT_LCD.c,83 :: 		unsigned int Read_ADC_Average() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;POT_LCD.c,84 :: 		adc_sum = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_adc_sum+0)
MOVT	R0, #hi_addr(_adc_sum+0)
STR	R1, [R0, #0]
;POT_LCD.c,86 :: 		for(i = 0; i < 16; i++) {
MOVS	R1, #0
MOVW	R0, #lo_addr(_i+0)
MOVT	R0, #hi_addr(_i+0)
STRB	R1, [R0, #0]
L_Read_ADC_Average0:
MOVW	R0, #lo_addr(_i+0)
MOVT	R0, #hi_addr(_i+0)
LDRB	R0, [R0, #0]
CMP	R0, #16
IT	CS
BCS	L_Read_ADC_Average1
;POT_LCD.c,87 :: 		adc_sum += ADC1_Get_Sample(10);
MOVS	R0, #10
BL	_ADC1_Get_Sample+0
MOVW	R2, #lo_addr(_adc_sum+0)
MOVT	R2, #hi_addr(_adc_sum+0)
LDR	R1, [R2, #0]
ADDS	R0, R1, R0
STR	R0, [R2, #0]
;POT_LCD.c,88 :: 		Delay_ms(2);
MOVW	R7, #15998
MOVT	R7, #0
NOP
NOP
L_Read_ADC_Average3:
SUBS	R7, R7, #1
BNE	L_Read_ADC_Average3
NOP
NOP
NOP
;POT_LCD.c,86 :: 		for(i = 0; i < 16; i++) {
MOVW	R1, #lo_addr(_i+0)
MOVT	R1, #hi_addr(_i+0)
LDRB	R0, [R1, #0]
ADDS	R0, R0, #1
STRB	R0, [R1, #0]
;POT_LCD.c,89 :: 		}
IT	AL
BAL	L_Read_ADC_Average0
L_Read_ADC_Average1:
;POT_LCD.c,91 :: 		return (unsigned int)(adc_sum / 16);
MOVW	R0, #lo_addr(_adc_sum+0)
MOVT	R0, #hi_addr(_adc_sum+0)
LDR	R0, [R0, #0]
LSRS	R0, R0, #4
UXTH	R0, R0
;POT_LCD.c,92 :: 		}
L_end_Read_ADC_Average:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Read_ADC_Average
_main:
;POT_LCD.c,94 :: 		void main() {
SUB	SP, SP, #4
;POT_LCD.c,100 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;POT_LCD.c,97 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;POT_LCD.c,100 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;POT_LCD.c,103 :: 		ADC_Set_Input_Channel(_ADC_CHANNEL_10);
MOVW	R0, #1024
BL	_ADC_Set_Input_Channel+0
;POT_LCD.c,106 :: 		ADC1_Init();
BL	_ADC1_Init+0
;POT_LCD.c,107 :: 		Set_ADC_Channel10_SampleTime_High();
BL	_Set_ADC_Channel10_SampleTime_High+0
;POT_LCD.c,110 :: 		Lcd_Init();
BL	_Lcd_Init+0
;POT_LCD.c,111 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;POT_LCD.c,112 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;POT_LCD.c,114 :: 		while(1) {
L_main5:
;POT_LCD.c,117 :: 		adc_avg = Read_ADC_Average();
BL	_Read_ADC_Average+0
MOVW	R1, #lo_addr(_adc_avg+0)
MOVT	R1, #hi_addr(_adc_avg+0)
STRH	R0, [R1, #0]
;POT_LCD.c,120 :: 		voltage = (adc_avg * ADC_REF_VOLTAGE) / ADC_FULL_SCALE_COUNTS;
VMOV	S2, R0
VCVT.F32	#0, S2, S2
MOVW	R0, #13107
MOVT	R0, #16467
VMOV	S0, R0
VMUL.F32	S1, S2, S0
MOVW	R0, #61440
MOVT	R0, #17791
VMOV	S0, R0
VDIV.F32	S0, S1, S0
MOVW	R0, #lo_addr(_voltage+0)
MOVT	R0, #hi_addr(_voltage+0)
VSTR	#1, S0, [R0, #0]
;POT_LCD.c,123 :: 		percent_f = (adc_avg * 100.0) / ADC_FULL_SCALE_COUNTS;
MOVW	R0, #0
MOVT	R0, #17096
VMOV	S0, R0
VMUL.F32	S1, S2, S0
MOVW	R0, #61440
MOVT	R0, #17791
VMOV	S0, R0
VDIV.F32	S1, S1, S0
MOVW	R0, #lo_addr(_percent_f+0)
MOVT	R0, #hi_addr(_percent_f+0)
VSTR	#1, S1, [R0, #0]
;POT_LCD.c,126 :: 		if(percent_f > 100.0)
MOVW	R0, #0
MOVT	R0, #17096
VMOV	S0, R0
VCMPE.F32	S1, S0
VMRS	#60, FPSCR
IT	LE
BLE	L_main7
;POT_LCD.c,127 :: 		percent_f = 100.0;
MOVW	R0, #0
MOVT	R0, #17096
VMOV	S0, R0
MOVW	R0, #lo_addr(_percent_f+0)
MOVT	R0, #hi_addr(_percent_f+0)
VSTR	#1, S0, [R0, #0]
L_main7:
;POT_LCD.c,130 :: 		volt_int  = (unsigned int)voltage;
MOVW	R2, #lo_addr(_voltage+0)
MOVT	R2, #hi_addr(_voltage+0)
VLDR	#1, S0, [R2, #0]
VCVT	#1, .F32, S0, S0
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_volt_int+0)
MOVT	R0, #hi_addr(_volt_int+0)
STRH	R1, [R0, #0]
;POT_LCD.c,131 :: 		volt_frac = (unsigned int)((voltage - volt_int) * 100.0);
VMOV	S1, R1
VCVT.F32	#0, S1, S1
MOV	R0, R2
VLDR	#1, S0, [R0, #0]
VSUB.F32	S1, S0, S1
MOVW	R0, #0
MOVT	R0, #17096
VMOV	S0, R0
VMUL.F32	S0, S1, S0
VCVT	#1, .F32, S0, S0
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_volt_frac+0)
MOVT	R0, #hi_addr(_volt_frac+0)
STRH	R1, [R0, #0]
;POT_LCD.c,134 :: 		pct_int  = (unsigned int)percent_f;
MOVW	R2, #lo_addr(_percent_f+0)
MOVT	R2, #hi_addr(_percent_f+0)
VLDR	#1, S0, [R2, #0]
VCVT	#1, .F32, S0, S0
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_pct_int+0)
MOVT	R0, #hi_addr(_pct_int+0)
STRH	R1, [R0, #0]
;POT_LCD.c,135 :: 		pct_frac = (unsigned int)((percent_f - pct_int) * 10.0);
VMOV	S1, R1
VCVT.F32	#0, S1, S1
MOV	R0, R2
VLDR	#1, S0, [R0, #0]
VSUB.F32	S1, S0, S1
VMOV.F32	S0, #10
VMUL.F32	S0, S1, S0
VCVT	#1, .F32, S0, S0
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_pct_frac+0)
MOVT	R0, #hi_addr(_pct_frac+0)
STRH	R1, [R0, #0]
;POT_LCD.c,138 :: 		Lcd_Out(1, 1, "V=");
MOVW	R0, #lo_addr(?lstr1_POT_LCD+0)
MOVT	R0, #hi_addr(?lstr1_POT_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;POT_LCD.c,140 :: 		WordToStr(volt_int, txt);
MOVW	R0, #lo_addr(_volt_int+0)
MOVT	R0, #hi_addr(_volt_int+0)
LDRH	R0, [R0, #0]
MOVW	R1, #lo_addr(_txt+0)
MOVT	R1, #hi_addr(_txt+0)
BL	_WordToStr+0
;POT_LCD.c,141 :: 		Ltrim(txt);
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_Ltrim+0
;POT_LCD.c,142 :: 		Lcd_Out(1, 3, txt);
MOVW	R2, #lo_addr(_txt+0)
MOVT	R2, #hi_addr(_txt+0)
MOVS	R1, #3
MOVS	R0, #1
BL	_Lcd_Out+0
;POT_LCD.c,144 :: 		Lcd_Chr(1, 3 + strlen(txt), '.');
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R0, R0, #3
MOVS	R2, #46
UXTB	R1, R0
MOVS	R0, #1
BL	_Lcd_Chr+0
;POT_LCD.c,145 :: 		Lcd_Chr(1, 4 + strlen(txt), (volt_frac / 10) + '0');
MOVW	R0, #lo_addr(_volt_frac+0)
MOVT	R0, #hi_addr(_volt_frac+0)
LDRH	R1, [R0, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTH	R0, R0
ADDS	R0, #48
STRH	R0, [SP, #0]
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R1, R0, #4
LDRH	R0, [SP, #0]
UXTB	R2, R0
UXTB	R1, R1
MOVS	R0, #1
BL	_Lcd_Chr+0
;POT_LCD.c,146 :: 		Lcd_Chr(1, 5 + strlen(txt), (volt_frac % 10) + '0');
MOVW	R0, #lo_addr(_volt_frac+0)
MOVT	R0, #hi_addr(_volt_frac+0)
LDRH	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTH	R0, R0
ADDS	R0, #48
STRH	R0, [SP, #0]
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R1, R0, #5
LDRH	R0, [SP, #0]
UXTB	R2, R0
UXTB	R1, R1
MOVS	R0, #1
BL	_Lcd_Chr+0
;POT_LCD.c,147 :: 		Lcd_Out(1, 7 + strlen(txt), "V   ");
MOVW	R0, #lo_addr(?lstr2_POT_LCD+0)
MOVT	R0, #hi_addr(?lstr2_POT_LCD+0)
STR	R0, [SP, #0]
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R1, R0, #7
LDR	R0, [SP, #0]
MOV	R2, R0
UXTB	R1, R1
MOVS	R0, #1
BL	_Lcd_Out+0
;POT_LCD.c,150 :: 		Lcd_Out(2, 1, "P=");
MOVW	R0, #lo_addr(?lstr3_POT_LCD+0)
MOVT	R0, #hi_addr(?lstr3_POT_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;POT_LCD.c,152 :: 		WordToStr(pct_int, txt);
MOVW	R0, #lo_addr(_pct_int+0)
MOVT	R0, #hi_addr(_pct_int+0)
LDRH	R0, [R0, #0]
MOVW	R1, #lo_addr(_txt+0)
MOVT	R1, #hi_addr(_txt+0)
BL	_WordToStr+0
;POT_LCD.c,153 :: 		Ltrim(txt);
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_Ltrim+0
;POT_LCD.c,154 :: 		Lcd_Out(2, 3, txt);
MOVW	R2, #lo_addr(_txt+0)
MOVT	R2, #hi_addr(_txt+0)
MOVS	R1, #3
MOVS	R0, #2
BL	_Lcd_Out+0
;POT_LCD.c,156 :: 		Lcd_Chr(2, 3 + strlen(txt), '.');
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R0, R0, #3
MOVS	R2, #46
UXTB	R1, R0
MOVS	R0, #2
BL	_Lcd_Chr+0
;POT_LCD.c,157 :: 		Lcd_Chr(2, 4 + strlen(txt), pct_frac + '0');
MOVW	R0, #lo_addr(_pct_frac+0)
MOVT	R0, #hi_addr(_pct_frac+0)
LDRH	R0, [R0, #0]
ADDS	R0, #48
STRH	R0, [SP, #0]
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R1, R0, #4
LDRH	R0, [SP, #0]
UXTB	R2, R0
UXTB	R1, R1
MOVS	R0, #2
BL	_Lcd_Chr+0
;POT_LCD.c,158 :: 		Lcd_Out(2, 6 + strlen(txt), "%   ");
MOVW	R0, #lo_addr(?lstr4_POT_LCD+0)
MOVT	R0, #hi_addr(?lstr4_POT_LCD+0)
STR	R0, [SP, #0]
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R1, R0, #6
LDR	R0, [SP, #0]
MOV	R2, R0
UXTB	R1, R1
MOVS	R0, #2
BL	_Lcd_Out+0
;POT_LCD.c,160 :: 		Delay_ms(300);
MOVW	R7, #40702
MOVT	R7, #36
NOP
NOP
L_main8:
SUBS	R7, R7, #1
BNE	L_main8
NOP
NOP
NOP
;POT_LCD.c,161 :: 		}
IT	AL
BAL	L_main5
;POT_LCD.c,162 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
