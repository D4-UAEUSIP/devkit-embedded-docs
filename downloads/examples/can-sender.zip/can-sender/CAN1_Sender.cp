#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN1_Sender.c"
#line 22 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN1_Sender.c"
unsigned long Can_Init_Flags;
unsigned char Can_Send_Flags;
unsigned char Tx_Data[8];
unsigned char counter;

void main() {


 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6 | _GPIO_PINMASK_7);

 GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIOB_ODR &= ~(_GPIO_PINMASK_6 | _GPIO_PINMASK_7);


 Can_Init_Flags = 0;
 Can_Send_Flags = 0;
#line 45 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN1_Sender.c"
 Can_Send_Flags = _CAN_TX_STD_FRAME &
 _CAN_TX_NO_RTR_FRAME;
#line 51 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN1_Sender.c"
 Can_Init_Flags = _CAN_CONFIG_AUTOMATIC_RETRANSMISSION &
 _CAN_CONFIG_RX_FIFO_NOT_LOCKED_ON_OVERRUN &
 _CAN_CONFIG_TIME_TRIGGERED_MODE_DISABLED &
 _CAN_CONFIG_TX_FIFO_PRIORITY_BY_IDINTIFIER &
 _CAN_CONFIG_WAKE_UP;
#line 68 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN1_Sender.c"
 CAN1InitializeAdvanced(1, 5, 4, 4, 1, Can_Init_Flags, &_GPIO_MODULE_CAN1_PB89);


 CAN1SetOperationMode(_CAN_OperatingMode_Initialization);




 CAN1SetOperationMode(_CAN_OperatingMode_Normal);

 counter = 0;

 while(1) {
 Tx_Data[0] = counter;
 Tx_Data[1] = 0;
 Tx_Data[2] = 0;
 Tx_Data[3] = 0;
 Tx_Data[4] = 0;
 Tx_Data[5] = 0;
 Tx_Data[6] = 0;
 Tx_Data[7] = 0;


 CAN1Write(0x777, Tx_Data, 1, Can_Send_Flags);


 GPIOC_ODR ^= _GPIO_PINMASK_10;
 GPIOB_ODR ^= _GPIO_PINMASK_6;

 counter++;

 Delay_ms(1000);
 }
}
