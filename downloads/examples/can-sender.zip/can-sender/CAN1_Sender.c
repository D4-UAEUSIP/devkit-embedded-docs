/*
   ------------------------------------------------------------
   STM32F446RE - CAN transmit test
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Module Board:
   there is 4 DIP Switches Make sure it is in the CAN Side
   
   Function:
     Send CAN frame every 1 second
     ID    = 0x777
     DLC   = 1
     DATA0 = incremental counter

   Notes:
     - This is transmit only
     - Counter increments from 0 to 255 then wraps around
     - Check your actual CAN1 pin routing on the board
*/

unsigned long Can_Init_Flags;
unsigned char Can_Send_Flags;
unsigned char Tx_Data[8];
unsigned char counter;

void main() {

  // Optional LEDs for visual indication
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIOB_ODR &= ~(_GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  // Clear flags
  Can_Init_Flags = 0;
  Can_Send_Flags = 0;

  /*
     Standard data frame:
       - no extended ID
       - no RTR
  */
  Can_Send_Flags = _CAN_TX_STD_FRAME &
                   _CAN_TX_NO_RTR_FRAME;

  /*
     CAN initialization flags
  */
  Can_Init_Flags = _CAN_CONFIG_AUTOMATIC_RETRANSMISSION &
                   _CAN_CONFIG_RX_FIFO_NOT_LOCKED_ON_OVERRUN &
                   _CAN_CONFIG_TIME_TRIGGERED_MODE_DISABLED &
                   _CAN_CONFIG_TX_FIFO_PRIORITY_BY_IDINTIFIER &
                   _CAN_CONFIG_WAKE_UP;

  /*
     Initialize CAN1

     Timing values below are copied from your reference example.
     They may need adjustment depending on your APB1 clock
     and required CAN bitrate.

     Last parameter = CAN pin mapping
     Reference keeps PD0/PD1.
     Change it if your board uses another CAN1 pin pair.
  */
  CAN1InitializeAdvanced(1, 5, 4, 4, 1, Can_Init_Flags, &_GPIO_MODULE_CAN1_PB89);

  // Enter initialization mode
  CAN1SetOperationMode(_CAN_OperatingMode_Initialization);

  // No receive filter needed for transmit-only test

  // Enter normal mode
  CAN1SetOperationMode(_CAN_OperatingMode_Normal);

  counter = 0;

  while(1) {
    Tx_Data[0] = counter;
    Tx_Data[1] = 0;
    Tx_Data[2] = 0;
    Tx_Data[3] = 0;
    Tx_Data[4] = 0;
    Tx_Data[5] = 0;
    Tx_Data[6] = 0;
    Tx_Data[7] = 0;

    // Send 1-byte CAN frame with standard ID 0x777
    CAN1Write(0x777, Tx_Data, 1, Can_Send_Flags);

    // Optional LED toggle for activity indication
    GPIOC_ODR ^= _GPIO_PINMASK_10;
    GPIOB_ODR ^= _GPIO_PINMASK_6;

    counter++;

    Delay_ms(1000);
  }
}