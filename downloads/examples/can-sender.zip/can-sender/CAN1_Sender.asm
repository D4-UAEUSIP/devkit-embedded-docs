_main:
;CAN1_Sender.c,27 :: 		void main() {
;CAN1_Sender.c,30 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R1, #3072
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;CAN1_Sender.c,31 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);
MOVW	R1, #192
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;CAN1_Sender.c,33 :: 		GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
LDR	R1, [R0, #0]
MVN	R0, #3072
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
STR	R1, [R0, #0]
;CAN1_Sender.c,34 :: 		GPIOB_ODR &= ~(_GPIO_PINMASK_6  | _GPIO_PINMASK_7);
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R0, #0]
MVN	R0, #192
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
STR	R1, [R0, #0]
;CAN1_Sender.c,37 :: 		Can_Init_Flags = 0;
MOVS	R0, #0
MOVW	R2, #lo_addr(_Can_Init_Flags+0)
MOVT	R2, #hi_addr(_Can_Init_Flags+0)
STR	R0, [R2, #0]
;CAN1_Sender.c,38 :: 		Can_Send_Flags = 0;
MOVS	R0, #0
MOVW	R1, #lo_addr(_Can_Send_Flags+0)
MOVT	R1, #hi_addr(_Can_Send_Flags+0)
STRB	R0, [R1, #0]
;CAN1_Sender.c,46 :: 		_CAN_TX_NO_RTR_FRAME;
MOVS	R0, #255
STRB	R0, [R1, #0]
;CAN1_Sender.c,55 :: 		_CAN_CONFIG_WAKE_UP;
MOV	R0, #-1
STR	R0, [R2, #0]
;CAN1_Sender.c,68 :: 		CAN1InitializeAdvanced(1, 5, 4, 4, 1, Can_Init_Flags, &_GPIO_MODULE_CAN1_PB89);
MOVW	R2, #lo_addr(__GPIO_MODULE_CAN1_PB89+0)
MOVT	R2, #hi_addr(__GPIO_MODULE_CAN1_PB89+0)
MOV	R1, #-1
MOVS	R0, #1
PUSH	(R2)
PUSH	(R1)
PUSH	(R0)
MOVS	R3, #4
MOVS	R2, #4
MOVS	R1, #5
MOVS	R0, #1
BL	_CAN1InitializeAdvanced+0
ADD	SP, SP, #12
;CAN1_Sender.c,71 :: 		CAN1SetOperationMode(_CAN_OperatingMode_Initialization);
MOVS	R0, #0
BL	_CAN1SetOperationMode+0
;CAN1_Sender.c,76 :: 		CAN1SetOperationMode(_CAN_OperatingMode_Normal);
MOVS	R0, #1
BL	_CAN1SetOperationMode+0
;CAN1_Sender.c,78 :: 		counter = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_counter+0)
MOVT	R0, #hi_addr(_counter+0)
STRB	R1, [R0, #0]
;CAN1_Sender.c,80 :: 		while(1) {
L_main0:
;CAN1_Sender.c,81 :: 		Tx_Data[0] = counter;
MOVW	R0, #lo_addr(_counter+0)
MOVT	R0, #hi_addr(_counter+0)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_Tx_Data+0)
MOVT	R0, #hi_addr(_Tx_Data+0)
STRB	R1, [R0, #0]
;CAN1_Sender.c,82 :: 		Tx_Data[1] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Tx_Data+1)
MOVT	R0, #hi_addr(_Tx_Data+1)
STRB	R1, [R0, #0]
;CAN1_Sender.c,83 :: 		Tx_Data[2] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Tx_Data+2)
MOVT	R0, #hi_addr(_Tx_Data+2)
STRB	R1, [R0, #0]
;CAN1_Sender.c,84 :: 		Tx_Data[3] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Tx_Data+3)
MOVT	R0, #hi_addr(_Tx_Data+3)
STRB	R1, [R0, #0]
;CAN1_Sender.c,85 :: 		Tx_Data[4] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Tx_Data+4)
MOVT	R0, #hi_addr(_Tx_Data+4)
STRB	R1, [R0, #0]
;CAN1_Sender.c,86 :: 		Tx_Data[5] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Tx_Data+5)
MOVT	R0, #hi_addr(_Tx_Data+5)
STRB	R1, [R0, #0]
;CAN1_Sender.c,87 :: 		Tx_Data[6] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Tx_Data+6)
MOVT	R0, #hi_addr(_Tx_Data+6)
STRB	R1, [R0, #0]
;CAN1_Sender.c,88 :: 		Tx_Data[7] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Tx_Data+7)
MOVT	R0, #hi_addr(_Tx_Data+7)
STRB	R1, [R0, #0]
;CAN1_Sender.c,91 :: 		CAN1Write(0x777, Tx_Data, 1, Can_Send_Flags);
MOVW	R0, #lo_addr(_Can_Send_Flags+0)
MOVT	R0, #hi_addr(_Can_Send_Flags+0)
LDRB	R0, [R0, #0]
UXTB	R3, R0
MOVS	R2, #1
MOVW	R1, #lo_addr(_Tx_Data+0)
MOVT	R1, #hi_addr(_Tx_Data+0)
MOVW	R0, #1911
BL	_CAN1Write+0
;CAN1_Sender.c,94 :: 		GPIOC_ODR ^= _GPIO_PINMASK_10;
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
LDR	R0, [R0, #0]
EOR	R1, R0, #1024
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
STR	R1, [R0, #0]
;CAN1_Sender.c,95 :: 		GPIOB_ODR ^= _GPIO_PINMASK_6;
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
LDR	R0, [R0, #0]
EOR	R1, R0, #64
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
STR	R1, [R0, #0]
;CAN1_Sender.c,97 :: 		counter++;
MOVW	R1, #lo_addr(_counter+0)
MOVT	R1, #hi_addr(_counter+0)
LDRB	R0, [R1, #0]
ADDS	R0, R0, #1
STRB	R0, [R1, #0]
;CAN1_Sender.c,99 :: 		Delay_ms(1000);
MOVW	R7, #24915
MOVT	R7, #81
NOP
NOP
L_main2:
SUBS	R7, R7, #1
BNE	L_main2
NOP
NOP
NOP
NOP
;CAN1_Sender.c,100 :: 		}
IT	AL
BAL	L_main0
;CAN1_Sender.c,101 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
