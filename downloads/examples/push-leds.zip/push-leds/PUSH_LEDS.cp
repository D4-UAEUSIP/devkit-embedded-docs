#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/PUSH_LEDS.c"
#line 40 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/PUSH_LEDS.c"
void main() {


 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6 | _GPIO_PINMASK_7);


 GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
 GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);


 GPIOC_ODR.B10 = 0;
 GPIOC_ODR.B11 = 0;
 GPIOB_ODR.B6 = 0;
 GPIOB_ODR.B7 = 0;

 while(1) {


 if(GPIOC_IDR.B7)
 GPIOC_ODR.B11 = 1;
 else
 GPIOC_ODR.B11 = 0;


 if(GPIOC_IDR.B13)
 GPIOC_ODR.B10 = 1;
 else
 GPIOC_ODR.B10 = 0;


 if(GPIOA_IDR.B9)
 GPIOB_ODR.B6 = 1;
 else
 GPIOB_ODR.B6 = 0;


 if(GPIOA_IDR.B10)
 GPIOB_ODR.B7 = 1;
 else
 GPIOB_ODR.B7 = 0;

 Delay_ms(20);
 }
}
