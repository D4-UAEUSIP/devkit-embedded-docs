/*
   ------------------------------------------------------------
   STM32F446RE - Push Button to LED Test
   mikroC PRO for ARM
   ------------------------------------------------------------
  Switches Selection:
   on Main Board:
   SW14 : PB-EN side

   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   Push button inputs:
     PUSH4 -> PC7
     PUSH3 -> PC13
     PUSH2 -> PA10
     PUSH1 -> PA9


   LED outputs:
     LED4 -> PC11   (PUSH4)
     LED3 -> PC10   (PUSH3)
     LED2 -> PB7   (PUSH2)
     LED1 -> PB6    (PUSH1)

   Operation:
     Each push button directly controls its corresponding LED.

   Assumption:
     - Button pressed = logic HIGH
     - LED ON = logic HIGH

*/

void main() {

  /* Configure LED pins as digital outputs */
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  /* Configure push button pins as digital inputs */
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);

  /* Initial state: all LEDs OFF */
  GPIOC_ODR.B10 = 0;
  GPIOC_ODR.B11 = 0;
  GPIOB_ODR.B6  = 0;
  GPIOB_ODR.B7  = 0;

  while(1) {

    /* PUSH4 (PC7) -> LED4 (PC11) */
    if(GPIOC_IDR.B7)
      GPIOC_ODR.B11 = 1;
    else
      GPIOC_ODR.B11 = 0;

    /* PUSH3 (PC13) -> LED3 (PC10) */
    if(GPIOC_IDR.B13)
      GPIOC_ODR.B10 = 1;
    else
      GPIOC_ODR.B10 = 0;

    /* PUSH1 (PA9) -> LED1 (PB6) */
    if(GPIOA_IDR.B9)
      GPIOB_ODR.B6 = 1;
    else
      GPIOB_ODR.B6 = 0;

    /* PUSH2 (PA10) -> LED2 (PB7) */
    if(GPIOA_IDR.B10)
      GPIOB_ODR.B7 = 1;
    else
      GPIOB_ODR.B7 = 0;

    Delay_ms(20);   // simple debounce delay
  }
}