#include <__Lib_Mmc.h>

/*
  STM32F446RE - mikroC PRO for ARM
  Create UAE.TXT on SD card and write:
    United Arab Emirates
   Switches Selection:
   on Main Board:

   SW27:  SRCLK side
   SW15 : SPI-SCK
   SW17 : SER side

   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
  SD card connections from the provided schematic:
    PA4 -> SD CS   (CD/DAT3)
    PA5 -> SD CLK
    PA6 -> SD MISO (DAT0)
    PA7 -> SD MOSI (CMD)

  Notes:
    - The SD card must be formatted as FAT16.
    - mikroC MMC FAT routines work in the root directory only.
    - File name must be in DOS 8.3 format.
*/

#define FILE_ATTR_CREATE    0xA0

#define STATUS_OK               0
#define STATUS_CARD_ERROR       1
#define STATUS_FAT_ERROR        2
#define STATUS_FILE_ERROR       3
#define STATUS_CLOSE_ERROR      4
#define STATUS_VERIFY_ERROR     5

char filename[] = "UAE.TXT";
char text_to_write[] = "United Arab Emirates";
unsigned short status_code = STATUS_OK;

/* mikroC MMC library requires the chip-select symbol. */
sbit Mmc_Chip_Select at GPIOA_ODR.B4;

void Halt_On_Error(unsigned short error_code) {
  status_code = error_code;

  while(1) {
    /* Inspect status_code in the debugger if execution stops here. */
  }
}

void Init_SD_Card(void) {
  unsigned int fat_result;

  /* Configure PA4 as manual chip-select output. */
  GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_4);
  Mmc_Chip_Select = 1;

  /*
    Start with a slow SPI clock for SD-card initialization.
    SPI1 uses PA5/PA6/PA7 on STM32F446RE.
  */
  SPI1_Init_Advanced(_SPI_FPCLK_DIV256,
                     _SPI_MASTER | _SPI_8_BIT |
                     _SPI_CLK_IDLE_LOW | _SPI_FIRST_CLK_EDGE_TRANSITION |
                     _SPI_MSB_FIRST | _SPI_SS_DISABLE |
                     _SPI_SSM_ENABLE | _SPI_SSI_1,
                     &_GPIO_MODULE_SPI1_PA567);

  fat_result = Mmc_Fat_Init();
  if(fat_result == 255) {
    Halt_On_Error(STATUS_CARD_ERROR);
  }
  if(fat_result != 0) {
    Halt_On_Error(STATUS_FAT_ERROR);
  }

  /*
    After successful initialization, move to a faster SPI clock.
    Increase further only if your board and SD card remain stable.
  */
  SPI1_Init_Advanced(_SPI_FPCLK_DIV8,
                     _SPI_MASTER | _SPI_8_BIT |
                     _SPI_CLK_IDLE_LOW | _SPI_FIRST_CLK_EDGE_TRANSITION |
                     _SPI_MSB_FIRST | _SPI_SS_DISABLE |
                     _SPI_SSM_ENABLE | _SPI_SSI_1,
                     &_GPIO_MODULE_SPI1_PA567);
}

unsigned short Verify_File_Content(void) {
  unsigned int assign_result;
  unsigned long file_size;
  unsigned long i;
  unsigned short read_data;

  assign_result = Mmc_Fat_Assign(filename, 0);
  if(assign_result == 0) {
    return 0;
  }

  Mmc_Fat_Reset(&file_size);
  if(file_size != (sizeof(text_to_write) - 1)) {
    Mmc_Fat_Close();
    return 0;
  }

  for(i = 0; i < file_size; i++) {
    Mmc_Fat_Read(&read_data);
    if((char)read_data != text_to_write[i]) {
      Mmc_Fat_Close();
      return 0;
    }
  }

  if(Mmc_Fat_Close() != 0) {
    return 0;
  }

  return 1;
}

void main() {
  unsigned int assign_result;

  Init_SD_Card();

  assign_result = Mmc_Fat_Assign(filename, FILE_ATTR_CREATE);
  if(assign_result == 0) {
    Halt_On_Error(STATUS_FILE_ERROR);
  }

  Mmc_Fat_Rewrite();
  Mmc_Fat_Write(text_to_write, sizeof(text_to_write) - 1);

  if(Mmc_Fat_Close() != 0) {
    Halt_On_Error(STATUS_CLOSE_ERROR);
  }

  if(!Verify_File_Content()) {
    Halt_On_Error(STATUS_VERIFY_ERROR);
  }

  status_code = STATUS_OK;

  while(1) {
    /* Success: UAE.TXT contains "United Arab Emirates". */
  }
}