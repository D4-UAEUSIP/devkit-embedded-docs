_Halt_On_Error:
;SD_CARD.c,45 :: 		void Halt_On_Error(unsigned short error_code) {
; error_code start address is: 0 (R0)
; error_code end address is: 0 (R0)
; error_code start address is: 0 (R0)
;SD_CARD.c,46 :: 		status_code = error_code;
MOVW	R1, #lo_addr(_status_code+0)
MOVT	R1, #hi_addr(_status_code+0)
STRB	R0, [R1, #0]
; error_code end address is: 0 (R0)
;SD_CARD.c,48 :: 		while(1) {
L_Halt_On_Error0:
;SD_CARD.c,50 :: 		}
IT	AL
BAL	L_Halt_On_Error0
;SD_CARD.c,51 :: 		}
L_end_Halt_On_Error:
BX	LR
; end of _Halt_On_Error
_Init_SD_Card:
;SD_CARD.c,53 :: 		void Init_SD_Card(void) {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;SD_CARD.c,57 :: 		GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_4);
MOVW	R1, #16
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Output+0
;SD_CARD.c,58 :: 		Mmc_Chip_Select = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;SD_CARD.c,69 :: 		&_GPIO_MODULE_SPI1_PA567);
MOVW	R2, #lo_addr(__GPIO_MODULE_SPI1_PA567+0)
MOVT	R2, #hi_addr(__GPIO_MODULE_SPI1_PA567+0)
;SD_CARD.c,68 :: 		_SPI_SSM_ENABLE | _SPI_SSI_1,
MOVW	R1, #772
;SD_CARD.c,64 :: 		SPI1_Init_Advanced(_SPI_FPCLK_DIV256,
MOVS	R0, #7
;SD_CARD.c,69 :: 		&_GPIO_MODULE_SPI1_PA567);
BL	_SPI1_Init_Advanced+0
;SD_CARD.c,71 :: 		fat_result = Mmc_Fat_Init();
BL	_Mmc_Fat_Init+0
; fat_result start address is: 8 (R2)
UXTB	R2, R0
;SD_CARD.c,72 :: 		if(fat_result == 255) {
CMP	R2, #255
IT	NE
BNE	L_Init_SD_Card2
;SD_CARD.c,73 :: 		Halt_On_Error(STATUS_CARD_ERROR);
MOVS	R0, #1
BL	_Halt_On_Error+0
;SD_CARD.c,74 :: 		}
L_Init_SD_Card2:
;SD_CARD.c,75 :: 		if(fat_result != 0) {
CMP	R2, #0
IT	EQ
BEQ	L_Init_SD_Card3
; fat_result end address is: 8 (R2)
;SD_CARD.c,76 :: 		Halt_On_Error(STATUS_FAT_ERROR);
MOVS	R0, #2
BL	_Halt_On_Error+0
;SD_CARD.c,77 :: 		}
L_Init_SD_Card3:
;SD_CARD.c,88 :: 		&_GPIO_MODULE_SPI1_PA567);
MOVW	R2, #lo_addr(__GPIO_MODULE_SPI1_PA567+0)
MOVT	R2, #hi_addr(__GPIO_MODULE_SPI1_PA567+0)
;SD_CARD.c,87 :: 		_SPI_SSM_ENABLE | _SPI_SSI_1,
MOVW	R1, #772
;SD_CARD.c,83 :: 		SPI1_Init_Advanced(_SPI_FPCLK_DIV8,
MOVS	R0, #2
;SD_CARD.c,88 :: 		&_GPIO_MODULE_SPI1_PA567);
BL	_SPI1_Init_Advanced+0
;SD_CARD.c,89 :: 		}
L_end_Init_SD_Card:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Init_SD_Card
_Verify_File_Content:
;SD_CARD.c,91 :: 		unsigned short Verify_File_Content(void) {
SUB	SP, SP, #16
STR	LR, [SP, #0]
;SD_CARD.c,97 :: 		assign_result = Mmc_Fat_Assign(filename, 0);
MOVS	R1, #0
MOVW	R0, #lo_addr(_filename+0)
MOVT	R0, #hi_addr(_filename+0)
BL	_Mmc_Fat_Assign+0
; assign_result start address is: 0 (R0)
;SD_CARD.c,98 :: 		if(assign_result == 0) {
CMP	R0, #0
IT	NE
BNE	L_Verify_File_Content4
; assign_result end address is: 0 (R0)
;SD_CARD.c,99 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_Verify_File_Content
;SD_CARD.c,100 :: 		}
L_Verify_File_Content4:
;SD_CARD.c,102 :: 		Mmc_Fat_Reset(&file_size);
ADD	R0, SP, #8
BL	_Mmc_Fat_Reset+0
;SD_CARD.c,103 :: 		if(file_size != (sizeof(text_to_write) - 1)) {
LDR	R0, [SP, #8]
CMP	R0, #20
IT	EQ
BEQ	L_Verify_File_Content5
;SD_CARD.c,104 :: 		Mmc_Fat_Close();
BL	_Mmc_Fat_Close+0
;SD_CARD.c,105 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_Verify_File_Content
;SD_CARD.c,106 :: 		}
L_Verify_File_Content5:
;SD_CARD.c,108 :: 		for(i = 0; i < file_size; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
L_Verify_File_Content6:
; i start address is: 8 (R2)
LDR	R0, [SP, #8]
CMP	R2, R0
IT	CS
BCS	L_Verify_File_Content7
;SD_CARD.c,109 :: 		Mmc_Fat_Read(&read_data);
ADD	R0, SP, #12
STR	R2, [SP, #4]
BL	_Mmc_Fat_Read+0
LDR	R2, [SP, #4]
;SD_CARD.c,110 :: 		if((char)read_data != text_to_write[i]) {
MOVW	R0, #lo_addr(_text_to_write+0)
MOVT	R0, #hi_addr(_text_to_write+0)
ADDS	R0, R0, R2
LDRB	R1, [R0, #0]
LDRB	R0, [SP, #12]
CMP	R0, R1
IT	EQ
BEQ	L_Verify_File_Content9
; i end address is: 8 (R2)
;SD_CARD.c,111 :: 		Mmc_Fat_Close();
BL	_Mmc_Fat_Close+0
;SD_CARD.c,112 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_Verify_File_Content
;SD_CARD.c,113 :: 		}
L_Verify_File_Content9:
;SD_CARD.c,108 :: 		for(i = 0; i < file_size; i++) {
; i start address is: 8 (R2)
ADDS	R2, R2, #1
;SD_CARD.c,114 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_Verify_File_Content6
L_Verify_File_Content7:
;SD_CARD.c,116 :: 		if(Mmc_Fat_Close() != 0) {
BL	_Mmc_Fat_Close+0
CMP	R0, #0
IT	EQ
BEQ	L_Verify_File_Content10
;SD_CARD.c,117 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_Verify_File_Content
;SD_CARD.c,118 :: 		}
L_Verify_File_Content10:
;SD_CARD.c,120 :: 		return 1;
MOVS	R0, #1
;SD_CARD.c,121 :: 		}
L_end_Verify_File_Content:
LDR	LR, [SP, #0]
ADD	SP, SP, #16
BX	LR
; end of _Verify_File_Content
_main:
;SD_CARD.c,123 :: 		void main() {
;SD_CARD.c,126 :: 		Init_SD_Card();
BL	_Init_SD_Card+0
;SD_CARD.c,128 :: 		assign_result = Mmc_Fat_Assign(filename, FILE_ATTR_CREATE);
MOVS	R1, #160
MOVW	R0, #lo_addr(_filename+0)
MOVT	R0, #hi_addr(_filename+0)
BL	_Mmc_Fat_Assign+0
; assign_result start address is: 0 (R0)
;SD_CARD.c,129 :: 		if(assign_result == 0) {
CMP	R0, #0
IT	NE
BNE	L_main11
; assign_result end address is: 0 (R0)
;SD_CARD.c,130 :: 		Halt_On_Error(STATUS_FILE_ERROR);
MOVS	R0, #3
BL	_Halt_On_Error+0
;SD_CARD.c,131 :: 		}
L_main11:
;SD_CARD.c,133 :: 		Mmc_Fat_Rewrite();
BL	_Mmc_Fat_Rewrite+0
;SD_CARD.c,134 :: 		Mmc_Fat_Write(text_to_write, sizeof(text_to_write) - 1);
MOVW	R1, #20
MOVW	R0, #lo_addr(_text_to_write+0)
MOVT	R0, #hi_addr(_text_to_write+0)
BL	_Mmc_Fat_Write+0
;SD_CARD.c,136 :: 		if(Mmc_Fat_Close() != 0) {
BL	_Mmc_Fat_Close+0
CMP	R0, #0
IT	EQ
BEQ	L_main12
;SD_CARD.c,137 :: 		Halt_On_Error(STATUS_CLOSE_ERROR);
MOVS	R0, #4
BL	_Halt_On_Error+0
;SD_CARD.c,138 :: 		}
L_main12:
;SD_CARD.c,140 :: 		if(!Verify_File_Content()) {
BL	_Verify_File_Content+0
CMP	R0, #0
IT	NE
BNE	L_main13
;SD_CARD.c,141 :: 		Halt_On_Error(STATUS_VERIFY_ERROR);
MOVS	R0, #5
BL	_Halt_On_Error+0
;SD_CARD.c,142 :: 		}
L_main13:
;SD_CARD.c,144 :: 		status_code = STATUS_OK;
MOVS	R1, #0
MOVW	R0, #lo_addr(_status_code+0)
MOVT	R0, #hi_addr(_status_code+0)
STRB	R1, [R0, #0]
;SD_CARD.c,146 :: 		while(1) {
L_main14:
;SD_CARD.c,148 :: 		}
IT	AL
BAL	L_main14
;SD_CARD.c,149 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
