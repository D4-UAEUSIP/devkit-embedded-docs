#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/SD_CARD.c"
#line 1 "c:/users/public/documents/mikroelektronika/mikroc pro for arm/uses/st m4/__lib_mmc.h"

typedef struct
{
 unsigned long cmd_timeout;
 unsigned long spi_timeout;
 unsigned long init_timeout;
} Mmc_Timeout_Values;
#line 38 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/SD_CARD.c"
char filename[] = "UAE.TXT";
char text_to_write[] = "United Arab Emirates";
unsigned short status_code =  0 ;


sbit Mmc_Chip_Select at GPIOA_ODR.B4;

void Halt_On_Error(unsigned short error_code) {
 status_code = error_code;

 while(1) {

 }
}

void Init_SD_Card(void) {
 unsigned int fat_result;


 GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_4);
 Mmc_Chip_Select = 1;
#line 64 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/SD_CARD.c"
 SPI1_Init_Advanced(_SPI_FPCLK_DIV256,
 _SPI_MASTER | _SPI_8_BIT |
 _SPI_CLK_IDLE_LOW | _SPI_FIRST_CLK_EDGE_TRANSITION |
 _SPI_MSB_FIRST | _SPI_SS_DISABLE |
 _SPI_SSM_ENABLE | _SPI_SSI_1,
 &_GPIO_MODULE_SPI1_PA567);

 fat_result = Mmc_Fat_Init();
 if(fat_result == 255) {
 Halt_On_Error( 1 );
 }
 if(fat_result != 0) {
 Halt_On_Error( 2 );
 }
#line 83 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/SD_CARD.c"
 SPI1_Init_Advanced(_SPI_FPCLK_DIV8,
 _SPI_MASTER | _SPI_8_BIT |
 _SPI_CLK_IDLE_LOW | _SPI_FIRST_CLK_EDGE_TRANSITION |
 _SPI_MSB_FIRST | _SPI_SS_DISABLE |
 _SPI_SSM_ENABLE | _SPI_SSI_1,
 &_GPIO_MODULE_SPI1_PA567);
}

unsigned short Verify_File_Content(void) {
 unsigned int assign_result;
 unsigned long file_size;
 unsigned long i;
 unsigned short read_data;

 assign_result = Mmc_Fat_Assign(filename, 0);
 if(assign_result == 0) {
 return 0;
 }

 Mmc_Fat_Reset(&file_size);
 if(file_size != (sizeof(text_to_write) - 1)) {
 Mmc_Fat_Close();
 return 0;
 }

 for(i = 0; i < file_size; i++) {
 Mmc_Fat_Read(&read_data);
 if((char)read_data != text_to_write[i]) {
 Mmc_Fat_Close();
 return 0;
 }
 }

 if(Mmc_Fat_Close() != 0) {
 return 0;
 }

 return 1;
}

void main() {
 unsigned int assign_result;

 Init_SD_Card();

 assign_result = Mmc_Fat_Assign(filename,  0xA0 );
 if(assign_result == 0) {
 Halt_On_Error( 3 );
 }

 Mmc_Fat_Rewrite();
 Mmc_Fat_Write(text_to_write, sizeof(text_to_write) - 1);

 if(Mmc_Fat_Close() != 0) {
 Halt_On_Error( 4 );
 }

 if(!Verify_File_Content()) {
 Halt_On_Error( 5 );
 }

 status_code =  0 ;

 while(1) {

 }
}
