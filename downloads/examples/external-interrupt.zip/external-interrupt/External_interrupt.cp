#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/External_interrupt.c"
#line 14 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/External_interrupt.c"
void EXTI15_10_ISR() iv IVT_INT_EXTI15_10 ics ICS_AUTO {
 if (EXTI_PR.B13) {
  GPIOB_ODR.B6  = 1;
 Delay_ms(250);
  GPIOB_ODR.B6  = 0;
 Delay_ms(250);
  GPIOB_ODR.B6  = 1;
 Delay_ms(250);
  GPIOB_ODR.B6  = 0;
 Delay_ms(250);

 EXTI_PR.B13 = 1;
 }
}

void main() {
 DisableInterrupts();

 RCC_AHB1ENR.B1 = 1;
 RCC_AHB1ENR.B2 = 1;
 SYSCFGEN_bit = 1;

 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6);
 GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_13);

  GPIOB_ODR.B6  = 0;

 SYSCFG_EXTICR4 &= 0xFF0F;
 SYSCFG_EXTICR4 |= 0x0020;
#line 52 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/External_interrupt.c"
 EXTI_IMR.B13 = 1;
 EXTI_FTSR.B13 = 0;
 EXTI_RTSR.B13 = 1;
 EXTI_PR.B13 = 1;


 NVIC_IntEnable(IVT_INT_EXTI15_10);
 EnableInterrupts();

 while (1) {
 }
}
