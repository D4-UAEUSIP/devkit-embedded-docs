_EXTI15_10_ISR:
;External_interrupt.c,14 :: 		void EXTI15_10_ISR() iv IVT_INT_EXTI15_10 ics ICS_AUTO {
;External_interrupt.c,15 :: 		if (EXTI_PR.B13) {          // check EXTI13 pending flag
MOVW	R0, #lo_addr(EXTI_PR+0)
MOVT	R0, #hi_addr(EXTI_PR+0)
_LX	[R0, ByteOffset(EXTI_PR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_EXTI15_10_ISR0
;External_interrupt.c,16 :: 		LED = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;External_interrupt.c,17 :: 		Delay_ms(250);
MOVW	R7, #22611
MOVT	R7, #20
NOP
NOP
L_EXTI15_10_ISR1:
SUBS	R7, R7, #1
BNE	L_EXTI15_10_ISR1
NOP
NOP
NOP
NOP
;External_interrupt.c,18 :: 		LED = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;External_interrupt.c,19 :: 		Delay_ms(250);
MOVW	R7, #22611
MOVT	R7, #20
NOP
NOP
L_EXTI15_10_ISR3:
SUBS	R7, R7, #1
BNE	L_EXTI15_10_ISR3
NOP
NOP
NOP
NOP
;External_interrupt.c,20 :: 		LED = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;External_interrupt.c,21 :: 		Delay_ms(250);
MOVW	R7, #22611
MOVT	R7, #20
NOP
NOP
L_EXTI15_10_ISR5:
SUBS	R7, R7, #1
BNE	L_EXTI15_10_ISR5
NOP
NOP
NOP
NOP
;External_interrupt.c,22 :: 		LED = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;External_interrupt.c,23 :: 		Delay_ms(250);
MOVW	R7, #22611
MOVT	R7, #20
NOP
NOP
L_EXTI15_10_ISR7:
SUBS	R7, R7, #1
BNE	L_EXTI15_10_ISR7
NOP
NOP
NOP
NOP
;External_interrupt.c,25 :: 		EXTI_PR.B13 = 1;        // clear EXTI13 pending flag
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(EXTI_PR+0)
MOVT	R0, #hi_addr(EXTI_PR+0)
_SX	[R0, ByteOffset(EXTI_PR+0)]
;External_interrupt.c,26 :: 		}
L_EXTI15_10_ISR0:
;External_interrupt.c,27 :: 		}
L_end_EXTI15_10_ISR:
BX	LR
; end of _EXTI15_10_ISR
_main:
;External_interrupt.c,29 :: 		void main() {
;External_interrupt.c,30 :: 		DisableInterrupts();
BL	_DisableInterrupts+0
;External_interrupt.c,32 :: 		RCC_AHB1ENR.B1 = 1;         // enable GPIOB clock
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
_SX	[R0, ByteOffset(RCC_AHB1ENR+0)]
;External_interrupt.c,33 :: 		RCC_AHB1ENR.B2 = 1;         // enable GPIOC clock
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
_SX	[R0, ByteOffset(RCC_AHB1ENR+0)]
;External_interrupt.c,34 :: 		SYSCFGEN_bit = 1;           // enable SYSCFG clock
MOVW	R0, #lo_addr(SYSCFGEN_bit+0)
MOVT	R0, #hi_addr(SYSCFGEN_bit+0)
_SX	[R0, ByteOffset(SYSCFGEN_bit+0)]
;External_interrupt.c,36 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6);    // PB6 as output
MOVW	R1, #64
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;External_interrupt.c,37 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_13);    // PC13 as input
MOVW	R1, #8192
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;External_interrupt.c,39 :: 		LED = 0;
MOVS	R2, #0
SXTB	R2, R2
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;External_interrupt.c,41 :: 		SYSCFG_EXTICR4 &= 0xFF0F;   // clear EXTI13[7:4]
MOVW	R0, #lo_addr(SYSCFG_EXTICR4+0)
MOVT	R0, #hi_addr(SYSCFG_EXTICR4+0)
LDR	R1, [R0, #0]
MOVW	R0, #65295
ANDS	R1, R0
MOVW	R0, #lo_addr(SYSCFG_EXTICR4+0)
MOVT	R0, #hi_addr(SYSCFG_EXTICR4+0)
STR	R1, [R0, #0]
;External_interrupt.c,42 :: 		SYSCFG_EXTICR4 |= 0x0020;   // EXTI13 mapped to Port C
MOVW	R0, #lo_addr(SYSCFG_EXTICR4+0)
MOVT	R0, #hi_addr(SYSCFG_EXTICR4+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #32
MOVW	R0, #lo_addr(SYSCFG_EXTICR4+0)
MOVT	R0, #hi_addr(SYSCFG_EXTICR4+0)
STR	R1, [R0, #0]
;External_interrupt.c,52 :: 		EXTI_IMR.B13  = 1;   // unmask EXTI13
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(EXTI_IMR+0)
MOVT	R0, #hi_addr(EXTI_IMR+0)
_SX	[R0, ByteOffset(EXTI_IMR+0)]
;External_interrupt.c,53 :: 		EXTI_FTSR.B13 = 0;   // disable falling-edge trigger
MOVW	R0, #lo_addr(EXTI_FTSR+0)
MOVT	R0, #hi_addr(EXTI_FTSR+0)
_SX	[R0, ByteOffset(EXTI_FTSR+0)]
;External_interrupt.c,54 :: 		EXTI_RTSR.B13 = 1;   // enable rising-edge trigger
MOVW	R0, #lo_addr(EXTI_RTSR+0)
MOVT	R0, #hi_addr(EXTI_RTSR+0)
_SX	[R0, ByteOffset(EXTI_RTSR+0)]
;External_interrupt.c,55 :: 		EXTI_PR.B13   = 1;   // clear any pending flag
MOVW	R0, #lo_addr(EXTI_PR+0)
MOVT	R0, #hi_addr(EXTI_PR+0)
_SX	[R0, ByteOffset(EXTI_PR+0)]
;External_interrupt.c,58 :: 		NVIC_IntEnable(IVT_INT_EXTI15_10);
MOVW	R0, #56
BL	_NVIC_IntEnable+0
;External_interrupt.c,59 :: 		EnableInterrupts();
BL	_EnableInterrupts+0
;External_interrupt.c,61 :: 		while (1) {
L_main9:
;External_interrupt.c,62 :: 		}
IT	AL
BAL	L_main9
;External_interrupt.c,63 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
