/*
 * MikroC for ARM version
 * PC13 -> external interrupt input
 * PB6  -> LED output
   Switches Selection:
   SW13 : if you wnat uset INT pin in the MIKROBUS1 select EX-INT side
          if you want to use PB3 Select KP-R2
          

 */

#define LED GPIOB_ODR.B6

void EXTI15_10_ISR() iv IVT_INT_EXTI15_10 ics ICS_AUTO {
    if (EXTI_PR.B13) {          // check EXTI13 pending flag
        LED = 1;
        Delay_ms(250);
        LED = 0;
        Delay_ms(250);
        LED = 1;
        Delay_ms(250);
        LED = 0;
        Delay_ms(250);

        EXTI_PR.B13 = 1;        // clear EXTI13 pending flag
    }
}

void main() {
    DisableInterrupts();

    RCC_AHB1ENR.B1 = 1;         // enable GPIOB clock
    RCC_AHB1ENR.B2 = 1;         // enable GPIOC clock
    SYSCFGEN_bit = 1;           // enable SYSCFG clock

    GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6);    // PB6 as output
    GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_13);    // PC13 as input

    LED = 0;

    SYSCFG_EXTICR4 &= 0xFF0F;   // clear EXTI13[7:4]
    SYSCFG_EXTICR4 |= 0x0020;   // EXTI13 mapped to Port C
    
    //if you want falling-edge trigger
    /*EXTI_IMR.B13  = 1;          // unmask EXTI13
    EXTI_FTSR.B13 = 1;          // falling-edge trigger
    EXTI_RTSR.B13 = 0;          // disable rising-edge trigger
    EXTI_PR.B13   = 1;          // clear any pending flag  */
    
    //if you want rising-edge trigger

    EXTI_IMR.B13  = 1;   // unmask EXTI13
    EXTI_FTSR.B13 = 0;   // disable falling-edge trigger
    EXTI_RTSR.B13 = 1;   // enable rising-edge trigger
    EXTI_PR.B13   = 1;   // clear any pending flag


    NVIC_IntEnable(IVT_INT_EXTI15_10);
    EnableInterrupts();

    while (1) {
    }
}