_delayMs_soft:
;Demo_Test.c,140 :: 		void delayMs_soft(unsigned int n) {
; n start address is: 0 (R0)
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;Demo_Test.c,142 :: 		for(; n > 0; n--) {
L_delayMs_soft0:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs_soft1
;Demo_Test.c,143 :: 		for(i = 0; i < 3195; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs_soft3:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
MOVW	R1, #3195
CMP	R2, R1
IT	CS
BCS	L_delayMs_soft4
;Demo_Test.c,144 :: 		asm nop;
NOP
;Demo_Test.c,143 :: 		for(i = 0; i < 3195; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;Demo_Test.c,145 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs_soft3
L_delayMs_soft4:
;Demo_Test.c,142 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;Demo_Test.c,146 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs_soft0
L_delayMs_soft1:
;Demo_Test.c,147 :: 		}
L_end_delayMs_soft:
BX	LR
; end of _delayMs_soft
_my_strlen:
;Demo_Test.c,150 :: 		unsigned short my_strlen(char *s) {
; s start address is: 0 (R0)
MOV	R1, R0
; s end address is: 0 (R0)
; s start address is: 4 (R1)
;Demo_Test.c,151 :: 		unsigned short len = 0;
; len start address is: 0 (R0)
MOVS	R0, #0
; s end address is: 4 (R1)
; len end address is: 0 (R0)
UXTB	R2, R0
MOV	R0, R1
;Demo_Test.c,152 :: 		while(s[len] != 0) len++;
L_my_strlen6:
; len start address is: 8 (R2)
; s start address is: 0 (R0)
ADDS	R1, R0, R2
LDRB	R1, [R1, #0]
CMP	R1, #0
IT	EQ
BEQ	L_my_strlen7
ADDS	R2, R2, #1
UXTB	R2, R2
; s end address is: 0 (R0)
IT	AL
BAL	L_my_strlen6
L_my_strlen7:
;Demo_Test.c,153 :: 		return len;
UXTB	R0, R2
; len end address is: 8 (R2)
;Demo_Test.c,154 :: 		}
L_end_my_strlen:
BX	LR
; end of _my_strlen
_clear16:
;Demo_Test.c,156 :: 		void clear16(char *s) {
; s start address is: 0 (R0)
; s end address is: 0 (R0)
; s start address is: 0 (R0)
;Demo_Test.c,158 :: 		for(i = 0; i < 16; i++) s[i] = ' ';
; i start address is: 12 (R3)
MOVS	R3, #0
; s end address is: 0 (R0)
; i end address is: 12 (R3)
L_clear168:
; i start address is: 12 (R3)
; s start address is: 0 (R0)
CMP	R3, #16
IT	CS
BCS	L_clear169
ADDS	R2, R0, R3
MOVS	R1, #32
STRB	R1, [R2, #0]
ADDS	R3, R3, #1
UXTB	R3, R3
; i end address is: 12 (R3)
IT	AL
BAL	L_clear168
L_clear169:
;Demo_Test.c,159 :: 		s[16] = 0;
ADDW	R2, R0, #16
; s end address is: 0 (R0)
MOVS	R1, #0
STRB	R1, [R2, #0]
;Demo_Test.c,160 :: 		}
L_end_clear16:
BX	LR
; end of _clear16
_center_text:
;Demo_Test.c,162 :: 		void center_text(char *dst16, char *src) {
; src start address is: 4 (R1)
; dst16 start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
MOV	R4, R0
MOV	R5, R1
; src end address is: 4 (R1)
; dst16 end address is: 0 (R0)
; dst16 start address is: 16 (R4)
; src start address is: 20 (R5)
;Demo_Test.c,165 :: 		clear16(dst16);
MOV	R0, R4
BL	_clear16+0
;Demo_Test.c,166 :: 		len = my_strlen(src);
MOV	R0, R5
BL	_my_strlen+0
; len start address is: 4 (R1)
UXTB	R1, R0
;Demo_Test.c,168 :: 		if(len >= 16) {
CMP	R0, #16
IT	CC
BCC	L_center_text11
; len end address is: 4 (R1)
;Demo_Test.c,169 :: 		for(i = 0; i < 16; i++) dst16[i] = src[i];
; i start address is: 0 (R0)
MOVS	R0, #0
; dst16 end address is: 16 (R4)
; i end address is: 0 (R0)
; src end address is: 20 (R5)
MOV	R1, R5
L_center_text12:
; i start address is: 0 (R0)
; src start address is: 4 (R1)
; src start address is: 4 (R1)
; src end address is: 4 (R1)
; dst16 start address is: 16 (R4)
CMP	R0, #16
IT	CS
BCS	L_center_text13
; src end address is: 4 (R1)
; src start address is: 4 (R1)
ADDS	R3, R4, R0
ADDS	R2, R1, R0
LDRB	R2, [R2, #0]
STRB	R2, [R3, #0]
ADDS	R0, R0, #1
UXTB	R0, R0
; src end address is: 4 (R1)
; i end address is: 0 (R0)
IT	AL
BAL	L_center_text12
L_center_text13:
;Demo_Test.c,170 :: 		dst16[16] = 0;
ADDW	R3, R4, #16
; dst16 end address is: 16 (R4)
MOVS	R2, #0
STRB	R2, [R3, #0]
;Demo_Test.c,171 :: 		return;
IT	AL
BAL	L_end_center_text
;Demo_Test.c,172 :: 		}
L_center_text11:
;Demo_Test.c,174 :: 		start = (16 - len) / 2;
; src start address is: 20 (R5)
; len start address is: 4 (R1)
; dst16 start address is: 16 (R4)
RSB	R3, R1, #16
SXTH	R3, R3
MOVS	R2, #2
SXTH	R2, R2
SDIV	R2, R3, R2
; start start address is: 8 (R2)
UXTB	R2, R2
;Demo_Test.c,176 :: 		for(i = 0; i < len; i++) {
; i start address is: 0 (R0)
MOVS	R0, #0
; dst16 end address is: 16 (R4)
; start end address is: 8 (R2)
; i end address is: 0 (R0)
; len end address is: 4 (R1)
MOV	R6, R4
UXTB	R4, R0
UXTB	R0, R2
L_center_text15:
; i start address is: 16 (R4)
; dst16 start address is: 24 (R6)
; start start address is: 0 (R0)
; start start address is: 0 (R0)
; start end address is: 0 (R0)
; len start address is: 4 (R1)
; src start address is: 20 (R5)
; src end address is: 20 (R5)
; dst16 start address is: 24 (R6)
; dst16 end address is: 24 (R6)
CMP	R4, R1
IT	CS
BCS	L_center_text16
; start end address is: 0 (R0)
; src end address is: 20 (R5)
; dst16 end address is: 24 (R6)
;Demo_Test.c,177 :: 		dst16[start + i] = src[i];
; dst16 start address is: 24 (R6)
; src start address is: 20 (R5)
; start start address is: 0 (R0)
ADDS	R2, R0, R4
SXTH	R2, R2
ADDS	R3, R6, R2
ADDS	R2, R5, R4
LDRB	R2, [R2, #0]
STRB	R2, [R3, #0]
;Demo_Test.c,176 :: 		for(i = 0; i < len; i++) {
ADDS	R4, R4, #1
UXTB	R4, R4
;Demo_Test.c,178 :: 		}
; start end address is: 0 (R0)
; len end address is: 4 (R1)
; src end address is: 20 (R5)
; dst16 end address is: 24 (R6)
; i end address is: 16 (R4)
IT	AL
BAL	L_center_text15
L_center_text16:
;Demo_Test.c,179 :: 		}
L_end_center_text:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _center_text
_lcd_show_centered:
;Demo_Test.c,181 :: 		void lcd_show_centered(char *line1, char *line2) {
; line2 start address is: 4 (R1)
; line1 start address is: 0 (R0)
SUB	SP, SP, #40
STR	LR, [SP, #0]
MOV	R7, R1
; line2 end address is: 4 (R1)
; line1 end address is: 0 (R0)
; line1 start address is: 0 (R0)
; line2 start address is: 28 (R7)
;Demo_Test.c,185 :: 		center_text(buf1, line1);
ADD	R2, SP, #4
MOV	R1, R0
; line1 end address is: 0 (R0)
MOV	R0, R2
BL	_center_text+0
;Demo_Test.c,186 :: 		center_text(buf2, line2);
ADD	R2, SP, #21
MOV	R1, R7
; line2 end address is: 28 (R7)
MOV	R0, R2
BL	_center_text+0
;Demo_Test.c,188 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Demo_Test.c,189 :: 		Lcd_Out(1, 1, buf1);
ADD	R2, SP, #4
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;Demo_Test.c,190 :: 		Lcd_Out(2, 1, buf2);
ADD	R2, SP, #21
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;Demo_Test.c,191 :: 		}
L_end_lcd_show_centered:
LDR	LR, [SP, #0]
ADD	SP, SP, #40
BX	LR
; end of _lcd_show_centered
_leds_all_off:
;Demo_Test.c,194 :: 		void leds_all_off() {
;Demo_Test.c,195 :: 		GPIOC_ODR.B10 = 0;   /* LED1 */
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Demo_Test.c,196 :: 		GPIOC_ODR.B11 = 0;   /* LED2 */
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Demo_Test.c,197 :: 		GPIOB_ODR.B6  = 0;   /* LED3 */
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Demo_Test.c,198 :: 		GPIOB_ODR.B7  = 0;   /* LED4 */
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Demo_Test.c,199 :: 		}
L_end_leds_all_off:
BX	LR
; end of _leds_all_off
_led_on:
;Demo_Test.c,201 :: 		void led_on(unsigned char idx) {
; idx start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R2, R0
; idx end address is: 0 (R0)
; idx start address is: 8 (R2)
;Demo_Test.c,202 :: 		leds_all_off();
BL	_leds_all_off+0
;Demo_Test.c,204 :: 		switch(idx) {
IT	AL
BAL	L_led_on18
; idx end address is: 8 (R2)
;Demo_Test.c,205 :: 		case 1: GPIOB_ODR.B6  = 1;  break; /* LED1 */
L_led_on20:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
_SX	[R1, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_led_on19
;Demo_Test.c,206 :: 		case 2: GPIOB_ODR.B7  = 1;  break; /* LED2 */
L_led_on21:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
_SX	[R1, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_led_on19
;Demo_Test.c,207 :: 		case 3: GPIOC_ODR.B10 = 1;  break; /* LED3 */
L_led_on22:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_led_on19
;Demo_Test.c,208 :: 		case 4: GPIOC_ODR.B11 = 1;  break; /* LED4 */
L_led_on23:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_led_on19
;Demo_Test.c,209 :: 		}
L_led_on18:
; idx start address is: 8 (R2)
CMP	R2, #1
IT	EQ
BEQ	L_led_on20
CMP	R2, #2
IT	EQ
BEQ	L_led_on21
CMP	R2, #3
IT	EQ
BEQ	L_led_on22
CMP	R2, #4
IT	EQ
BEQ	L_led_on23
; idx end address is: 8 (R2)
L_led_on19:
;Demo_Test.c,210 :: 		}
L_end_led_on:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _led_on
_map_push_to_leds:
;Demo_Test.c,212 :: 		void map_push_to_leds() {
;Demo_Test.c,218 :: 		GPIOC_ODR.B10 = GPIOC_IDR.B13;
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Demo_Test.c,219 :: 		GPIOC_ODR.B11 = GPIOC_IDR.B7;
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Demo_Test.c,220 :: 		GPIOB_ODR.B6  = GPIOA_IDR.B9;
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Demo_Test.c,221 :: 		GPIOB_ODR.B7  = GPIOA_IDR.B10;
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Demo_Test.c,222 :: 		}
L_end_map_push_to_leds:
BX	LR
; end of _map_push_to_leds
_Keypad_AllColumns_Low:
;Demo_Test.c,224 :: 		void Keypad_AllColumns_Low() {
;Demo_Test.c,225 :: 		GPIOC_ODR.B12 = 0;   /* C1 */
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Demo_Test.c,226 :: 		GPIOC_ODR.B1  = 0;   /* C2 */
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Demo_Test.c,227 :: 		GPIOB_ODR.B2  = 0;   /* C3 */
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Demo_Test.c,228 :: 		GPIOD_ODR.B2  = 0;   /* C4 */
MOVW	R0, #lo_addr(GPIOD_ODR+0)
MOVT	R0, #hi_addr(GPIOD_ODR+0)
_SX	[R0, ByteOffset(GPIOD_ODR+0)]
;Demo_Test.c,229 :: 		}
L_end_Keypad_AllColumns_Low:
BX	LR
; end of _Keypad_AllColumns_Low
_Keypad_SelectColumn:
;Demo_Test.c,231 :: 		void Keypad_SelectColumn(unsigned short col) {
; col start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R2, R0
; col end address is: 0 (R0)
; col start address is: 8 (R2)
;Demo_Test.c,232 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Demo_Test.c,234 :: 		switch(col) {
IT	AL
BAL	L_Keypad_SelectColumn24
; col end address is: 8 (R2)
;Demo_Test.c,235 :: 		case 0: GPIOC_ODR.B12 = 1; break;   /* C1 */
L_Keypad_SelectColumn26:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn25
;Demo_Test.c,236 :: 		case 1: GPIOC_ODR.B1  = 1; break;   /* C2 */
L_Keypad_SelectColumn27:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn25
;Demo_Test.c,237 :: 		case 2: GPIOB_ODR.B2  = 1; break;   /* C3 */
L_Keypad_SelectColumn28:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
_SX	[R1, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn25
;Demo_Test.c,238 :: 		case 3: GPIOD_ODR.B2  = 1; break;   /* C4 */
L_Keypad_SelectColumn29:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOD_ODR+0)
MOVT	R1, #hi_addr(GPIOD_ODR+0)
_SX	[R1, ByteOffset(GPIOD_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn25
;Demo_Test.c,239 :: 		}
L_Keypad_SelectColumn24:
; col start address is: 8 (R2)
CMP	R2, #0
IT	EQ
BEQ	L_Keypad_SelectColumn26
CMP	R2, #1
IT	EQ
BEQ	L_Keypad_SelectColumn27
CMP	R2, #2
IT	EQ
BEQ	L_Keypad_SelectColumn28
CMP	R2, #3
IT	EQ
BEQ	L_Keypad_SelectColumn29
; col end address is: 8 (R2)
L_Keypad_SelectColumn25:
;Demo_Test.c,240 :: 		}
L_end_Keypad_SelectColumn:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_SelectColumn
_Keypad_ReadRow:
;Demo_Test.c,242 :: 		unsigned short Keypad_ReadRow() {
;Demo_Test.c,243 :: 		if(GPIOC_IDR.B7  == 1) return 0;   /* R1 */
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow30
MOVS	R0, #0
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow30:
;Demo_Test.c,244 :: 		if(GPIOC_IDR.B13 == 1) return 1;   /* R2 */
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow31
MOVS	R0, #1
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow31:
;Demo_Test.c,245 :: 		if(GPIOA_IDR.B9  == 1) return 2;   /* R3 */
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow32
MOVS	R0, #2
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow32:
;Demo_Test.c,246 :: 		if(GPIOA_IDR.B10 == 1) return 3;   /* R4 */
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow33
MOVS	R0, #3
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow33:
;Demo_Test.c,248 :: 		return 255;
MOVS	R0, #255
;Demo_Test.c,249 :: 		}
L_end_Keypad_ReadRow:
BX	LR
; end of _Keypad_ReadRow
_Keypad_GetKey:
;Demo_Test.c,251 :: 		char Keypad_GetKey() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,254 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
MOVS	R3, #0
; col end address is: 12 (R3)
L_Keypad_GetKey34:
; col start address is: 12 (R3)
CMP	R3, #4
IT	CS
BCS	L_Keypad_GetKey35
;Demo_Test.c,255 :: 		Keypad_SelectColumn(col);
UXTB	R0, R3
BL	_Keypad_SelectColumn+0
;Demo_Test.c,256 :: 		Delay_ms(1);
MOVW	R7, #5331
MOVT	R7, #0
NOP
NOP
L_Keypad_GetKey37:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey37
NOP
NOP
NOP
NOP
;Demo_Test.c,258 :: 		row = Keypad_ReadRow();
BL	_Keypad_ReadRow+0
; row start address is: 8 (R2)
UXTB	R2, R0
;Demo_Test.c,259 :: 		if(row != 255) {
CMP	R0, #255
IT	EQ
BEQ	L_Keypad_GetKey39
;Demo_Test.c,260 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Demo_Test.c,261 :: 		return keymap[row][col];
LSLS	R1, R2, #2
; row end address is: 8 (R2)
MOVW	R0, #lo_addr(_keymap+0)
MOVT	R0, #hi_addr(_keymap+0)
ADDS	R0, R0, R1
ADDS	R0, R0, R3
; col end address is: 12 (R3)
LDRB	R0, [R0, #0]
IT	AL
BAL	L_end_Keypad_GetKey
;Demo_Test.c,262 :: 		}
L_Keypad_GetKey39:
;Demo_Test.c,254 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
ADDS	R3, R3, #1
UXTB	R3, R3
;Demo_Test.c,263 :: 		}
; col end address is: 12 (R3)
IT	AL
BAL	L_Keypad_GetKey34
L_Keypad_GetKey35:
;Demo_Test.c,265 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Demo_Test.c,266 :: 		return 0;
MOVS	R0, #0
;Demo_Test.c,267 :: 		}
L_end_Keypad_GetKey:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_GetKey
_Keypad_GetKey_Click:
;Demo_Test.c,269 :: 		char Keypad_GetKey_Click() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,272 :: 		while(1) {
L_Keypad_GetKey_Click40:
;Demo_Test.c,273 :: 		key = Keypad_GetKey();
BL	_Keypad_GetKey+0
; key start address is: 16 (R4)
UXTB	R4, R0
;Demo_Test.c,274 :: 		if(key != 0) {
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_GetKey_Click42
;Demo_Test.c,275 :: 		Delay_ms(20);
MOVW	R7, #41129
MOVT	R7, #1
NOP
NOP
L_Keypad_GetKey_Click43:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click43
NOP
NOP
;Demo_Test.c,276 :: 		if(Keypad_GetKey() == key) {
BL	_Keypad_GetKey+0
CMP	R0, R4
IT	NE
BNE	L_Keypad_GetKey_Click45
; key end address is: 16 (R4)
;Demo_Test.c,277 :: 		while(Keypad_GetKey() != 0) {
L_Keypad_GetKey_Click46:
; key start address is: 16 (R4)
BL	_Keypad_GetKey+0
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_GetKey_Click47
;Demo_Test.c,278 :: 		Delay_ms(10);
MOVW	R7, #53331
MOVT	R7, #0
NOP
NOP
L_Keypad_GetKey_Click48:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click48
NOP
NOP
NOP
NOP
;Demo_Test.c,279 :: 		}
IT	AL
BAL	L_Keypad_GetKey_Click46
L_Keypad_GetKey_Click47:
;Demo_Test.c,280 :: 		Delay_ms(20);
MOVW	R7, #41129
MOVT	R7, #1
NOP
NOP
L_Keypad_GetKey_Click50:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click50
NOP
NOP
;Demo_Test.c,281 :: 		return key;
UXTB	R0, R4
; key end address is: 16 (R4)
IT	AL
BAL	L_end_Keypad_GetKey_Click
;Demo_Test.c,282 :: 		}
L_Keypad_GetKey_Click45:
;Demo_Test.c,283 :: 		}
L_Keypad_GetKey_Click42:
;Demo_Test.c,284 :: 		}
IT	AL
BAL	L_Keypad_GetKey_Click40
;Demo_Test.c,285 :: 		}
L_end_Keypad_GetKey_Click:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_GetKey_Click
_keypad_init_mode:
;Demo_Test.c,287 :: 		void keypad_init_mode() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,289 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
MOVW	R1, #8320
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;Demo_Test.c,290 :: 		GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);
MOVW	R1, #1536
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Input+0
;Demo_Test.c,293 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
MOVW	R1, #4098
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;Demo_Test.c,294 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;Demo_Test.c,295 :: 		GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOD_BASE+0)
MOVT	R0, #hi_addr(GPIOD_BASE+0)
BL	_GPIO_Digital_Output+0
;Demo_Test.c,297 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Demo_Test.c,298 :: 		}
L_end_keypad_init_mode:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _keypad_init_mode
_push_init_mode:
;Demo_Test.c,300 :: 		void push_init_mode() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,302 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
MOVW	R1, #8320
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;Demo_Test.c,303 :: 		GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);
MOVW	R1, #1536
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Input+0
;Demo_Test.c,306 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
MOVW	R1, #4098
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;Demo_Test.c,307 :: 		GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Input+0
;Demo_Test.c,308 :: 		GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOD_BASE+0)
MOVT	R0, #hi_addr(GPIOD_BASE+0)
BL	_GPIO_Digital_Input+0
;Demo_Test.c,309 :: 		}
L_end_push_init_mode:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _push_init_mode
_BcdToDec:
;Demo_Test.c,312 :: 		unsigned short BcdToDec(unsigned short val) {
; val start address is: 0 (R0)
; val end address is: 0 (R0)
; val start address is: 0 (R0)
;Demo_Test.c,313 :: 		return ((val >> 4) * 10) + (val & 0x0F);
LSRS	R2, R0, #4
UXTB	R2, R2
MOVS	R1, #10
SXTH	R1, R1
MULS	R2, R1, R2
SXTH	R2, R2
AND	R1, R0, #15
UXTB	R1, R1
; val end address is: 0 (R0)
ADDS	R1, R2, R1
UXTB	R0, R1
;Demo_Test.c,314 :: 		}
L_end_BcdToDec:
BX	LR
; end of _BcdToDec
_I2C1_HW_Init:
;Demo_Test.c,316 :: 		void I2C1_HW_Init() {
;Demo_Test.c,317 :: 		RCC_AHB1ENR |= 0x00000002;      /* GPIOB clock enable */
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;Demo_Test.c,318 :: 		RCC_APB1ENR |= 0x00200000;      /* I2C1 clock enable */
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2097152
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;Demo_Test.c,320 :: 		GPIOB_AFRH &= ~0x000000FF;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
AND	R1, R0, #0
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;Demo_Test.c,321 :: 		GPIOB_AFRH |=  0x00000044;      /* PB8, PB9 -> AF4 */
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #68
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;Demo_Test.c,323 :: 		GPIOB_MODER &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;Demo_Test.c,324 :: 		GPIOB_MODER |=  0x000A0000;     /* alternate function */
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #655360
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;Demo_Test.c,326 :: 		GPIOB_OTYPER |= 0x00000300;     /* open drain */
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #768
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
STR	R1, [R0, #0]
;Demo_Test.c,328 :: 		GPIOB_PUPDR &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;Demo_Test.c,329 :: 		GPIOB_PUPDR |=  0x00050000;     /* pull-up */
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #327680
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;Demo_Test.c,331 :: 		I2C1_CR1 = 0x8000;
MOVW	R1, #32768
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;Demo_Test.c,332 :: 		I2C1_CR1 &= ~0x8000;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R1, [R0, #0]
MOVW	R0, #32767
ANDS	R1, R0
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;Demo_Test.c,334 :: 		I2C1_CR2 = 16;
MOVS	R1, #16
MOVW	R0, #lo_addr(I2C1_CR2+0)
MOVT	R0, #hi_addr(I2C1_CR2+0)
STR	R1, [R0, #0]
;Demo_Test.c,335 :: 		I2C1_CCR = 80;
MOVS	R1, #80
MOVW	R0, #lo_addr(I2C1_CCR+0)
MOVT	R0, #hi_addr(I2C1_CCR+0)
STR	R1, [R0, #0]
;Demo_Test.c,336 :: 		I2C1_TRISE = 17;
MOVS	R1, #17
MOVW	R0, #lo_addr(I2C1_TRISE+0)
MOVT	R0, #hi_addr(I2C1_TRISE+0)
STR	R1, [R0, #0]
;Demo_Test.c,338 :: 		I2C1_CR1 |= 0x0001;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;Demo_Test.c,339 :: 		}
L_end_I2C1_HW_Init:
BX	LR
; end of _I2C1_HW_Init
_I2C1_WaitWhileBusy:
;Demo_Test.c,341 :: 		unsigned short I2C1_WaitWhileBusy() {
;Demo_Test.c,342 :: 		unsigned long timeout = 60000;
; timeout start address is: 4 (R1)
MOVW	R1, #60000
MOVT	R1, #0
; timeout end address is: 4 (R1)
;Demo_Test.c,343 :: 		while((I2C1_SR2 & 2) && timeout) timeout--;
L_I2C1_WaitWhileBusy52:
; timeout start address is: 4 (R1)
MOVW	R0, #lo_addr(I2C1_SR2+0)
MOVT	R0, #hi_addr(I2C1_SR2+0)
LDR	R0, [R0, #0]
AND	R0, R0, #2
CMP	R0, #0
IT	EQ
BEQ	L__I2C1_WaitWhileBusy163
CMP	R1, #0
IT	EQ
BEQ	L__I2C1_WaitWhileBusy162
L__I2C1_WaitWhileBusy161:
SUBS	R1, R1, #1
IT	AL
BAL	L_I2C1_WaitWhileBusy52
L__I2C1_WaitWhileBusy163:
L__I2C1_WaitWhileBusy162:
;Demo_Test.c,344 :: 		return (timeout != 0);
CMP	R1, #0
MOVW	R0, #0
BEQ	L__I2C1_WaitWhileBusy205
MOVS	R0, #1
L__I2C1_WaitWhileBusy205:
; timeout end address is: 4 (R1)
UXTB	R0, R0
;Demo_Test.c,345 :: 		}
L_end_I2C1_WaitWhileBusy:
BX	LR
; end of _I2C1_WaitWhileBusy
_I2C1_WaitTXE:
;Demo_Test.c,347 :: 		unsigned short I2C1_WaitTXE() {
;Demo_Test.c,348 :: 		unsigned long timeout = 60000;
; timeout start address is: 4 (R1)
MOVW	R1, #60000
MOVT	R1, #0
; timeout end address is: 4 (R1)
;Demo_Test.c,349 :: 		while(!(I2C1_SR1 & 0x80) && timeout) timeout--;
L_I2C1_WaitTXE56:
; timeout start address is: 4 (R1)
MOVW	R0, #lo_addr(I2C1_SR1+0)
MOVT	R0, #hi_addr(I2C1_SR1+0)
LDR	R0, [R0, #0]
AND	R0, R0, #128
CMP	R0, #0
IT	NE
BNE	L__I2C1_WaitTXE166
CMP	R1, #0
IT	EQ
BEQ	L__I2C1_WaitTXE165
L__I2C1_WaitTXE164:
SUBS	R1, R1, #1
IT	AL
BAL	L_I2C1_WaitTXE56
L__I2C1_WaitTXE166:
L__I2C1_WaitTXE165:
;Demo_Test.c,350 :: 		return (timeout != 0);
CMP	R1, #0
MOVW	R0, #0
BEQ	L__I2C1_WaitTXE207
MOVS	R0, #1
L__I2C1_WaitTXE207:
; timeout end address is: 4 (R1)
UXTB	R0, R0
;Demo_Test.c,351 :: 		}
L_end_I2C1_WaitTXE:
BX	LR
; end of _I2C1_WaitTXE
_I2C1_WaitRXNE:
;Demo_Test.c,353 :: 		unsigned short I2C1_WaitRXNE() {
;Demo_Test.c,354 :: 		unsigned long timeout = 60000;
; timeout start address is: 4 (R1)
MOVW	R1, #60000
MOVT	R1, #0
; timeout end address is: 4 (R1)
;Demo_Test.c,355 :: 		while(!(I2C1_SR1 & 0x40) && timeout) timeout--;
L_I2C1_WaitRXNE60:
; timeout start address is: 4 (R1)
MOVW	R0, #lo_addr(I2C1_SR1+0)
MOVT	R0, #hi_addr(I2C1_SR1+0)
LDR	R0, [R0, #0]
AND	R0, R0, #64
CMP	R0, #0
IT	NE
BNE	L__I2C1_WaitRXNE169
CMP	R1, #0
IT	EQ
BEQ	L__I2C1_WaitRXNE168
L__I2C1_WaitRXNE167:
SUBS	R1, R1, #1
IT	AL
BAL	L_I2C1_WaitRXNE60
L__I2C1_WaitRXNE169:
L__I2C1_WaitRXNE168:
;Demo_Test.c,356 :: 		return (timeout != 0);
CMP	R1, #0
MOVW	R0, #0
BEQ	L__I2C1_WaitRXNE209
MOVS	R0, #1
L__I2C1_WaitRXNE209:
; timeout end address is: 4 (R1)
UXTB	R0, R0
;Demo_Test.c,357 :: 		}
L_end_I2C1_WaitRXNE:
BX	LR
; end of _I2C1_WaitRXNE
_I2C1_Start_WriteAddr:
;Demo_Test.c,359 :: 		unsigned short I2C1_Start_WriteAddr(unsigned short saddr) {
; saddr start address is: 0 (R0)
; saddr end address is: 0 (R0)
; saddr start address is: 0 (R0)
;Demo_Test.c,363 :: 		I2C1_CR1 |= 0x0100;
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #256
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;Demo_Test.c,364 :: 		timeout = 60000;
; timeout start address is: 8 (R2)
MOVW	R2, #60000
; saddr end address is: 0 (R0)
; timeout end address is: 8 (R2)
;Demo_Test.c,365 :: 		while(!(I2C1_SR1 & 1) && timeout) timeout--;
L_I2C1_Start_WriteAddr64:
; timeout start address is: 8 (R2)
; saddr start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #1
CMP	R1, #0
IT	NE
BNE	L__I2C1_Start_WriteAddr172
CMP	R2, #0
IT	EQ
BEQ	L__I2C1_Start_WriteAddr171
L__I2C1_Start_WriteAddr170:
SUBS	R2, R2, #1
IT	AL
BAL	L_I2C1_Start_WriteAddr64
L__I2C1_Start_WriteAddr172:
L__I2C1_Start_WriteAddr171:
;Demo_Test.c,366 :: 		if(timeout == 0) return 0;
CMP	R2, #0
IT	NE
BNE	L_I2C1_Start_WriteAddr68
; saddr end address is: 0 (R0)
; timeout end address is: 8 (R2)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_Start_WriteAddr
L_I2C1_Start_WriteAddr68:
;Demo_Test.c,368 :: 		I2C1_DR = saddr << 1;
; saddr start address is: 0 (R0)
LSLS	R2, R0, #1
UXTH	R2, R2
; saddr end address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_DR+0)
MOVT	R1, #hi_addr(I2C1_DR+0)
STR	R2, [R1, #0]
;Demo_Test.c,370 :: 		timeout = 60000;
; timeout start address is: 0 (R0)
MOVW	R0, #60000
; timeout end address is: 0 (R0)
;Demo_Test.c,371 :: 		while(timeout) {
L_I2C1_Start_WriteAddr69:
; timeout start address is: 0 (R0)
CMP	R0, #0
IT	EQ
BEQ	L_I2C1_Start_WriteAddr70
;Demo_Test.c,372 :: 		if(I2C1_SR1 & 2) {
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #2
CMP	R1, #0
IT	EQ
BEQ	L_I2C1_Start_WriteAddr71
; timeout end address is: 0 (R0)
;Demo_Test.c,373 :: 		tmp = I2C1_SR2;
MOVW	R1, #lo_addr(I2C1_SR2+0)
MOVT	R1, #hi_addr(I2C1_SR2+0)
; tmp start address is: 4 (R1)
LDR	R1, [R1, #0]
; tmp end address is: 4 (R1)
;Demo_Test.c,374 :: 		return 1;
MOVS	R0, #1
IT	AL
BAL	L_end_I2C1_Start_WriteAddr
;Demo_Test.c,375 :: 		}
L_I2C1_Start_WriteAddr71:
;Demo_Test.c,376 :: 		if(I2C1_SR1 & 0x0400) {
; timeout start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #1024
CMP	R1, #0
IT	EQ
BEQ	L_I2C1_Start_WriteAddr72
; timeout end address is: 0 (R0)
;Demo_Test.c,377 :: 		I2C1_SR1 &= ~0x0400;
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R2, [R1, #0]
MVN	R1, #1024
ANDS	R2, R1
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
STR	R2, [R1, #0]
;Demo_Test.c,378 :: 		I2C1_CR1 |= 0x0200;
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #512
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;Demo_Test.c,379 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_Start_WriteAddr
;Demo_Test.c,380 :: 		}
L_I2C1_Start_WriteAddr72:
;Demo_Test.c,381 :: 		timeout--;
; timeout start address is: 0 (R0)
SUBS	R0, R0, #1
;Demo_Test.c,382 :: 		}
; timeout end address is: 0 (R0)
IT	AL
BAL	L_I2C1_Start_WriteAddr69
L_I2C1_Start_WriteAddr70:
;Demo_Test.c,384 :: 		I2C1_CR1 |= 0x0200;
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #512
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;Demo_Test.c,385 :: 		return 0;
MOVS	R0, #0
;Demo_Test.c,386 :: 		}
L_end_I2C1_Start_WriteAddr:
BX	LR
; end of _I2C1_Start_WriteAddr
_I2C1_BurstRead:
;Demo_Test.c,391 :: 		unsigned short data_buf[]) {
; data_buf start address is: 12 (R3)
; count start address is: 8 (R2)
; start_reg start address is: 4 (R1)
; saddr start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
MOV	R7, R3
UXTB	R3, R0
UXTB	R8, R1
UXTB	R6, R2
; data_buf end address is: 12 (R3)
; count end address is: 8 (R2)
; start_reg end address is: 4 (R1)
; saddr end address is: 0 (R0)
; saddr start address is: 12 (R3)
; start_reg start address is: 32 (R8)
; count start address is: 24 (R6)
; data_buf start address is: 28 (R7)
;Demo_Test.c,395 :: 		if(!I2C1_WaitWhileBusy()) return 0;
BL	_I2C1_WaitWhileBusy+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead73
; start_reg end address is: 32 (R8)
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead73:
;Demo_Test.c,397 :: 		I2C1_CR1 &= ~0x0800;
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
; start_reg start address is: 32 (R8)
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #2048
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,398 :: 		if(!I2C1_Start_WriteAddr(saddr)) return 0;
UXTB	R0, R3
BL	_I2C1_Start_WriteAddr+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead74
; start_reg end address is: 32 (R8)
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead74:
;Demo_Test.c,400 :: 		if(!I2C1_WaitTXE()) return 0;
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
; start_reg start address is: 32 (R8)
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead75
; start_reg end address is: 32 (R8)
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead75:
;Demo_Test.c,401 :: 		I2C1_DR = start_reg;
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
; start_reg start address is: 32 (R8)
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R8, [R4, #0]
; start_reg end address is: 32 (R8)
;Demo_Test.c,402 :: 		if(!I2C1_WaitTXE()) return 0;
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead76
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead76:
;Demo_Test.c,404 :: 		I2C1_CR1 |= 0x0100;
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #256
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,406 :: 		unsigned long timeout = 60000;
; timeout start address is: 0 (R0)
MOVW	R0, #60000
MOVT	R0, #0
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; timeout end address is: 0 (R0)
; saddr end address is: 12 (R3)
UXTB	R2, R6
MOV	R1, R7
MOV	R5, R0
;Demo_Test.c,407 :: 		while(!(I2C1_SR1 & 1) && timeout) timeout--;
L_I2C1_BurstRead77:
; timeout start address is: 20 (R5)
; data_buf start address is: 4 (R1)
; count start address is: 8 (R2)
; saddr start address is: 12 (R3)
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1
CMP	R4, #0
IT	NE
BNE	L__I2C1_BurstRead175
CMP	R5, #0
IT	EQ
BEQ	L__I2C1_BurstRead174
L__I2C1_BurstRead173:
SUBS	R5, R5, #1
IT	AL
BAL	L_I2C1_BurstRead77
L__I2C1_BurstRead175:
L__I2C1_BurstRead174:
;Demo_Test.c,408 :: 		if(timeout == 0) return 0;
CMP	R5, #0
IT	NE
BNE	L_I2C1_BurstRead81
; data_buf end address is: 4 (R1)
; count end address is: 8 (R2)
; saddr end address is: 12 (R3)
; timeout end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead81:
;Demo_Test.c,411 :: 		I2C1_DR = (saddr << 1) | 1;
; saddr start address is: 12 (R3)
; count start address is: 8 (R2)
; data_buf start address is: 4 (R1)
LSLS	R4, R3, #1
UXTH	R4, R4
; saddr end address is: 12 (R3)
ORR	R5, R4, #1
UXTH	R5, R5
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;Demo_Test.c,413 :: 		unsigned long timeout = 60000;
; timeout start address is: 12 (R3)
MOVW	R3, #60000
MOVT	R3, #0
; data_buf end address is: 4 (R1)
; count end address is: 8 (R2)
; timeout end address is: 12 (R3)
STRB	R2, [SP, #4]
MOV	R2, R1
LDRB	R1, [SP, #4]
;Demo_Test.c,414 :: 		while(timeout) {
L_I2C1_BurstRead82:
; timeout start address is: 12 (R3)
; count start address is: 4 (R1)
; data_buf start address is: 8 (R2)
CMP	R3, #0
IT	EQ
BEQ	L_I2C1_BurstRead83
;Demo_Test.c,415 :: 		if(I2C1_SR1 & 2) break;
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	EQ
BEQ	L_I2C1_BurstRead84
IT	AL
BAL	L_I2C1_BurstRead83
L_I2C1_BurstRead84:
;Demo_Test.c,416 :: 		if(I2C1_SR1 & 0x0400) {
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1024
CMP	R4, #0
IT	EQ
BEQ	L_I2C1_BurstRead85
; count end address is: 4 (R1)
; timeout end address is: 12 (R3)
; data_buf end address is: 8 (R2)
;Demo_Test.c,417 :: 		I2C1_SR1 &= ~0x0400;
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R5, [R4, #0]
MVN	R4, #1024
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,418 :: 		I2C1_CR1 |= 0x0200;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,419 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
;Demo_Test.c,420 :: 		}
L_I2C1_BurstRead85:
;Demo_Test.c,421 :: 		timeout--;
; data_buf start address is: 8 (R2)
; timeout start address is: 12 (R3)
; count start address is: 4 (R1)
SUBS	R3, R3, #1
;Demo_Test.c,422 :: 		}
IT	AL
BAL	L_I2C1_BurstRead82
L_I2C1_BurstRead83:
;Demo_Test.c,423 :: 		if(timeout == 0) {
CMP	R3, #0
IT	NE
BNE	L_I2C1_BurstRead86
; count end address is: 4 (R1)
; timeout end address is: 12 (R3)
; data_buf end address is: 8 (R2)
;Demo_Test.c,424 :: 		I2C1_CR1 |= 0x0200;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,425 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
;Demo_Test.c,426 :: 		}
L_I2C1_BurstRead86:
;Demo_Test.c,429 :: 		tmp = I2C1_SR2;
; data_buf start address is: 8 (R2)
; count start address is: 4 (R1)
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R4, #0]
; tmp end address is: 0 (R0)
;Demo_Test.c,430 :: 		I2C1_CR1 |= 0x0400;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #1024
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,432 :: 		for(i = 0; i < count; i++) {
; i start address is: 24 (R6)
MOVS	R6, #0
; count end address is: 4 (R1)
; i end address is: 24 (R6)
UXTB	R3, R1
L_I2C1_BurstRead87:
; i start address is: 24 (R6)
; data_buf start address is: 8 (R2)
; data_buf end address is: 8 (R2)
; count start address is: 12 (R3)
CMP	R6, R3
IT	CS
BCS	L_I2C1_BurstRead88
; data_buf end address is: 8 (R2)
;Demo_Test.c,433 :: 		if(i == (count - 1)) {
; data_buf start address is: 8 (R2)
SUBS	R4, R3, #1
SXTH	R4, R4
CMP	R6, R4
IT	NE
BNE	L_I2C1_BurstRead90
;Demo_Test.c,434 :: 		I2C1_CR1 &= ~0x0400;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #1024
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,435 :: 		I2C1_CR1 |=  0x0200;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;Demo_Test.c,436 :: 		}
L_I2C1_BurstRead90:
;Demo_Test.c,438 :: 		if(!I2C1_WaitRXNE()) return 0;
BL	_I2C1_WaitRXNE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead91
; data_buf end address is: 8 (R2)
; count end address is: 12 (R3)
; i end address is: 24 (R6)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead91:
;Demo_Test.c,439 :: 		data_buf[i] = I2C1_DR;
; i start address is: 24 (R6)
; count start address is: 12 (R3)
; data_buf start address is: 8 (R2)
ADDS	R5, R2, R6
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
LDR	R4, [R4, #0]
STRB	R4, [R5, #0]
;Demo_Test.c,432 :: 		for(i = 0; i < count; i++) {
ADDS	R6, R6, #1
UXTB	R6, R6
;Demo_Test.c,440 :: 		}
; data_buf end address is: 8 (R2)
; count end address is: 12 (R3)
; i end address is: 24 (R6)
IT	AL
BAL	L_I2C1_BurstRead87
L_I2C1_BurstRead88:
;Demo_Test.c,442 :: 		return 1;
MOVS	R0, #1
;Demo_Test.c,443 :: 		}
L_end_I2C1_BurstRead:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _I2C1_BurstRead
_I2C1_WriteByte_Reg:
;Demo_Test.c,447 :: 		unsigned short value) {
; value start address is: 8 (R2)
; reg_addr start address is: 4 (R1)
; saddr start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R5, R2
UXTB	R2, R0
UXTB	R4, R1
; value end address is: 8 (R2)
; reg_addr end address is: 4 (R1)
; saddr end address is: 0 (R0)
; saddr start address is: 8 (R2)
; reg_addr start address is: 16 (R4)
; value start address is: 20 (R5)
;Demo_Test.c,448 :: 		if(!I2C1_WaitWhileBusy()) return 0;
BL	_I2C1_WaitWhileBusy+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg92
; saddr end address is: 8 (R2)
; reg_addr end address is: 16 (R4)
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg92:
;Demo_Test.c,449 :: 		if(!I2C1_Start_WriteAddr(saddr)) return 0;
; value start address is: 20 (R5)
; reg_addr start address is: 16 (R4)
; saddr start address is: 8 (R2)
UXTB	R0, R2
; saddr end address is: 8 (R2)
BL	_I2C1_Start_WriteAddr+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg93
; reg_addr end address is: 16 (R4)
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg93:
;Demo_Test.c,451 :: 		if(!I2C1_WaitTXE()) return 0;
; value start address is: 20 (R5)
; reg_addr start address is: 16 (R4)
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg94
; reg_addr end address is: 16 (R4)
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg94:
;Demo_Test.c,452 :: 		I2C1_DR = reg_addr;
; value start address is: 20 (R5)
; reg_addr start address is: 16 (R4)
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R4, [R3, #0]
; reg_addr end address is: 16 (R4)
;Demo_Test.c,454 :: 		if(!I2C1_WaitTXE()) return 0;
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg95
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg95:
;Demo_Test.c,455 :: 		I2C1_DR = value;
; value start address is: 20 (R5)
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R5, [R3, #0]
; value end address is: 20 (R5)
;Demo_Test.c,457 :: 		if(!I2C1_WaitTXE()) return 0;
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg96
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg96:
;Demo_Test.c,458 :: 		I2C1_CR1 |= 0x0200;
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #512
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;Demo_Test.c,459 :: 		return 1;
MOVS	R0, #1
;Demo_Test.c,460 :: 		}
L_end_I2C1_WriteByte_Reg:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _I2C1_WriteByte_Reg
_DS1337_Init:
;Demo_Test.c,462 :: 		void DS1337_Init() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,463 :: 		I2C1_WriteByte_Reg(DS1337_ADDR, 0x0E, 0x00);
MOVS	R2, #0
MOVS	R1, #14
MOVS	R0, #104
BL	_I2C1_WriteByte_Reg+0
;Demo_Test.c,464 :: 		I2C1_WriteByte_Reg(DS1337_ADDR, 0x0F, 0x00);
MOVS	R2, #0
MOVS	R1, #15
MOVS	R0, #104
BL	_I2C1_WriteByte_Reg+0
;Demo_Test.c,465 :: 		}
L_end_DS1337_Init:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _DS1337_Init
_DS1337_GetDateTime:
;Demo_Test.c,467 :: 		unsigned short DS1337_GetDateTime() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,468 :: 		if(!I2C1_BurstRead(DS1337_ADDR, 0x00, 7, rtc_buf)) return 0;
MOVW	R3, #lo_addr(_rtc_buf+0)
MOVT	R3, #hi_addr(_rtc_buf+0)
MOVS	R2, #7
MOVS	R1, #0
MOVS	R0, #104
BL	_I2C1_BurstRead+0
CMP	R0, #0
IT	NE
BNE	L_DS1337_GetDateTime97
MOVS	R0, #0
IT	AL
BAL	L_end_DS1337_GetDateTime
L_DS1337_GetDateTime97:
;Demo_Test.c,470 :: 		rtc_second = BcdToDec(rtc_buf[0] & 0x7F);
MOVW	R0, #lo_addr(_rtc_buf+0)
MOVT	R0, #hi_addr(_rtc_buf+0)
LDRB	R0, [R0, #0]
AND	R0, R0, #127
BL	_BcdToDec+0
MOVW	R1, #lo_addr(_rtc_second+0)
MOVT	R1, #hi_addr(_rtc_second+0)
STRB	R0, [R1, #0]
;Demo_Test.c,471 :: 		rtc_minute = BcdToDec(rtc_buf[1] & 0x7F);
MOVW	R0, #lo_addr(_rtc_buf+1)
MOVT	R0, #hi_addr(_rtc_buf+1)
LDRB	R0, [R0, #0]
AND	R0, R0, #127
BL	_BcdToDec+0
MOVW	R1, #lo_addr(_rtc_minute+0)
MOVT	R1, #hi_addr(_rtc_minute+0)
STRB	R0, [R1, #0]
;Demo_Test.c,472 :: 		rtc_hour   = BcdToDec(rtc_buf[2] & 0x3F);
MOVW	R0, #lo_addr(_rtc_buf+2)
MOVT	R0, #hi_addr(_rtc_buf+2)
LDRB	R0, [R0, #0]
AND	R0, R0, #63
BL	_BcdToDec+0
MOVW	R1, #lo_addr(_rtc_hour+0)
MOVT	R1, #hi_addr(_rtc_hour+0)
STRB	R0, [R1, #0]
;Demo_Test.c,473 :: 		rtc_day    = BcdToDec(rtc_buf[4] & 0x3F);
MOVW	R0, #lo_addr(_rtc_buf+4)
MOVT	R0, #hi_addr(_rtc_buf+4)
LDRB	R0, [R0, #0]
AND	R0, R0, #63
BL	_BcdToDec+0
MOVW	R1, #lo_addr(_rtc_day+0)
MOVT	R1, #hi_addr(_rtc_day+0)
STRB	R0, [R1, #0]
;Demo_Test.c,474 :: 		rtc_month  = BcdToDec(rtc_buf[5] & 0x1F);
MOVW	R0, #lo_addr(_rtc_buf+5)
MOVT	R0, #hi_addr(_rtc_buf+5)
LDRB	R0, [R0, #0]
AND	R0, R0, #31
BL	_BcdToDec+0
MOVW	R1, #lo_addr(_rtc_month+0)
MOVT	R1, #hi_addr(_rtc_month+0)
STRB	R0, [R1, #0]
;Demo_Test.c,475 :: 		rtc_year   = BcdToDec(rtc_buf[6]);
MOVW	R0, #lo_addr(_rtc_buf+6)
MOVT	R0, #hi_addr(_rtc_buf+6)
LDRB	R0, [R0, #0]
BL	_BcdToDec+0
MOVW	R1, #lo_addr(_rtc_year+0)
MOVT	R1, #hi_addr(_rtc_year+0)
STRB	R0, [R1, #0]
;Demo_Test.c,477 :: 		return 1;
MOVS	R0, #1
;Demo_Test.c,478 :: 		}
L_end_DS1337_GetDateTime:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _DS1337_GetDateTime
_Read_ADC_Average:
;Demo_Test.c,481 :: 		unsigned int Read_ADC_Average() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,483 :: 		adc_sum = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_adc_sum+0)
MOVT	R0, #hi_addr(_adc_sum+0)
STR	R1, [R0, #0]
;Demo_Test.c,485 :: 		for(i = 0; i < 16; i++) {
; i start address is: 20 (R5)
MOVS	R5, #0
; i end address is: 20 (R5)
L_Read_ADC_Average98:
; i start address is: 20 (R5)
CMP	R5, #16
IT	CS
BCS	L_Read_ADC_Average99
;Demo_Test.c,486 :: 		adc_sum += ADC1_Get_Sample(10);   /* PC0 = channel 10 */
MOVS	R0, #10
BL	_ADC1_Get_Sample+0
MOVW	R2, #lo_addr(_adc_sum+0)
MOVT	R2, #hi_addr(_adc_sum+0)
LDR	R1, [R2, #0]
ADDS	R0, R1, R0
STR	R0, [R2, #0]
;Demo_Test.c,487 :: 		Delay_ms(2);
MOVW	R7, #10665
MOVT	R7, #0
NOP
NOP
L_Read_ADC_Average101:
SUBS	R7, R7, #1
BNE	L_Read_ADC_Average101
NOP
NOP
;Demo_Test.c,485 :: 		for(i = 0; i < 16; i++) {
ADDS	R5, R5, #1
UXTB	R5, R5
;Demo_Test.c,488 :: 		}
; i end address is: 20 (R5)
IT	AL
BAL	L_Read_ADC_Average98
L_Read_ADC_Average99:
;Demo_Test.c,490 :: 		return (unsigned int)(adc_sum / 16);
MOVW	R0, #lo_addr(_adc_sum+0)
MOVT	R0, #hi_addr(_adc_sum+0)
LDR	R0, [R0, #0]
LSRS	R0, R0, #4
UXTH	R0, R0
;Demo_Test.c,491 :: 		}
L_end_Read_ADC_Average:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Read_ADC_Average
_Read_LM34_Celsius:
;Demo_Test.c,493 :: 		void Read_LM34_Celsius() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,494 :: 		adc_avg = Read_ADC_Average();
BL	_Read_ADC_Average+0
MOVW	R1, #lo_addr(_adc_avg+0)
MOVT	R1, #hi_addr(_adc_avg+0)
STRH	R0, [R1, #0]
;Demo_Test.c,496 :: 		voltage = (adc_avg * 3.3) / 4095.0;
VMOV	S1, R0
VCVT.F32	#0, S1, S1
MOVW	R0, #13107
MOVT	R0, #16467
VMOV	S0, R0
VMUL.F32	S1, S1, S0
MOVW	R0, #61440
MOVT	R0, #17791
VMOV	S0, R0
VDIV.F32	S1, S1, S0
MOVW	R0, #lo_addr(_voltage+0)
MOVT	R0, #hi_addr(_voltage+0)
VSTR	#1, S1, [R0, #0]
;Demo_Test.c,497 :: 		temp_f  = voltage * 100.0;
MOVW	R0, #0
MOVT	R0, #17096
VMOV	S0, R0
VMUL.F32	S1, S1, S0
MOVW	R0, #lo_addr(_temp_f+0)
MOVT	R0, #hi_addr(_temp_f+0)
VSTR	#1, S1, [R0, #0]
;Demo_Test.c,498 :: 		temp_c  = (temp_f - 32.0) * 5.0 / 9.0;
MOV	R0, #1107296256
VMOV	S0, R0
VSUB.F32	S1, S1, S0
VMOV.F32	S0, #5
VMUL.F32	S1, S1, S0
VMOV.F32	S0, #9
VDIV.F32	S1, S1, S0
MOVW	R0, #lo_addr(_temp_c+0)
MOVT	R0, #hi_addr(_temp_c+0)
VSTR	#1, S1, [R0, #0]
;Demo_Test.c,500 :: 		temp_c_int  = (unsigned int)temp_c;
VCVT	#1, .F32, S0, S1
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_temp_c_int+0)
MOVT	R0, #hi_addr(_temp_c_int+0)
STRH	R1, [R0, #0]
;Demo_Test.c,501 :: 		temp_c_frac = (unsigned int)((temp_c - temp_c_int) * 10.0);
VMOV	S0, R1
VCVT.F32	#0, S0, S0
VSUB.F32	S1, S1, S0
VMOV.F32	S0, #10
VMUL.F32	S0, S1, S0
VCVT	#1, .F32, S0, S0
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_temp_c_frac+0)
MOVT	R0, #hi_addr(_temp_c_frac+0)
STRH	R1, [R0, #0]
;Demo_Test.c,502 :: 		}
L_end_Read_LM34_Celsius:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Read_LM34_Celsius
_pulse_srclk:
;Demo_Test.c,505 :: 		void pulse_srclk() {
;Demo_Test.c,506 :: 		SR_SRCLK = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Demo_Test.c,507 :: 		Delay_us(1);
MOVW	R7, #3
MOVT	R7, #0
NOP
NOP
L_pulse_srclk103:
SUBS	R7, R7, #1
BNE	L_pulse_srclk103
NOP
NOP
NOP
NOP
;Demo_Test.c,508 :: 		SR_SRCLK = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Demo_Test.c,509 :: 		Delay_us(1);
MOVW	R7, #3
MOVT	R7, #0
NOP
NOP
L_pulse_srclk105:
SUBS	R7, R7, #1
BNE	L_pulse_srclk105
NOP
NOP
NOP
NOP
;Demo_Test.c,510 :: 		}
L_end_pulse_srclk:
BX	LR
; end of _pulse_srclk
_pulse_rclk:
;Demo_Test.c,512 :: 		void pulse_rclk() {
;Demo_Test.c,513 :: 		SR_RCLK = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Demo_Test.c,514 :: 		Delay_us(1);
MOVW	R7, #3
MOVT	R7, #0
NOP
NOP
L_pulse_rclk107:
SUBS	R7, R7, #1
BNE	L_pulse_rclk107
NOP
NOP
NOP
NOP
;Demo_Test.c,515 :: 		SR_RCLK = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Demo_Test.c,516 :: 		Delay_us(1);
MOVW	R7, #3
MOVT	R7, #0
NOP
NOP
L_pulse_rclk109:
SUBS	R7, R7, #1
BNE	L_pulse_rclk109
NOP
NOP
NOP
NOP
;Demo_Test.c,517 :: 		}
L_end_pulse_rclk:
BX	LR
; end of _pulse_rclk
_shift_out_byte:
;Demo_Test.c,519 :: 		void shift_out_byte(unsigned char value) {
; value start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; value end address is: 0 (R0)
; value start address is: 0 (R0)
;Demo_Test.c,522 :: 		for(i = 0; i < 8; i++) {
; i start address is: 12 (R3)
MOVS	R3, #0
; value end address is: 0 (R0)
; i end address is: 12 (R3)
UXTB	R4, R0
L_shift_out_byte111:
; i start address is: 12 (R3)
; value start address is: 16 (R4)
CMP	R3, #8
IT	CS
BCS	L_shift_out_byte112
;Demo_Test.c,523 :: 		if(value & 0x80)
AND	R1, R4, #128
UXTB	R1, R1
CMP	R1, #0
IT	EQ
BEQ	L_shift_out_byte114
;Demo_Test.c,524 :: 		SR_SER = 1;
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
_SX	[R1, ByteOffset(GPIOA_ODR+0)]
IT	AL
BAL	L_shift_out_byte115
L_shift_out_byte114:
;Demo_Test.c,526 :: 		SR_SER = 0;
MOVS	R2, #0
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
_SX	[R1, ByteOffset(GPIOA_ODR+0)]
L_shift_out_byte115:
;Demo_Test.c,528 :: 		pulse_srclk();
BL	_pulse_srclk+0
;Demo_Test.c,529 :: 		value <<= 1;
LSLS	R1, R4, #1
UXTB	R4, R1
;Demo_Test.c,522 :: 		for(i = 0; i < 8; i++) {
ADDS	R3, R3, #1
UXTB	R3, R3
;Demo_Test.c,530 :: 		}
; value end address is: 16 (R4)
; i end address is: 12 (R3)
IT	AL
BAL	L_shift_out_byte111
L_shift_out_byte112:
;Demo_Test.c,531 :: 		}
L_end_shift_out_byte:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _shift_out_byte
_display_raw_4:
;Demo_Test.c,533 :: 		void display_raw_4(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
; d4 start address is: 12 (R3)
; d3 start address is: 8 (R2)
; d2 start address is: 4 (R1)
; d1 start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R5, R0
UXTB	R6, R1
UXTB	R8, R2
; d4 end address is: 12 (R3)
; d3 end address is: 8 (R2)
; d2 end address is: 4 (R1)
; d1 end address is: 0 (R0)
; d1 start address is: 20 (R5)
; d2 start address is: 24 (R6)
; d3 start address is: 32 (R8)
; d4 start address is: 12 (R3)
;Demo_Test.c,534 :: 		shift_out_byte(d4);
UXTB	R0, R3
; d4 end address is: 12 (R3)
BL	_shift_out_byte+0
;Demo_Test.c,535 :: 		shift_out_byte(d3);
UXTB	R0, R8
; d3 end address is: 32 (R8)
BL	_shift_out_byte+0
;Demo_Test.c,536 :: 		shift_out_byte(d2);
UXTB	R0, R6
; d2 end address is: 24 (R6)
BL	_shift_out_byte+0
;Demo_Test.c,537 :: 		shift_out_byte(d1);
UXTB	R0, R5
; d1 end address is: 20 (R5)
BL	_shift_out_byte+0
;Demo_Test.c,538 :: 		pulse_rclk();
BL	_pulse_rclk+0
;Demo_Test.c,539 :: 		}
L_end_display_raw_4:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _display_raw_4
_clear_7seg:
;Demo_Test.c,541 :: 		void clear_7seg() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Demo_Test.c,542 :: 		display_raw_4(0x00, 0x00, 0x00, 0x00);
MOVS	R3, #0
MOVS	R2, #0
MOVS	R1, #0
MOVS	R0, #0
BL	_display_raw_4+0
;Demo_Test.c,543 :: 		}
L_end_clear_7seg:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _clear_7seg
_display_number_4digit:
;Demo_Test.c,545 :: 		void display_number_4digit(unsigned int value) {
; value start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; value end address is: 0 (R0)
; value start address is: 0 (R0)
;Demo_Test.c,548 :: 		d1 = value / 1000;
MOVW	R1, #1000
UDIV	R7, R0, R1
UXTH	R7, R7
;Demo_Test.c,549 :: 		d2 = (value / 100) % 10;
MOVS	R1, #100
UDIV	R2, R0, R1
UXTH	R2, R2
MOVS	R1, #10
UDIV	R6, R2, R1
MLS	R6, R1, R6, R2
UXTH	R6, R6
;Demo_Test.c,550 :: 		d3 = (value / 10) % 10;
MOVS	R1, #10
UDIV	R2, R0, R1
UXTH	R2, R2
MOVS	R1, #10
UDIV	R3, R2, R1
MLS	R3, R1, R3, R2
UXTH	R3, R3
;Demo_Test.c,551 :: 		d4 = value % 10;
MOVS	R2, #10
UDIV	R1, R0, R2
MLS	R1, R2, R1, R0
UXTH	R1, R1
; value end address is: 0 (R0)
;Demo_Test.c,553 :: 		display_raw_4(seg_code[d1], seg_code[d2], seg_code[d3], seg_code[d4]);
UXTB	R2, R1
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
UXTB	R5, R1
UXTB	R2, R3
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
UXTB	R4, R1
UXTB	R2, R6
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
UXTB	R3, R1
UXTB	R2, R7
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
UXTB	R2, R4
UXTB	R0, R1
UXTB	R1, R3
UXTB	R3, R5
BL	_display_raw_4+0
;Demo_Test.c,554 :: 		}
L_end_display_number_4digit:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _display_number_4digit
_show_password_screen:
;Demo_Test.c,557 :: 		void show_password_screen() {
SUB	SP, SP, #40
STR	LR, [SP, #0]
;Demo_Test.c,562 :: 		center_text(line1, "Enter Password");
MOVW	R1, #lo_addr(?lstr1_Demo_Test+0)
MOVT	R1, #hi_addr(?lstr1_Demo_Test+0)
ADD	R0, SP, #4
BL	_center_text+0
;Demo_Test.c,563 :: 		clear16(line2);
ADD	R0, SP, #21
BL	_clear16+0
;Demo_Test.c,565 :: 		for(i = 0; i < password_len && i < 16; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
L_show_password_screen116:
; i start address is: 8 (R2)
MOVW	R0, #lo_addr(_password_len+0)
MOVT	R0, #hi_addr(_password_len+0)
LDRB	R0, [R0, #0]
CMP	R2, R0
IT	CS
BCS	L__show_password_screen178
CMP	R2, #16
IT	CS
BCS	L__show_password_screen177
L__show_password_screen176:
;Demo_Test.c,566 :: 		line2[i] = password_buf[i];
ADD	R0, SP, #21
ADDS	R1, R0, R2
MOVW	R0, #lo_addr(_password_buf+0)
MOVT	R0, #hi_addr(_password_buf+0)
ADDS	R0, R0, R2
LDRB	R0, [R0, #0]
STRB	R0, [R1, #0]
;Demo_Test.c,565 :: 		for(i = 0; i < password_len && i < 16; i++) {
ADDS	R2, R2, #1
UXTB	R2, R2
;Demo_Test.c,567 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_show_password_screen116
;Demo_Test.c,565 :: 		for(i = 0; i < password_len && i < 16; i++) {
L__show_password_screen178:
L__show_password_screen177:
;Demo_Test.c,569 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Demo_Test.c,570 :: 		Lcd_Out(1, 1, line1);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;Demo_Test.c,571 :: 		Lcd_Out(2, 1, line2);
ADD	R0, SP, #21
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;Demo_Test.c,572 :: 		}
L_end_show_password_screen:
LDR	LR, [SP, #0]
ADD	SP, SP, #40
BX	LR
; end of _show_password_screen
_show_run_screen:
;Demo_Test.c,574 :: 		void show_run_screen() {
SUB	SP, SP, #40
STR	LR, [SP, #0]
;Demo_Test.c,579 :: 		clear16(line1);
ADD	R0, SP, #4
BL	_clear16+0
;Demo_Test.c,580 :: 		clear16(line2);
ADD	R0, SP, #21
BL	_clear16+0
;Demo_Test.c,583 :: 		line1[0] = (rtc_day / 10) + '0';
ADD	R4, SP, #4
MOVW	R2, #lo_addr(_rtc_day+0)
MOVT	R2, #hi_addr(_rtc_day+0)
LDRB	R1, [R2, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R4, #0]
;Demo_Test.c,584 :: 		line1[1] = (rtc_day % 10) + '0';
ADDS	R3, R4, #1
MOV	R0, R2
LDRB	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,585 :: 		line1[2] = '/';
ADDS	R1, R4, #2
MOVS	R0, #47
STRB	R0, [R1, #0]
;Demo_Test.c,586 :: 		line1[3] = (rtc_month / 10) + '0';
ADDS	R3, R4, #3
MOVW	R2, #lo_addr(_rtc_month+0)
MOVT	R2, #hi_addr(_rtc_month+0)
LDRB	R1, [R2, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,587 :: 		line1[4] = (rtc_month % 10) + '0';
ADDS	R3, R4, #4
MOV	R0, R2
LDRB	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,588 :: 		line1[5] = '/';
ADDS	R1, R4, #5
MOVS	R0, #47
STRB	R0, [R1, #0]
;Demo_Test.c,589 :: 		line1[6] = (rtc_year / 10) + '0';
ADDS	R3, R4, #6
MOVW	R2, #lo_addr(_rtc_year+0)
MOVT	R2, #hi_addr(_rtc_year+0)
LDRB	R1, [R2, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,590 :: 		line1[7] = (rtc_year % 10) + '0';
ADDS	R3, R4, #7
MOV	R0, R2
LDRB	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,593 :: 		line1[10] = (temp_c_int / 10) ? ((temp_c_int / 10) + '0') : ' ';
ADDW	R2, R4, #10
MOVW	R0, #lo_addr(_temp_c_int+0)
MOVT	R0, #hi_addr(_temp_c_int+0)
LDRH	R1, [R0, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTH	R0, R0
CMP	R0, #0
IT	EQ
BEQ	L_show_run_screen121
MOVW	R0, #lo_addr(_temp_c_int+0)
MOVT	R0, #hi_addr(_temp_c_int+0)
LDRH	R1, [R0, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTH	R0, R0
ADDS	R0, #48
UXTH	R0, R0
; ?FLOC___show_run_screen?T333 start address is: 0 (R0)
; ?FLOC___show_run_screen?T333 end address is: 0 (R0)
IT	AL
BAL	L_show_run_screen122
L_show_run_screen121:
; ?FLOC___show_run_screen?T333 start address is: 0 (R0)
MOVS	R0, #32
; ?FLOC___show_run_screen?T333 end address is: 0 (R0)
L_show_run_screen122:
; ?FLOC___show_run_screen?T333 start address is: 0 (R0)
STRB	R0, [R2, #0]
; ?FLOC___show_run_screen?T333 end address is: 0 (R0)
;Demo_Test.c,594 :: 		line1[11] = (temp_c_int % 10) + '0';
ADD	R4, SP, #4
ADDW	R3, R4, #11
MOVW	R0, #lo_addr(_temp_c_int+0)
MOVT	R0, #hi_addr(_temp_c_int+0)
LDRH	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTH	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,595 :: 		line1[12] = '.';
ADDW	R1, R4, #12
MOVS	R0, #46
STRB	R0, [R1, #0]
;Demo_Test.c,596 :: 		line1[13] = temp_c_frac + '0';
ADDW	R1, R4, #13
MOVW	R0, #lo_addr(_temp_c_frac+0)
MOVT	R0, #hi_addr(_temp_c_frac+0)
LDRH	R0, [R0, #0]
ADDS	R0, #48
STRB	R0, [R1, #0]
;Demo_Test.c,597 :: 		line1[14] = 'C';
ADDW	R1, R4, #14
MOVS	R0, #67
STRB	R0, [R1, #0]
;Demo_Test.c,600 :: 		line2[0] = (rtc_hour / 10) + '0';
ADD	R4, SP, #21
MOVW	R2, #lo_addr(_rtc_hour+0)
MOVT	R2, #hi_addr(_rtc_hour+0)
LDRB	R1, [R2, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R4, #0]
;Demo_Test.c,601 :: 		line2[1] = (rtc_hour % 10) + '0';
ADDS	R3, R4, #1
MOV	R0, R2
LDRB	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,602 :: 		line2[2] = ':';
ADDS	R1, R4, #2
MOVS	R0, #58
STRB	R0, [R1, #0]
;Demo_Test.c,603 :: 		line2[3] = (rtc_minute / 10) + '0';
ADDS	R3, R4, #3
MOVW	R2, #lo_addr(_rtc_minute+0)
MOVT	R2, #hi_addr(_rtc_minute+0)
LDRB	R1, [R2, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,604 :: 		line2[4] = (rtc_minute % 10) + '0';
ADDS	R3, R4, #4
MOV	R0, R2
LDRB	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,605 :: 		line2[5] = ':';
ADDS	R1, R4, #5
MOVS	R0, #58
STRB	R0, [R1, #0]
;Demo_Test.c,606 :: 		line2[6] = (rtc_second / 10) + '0';
ADDS	R3, R4, #6
MOVW	R2, #lo_addr(_rtc_second+0)
MOVT	R2, #hi_addr(_rtc_second+0)
LDRB	R1, [R2, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,607 :: 		line2[7] = (rtc_second % 10) + '0';
ADDS	R3, R4, #7
MOV	R0, R2
LDRB	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;Demo_Test.c,615 :: 		sw4 = GPIOC_IDR.B12 ? '0' : '1';
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_show_run_screen123
; ?FLOC___show_run_screen?T386 start address is: 0 (R0)
MOVS	R0, #48
; ?FLOC___show_run_screen?T386 end address is: 0 (R0)
IT	AL
BAL	L_show_run_screen124
L_show_run_screen123:
; ?FLOC___show_run_screen?T386 start address is: 0 (R0)
MOVS	R0, #49
; ?FLOC___show_run_screen?T386 end address is: 0 (R0)
L_show_run_screen124:
; ?FLOC___show_run_screen?T386 start address is: 0 (R0)
; sw4 start address is: 8 (R2)
UXTB	R2, R0
; ?FLOC___show_run_screen?T386 end address is: 0 (R0)
;Demo_Test.c,616 :: 		sw3 = GPIOC_IDR.B1  ? '0' : '1';
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_show_run_screen125
; ?FLOC___show_run_screen?T388 start address is: 0 (R0)
MOVS	R0, #48
; ?FLOC___show_run_screen?T388 end address is: 0 (R0)
IT	AL
BAL	L_show_run_screen126
L_show_run_screen125:
; ?FLOC___show_run_screen?T388 start address is: 0 (R0)
MOVS	R0, #49
; ?FLOC___show_run_screen?T388 end address is: 0 (R0)
L_show_run_screen126:
; ?FLOC___show_run_screen?T388 start address is: 0 (R0)
; sw3 start address is: 12 (R3)
UXTB	R3, R0
; ?FLOC___show_run_screen?T388 end address is: 0 (R0)
;Demo_Test.c,617 :: 		sw2 = GPIOB_IDR.B2  ? '0' : '1';
MOVW	R0, #lo_addr(GPIOB_IDR+0)
MOVT	R0, #hi_addr(GPIOB_IDR+0)
_LX	[R0, ByteOffset(GPIOB_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_show_run_screen127
; ?FLOC___show_run_screen?T390 start address is: 0 (R0)
MOVS	R0, #48
; ?FLOC___show_run_screen?T390 end address is: 0 (R0)
IT	AL
BAL	L_show_run_screen128
L_show_run_screen127:
; ?FLOC___show_run_screen?T390 start address is: 0 (R0)
MOVS	R0, #49
; ?FLOC___show_run_screen?T390 end address is: 0 (R0)
L_show_run_screen128:
; ?FLOC___show_run_screen?T390 start address is: 0 (R0)
; sw2 start address is: 16 (R4)
UXTB	R4, R0
; ?FLOC___show_run_screen?T390 end address is: 0 (R0)
;Demo_Test.c,618 :: 		sw1 = GPIOD_IDR.B2  ? '0' : '1';
MOVW	R0, #lo_addr(GPIOD_IDR+0)
MOVT	R0, #hi_addr(GPIOD_IDR+0)
_LX	[R0, ByteOffset(GPIOD_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_show_run_screen129
; ?FLOC___show_run_screen?T392 start address is: 0 (R0)
MOVS	R0, #48
; ?FLOC___show_run_screen?T392 end address is: 0 (R0)
IT	AL
BAL	L_show_run_screen130
L_show_run_screen129:
; ?FLOC___show_run_screen?T392 start address is: 0 (R0)
MOVS	R0, #49
; ?FLOC___show_run_screen?T392 end address is: 0 (R0)
L_show_run_screen130:
; ?FLOC___show_run_screen?T392 start address is: 0 (R0)
; sw1 start address is: 20 (R5)
UXTB	R5, R0
; ?FLOC___show_run_screen?T392 end address is: 0 (R0)
;Demo_Test.c,620 :: 		line2[12] = sw4;
ADD	R1, SP, #21
ADDW	R0, R1, #12
STRB	R2, [R0, #0]
; sw4 end address is: 8 (R2)
;Demo_Test.c,621 :: 		line2[13] = sw3;
ADDW	R0, R1, #13
STRB	R3, [R0, #0]
; sw3 end address is: 12 (R3)
;Demo_Test.c,622 :: 		line2[14] = sw2;
ADDW	R0, R1, #14
STRB	R4, [R0, #0]
; sw2 end address is: 16 (R4)
;Demo_Test.c,623 :: 		line2[15] = sw1;
ADDW	R0, R1, #15
STRB	R5, [R0, #0]
; sw1 end address is: 20 (R5)
;Demo_Test.c,625 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Demo_Test.c,626 :: 		Lcd_Out(1, 1, line1);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;Demo_Test.c,627 :: 		Lcd_Out(2, 1, line2);
ADD	R0, SP, #21
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;Demo_Test.c,628 :: 		}
L_end_show_run_screen:
LDR	LR, [SP, #0]
ADD	SP, SP, #40
BX	LR
; end of _show_run_screen
_main:
;Demo_Test.c,631 :: 		void main() {
SUB	SP, SP, #4
;Demo_Test.c,638 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;Demo_Test.c,635 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;Demo_Test.c,638 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;Demo_Test.c,641 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R1, #3072
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;Demo_Test.c,642 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);
MOVW	R1, #192
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;Demo_Test.c,645 :: 		GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_8 | _GPIO_PINMASK_14 | _GPIO_PINMASK_15);
MOVW	R1, #49408
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Output+0
;Demo_Test.c,648 :: 		ADC_Set_Input_Channel(_ADC_CHANNEL_10);
MOVW	R0, #1024
BL	_ADC_Set_Input_Channel+0
;Demo_Test.c,649 :: 		ADC1_Init();
BL	_ADC1_Init+0
;Demo_Test.c,651 :: 		leds_all_off();
BL	_leds_all_off+0
;Demo_Test.c,652 :: 		clear_7seg();
BL	_clear_7seg+0
;Demo_Test.c,654 :: 		keypad_init_mode();
BL	_keypad_init_mode+0
;Demo_Test.c,655 :: 		I2C1_HW_Init();
BL	_I2C1_HW_Init+0
;Demo_Test.c,657 :: 		Lcd_Init();
BL	_Lcd_Init+0
;Demo_Test.c,658 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Demo_Test.c,659 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;Demo_Test.c,661 :: 		DS1337_Init();
BL	_DS1337_Init+0
;Demo_Test.c,664 :: 		lcd_show_centered("UAEU", "SIP & DISTRICT4.0");
MOVW	R1, #lo_addr(?lstr3_Demo_Test+0)
MOVT	R1, #hi_addr(?lstr3_Demo_Test+0)
MOVW	R0, #lo_addr(?lstr2_Demo_Test+0)
MOVT	R0, #hi_addr(?lstr2_Demo_Test+0)
BL	_lcd_show_centered+0
;Demo_Test.c,665 :: 		intro_start_ms = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_intro_start_ms+0)
MOVT	R0, #hi_addr(_intro_start_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,666 :: 		ms_ticks = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
STR	R1, [R0, #0]
;Demo_Test.c,667 :: 		demo_state = DEMO_INTRO;
MOVS	R1, #0
MOVW	R0, #lo_addr(_demo_state+0)
MOVT	R0, #hi_addr(_demo_state+0)
STRB	R1, [R0, #0]
;Demo_Test.c,669 :: 		while(1) {
L_main131:
;Demo_Test.c,670 :: 		delayMs_soft(1);
MOVS	R0, #1
BL	_delayMs_soft+0
;Demo_Test.c,671 :: 		ms_ticks++;
MOVW	R1, #lo_addr(_ms_ticks+0)
MOVT	R1, #hi_addr(_ms_ticks+0)
LDR	R0, [R1, #0]
ADDS	R0, R0, #1
STR	R0, [R1, #0]
;Demo_Test.c,674 :: 		if(demo_state == DEMO_INTRO) {
MOVW	R0, #lo_addr(_demo_state+0)
MOVT	R0, #hi_addr(_demo_state+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	NE
BNE	L_main133
;Demo_Test.c,675 :: 		if(ms_ticks - intro_start_ms >= 5000) {
MOVW	R0, #lo_addr(_intro_start_ms+0)
MOVT	R0, #hi_addr(_intro_start_ms+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R0, [R0, #0]
SUB	R1, R0, R1
MOVW	R0, #5000
CMP	R1, R0
IT	CC
BCC	L_main134
;Demo_Test.c,676 :: 		password_len = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_password_len+0)
MOVT	R0, #hi_addr(_password_len+0)
STRB	R1, [R0, #0]
;Demo_Test.c,677 :: 		password_buf[0] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_password_buf+0)
MOVT	R0, #hi_addr(_password_buf+0)
STRB	R1, [R0, #0]
;Demo_Test.c,678 :: 		show_password_screen();
BL	_show_password_screen+0
;Demo_Test.c,679 :: 		demo_state = DEMO_PASSWORD;
MOVS	R1, #1
MOVW	R0, #lo_addr(_demo_state+0)
MOVT	R0, #hi_addr(_demo_state+0)
STRB	R1, [R0, #0]
;Demo_Test.c,680 :: 		}
L_main134:
;Demo_Test.c,681 :: 		}
IT	AL
BAL	L_main135
L_main133:
;Demo_Test.c,684 :: 		else if(demo_state == DEMO_PASSWORD) {
MOVW	R0, #lo_addr(_demo_state+0)
MOVT	R0, #hi_addr(_demo_state+0)
LDRB	R0, [R0, #0]
CMP	R0, #1
IT	NE
BNE	L_main136
;Demo_Test.c,685 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
STRB	R0, [SP, #0]
;Demo_Test.c,687 :: 		if((key >= '0' && key <= '9') ||
CMP	R0, #48
IT	CC
BCC	L__main183
LDRB	R0, [SP, #0]
CMP	R0, #57
IT	HI
BHI	L__main182
IT	AL
BAL	L__main179
L__main183:
L__main182:
;Demo_Test.c,688 :: 		(key >= 'A' && key <= 'D') ||
LDRB	R0, [SP, #0]
CMP	R0, #65
IT	CC
BCC	L__main185
LDRB	R0, [SP, #0]
CMP	R0, #68
IT	HI
BHI	L__main184
IT	AL
BAL	L__main179
L__main185:
L__main184:
;Demo_Test.c,689 :: 		(key == '*')) {
LDRB	R0, [SP, #0]
CMP	R0, #42
IT	EQ
BEQ	L__main186
IT	AL
BAL	L_main143
L__main179:
L__main186:
;Demo_Test.c,691 :: 		if(key == '*') {
LDRB	R0, [SP, #0]
CMP	R0, #42
IT	NE
BNE	L_main144
;Demo_Test.c,692 :: 		if(password_len > 0) {
MOVW	R0, #lo_addr(_password_len+0)
MOVT	R0, #hi_addr(_password_len+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	LS
BLS	L_main145
;Demo_Test.c,693 :: 		password_len--;
MOVW	R2, #lo_addr(_password_len+0)
MOVT	R2, #hi_addr(_password_len+0)
LDRB	R0, [R2, #0]
SUBS	R1, R0, #1
UXTB	R1, R1
STRB	R1, [R2, #0]
;Demo_Test.c,694 :: 		password_buf[password_len] = 0;
MOVW	R0, #lo_addr(_password_buf+0)
MOVT	R0, #hi_addr(_password_buf+0)
ADDS	R1, R0, R1
MOVS	R0, #0
STRB	R0, [R1, #0]
;Demo_Test.c,695 :: 		}
L_main145:
;Demo_Test.c,696 :: 		} else {
IT	AL
BAL	L_main146
L_main144:
;Demo_Test.c,697 :: 		if(password_len < 16) {
MOVW	R0, #lo_addr(_password_len+0)
MOVT	R0, #hi_addr(_password_len+0)
LDRB	R0, [R0, #0]
CMP	R0, #16
IT	CS
BCS	L_main147
;Demo_Test.c,698 :: 		password_buf[password_len] = key;
MOVW	R2, #lo_addr(_password_len+0)
MOVT	R2, #hi_addr(_password_len+0)
LDRB	R1, [R2, #0]
MOVW	R0, #lo_addr(_password_buf+0)
MOVT	R0, #hi_addr(_password_buf+0)
ADDS	R1, R0, R1
LDRB	R0, [SP, #0]
STRB	R0, [R1, #0]
;Demo_Test.c,699 :: 		password_len++;
MOV	R0, R2
LDRB	R0, [R0, #0]
ADDS	R1, R0, #1
UXTB	R1, R1
STRB	R1, [R2, #0]
;Demo_Test.c,700 :: 		password_buf[password_len] = 0;
MOVW	R0, #lo_addr(_password_buf+0)
MOVT	R0, #hi_addr(_password_buf+0)
ADDS	R1, R0, R1
MOVS	R0, #0
STRB	R0, [R1, #0]
;Demo_Test.c,701 :: 		}
L_main147:
;Demo_Test.c,702 :: 		}
L_main146:
;Demo_Test.c,704 :: 		show_password_screen();
BL	_show_password_screen+0
;Demo_Test.c,705 :: 		}
IT	AL
BAL	L_main148
L_main143:
;Demo_Test.c,706 :: 		else if(key == '#') {
LDRB	R0, [SP, #0]
CMP	R0, #35
IT	NE
BNE	L_main149
;Demo_Test.c,708 :: 		push_init_mode();             /* rows become push inputs, columns become switch inputs */
BL	_push_init_mode+0
;Demo_Test.c,709 :: 		leds_all_off();
BL	_leds_all_off+0
;Demo_Test.c,710 :: 		counter_7seg = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_counter_7seg+0)
MOVT	R0, #hi_addr(_counter_7seg+0)
STRH	R1, [R0, #0]
;Demo_Test.c,711 :: 		display_number_4digit(counter_7seg);
MOVW	R0, #0
BL	_display_number_4digit+0
;Demo_Test.c,713 :: 		led_step = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_led_step+0)
MOVT	R0, #hi_addr(_led_step+0)
STRB	R1, [R0, #0]
;Demo_Test.c,714 :: 		led_cycle = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_led_cycle+0)
MOVT	R0, #hi_addr(_led_cycle+0)
STRB	R1, [R0, #0]
;Demo_Test.c,715 :: 		led_pattern_done = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_led_pattern_done+0)
MOVT	R0, #hi_addr(_led_pattern_done+0)
STRB	R1, [R0, #0]
;Demo_Test.c,717 :: 		last_rtc_ms = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_last_rtc_ms+0)
MOVT	R0, #hi_addr(_last_rtc_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,718 :: 		last_screen_ms = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_last_screen_ms+0)
MOVT	R0, #hi_addr(_last_screen_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,719 :: 		last_counter_ms = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_last_counter_ms+0)
MOVT	R0, #hi_addr(_last_counter_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,720 :: 		last_led_ms = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_last_led_ms+0)
MOVT	R0, #hi_addr(_last_led_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,722 :: 		DS1337_GetDateTime();
BL	_DS1337_GetDateTime+0
;Demo_Test.c,723 :: 		Read_LM34_Celsius();
BL	_Read_LM34_Celsius+0
;Demo_Test.c,724 :: 		show_run_screen();
BL	_show_run_screen+0
;Demo_Test.c,726 :: 		demo_state = DEMO_RUN;
MOVS	R1, #2
MOVW	R0, #lo_addr(_demo_state+0)
MOVT	R0, #hi_addr(_demo_state+0)
STRB	R1, [R0, #0]
;Demo_Test.c,727 :: 		}
L_main149:
L_main148:
;Demo_Test.c,728 :: 		}
IT	AL
BAL	L_main150
L_main136:
;Demo_Test.c,731 :: 		else if(demo_state == DEMO_RUN) {
MOVW	R0, #lo_addr(_demo_state+0)
MOVT	R0, #hi_addr(_demo_state+0)
LDRB	R0, [R0, #0]
CMP	R0, #2
IT	NE
BNE	L_main151
;Demo_Test.c,734 :: 		if(ms_ticks - last_rtc_ms >= 1000) {
MOVW	R0, #lo_addr(_last_rtc_ms+0)
MOVT	R0, #hi_addr(_last_rtc_ms+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R0, [R0, #0]
SUB	R0, R0, R1
CMP	R0, #1000
IT	CC
BCC	L_main152
;Demo_Test.c,735 :: 		last_rtc_ms = ms_ticks;
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_last_rtc_ms+0)
MOVT	R0, #hi_addr(_last_rtc_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,736 :: 		DS1337_GetDateTime();
BL	_DS1337_GetDateTime+0
;Demo_Test.c,737 :: 		}
L_main152:
;Demo_Test.c,740 :: 		if(ms_ticks - last_screen_ms >= 200) {
MOVW	R0, #lo_addr(_last_screen_ms+0)
MOVT	R0, #hi_addr(_last_screen_ms+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R0, [R0, #0]
SUB	R0, R0, R1
CMP	R0, #200
IT	CC
BCC	L_main153
;Demo_Test.c,741 :: 		last_screen_ms = ms_ticks;
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_last_screen_ms+0)
MOVT	R0, #hi_addr(_last_screen_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,742 :: 		Read_LM34_Celsius();
BL	_Read_LM34_Celsius+0
;Demo_Test.c,743 :: 		show_run_screen();
BL	_show_run_screen+0
;Demo_Test.c,744 :: 		}
L_main153:
;Demo_Test.c,747 :: 		if(ms_ticks - last_counter_ms >= 100) {
MOVW	R0, #lo_addr(_last_counter_ms+0)
MOVT	R0, #hi_addr(_last_counter_ms+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R0, [R0, #0]
SUB	R0, R0, R1
CMP	R0, #100
IT	CC
BCC	L_main154
;Demo_Test.c,748 :: 		last_counter_ms = ms_ticks;
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_last_counter_ms+0)
MOVT	R0, #hi_addr(_last_counter_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,749 :: 		counter_7seg++;
MOVW	R2, #lo_addr(_counter_7seg+0)
MOVT	R2, #hi_addr(_counter_7seg+0)
LDRH	R0, [R2, #0]
ADDS	R1, R0, #1
UXTH	R1, R1
STRH	R1, [R2, #0]
;Demo_Test.c,750 :: 		if(counter_7seg > 9999) counter_7seg = 0;
MOVW	R0, #9999
CMP	R1, R0
IT	LS
BLS	L_main155
MOVS	R1, #0
MOVW	R0, #lo_addr(_counter_7seg+0)
MOVT	R0, #hi_addr(_counter_7seg+0)
STRH	R1, [R0, #0]
L_main155:
;Demo_Test.c,751 :: 		display_number_4digit(counter_7seg);
MOVW	R0, #lo_addr(_counter_7seg+0)
MOVT	R0, #hi_addr(_counter_7seg+0)
LDRH	R0, [R0, #0]
BL	_display_number_4digit+0
;Demo_Test.c,752 :: 		}
L_main154:
;Demo_Test.c,755 :: 		if(!led_pattern_done) {
MOVW	R0, #lo_addr(_led_pattern_done+0)
MOVT	R0, #hi_addr(_led_pattern_done+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	NE
BNE	L_main156
;Demo_Test.c,756 :: 		if(ms_ticks - last_led_ms >= 200) {
MOVW	R0, #lo_addr(_last_led_ms+0)
MOVT	R0, #hi_addr(_last_led_ms+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R0, [R0, #0]
SUB	R0, R0, R1
CMP	R0, #200
IT	CC
BCC	L_main157
;Demo_Test.c,757 :: 		last_led_ms = ms_ticks;
MOVW	R0, #lo_addr(_ms_ticks+0)
MOVT	R0, #hi_addr(_ms_ticks+0)
LDR	R1, [R0, #0]
MOVW	R0, #lo_addr(_last_led_ms+0)
MOVT	R0, #hi_addr(_last_led_ms+0)
STR	R1, [R0, #0]
;Demo_Test.c,759 :: 		led_on(led_seq[led_step]);
MOVW	R0, #lo_addr(_led_step+0)
MOVT	R0, #hi_addr(_led_step+0)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_led_seq+0)
MOVT	R0, #hi_addr(_led_seq+0)
ADDS	R0, R0, R1
LDRB	R0, [R0, #0]
BL	_led_on+0
;Demo_Test.c,760 :: 		led_step++;
MOVW	R1, #lo_addr(_led_step+0)
MOVT	R1, #hi_addr(_led_step+0)
LDRB	R0, [R1, #0]
ADDS	R0, R0, #1
UXTB	R0, R0
STRB	R0, [R1, #0]
;Demo_Test.c,762 :: 		if(led_step >= 6) {
CMP	R0, #6
IT	CC
BCC	L_main158
;Demo_Test.c,763 :: 		led_step = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_led_step+0)
MOVT	R0, #hi_addr(_led_step+0)
STRB	R1, [R0, #0]
;Demo_Test.c,764 :: 		led_cycle++;
MOVW	R1, #lo_addr(_led_cycle+0)
MOVT	R1, #hi_addr(_led_cycle+0)
LDRB	R0, [R1, #0]
ADDS	R0, R0, #1
UXTB	R0, R0
STRB	R0, [R1, #0]
;Demo_Test.c,765 :: 		if(led_cycle >= 5) {
CMP	R0, #5
IT	CC
BCC	L_main159
;Demo_Test.c,766 :: 		led_pattern_done = 1;
MOVS	R1, #1
MOVW	R0, #lo_addr(_led_pattern_done+0)
MOVT	R0, #hi_addr(_led_pattern_done+0)
STRB	R1, [R0, #0]
;Demo_Test.c,767 :: 		leds_all_off();
BL	_leds_all_off+0
;Demo_Test.c,768 :: 		}
L_main159:
;Demo_Test.c,769 :: 		}
L_main158:
;Demo_Test.c,770 :: 		}
L_main157:
;Demo_Test.c,771 :: 		}
IT	AL
BAL	L_main160
L_main156:
;Demo_Test.c,774 :: 		map_push_to_leds();
BL	_map_push_to_leds+0
;Demo_Test.c,775 :: 		}
L_main160:
;Demo_Test.c,776 :: 		}
L_main151:
L_main150:
L_main135:
;Demo_Test.c,777 :: 		}
IT	AL
BAL	L_main131
;Demo_Test.c,778 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
