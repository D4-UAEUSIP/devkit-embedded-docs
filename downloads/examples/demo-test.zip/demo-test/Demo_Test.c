/*
   --------------------------------------------------------------------
   STM32F446RE Demo
   mikroC PRO for ARM

   Features:
   - LCD 16x2
   - Keypad
   - DS1337 RTC (register-level I2C1)
   - LM34 on PC0
   - 4-digit 7-segment via 74HC595
   - 4 LEDs
   - 4 push buttons
   - 4 digital switches

   Sequence:
   1) LCD shows:
        line1 centered: "UAEU"
        line2 centered: "SIP & DISTRICT4.0"
      for 5 seconds

   2) LCD shows:
        line1 centered: "Enter Password"
        line2: typed keypad characters
      when user presses '#', go to run screen

   3) Run screen:
      - LCD line1: date on left, temperature on right
      - LCD line2: time on left, switch states on right
      - RTC updates every 1 second
      - LM34 / switch display updates every 200 ms
      - shift-register 7-segment counts every 100 ms
      - LED pattern runs concurrently:
            LED1 -> LED2 -> LED3 -> LED4 -> LED3 -> LED2
        one step every 200 ms
        repeat 5 times
      - after LED pattern finishes:
            all LEDs OFF
            push button states mapped to LEDs

   Notes:
   - During password entry:
       keypad uses PC12, PC1, PB2, PD2 as column outputs
       and PC7, PC13, PA9, PA10 as row inputs
   - After '#' is pressed:
       row pins are reconfigured as push button inputs
       column pins are reconfigured as digital switch inputs
   --------------------------------------------------------------------
*/

/* ========================= LCD ========================= */
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

/* ========================= 7SEG SHIFT REG ========================= */
/* SER -> PA8, SRCLK -> PA14, RCLK -> PA15 */
sbit SR_SER   at GPIOA_ODR.B8;
sbit SR_SRCLK at GPIOA_ODR.B14;
sbit SR_RCLK  at GPIOA_ODR.B15;

/* ========================= CONSTANTS ========================= */
#define DS1337_ADDR     0x68

#define DEMO_INTRO      0
#define DEMO_PASSWORD   1
#define DEMO_RUN        2

/* ========================= GLOBALS ========================= */
const char keymap[4][4] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

/* 7-seg bit map:
   bit0=a bit1=b bit2=c bit3=d bit4=e bit5=f bit6=g bit7=dp
*/
const unsigned char seg_code[10] = {
  0x3F,   /* 0 */
  0x06,   /* 1 */
  0x5B,   /* 2 */
  0x4F,   /* 3 */
  0x66,   /* 4 */
  0x6D,   /* 5 */
  0x7D,   /* 6 */
  0x07,   /* 7 */
  0x7F,   /* 8 */
  0x6F    /* 9 */
};

unsigned short rtc_buf[7];
char password_buf[17];
unsigned short password_len = 0;

unsigned char demo_state = DEMO_INTRO;
unsigned long ms_ticks = 0;

/* timers */
unsigned long intro_start_ms = 0;
unsigned long last_rtc_ms = 0;
unsigned long last_screen_ms = 0;
unsigned long last_counter_ms = 0;
unsigned long last_led_ms = 0;

/* 7-seg counter */
unsigned int counter_7seg = 0;

/* LED pattern */
const unsigned char led_seq[6] = {1,2,3,4,3,2};
unsigned char led_step = 0;
unsigned char led_cycle = 0;
unsigned char led_pattern_done = 0;

/* RTC cache */
unsigned short rtc_day, rtc_month, rtc_year;
unsigned short rtc_hour, rtc_minute, rtc_second;

/* LM34 cache */
unsigned int adc_avg;
unsigned long adc_sum;
float voltage;
float temp_f;
float temp_c;
unsigned int temp_c_int;
unsigned int temp_c_frac;

/* ========================= SIMPLE DELAY ========================= */
void delayMs_soft(unsigned int n) {
  unsigned int i;
  for(; n > 0; n--) {
    for(i = 0; i < 3195; i++) {
      asm nop;
    }
  }
}

/* ========================= STRING HELPERS ========================= */
unsigned short my_strlen(char *s) {
  unsigned short len = 0;
  while(s[len] != 0) len++;
  return len;
}

void clear16(char *s) {
  unsigned short i;
  for(i = 0; i < 16; i++) s[i] = ' ';
  s[16] = 0;
}

void center_text(char *dst16, char *src) {
  unsigned short len, start, i;

  clear16(dst16);
  len = my_strlen(src);

  if(len >= 16) {
    for(i = 0; i < 16; i++) dst16[i] = src[i];
    dst16[16] = 0;
    return;
  }

  start = (16 - len) / 2;

  for(i = 0; i < len; i++) {
    dst16[start + i] = src[i];
  }
}

void lcd_show_centered(char *line1, char *line2) {
  char buf1[17];
  char buf2[17];

  center_text(buf1, line1);
  center_text(buf2, line2);

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, buf1);
  Lcd_Out(2, 1, buf2);
}

/* ========================= LED CONTROL ========================= */
void leds_all_off() {
  GPIOC_ODR.B10 = 0;   /* LED1 */
  GPIOC_ODR.B11 = 0;   /* LED2 */
  GPIOB_ODR.B6  = 0;   /* LED3 */
  GPIOB_ODR.B7  = 0;   /* LED4 */
}

void led_on(unsigned char idx) {
  leds_all_off();

  switch(idx) {
    case 1: GPIOB_ODR.B6  = 1;  break; /* LED1 */
    case 2: GPIOB_ODR.B7  = 1;  break; /* LED2 */
    case 3: GPIOC_ODR.B10 = 1;  break; /* LED3 */
    case 4: GPIOC_ODR.B11 = 1;  break; /* LED4 */
  }
}

void map_push_to_leds() {
  /* push1 -> PC7  -> LED1 PC10
     push2 -> PC13 -> LED2 PC11
     push3 -> PA9  -> LED3 PB6
     push4 -> PA10 -> LED4 PB7
  */
  GPIOC_ODR.B10 = GPIOC_IDR.B13;
  GPIOC_ODR.B11 = GPIOC_IDR.B7;
  GPIOB_ODR.B6  = GPIOA_IDR.B9;
  GPIOB_ODR.B7  = GPIOA_IDR.B10;
}
/* ========================= KEYPAD ========================= */
void Keypad_AllColumns_Low() {
  GPIOC_ODR.B12 = 0;   /* C1 */
  GPIOC_ODR.B1  = 0;   /* C2 */
  GPIOB_ODR.B2  = 0;   /* C3 */
  GPIOD_ODR.B2  = 0;   /* C4 */
}

void Keypad_SelectColumn(unsigned short col) {
  Keypad_AllColumns_Low();

  switch(col) {
    case 0: GPIOC_ODR.B12 = 1; break;   /* C1 */
    case 1: GPIOC_ODR.B1  = 1; break;   /* C2 */
    case 2: GPIOB_ODR.B2  = 1; break;   /* C3 */
    case 3: GPIOD_ODR.B2  = 1; break;   /* C4 */
  }
}

unsigned short Keypad_ReadRow() {
  if(GPIOC_IDR.B7  == 1) return 0;   /* R1 */
  if(GPIOC_IDR.B13 == 1) return 1;   /* R2 */
  if(GPIOA_IDR.B9  == 1) return 2;   /* R3 */
  if(GPIOA_IDR.B10 == 1) return 3;   /* R4 */

  return 255;
}

char Keypad_GetKey() {
  unsigned short row, col;

  for(col = 0; col < 4; col++) {
    Keypad_SelectColumn(col);
    Delay_ms(1);

    row = Keypad_ReadRow();
    if(row != 255) {
      Keypad_AllColumns_Low();
      return keymap[row][col];
    }
  }

  Keypad_AllColumns_Low();
  return 0;
}

char Keypad_GetKey_Click() {
  char key;

  while(1) {
    key = Keypad_GetKey();
    if(key != 0) {
      Delay_ms(20);
      if(Keypad_GetKey() == key) {
        while(Keypad_GetKey() != 0) {
          Delay_ms(10);
        }
        Delay_ms(20);
        return key;
      }
    }
  }
}

void keypad_init_mode() {
  /* rows as inputs */
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);

  /* columns as outputs */
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);

  Keypad_AllColumns_Low();
}

void push_init_mode() {
  /* repurpose row pins as push button inputs */
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);

  /* release keypad columns and read them as digital switches */
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
  GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_2);
  GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_2);
}

/* ========================= DS1337 RTC ========================= */
unsigned short BcdToDec(unsigned short val) {
  return ((val >> 4) * 10) + (val & 0x0F);
}

void I2C1_HW_Init() {
  RCC_AHB1ENR |= 0x00000002;      /* GPIOB clock enable */
  RCC_APB1ENR |= 0x00200000;      /* I2C1 clock enable */

  GPIOB_AFRH &= ~0x000000FF;
  GPIOB_AFRH |=  0x00000044;      /* PB8, PB9 -> AF4 */

  GPIOB_MODER &= ~0x000F0000;
  GPIOB_MODER |=  0x000A0000;     /* alternate function */

  GPIOB_OTYPER |= 0x00000300;     /* open drain */

  GPIOB_PUPDR &= ~0x000F0000;
  GPIOB_PUPDR |=  0x00050000;     /* pull-up */

  I2C1_CR1 = 0x8000;
  I2C1_CR1 &= ~0x8000;

  I2C1_CR2 = 16;
  I2C1_CCR = 80;
  I2C1_TRISE = 17;

  I2C1_CR1 |= 0x0001;
}

unsigned short I2C1_WaitWhileBusy() {
  unsigned long timeout = 60000;
  while((I2C1_SR2 & 2) && timeout) timeout--;
  return (timeout != 0);
}

unsigned short I2C1_WaitTXE() {
  unsigned long timeout = 60000;
  while(!(I2C1_SR1 & 0x80) && timeout) timeout--;
  return (timeout != 0);
}

unsigned short I2C1_WaitRXNE() {
  unsigned long timeout = 60000;
  while(!(I2C1_SR1 & 0x40) && timeout) timeout--;
  return (timeout != 0);
}

unsigned short I2C1_Start_WriteAddr(unsigned short saddr) {
  volatile unsigned int tmp;
  unsigned long timeout;

  I2C1_CR1 |= 0x0100;
  timeout = 60000;
  while(!(I2C1_SR1 & 1) && timeout) timeout--;
  if(timeout == 0) return 0;

  I2C1_DR = saddr << 1;

  timeout = 60000;
  while(timeout) {
    if(I2C1_SR1 & 2) {
      tmp = I2C1_SR2;
      return 1;
    }
    if(I2C1_SR1 & 0x0400) {
      I2C1_SR1 &= ~0x0400;
      I2C1_CR1 |= 0x0200;
      return 0;
    }
    timeout--;
  }

  I2C1_CR1 |= 0x0200;
  return 0;
}

unsigned short I2C1_BurstRead(unsigned short saddr,
                              unsigned short start_reg,
                              unsigned short count,
                              unsigned short data_buf[]) {
  volatile unsigned int tmp;
  unsigned short i;

  if(!I2C1_WaitWhileBusy()) return 0;

  I2C1_CR1 &= ~0x0800;
  if(!I2C1_Start_WriteAddr(saddr)) return 0;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_DR = start_reg;
  if(!I2C1_WaitTXE()) return 0;

  I2C1_CR1 |= 0x0100;
  {
    unsigned long timeout = 60000;
    while(!(I2C1_SR1 & 1) && timeout) timeout--;
    if(timeout == 0) return 0;
  }

  I2C1_DR = (saddr << 1) | 1;
  {
    unsigned long timeout = 60000;
    while(timeout) {
      if(I2C1_SR1 & 2) break;
      if(I2C1_SR1 & 0x0400) {
        I2C1_SR1 &= ~0x0400;
        I2C1_CR1 |= 0x0200;
        return 0;
      }
      timeout--;
    }
    if(timeout == 0) {
      I2C1_CR1 |= 0x0200;
      return 0;
    }
  }

  tmp = I2C1_SR2;
  I2C1_CR1 |= 0x0400;

  for(i = 0; i < count; i++) {
    if(i == (count - 1)) {
      I2C1_CR1 &= ~0x0400;
      I2C1_CR1 |=  0x0200;
    }

    if(!I2C1_WaitRXNE()) return 0;
    data_buf[i] = I2C1_DR;
  }

  return 1;
}

unsigned short I2C1_WriteByte_Reg(unsigned short saddr,
                                  unsigned short reg_addr,
                                  unsigned short value) {
  if(!I2C1_WaitWhileBusy()) return 0;
  if(!I2C1_Start_WriteAddr(saddr)) return 0;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_DR = reg_addr;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_DR = value;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_CR1 |= 0x0200;
  return 1;
}

void DS1337_Init() {
  I2C1_WriteByte_Reg(DS1337_ADDR, 0x0E, 0x00);
  I2C1_WriteByte_Reg(DS1337_ADDR, 0x0F, 0x00);
}

unsigned short DS1337_GetDateTime() {
  if(!I2C1_BurstRead(DS1337_ADDR, 0x00, 7, rtc_buf)) return 0;

  rtc_second = BcdToDec(rtc_buf[0] & 0x7F);
  rtc_minute = BcdToDec(rtc_buf[1] & 0x7F);
  rtc_hour   = BcdToDec(rtc_buf[2] & 0x3F);
  rtc_day    = BcdToDec(rtc_buf[4] & 0x3F);
  rtc_month  = BcdToDec(rtc_buf[5] & 0x1F);
  rtc_year   = BcdToDec(rtc_buf[6]);

  return 1;
}

/* ========================= LM34 ========================= */
unsigned int Read_ADC_Average() {
  unsigned short i;
  adc_sum = 0;

  for(i = 0; i < 16; i++) {
    adc_sum += ADC1_Get_Sample(10);   /* PC0 = channel 10 */
    Delay_ms(2);
  }

  return (unsigned int)(adc_sum / 16);
}

void Read_LM34_Celsius() {
  adc_avg = Read_ADC_Average();

  voltage = (adc_avg * 3.3) / 4095.0;
  temp_f  = voltage * 100.0;
  temp_c  = (temp_f - 32.0) * 5.0 / 9.0;

  temp_c_int  = (unsigned int)temp_c;
  temp_c_frac = (unsigned int)((temp_c - temp_c_int) * 10.0);
}

/* ========================= SHIFT REGISTER 7SEG ========================= */
void pulse_srclk() {
  SR_SRCLK = 1;
  Delay_us(1);
  SR_SRCLK = 0;
  Delay_us(1);
}

void pulse_rclk() {
  SR_RCLK = 1;
  Delay_us(1);
  SR_RCLK = 0;
  Delay_us(1);
}

void shift_out_byte(unsigned char value) {
  unsigned char i;

  for(i = 0; i < 8; i++) {
    if(value & 0x80)
      SR_SER = 1;
    else
      SR_SER = 0;

    pulse_srclk();
    value <<= 1;
  }
}

void display_raw_4(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
  shift_out_byte(d4);
  shift_out_byte(d3);
  shift_out_byte(d2);
  shift_out_byte(d1);
  pulse_rclk();
}

void clear_7seg() {
  display_raw_4(0x00, 0x00, 0x00, 0x00);
}

void display_number_4digit(unsigned int value) {
  unsigned char d1, d2, d3, d4;

  d1 = value / 1000;
  d2 = (value / 100) % 10;
  d3 = (value / 10) % 10;
  d4 = value % 10;

  display_raw_4(seg_code[d1], seg_code[d2], seg_code[d3], seg_code[d4]);
}

/* ========================= SCREEN BUILDERS ========================= */
void show_password_screen() {
  char line1[17];
  char line2[17];
  unsigned short i;

  center_text(line1, "Enter Password");
  clear16(line2);

  for(i = 0; i < password_len && i < 16; i++) {
    line2[i] = password_buf[i];
  }

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, line1);
  Lcd_Out(2, 1, line2);
}

void show_run_screen() {
  char line1[17];
  char line2[17];
  char sw1, sw2, sw3, sw4;

  clear16(line1);
  clear16(line2);

  /* left side date */
  line1[0] = (rtc_day / 10) + '0';
  line1[1] = (rtc_day % 10) + '0';
  line1[2] = '/';
  line1[3] = (rtc_month / 10) + '0';
  line1[4] = (rtc_month % 10) + '0';
  line1[5] = '/';
  line1[6] = (rtc_year / 10) + '0';
  line1[7] = (rtc_year % 10) + '0';

  /* right side temp: 25.5C */
  line1[10] = (temp_c_int / 10) ? ((temp_c_int / 10) + '0') : ' ';
  line1[11] = (temp_c_int % 10) + '0';
  line1[12] = '.';
  line1[13] = temp_c_frac + '0';
  line1[14] = 'C';

  /* left side time */
  line2[0] = (rtc_hour / 10) + '0';
  line2[1] = (rtc_hour % 10) + '0';
  line2[2] = ':';
  line2[3] = (rtc_minute / 10) + '0';
  line2[4] = (rtc_minute % 10) + '0';
  line2[5] = ':';
  line2[6] = (rtc_second / 10) + '0';
  line2[7] = (rtc_second % 10) + '0';

  /* switch states on right:
     SW4 -> PC12
     SW3 -> PC1
     SW2 -> PB2
     SW1 -> PD2
  */
  sw4 = GPIOC_IDR.B12 ? '0' : '1';
  sw3 = GPIOC_IDR.B1  ? '0' : '1';
  sw2 = GPIOB_IDR.B2  ? '0' : '1';
  sw1 = GPIOD_IDR.B2  ? '0' : '1';

  line2[12] = sw4;
  line2[13] = sw3;
  line2[14] = sw2;
  line2[15] = sw1;

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, line1);
  Lcd_Out(2, 1, line2);
}

/* ========================= MAIN ========================= */
void main() {
  char key;

  /* LCD pins */
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  /* LED pins */
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  /* shift register pins */
  GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_8 | _GPIO_PINMASK_14 | _GPIO_PINMASK_15);

  /* ADC for LM34 on PC0 */
  ADC_Set_Input_Channel(_ADC_CHANNEL_10);
  ADC1_Init();

  leds_all_off();
  clear_7seg();

  keypad_init_mode();
  I2C1_HW_Init();

  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  DS1337_Init();

  /* Step 1 */
  lcd_show_centered("UAEU", "SIP & DISTRICT4.0");
  intro_start_ms = 0;
  ms_ticks = 0;
  demo_state = DEMO_INTRO;

  while(1) {
    delayMs_soft(1);
    ms_ticks++;

    /* Step 1 -> Step 2 after 5 seconds */
    if(demo_state == DEMO_INTRO) {
      if(ms_ticks - intro_start_ms >= 5000) {
        password_len = 0;
        password_buf[0] = 0;
        show_password_screen();
        demo_state = DEMO_PASSWORD;
      }
    }

    /* Step 2: password entry using keypad */
    else if(demo_state == DEMO_PASSWORD) {
      key = Keypad_GetKey_Click();

      if((key >= '0' && key <= '9') ||
         (key >= 'A' && key <= 'D') ||
         (key == '*')) {

        if(key == '*') {
          if(password_len > 0) {
            password_len--;
            password_buf[password_len] = 0;
          }
        } else {
          if(password_len < 16) {
            password_buf[password_len] = key;
            password_len++;
            password_buf[password_len] = 0;
          }
        }

        show_password_screen();
      }
      else if(key == '#') {
        /* switch to run mode */
        push_init_mode();             /* rows become push inputs, columns become switch inputs */
        leds_all_off();
        counter_7seg = 0;
        display_number_4digit(counter_7seg);

        led_step = 0;
        led_cycle = 0;
        led_pattern_done = 0;

        last_rtc_ms = 0;
        last_screen_ms = 0;
        last_counter_ms = 0;
        last_led_ms = 0;

        DS1337_GetDateTime();
        Read_LM34_Celsius();
        show_run_screen();

        demo_state = DEMO_RUN;
      }
    }

    /* Step 3: RTC + temp + switches + counter + LED pattern + push mapping */
    else if(demo_state == DEMO_RUN) {

      /* RTC update every 1 second */
      if(ms_ticks - last_rtc_ms >= 1000) {
        last_rtc_ms = ms_ticks;
        DS1337_GetDateTime();
      }

      /* screen update every 200 ms */
      if(ms_ticks - last_screen_ms >= 200) {
        last_screen_ms = ms_ticks;
        Read_LM34_Celsius();
        show_run_screen();
      }

      /* 7-seg counter every 100 ms */
      if(ms_ticks - last_counter_ms >= 100) {
        last_counter_ms = ms_ticks;
        counter_7seg++;
        if(counter_7seg > 9999) counter_7seg = 0;
        display_number_4digit(counter_7seg);
      }

      /* LED pattern every 200 ms for 5 cycles */
      if(!led_pattern_done) {
        if(ms_ticks - last_led_ms >= 200) {
          last_led_ms = ms_ticks;

          led_on(led_seq[led_step]);
          led_step++;

          if(led_step >= 6) {
            led_step = 0;
            led_cycle++;
            if(led_cycle >= 5) {
              led_pattern_done = 1;
              leds_all_off();
            }
          }
        }
      }
      else {
        /* after pattern finished, push buttons control LEDs */
        map_push_to_leds();
      }
    }
  }
}