#define LED GPIOB_ODR.B6
#define SCB_SCR_REG (*((volatile unsigned long *)0xE000ED10))
#define SLEEPDEEP   0x00000004

// on the start the LED will be on for 500ms then off and after 1000m the mcu enter the standby mode
// to wakeup it just press the wakeup button
/*
   Switches Selection:
   on Main Board:

   SW5 : Wake_UP side
   VR1: adujest it till  you see the text on LCD

   on Module Board:
   there is 4 DIP Switches Make sure it is in the CAN Side

*/

void enter_standby() {
    RCC_APB1ENR.B28 = 1;      // enable PWR clock

    PWR_CR.B2 = 1;            // CWUF: clear wakeup flag
    PWR_CR.B3 = 1;            // CSBF: clear standby flag
    PWR_CSR.B8 = 1;           // EWUP1: enable PA0-WKUP
    PWR_CR.B1 = 1;            // PDDS: select Standby mode

    SCB_SCR_REG |= SLEEPDEEP; // deep sleep

    asm {
        WFI
    }
}

void main() {
    RCC_AHB1ENR.B1 = 1;                               // GPIOB clock
    GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6); // PB6 output
    LED = 0;

    RCC_APB1ENR.B28 = 1;                              // PWR clock

    if (PWR_CSR.B1) {                                 // SBF: woke from Standby
        PWR_CR.B3 = 1;                                // clear standby flag
        LED = 1;
        Delay_ms(500);
        LED = 0;
    }

    Delay_ms(1000);                                   // demo delay
    enter_standby();

    while (1);
}