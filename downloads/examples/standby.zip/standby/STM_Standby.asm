_enter_standby:
;STM_Standby.c,5 :: 		void enter_standby() {
;STM_Standby.c,6 :: 		RCC_APB1ENR.B28 = 1;      // enable PWR clock
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
_SX	[R0, ByteOffset(RCC_APB1ENR+0)]
;STM_Standby.c,8 :: 		PWR_CR.B2 = 1;            // CWUF: clear wakeup flag
MOVW	R0, #lo_addr(PWR_CR+0)
MOVT	R0, #hi_addr(PWR_CR+0)
_SX	[R0, ByteOffset(PWR_CR+0)]
;STM_Standby.c,9 :: 		PWR_CR.B3 = 1;            // CSBF: clear standby flag
MOVW	R0, #lo_addr(PWR_CR+0)
MOVT	R0, #hi_addr(PWR_CR+0)
_SX	[R0, ByteOffset(PWR_CR+0)]
;STM_Standby.c,10 :: 		PWR_CSR.B8 = 1;           // EWUP1: enable PA0-WKUP
MOVW	R0, #lo_addr(PWR_CSR+0)
MOVT	R0, #hi_addr(PWR_CSR+0)
_SX	[R0, ByteOffset(PWR_CSR+0)]
;STM_Standby.c,11 :: 		PWR_CR.B1 = 1;            // PDDS: select Standby mode
MOVW	R0, #lo_addr(PWR_CR+0)
MOVT	R0, #hi_addr(PWR_CR+0)
_SX	[R0, ByteOffset(PWR_CR+0)]
;STM_Standby.c,13 :: 		SCB_SCR_REG |= SLEEPDEEP; // deep sleep
MOVW	R0, -536810224
MOVT	R0, 57344
LDR	R0, [R0, #0]
ORR	R1, R0, #4
MOVW	R0, -536810224
MOVT	R0, 57344
STR	R1, [R0, #0]
;STM_Standby.c,16 :: 		WFI
WFI
;STM_Standby.c,18 :: 		}
L_end_enter_standby:
BX	LR
; end of _enter_standby
_main:
;STM_Standby.c,20 :: 		void main() {
;STM_Standby.c,21 :: 		RCC_AHB1ENR.B1 = 1;                               // GPIOB clock
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
_SX	[R0, ByteOffset(RCC_AHB1ENR+0)]
;STM_Standby.c,22 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6); // PB6 output
MOVW	R1, #64
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;STM_Standby.c,23 :: 		LED = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM_Standby.c,25 :: 		RCC_APB1ENR.B28 = 1;                              // PWR clock
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
_SX	[R0, ByteOffset(RCC_APB1ENR+0)]
;STM_Standby.c,27 :: 		if (PWR_CSR.B1) {                                 // SBF: woke from Standby
MOVW	R0, #lo_addr(PWR_CSR+0)
MOVT	R0, #hi_addr(PWR_CSR+0)
_LX	[R0, ByteOffset(PWR_CSR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_main0
;STM_Standby.c,28 :: 		PWR_CR.B3 = 1;                                // clear standby flag
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(PWR_CR+0)
MOVT	R0, #hi_addr(PWR_CR+0)
_SX	[R0, ByteOffset(PWR_CR+0)]
;STM_Standby.c,29 :: 		LED = 1;
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM_Standby.c,30 :: 		Delay_ms(500);
MOVW	R7, #45225
MOVT	R7, #40
NOP
NOP
L_main1:
SUBS	R7, R7, #1
BNE	L_main1
NOP
NOP
;STM_Standby.c,31 :: 		LED = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM_Standby.c,32 :: 		}
L_main0:
;STM_Standby.c,34 :: 		Delay_ms(1000);                                   // demo delay
MOVW	R7, #24915
MOVT	R7, #81
NOP
NOP
L_main3:
SUBS	R7, R7, #1
BNE	L_main3
NOP
NOP
NOP
NOP
;STM_Standby.c,35 :: 		enter_standby();
BL	_enter_standby+0
;STM_Standby.c,37 :: 		while (1);
L_main5:
IT	AL
BAL	L_main5
;STM_Standby.c,38 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
