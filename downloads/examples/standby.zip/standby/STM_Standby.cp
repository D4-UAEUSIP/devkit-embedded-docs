#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/STM_Standby.c"




void enter_standby() {
 RCC_APB1ENR.B28 = 1;

 PWR_CR.B2 = 1;
 PWR_CR.B3 = 1;
 PWR_CSR.B8 = 1;
 PWR_CR.B1 = 1;

  (*((volatile unsigned long *)0xE000ED10))  |=  0x00000004 ;

 asm {
 WFI
 }
}

void main() {
 RCC_AHB1ENR.B1 = 1;
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6);
  GPIOB_ODR.B6  = 0;

 RCC_APB1ENR.B28 = 1;

 if (PWR_CSR.B1) {
 PWR_CR.B3 = 1;
  GPIOB_ODR.B6  = 1;
 Delay_ms(500);
  GPIOB_ODR.B6  = 0;
 }

 Delay_ms(1000);
 enter_standby();

 while (1);
}
