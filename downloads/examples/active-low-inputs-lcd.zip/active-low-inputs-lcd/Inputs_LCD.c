/*
   ------------------------------------------------------------
   STM32F446RE - Active-Low Inputs on LCD
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   SW24,SW25,SW7,SW10 : GPIO side
   VR1: adujest it till  you see the text on LCD
   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5

   Inputs:
     IN4 -> PC11
     IN3 -> PC10
     IN2 -> PB7
     IN1 -> PB6

   Input behavior:
     Inputs are active LOW.
     LOW  -> displayed as 1
     HIGH -> displayed as 0

   LCD display:
     Line 1: IN1 and IN2
     Line 2: IN3 and IN4
*/

// ---------------- LCD pin mapping ----------------
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

// Direction declarations required by mikroC LCD library
sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

char ActiveLowState(unsigned short value) {
  if(value == 0)
    return '1';

  return '0';
}

void main() {
  char in1, in2, in3, in4;

  // Configure LCD pins as outputs
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  // Configure active-low inputs
  GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_6 | _GPIO_PINMASK_7);
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);

  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1, 1, "IN1:0  IN2:0");
  Lcd_Out(2, 1, "IN3:0  IN4:0");

  while(1) {
    in1 = ActiveLowState(GPIOB_IDR.B6);
    in2 = ActiveLowState(GPIOB_IDR.B7);
    in3 = ActiveLowState(GPIOC_IDR.B10);
    in4 = ActiveLowState(GPIOC_IDR.B11);

    Lcd_Chr(1, 5, in1);
    Lcd_Chr(1, 12, in2);
    Lcd_Chr(2, 5, in3);
    Lcd_Chr(2, 12, in4);

    Delay_ms(100);
  }
}
