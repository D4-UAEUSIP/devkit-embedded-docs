_ActiveLowState:
;Inputs_LCD.c,53 :: 		char ActiveLowState(unsigned short value) {
; value start address is: 0 (R0)
; value end address is: 0 (R0)
; value start address is: 0 (R0)
;Inputs_LCD.c,54 :: 		if(value == 0)
CMP	R0, #0
IT	NE
BNE	L_ActiveLowState0
; value end address is: 0 (R0)
;Inputs_LCD.c,55 :: 		return '1';
MOVS	R0, #49
IT	AL
BAL	L_end_ActiveLowState
L_ActiveLowState0:
;Inputs_LCD.c,57 :: 		return '0';
MOVS	R0, #48
;Inputs_LCD.c,58 :: 		}
L_end_ActiveLowState:
BX	LR
; end of _ActiveLowState
_main:
;Inputs_LCD.c,60 :: 		void main() {
;Inputs_LCD.c,67 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;Inputs_LCD.c,64 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;Inputs_LCD.c,67 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;Inputs_LCD.c,70 :: 		GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_6 | _GPIO_PINMASK_7);
MOVW	R1, #192
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Input+0
;Inputs_LCD.c,71 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R1, #3072
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;Inputs_LCD.c,73 :: 		Lcd_Init();
BL	_Lcd_Init+0
;Inputs_LCD.c,74 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Inputs_LCD.c,75 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;Inputs_LCD.c,77 :: 		Lcd_Out(1, 1, "IN1:0  IN2:0");
MOVW	R0, #lo_addr(?lstr1_Inputs_LCD+0)
MOVT	R0, #hi_addr(?lstr1_Inputs_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;Inputs_LCD.c,78 :: 		Lcd_Out(2, 1, "IN3:0  IN4:0");
MOVW	R0, #lo_addr(?lstr2_Inputs_LCD+0)
MOVT	R0, #hi_addr(?lstr2_Inputs_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;Inputs_LCD.c,80 :: 		while(1) {
L_main1:
;Inputs_LCD.c,81 :: 		in1 = ActiveLowState(GPIOB_IDR.B6);
MOVW	R0, #lo_addr(GPIOB_IDR+0)
MOVT	R0, #hi_addr(GPIOB_IDR+0)
_LX	[R0, ByteOffset(GPIOB_IDR+0)]
BL	_ActiveLowState+0
; in1 start address is: 32 (R8)
UXTB	R8, R0
;Inputs_LCD.c,82 :: 		in2 = ActiveLowState(GPIOB_IDR.B7);
MOVW	R0, #lo_addr(GPIOB_IDR+0)
MOVT	R0, #hi_addr(GPIOB_IDR+0)
_LX	[R0, ByteOffset(GPIOB_IDR+0)]
BL	_ActiveLowState+0
; in2 start address is: 36 (R9)
UXTB	R9, R0
;Inputs_LCD.c,83 :: 		in3 = ActiveLowState(GPIOC_IDR.B10);
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
BL	_ActiveLowState+0
; in3 start address is: 40 (R10)
UXTB	R10, R0
;Inputs_LCD.c,84 :: 		in4 = ActiveLowState(GPIOC_IDR.B11);
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
BL	_ActiveLowState+0
; in4 start address is: 44 (R11)
UXTB	R11, R0
;Inputs_LCD.c,86 :: 		Lcd_Chr(1, 5, in1);
UXTB	R2, R8
MOVS	R1, #5
MOVS	R0, #1
BL	_Lcd_Chr+0
;Inputs_LCD.c,87 :: 		Lcd_Chr(1, 12, in2);
UXTB	R2, R9
MOVS	R1, #12
MOVS	R0, #1
BL	_Lcd_Chr+0
;Inputs_LCD.c,88 :: 		Lcd_Chr(2, 5, in3);
UXTB	R2, R10
MOVS	R1, #5
MOVS	R0, #2
BL	_Lcd_Chr+0
;Inputs_LCD.c,89 :: 		Lcd_Chr(2, 12, in4);
UXTB	R2, R11
MOVS	R1, #12
MOVS	R0, #2
BL	_Lcd_Chr+0
;Inputs_LCD.c,91 :: 		Delay_ms(100);
MOVW	R7, #9043
MOVT	R7, #8
NOP
NOP
L_main3:
SUBS	R7, R7, #1
BNE	L_main3
NOP
NOP
NOP
NOP
;Inputs_LCD.c,92 :: 		}
IT	AL
BAL	L_main1
; in1 end address is: 32 (R8)
; in2 end address is: 36 (R9)
; in3 end address is: 40 (R10)
; in4 end address is: 44 (R11)
;Inputs_LCD.c,93 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
