/*
   ------------------------------------------------------------
   STM32F446RE - LED Test
   mikroC PRO for ARM
   ------------------------------------------------------------

   LED outputs:
     LED4 -> PC11  
     LED3 -> PC10   
     LED2 -> PB7    
     LED1 -> PB6    

   Operation:
     LED Flashing

   Assumption:
     - LED ON = logic HIGH

*/
void main() {

  // Configure LED pins as output
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  // Turn all LEDs OFF initially
  GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIOB_ODR &= ~(_GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  while(1) {

    // LED4 (PC11)
    GPIOC_ODR |= _GPIO_PINMASK_11;
    Delay_ms(1000);
    GPIOC_ODR &= ~_GPIO_PINMASK_11;

    // LED3 (PC10)
    GPIOC_ODR |= _GPIO_PINMASK_10;
    Delay_ms(1000);
    GPIOC_ODR &= ~_GPIO_PINMASK_10;

    // LED2 (PB7)
    GPIOB_ODR |= _GPIO_PINMASK_7;
    Delay_ms(1000);
    GPIOB_ODR &= ~_GPIO_PINMASK_7;

    // LED1 (PB6)
    GPIOB_ODR |= _GPIO_PINMASK_6;
    Delay_ms(1000);
    GPIOB_ODR &= ~_GPIO_PINMASK_6;
  }
}