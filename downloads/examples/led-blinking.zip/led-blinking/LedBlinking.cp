#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/LedBlinking.c"
#line 20 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/LedBlinking.c"
void main() {


 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6 | _GPIO_PINMASK_7);


 GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIOB_ODR &= ~(_GPIO_PINMASK_6 | _GPIO_PINMASK_7);

 while(1) {


 GPIOC_ODR |= _GPIO_PINMASK_11;
 Delay_ms(1000);
 GPIOC_ODR &= ~_GPIO_PINMASK_11;


 GPIOC_ODR |= _GPIO_PINMASK_10;
 Delay_ms(1000);
 GPIOC_ODR &= ~_GPIO_PINMASK_10;


 GPIOB_ODR |= _GPIO_PINMASK_7;
 Delay_ms(1000);
 GPIOB_ODR &= ~_GPIO_PINMASK_7;


 GPIOB_ODR |= _GPIO_PINMASK_6;
 Delay_ms(1000);
 GPIOB_ODR &= ~_GPIO_PINMASK_6;
 }
}
