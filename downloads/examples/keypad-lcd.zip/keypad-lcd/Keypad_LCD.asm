_Keypad_AllColumns_Low:
;Keypad_LCD.c,70 :: 		void Keypad_AllColumns_Low() {
;Keypad_LCD.c,71 :: 		GPIOC_ODR.B12 = 0;   // C1
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Keypad_LCD.c,72 :: 		GPIOC_ODR.B1  = 0;   // C2
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Keypad_LCD.c,73 :: 		GPIOB_ODR.B2  = 0;   // C3
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Keypad_LCD.c,74 :: 		GPIOD_ODR.B2  = 0;   // C4
MOVW	R0, #lo_addr(GPIOD_ODR+0)
MOVT	R0, #hi_addr(GPIOD_ODR+0)
_SX	[R0, ByteOffset(GPIOD_ODR+0)]
;Keypad_LCD.c,75 :: 		}
L_end_Keypad_AllColumns_Low:
BX	LR
; end of _Keypad_AllColumns_Low
_Keypad_SelectColumn:
;Keypad_LCD.c,77 :: 		void Keypad_SelectColumn(unsigned short col) {
; col start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R2, R0
; col end address is: 0 (R0)
; col start address is: 8 (R2)
;Keypad_LCD.c,78 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Keypad_LCD.c,80 :: 		switch(col) {
IT	AL
BAL	L_Keypad_SelectColumn0
; col end address is: 8 (R2)
;Keypad_LCD.c,81 :: 		case 0: GPIOC_ODR.B12 = 1; break;   // C1
L_Keypad_SelectColumn2:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn1
;Keypad_LCD.c,82 :: 		case 1: GPIOC_ODR.B1  = 1; break;   // C2
L_Keypad_SelectColumn3:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn1
;Keypad_LCD.c,83 :: 		case 2: GPIOB_ODR.B2  = 1; break;   // C3
L_Keypad_SelectColumn4:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
_SX	[R1, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn1
;Keypad_LCD.c,84 :: 		case 3: GPIOD_ODR.B2  = 1; break;   // C4
L_Keypad_SelectColumn5:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOD_ODR+0)
MOVT	R1, #hi_addr(GPIOD_ODR+0)
_SX	[R1, ByteOffset(GPIOD_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn1
;Keypad_LCD.c,85 :: 		}
L_Keypad_SelectColumn0:
; col start address is: 8 (R2)
CMP	R2, #0
IT	EQ
BEQ	L_Keypad_SelectColumn2
CMP	R2, #1
IT	EQ
BEQ	L_Keypad_SelectColumn3
CMP	R2, #2
IT	EQ
BEQ	L_Keypad_SelectColumn4
CMP	R2, #3
IT	EQ
BEQ	L_Keypad_SelectColumn5
; col end address is: 8 (R2)
L_Keypad_SelectColumn1:
;Keypad_LCD.c,86 :: 		}
L_end_Keypad_SelectColumn:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_SelectColumn
_Keypad_ReadRow:
;Keypad_LCD.c,88 :: 		unsigned short Keypad_ReadRow() {
;Keypad_LCD.c,89 :: 		if(GPIOC_IDR.B7  == 1) return 0;   // R1
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow6
MOVS	R0, #0
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow6:
;Keypad_LCD.c,90 :: 		if(GPIOC_IDR.B13 == 1) return 1;   // R2
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow7
MOVS	R0, #1
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow7:
;Keypad_LCD.c,91 :: 		if(GPIOA_IDR.B9  == 1) return 2;   // R3
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow8
MOVS	R0, #2
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow8:
;Keypad_LCD.c,92 :: 		if(GPIOA_IDR.B10 == 1) return 3;   // R4
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow9
MOVS	R0, #3
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow9:
;Keypad_LCD.c,94 :: 		return 255;
MOVS	R0, #255
;Keypad_LCD.c,95 :: 		}
L_end_Keypad_ReadRow:
BX	LR
; end of _Keypad_ReadRow
_Keypad_GetKey:
;Keypad_LCD.c,104 :: 		char Keypad_GetKey() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Keypad_LCD.c,107 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
MOVS	R3, #0
; col end address is: 12 (R3)
L_Keypad_GetKey10:
; col start address is: 12 (R3)
CMP	R3, #4
IT	CS
BCS	L_Keypad_GetKey11
;Keypad_LCD.c,108 :: 		Keypad_SelectColumn(col);
UXTB	R0, R3
BL	_Keypad_SelectColumn+0
;Keypad_LCD.c,109 :: 		Delay_ms(1);
MOVW	R7, #7998
MOVT	R7, #0
NOP
NOP
L_Keypad_GetKey13:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey13
NOP
NOP
NOP
;Keypad_LCD.c,111 :: 		row = Keypad_ReadRow();
BL	_Keypad_ReadRow+0
; row start address is: 8 (R2)
UXTB	R2, R0
;Keypad_LCD.c,112 :: 		if(row != 255) {
CMP	R0, #255
IT	EQ
BEQ	L_Keypad_GetKey15
;Keypad_LCD.c,113 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Keypad_LCD.c,114 :: 		return keymap[row][col];
LSLS	R1, R2, #2
; row end address is: 8 (R2)
MOVW	R0, #lo_addr(_keymap+0)
MOVT	R0, #hi_addr(_keymap+0)
ADDS	R0, R0, R1
ADDS	R0, R0, R3
; col end address is: 12 (R3)
LDRB	R0, [R0, #0]
IT	AL
BAL	L_end_Keypad_GetKey
;Keypad_LCD.c,115 :: 		}
L_Keypad_GetKey15:
;Keypad_LCD.c,107 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
ADDS	R3, R3, #1
UXTB	R3, R3
;Keypad_LCD.c,116 :: 		}
; col end address is: 12 (R3)
IT	AL
BAL	L_Keypad_GetKey10
L_Keypad_GetKey11:
;Keypad_LCD.c,118 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Keypad_LCD.c,119 :: 		return 0;
MOVS	R0, #0
;Keypad_LCD.c,120 :: 		}
L_end_Keypad_GetKey:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_GetKey
_LCD_PutKey:
;Keypad_LCD.c,122 :: 		void LCD_PutKey(char k, unsigned short *pos) {
; pos start address is: 4 (R1)
; k start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
MOV	R6, R1
; pos end address is: 4 (R1)
; k end address is: 0 (R0)
; k start address is: 0 (R0)
; pos start address is: 24 (R6)
;Keypad_LCD.c,124 :: 		txt[0] = k;
ADD	R2, SP, #4
STRB	R0, [R2, #0]
; k end address is: 0 (R0)
;Keypad_LCD.c,125 :: 		txt[1] = 0;
ADDS	R3, R2, #1
MOVS	R2, #0
STRB	R2, [R3, #0]
;Keypad_LCD.c,127 :: 		if(*pos >= 32) {
LDRB	R2, [R6, #0]
CMP	R2, #32
IT	CC
BCC	L_LCD_PutKey16
;Keypad_LCD.c,128 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Keypad_LCD.c,129 :: 		*pos = 0;
MOVS	R2, #0
STRB	R2, [R6, #0]
;Keypad_LCD.c,130 :: 		}
L_LCD_PutKey16:
;Keypad_LCD.c,132 :: 		if(*pos < 16)
LDRB	R2, [R6, #0]
CMP	R2, #16
IT	CS
BCS	L_LCD_PutKey17
;Keypad_LCD.c,133 :: 		Lcd_Out(1, *pos + 1, txt);
ADD	R3, SP, #4
LDRB	R2, [R6, #0]
ADDS	R2, R2, #1
UXTB	R1, R2
MOV	R2, R3
MOVS	R0, #1
BL	_Lcd_Out+0
IT	AL
BAL	L_LCD_PutKey18
L_LCD_PutKey17:
;Keypad_LCD.c,135 :: 		Lcd_Out(2, (*pos - 16) + 1, txt);
ADD	R3, SP, #4
LDRB	R2, [R6, #0]
SUBS	R2, #16
SXTH	R2, R2
ADDS	R2, R2, #1
UXTB	R1, R2
MOV	R2, R3
MOVS	R0, #2
BL	_Lcd_Out+0
L_LCD_PutKey18:
;Keypad_LCD.c,137 :: 		(*pos)++;
LDRB	R2, [R6, #0]
ADDS	R2, R2, #1
STRB	R2, [R6, #0]
; pos end address is: 24 (R6)
;Keypad_LCD.c,138 :: 		}
L_end_LCD_PutKey:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _LCD_PutKey
_main:
;Keypad_LCD.c,140 :: 		void main() {
SUB	SP, SP, #4
;Keypad_LCD.c,142 :: 		char last_key = 0;
MOVS	R0, #0
STRB	R0, [SP, #1]
MOVS	R0, #0
STRB	R0, [SP, #2]
;Keypad_LCD.c,143 :: 		unsigned short lcd_pos = 0;
;Keypad_LCD.c,149 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;Keypad_LCD.c,146 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;Keypad_LCD.c,149 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;Keypad_LCD.c,152 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
MOVW	R1, #8320
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;Keypad_LCD.c,153 :: 		GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);
MOVW	R1, #1536
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Input+0
;Keypad_LCD.c,156 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
MOVW	R1, #4098
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;Keypad_LCD.c,157 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;Keypad_LCD.c,158 :: 		GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOD_BASE+0)
MOVT	R0, #hi_addr(GPIOD_BASE+0)
BL	_GPIO_Digital_Output+0
;Keypad_LCD.c,160 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;Keypad_LCD.c,162 :: 		Lcd_Init();
BL	_Lcd_Init+0
;Keypad_LCD.c,163 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Keypad_LCD.c,164 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;Keypad_LCD.c,166 :: 		Lcd_Out(1, 1, "Keypad Test");
MOVW	R0, #lo_addr(?lstr1_Keypad_LCD+0)
MOVT	R0, #hi_addr(?lstr1_Keypad_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;Keypad_LCD.c,167 :: 		Lcd_Out(2, 1, "Press Key...");
MOVW	R0, #lo_addr(?lstr2_Keypad_LCD+0)
MOVT	R0, #hi_addr(?lstr2_Keypad_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;Keypad_LCD.c,168 :: 		Delay_ms(1500);
MOVW	R7, #6910
MOVT	R7, #183
NOP
NOP
L_main19:
SUBS	R7, R7, #1
BNE	L_main19
NOP
NOP
NOP
;Keypad_LCD.c,169 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;Keypad_LCD.c,171 :: 		while(1) {
L_main21:
;Keypad_LCD.c,172 :: 		key = Keypad_GetKey();
BL	_Keypad_GetKey+0
STRB	R0, [SP, #0]
;Keypad_LCD.c,179 :: 		if((key != 0) && (last_key == 0)) {
CMP	R0, #0
IT	EQ
BEQ	L__main34
LDRB	R0, [SP, #1]
CMP	R0, #0
IT	NE
BNE	L__main33
L__main32:
;Keypad_LCD.c,180 :: 		Delay_ms(20);              // debounce confirm
MOVW	R7, #28926
MOVT	R7, #2
NOP
NOP
L_main26:
SUBS	R7, R7, #1
BNE	L_main26
NOP
NOP
NOP
;Keypad_LCD.c,181 :: 		key = Keypad_GetKey();
BL	_Keypad_GetKey+0
STRB	R0, [SP, #0]
;Keypad_LCD.c,182 :: 		if(key != 0) {
CMP	R0, #0
IT	EQ
BEQ	L_main28
;Keypad_LCD.c,183 :: 		LCD_PutKey(key, &lcd_pos);
ADD	R0, SP, #2
MOV	R1, R0
LDRB	R0, [SP, #0]
BL	_LCD_PutKey+0
;Keypad_LCD.c,184 :: 		last_key = key;
LDRB	R0, [SP, #0]
STRB	R0, [SP, #1]
;Keypad_LCD.c,185 :: 		}
L_main28:
;Keypad_LCD.c,179 :: 		if((key != 0) && (last_key == 0)) {
L__main34:
L__main33:
;Keypad_LCD.c,191 :: 		if(key == 0) {
LDRB	R0, [SP, #0]
CMP	R0, #0
IT	NE
BNE	L_main29
;Keypad_LCD.c,192 :: 		last_key = 0;
MOVS	R0, #0
STRB	R0, [SP, #1]
;Keypad_LCD.c,193 :: 		}
L_main29:
;Keypad_LCD.c,195 :: 		Delay_ms(10);
MOVW	R7, #14462
MOVT	R7, #1
NOP
NOP
L_main30:
SUBS	R7, R7, #1
BNE	L_main30
NOP
NOP
NOP
;Keypad_LCD.c,196 :: 		}
IT	AL
BAL	L_main21
;Keypad_LCD.c,197 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
