/*
   ------------------------------------------------------------
   STM32F446RE - 4x4 Keypad to LCD Test
   One press = one character
   Hardware:
     - columns externally pulled UP
     - rows externally pulled DOWN
   ------------------------------------------------------------
   Switches Selection:
   SW11 :   All off
   SW12 : must be in DIS side
   SW13 : KP-R2 side
   SW16: KP-C side
   SW2 : KP-R3 side
   SW19 : 2:ON   1 :off
   VR1: adujest it till  you see the text on LCD

   Rows:
     R1 -> PC7
     R2 -> PC13
     R3 -> PA9
     R4 -> PA10

   Columns:
     C1 -> PC12
     C2 -> PC1
     C3 -> PB2
     C4 -> PD2

   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5
*/

// ---------------- LCD pin mapping ----------------
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

// ---------------- Key map ----------------
const char keymap[4][4] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

/*
   In this hardware:
   - rows idle LOW because of external pulldown
   - columns are scanned as outputs
   - inactive columns are driven LOW
   - selected column is driven HIGH
   - pressed key on selected column makes row HIGH
*/
void Keypad_AllColumns_Low() {
  GPIOC_ODR.B12 = 0;   // C1
  GPIOC_ODR.B1  = 0;   // C2
  GPIOB_ODR.B2  = 0;   // C3
  GPIOD_ODR.B2  = 0;   // C4
}

void Keypad_SelectColumn(unsigned short col) {
  Keypad_AllColumns_Low();

  switch(col) {
    case 0: GPIOC_ODR.B12 = 1; break;   // C1
    case 1: GPIOC_ODR.B1  = 1; break;   // C2
    case 2: GPIOB_ODR.B2  = 1; break;   // C3
    case 3: GPIOD_ODR.B2  = 1; break;   // C4
  }
}

unsigned short Keypad_ReadRow() {
  if(GPIOC_IDR.B7  == 1) return 0;   // R1
  if(GPIOC_IDR.B13 == 1) return 1;   // R2
  if(GPIOA_IDR.B9  == 1) return 2;   // R3
  if(GPIOA_IDR.B10 == 1) return 3;   // R4

  return 255;
}

/*
   Scan keypad once.
   Returns:
     pressed key character
   or
     0 if no key is pressed
*/
char Keypad_GetKey() {
  unsigned short row, col;

  for(col = 0; col < 4; col++) {
    Keypad_SelectColumn(col);
    Delay_ms(1);

    row = Keypad_ReadRow();
    if(row != 255) {
      Keypad_AllColumns_Low();
      return keymap[row][col];
    }
  }

  Keypad_AllColumns_Low();
  return 0;
}

void LCD_PutKey(char k, unsigned short *pos) {
  char txt[2];
  txt[0] = k;
  txt[1] = 0;

  if(*pos >= 32) {
    Lcd_Cmd(_LCD_CLEAR);
    *pos = 0;
  }

  if(*pos < 16)
    Lcd_Out(1, *pos + 1, txt);
  else
    Lcd_Out(2, (*pos - 16) + 1, txt);

  (*pos)++;
}

void main() {
  char key;
  char last_key = 0;
  unsigned short lcd_pos = 0;

  // LCD outputs
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  // keypad rows as inputs
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);

  // keypad columns as outputs
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
  GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);

  Keypad_AllColumns_Low();

  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1, 1, "Keypad Test");
  Lcd_Out(2, 1, "Press Key...");
  Delay_ms(1500);
  Lcd_Cmd(_LCD_CLEAR);

  while(1) {
    key = Keypad_GetKey();

    /*
      Write only on a new press:
      previous state = no key
      current state  = key pressed
    */
    if((key != 0) && (last_key == 0)) {
      Delay_ms(20);              // debounce confirm
      key = Keypad_GetKey();
      if(key != 0) {
        LCD_PutKey(key, &lcd_pos);
        last_key = key;
      }
    }

    /*
      Reset state only after full release
    */
    if(key == 0) {
      last_key = 0;
    }

    Delay_ms(10);
  }
}