#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Seven_segment.c"
#line 65 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Seven_segment.c"
void all_digits_off() {
 GPIOB_ODR &= ~ ( _GPIO_PINMASK_12  | _GPIO_PINMASK_13  | _GPIO_PINMASK_14  | _GPIO_PINMASK_15 ) ;
}

void all_segments_off() {
 GPIOB_ODR |=  ( _GPIO_PINMASK_0  | _GPIO_PINMASK_1  | _GPIO_PINMASK_3  | _GPIO_PINMASK_4  | _GPIO_PINMASK_5  | _GPIO_PINMASK_10 ) ;
 GPIOA_ODR |=  _GPIO_PINMASK_13 ;
}

void digit_on(unsigned short d) {
 all_digits_off();

 if(d == 1) GPIOB_ODR |=  _GPIO_PINMASK_12 ;
 if(d == 2) GPIOB_ODR |=  _GPIO_PINMASK_13 ;
 if(d == 3) GPIOB_ODR |=  _GPIO_PINMASK_14 ;
 if(d == 4) GPIOB_ODR |=  _GPIO_PINMASK_15 ;
}
#line 87 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Seven_segment.c"
void set_segments(unsigned short num) {

 all_segments_off();

 if(num == 255) return;

 switch(num) {
 case 0:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_1 | _GPIO_PINMASK_3 | _GPIO_PINMASK_4 | _GPIO_PINMASK_5 | _GPIO_PINMASK_10 );
 break;

 case 1:
 GPIOB_ODR &= ~( _GPIO_PINMASK_1 | _GPIO_PINMASK_3 );
 break;

 case 2:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_1 | _GPIO_PINMASK_4 | _GPIO_PINMASK_5 );
 GPIOA_ODR &= ~ _GPIO_PINMASK_13 ;
 break;

 case 3:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_1 | _GPIO_PINMASK_3 | _GPIO_PINMASK_4 );
 GPIOA_ODR &= ~ _GPIO_PINMASK_13 ;
 break;

 case 4:
 GPIOB_ODR &= ~( _GPIO_PINMASK_1 | _GPIO_PINMASK_3 | _GPIO_PINMASK_10 );
 GPIOA_ODR &= ~ _GPIO_PINMASK_13 ;
 break;

 case 5:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_3 | _GPIO_PINMASK_4 | _GPIO_PINMASK_10 );
 GPIOA_ODR &= ~ _GPIO_PINMASK_13 ;
 break;

 case 6:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_3 | _GPIO_PINMASK_4 | _GPIO_PINMASK_5 | _GPIO_PINMASK_10 );
 GPIOA_ODR &= ~ _GPIO_PINMASK_13 ;
 break;

 case 7:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_1 | _GPIO_PINMASK_3 );
 break;

 case 8:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_1 | _GPIO_PINMASK_3 | _GPIO_PINMASK_4 | _GPIO_PINMASK_5 | _GPIO_PINMASK_10 );
 GPIOA_ODR &= ~ _GPIO_PINMASK_13 ;
 break;

 case 9:
 GPIOB_ODR &= ~( _GPIO_PINMASK_0 | _GPIO_PINMASK_1 | _GPIO_PINMASK_3 | _GPIO_PINMASK_4 | _GPIO_PINMASK_10 );
 GPIOA_ODR &= ~ _GPIO_PINMASK_13 ;
 break;
 }
}

void display_4digits(unsigned short d1,
 unsigned short d2,
 unsigned short d3,
 unsigned short d4,
 unsigned int loops) {

 unsigned int i;

 for(i = 0; i < loops; i++) {

 set_segments(d1);
 digit_on(1);
 Delay_ms(2);

 set_segments(d2);
 digit_on(2);
 Delay_ms(2);

 set_segments(d3);
 digit_on(3);
 Delay_ms(2);

 set_segments(d4);
 digit_on(4);
 Delay_ms(2);
 }

 all_digits_off();
}
#line 176 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Seven_segment.c"
void display_number(unsigned int value, unsigned int loops) {

 unsigned short d1, d2, d3, d4;

 d1 = value / 1000;
 d2 = (value / 100) % 10;
 d3 = (value / 10) % 10;
 d4 = value % 10;


 if(d1 == 0) d1 = 255;
 if(d1 == 255 && d2 == 0) d2 = 255;
 if(d2 == 255 && d3 == 0) d3 = 255;

 display_4digits(d1, d2, d3, d4, loops);
}

void main() {

 unsigned short i;
 unsigned int count;

 GPIO_Digital_Output(&GPIOA_BASE,  _GPIO_PINMASK_13 );
 GPIO_Digital_Output(&GPIOB_BASE,
  _GPIO_PINMASK_0 | _GPIO_PINMASK_1 | _GPIO_PINMASK_3 |
  _GPIO_PINMASK_4 | _GPIO_PINMASK_5 | _GPIO_PINMASK_10 |
  _GPIO_PINMASK_12 | _GPIO_PINMASK_13 | _GPIO_PINMASK_14 | _GPIO_PINMASK_15 );

 all_digits_off();
 all_segments_off();

 while(1) {


 for(i = 0; i <= 9; i++) {
 display_4digits(i, i, i, i, 125);
 }


 for(count = 0; count <= 9999; count++) {
 display_number(count, 13);
 }
 }
}
