_all_digits_off:
;Seven_segment.c,65 :: 		void all_digits_off() {
;Seven_segment.c,66 :: 		GPIOB_ODR &= ~ALL_DIG_MASK;
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R0, #0]
MVN	R0, #61440
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
STR	R1, [R0, #0]
;Seven_segment.c,67 :: 		}
L_end_all_digits_off:
BX	LR
; end of _all_digits_off
_all_segments_off:
;Seven_segment.c,69 :: 		void all_segments_off() {
;Seven_segment.c,70 :: 		GPIOB_ODR |= ALL_SEG_B_MASK;   // OFF (active LOW)
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R0, #0]
MOVW	R0, #1083
ORRS	R1, R0
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
STR	R1, [R0, #0]
;Seven_segment.c,71 :: 		GPIOA_ODR |= SEG_G_MASK;
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #8192
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
STR	R1, [R0, #0]
;Seven_segment.c,72 :: 		}
L_end_all_segments_off:
BX	LR
; end of _all_segments_off
_digit_on:
;Seven_segment.c,74 :: 		void digit_on(unsigned short d) {
; d start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R3, R0
; d end address is: 0 (R0)
; d start address is: 12 (R3)
;Seven_segment.c,75 :: 		all_digits_off();
BL	_all_digits_off+0
;Seven_segment.c,77 :: 		if(d == 1) GPIOB_ODR |= DIG1_MASK;
CMP	R3, #1
IT	NE
BNE	L_digit_on0
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #4096
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
L_digit_on0:
;Seven_segment.c,78 :: 		if(d == 2) GPIOB_ODR |= DIG2_MASK;
CMP	R3, #2
IT	NE
BNE	L_digit_on1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #8192
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
L_digit_on1:
;Seven_segment.c,79 :: 		if(d == 3) GPIOB_ODR |= DIG3_MASK;
CMP	R3, #3
IT	NE
BNE	L_digit_on2
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #16384
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
L_digit_on2:
;Seven_segment.c,80 :: 		if(d == 4) GPIOB_ODR |= DIG4_MASK;
CMP	R3, #4
IT	NE
BNE	L_digit_on3
; d end address is: 12 (R3)
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #32768
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
L_digit_on3:
;Seven_segment.c,81 :: 		}
L_end_digit_on:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _digit_on
_set_segments:
;Seven_segment.c,87 :: 		void set_segments(unsigned short num) {
; num start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R2, R0
; num end address is: 0 (R0)
; num start address is: 8 (R2)
;Seven_segment.c,89 :: 		all_segments_off();
BL	_all_segments_off+0
;Seven_segment.c,91 :: 		if(num == 255) return;   // blank digit
CMP	R2, #255
IT	NE
BNE	L_set_segments4
; num end address is: 8 (R2)
IT	AL
BAL	L_end_set_segments
L_set_segments4:
;Seven_segment.c,93 :: 		switch(num) {
; num start address is: 8 (R2)
IT	AL
BAL	L_set_segments5
; num end address is: 8 (R2)
;Seven_segment.c,94 :: 		case 0:
L_set_segments7:
;Seven_segment.c,95 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK|SEG_E_MASK|SEG_F_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MOVW	R1, #64452
MOVT	R1, #65535
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,96 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,98 :: 		case 1:
L_set_segments8:
;Seven_segment.c,99 :: 		GPIOB_ODR &= ~(SEG_B_MASK|SEG_C_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #10
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,100 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,102 :: 		case 2:
L_set_segments9:
;Seven_segment.c,103 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_D_MASK|SEG_E_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #51
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,104 :: 		GPIOA_ODR &= ~SEG_G_MASK;
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #8192
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,105 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,107 :: 		case 3:
L_set_segments10:
;Seven_segment.c,108 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #27
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,109 :: 		GPIOA_ODR &= ~SEG_G_MASK;
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #8192
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,110 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,112 :: 		case 4:
L_set_segments11:
;Seven_segment.c,113 :: 		GPIOB_ODR &= ~(SEG_B_MASK|SEG_C_MASK|SEG_F_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MOVW	R1, #64501
MOVT	R1, #65535
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,114 :: 		GPIOA_ODR &= ~SEG_G_MASK;
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #8192
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,115 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,117 :: 		case 5:
L_set_segments12:
;Seven_segment.c,118 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_C_MASK|SEG_D_MASK|SEG_F_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MOVW	R1, #64486
MOVT	R1, #65535
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,119 :: 		GPIOA_ODR &= ~SEG_G_MASK;
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #8192
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,120 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,122 :: 		case 6:
L_set_segments13:
;Seven_segment.c,123 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_C_MASK|SEG_D_MASK|SEG_E_MASK|SEG_F_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MOVW	R1, #64454
MOVT	R1, #65535
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,124 :: 		GPIOA_ODR &= ~SEG_G_MASK;
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #8192
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,125 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,127 :: 		case 7:
L_set_segments14:
;Seven_segment.c,128 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #11
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,129 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,131 :: 		case 8:
L_set_segments15:
;Seven_segment.c,132 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK|SEG_E_MASK|SEG_F_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MOVW	R1, #64452
MOVT	R1, #65535
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,133 :: 		GPIOA_ODR &= ~SEG_G_MASK;
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #8192
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,134 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,136 :: 		case 9:
L_set_segments16:
;Seven_segment.c,137 :: 		GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK|SEG_F_MASK);
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
LDR	R2, [R1, #0]
MOVW	R1, #64484
MOVT	R1, #65535
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,138 :: 		GPIOA_ODR &= ~SEG_G_MASK;
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
LDR	R2, [R1, #0]
MVN	R1, #8192
ANDS	R2, R1
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
STR	R2, [R1, #0]
;Seven_segment.c,139 :: 		break;
IT	AL
BAL	L_set_segments6
;Seven_segment.c,140 :: 		}
L_set_segments5:
; num start address is: 8 (R2)
CMP	R2, #0
IT	EQ
BEQ	L_set_segments7
CMP	R2, #1
IT	EQ
BEQ	L_set_segments8
CMP	R2, #2
IT	EQ
BEQ	L_set_segments9
CMP	R2, #3
IT	EQ
BEQ	L_set_segments10
CMP	R2, #4
IT	EQ
BEQ	L_set_segments11
CMP	R2, #5
IT	EQ
BEQ	L_set_segments12
CMP	R2, #6
IT	EQ
BEQ	L_set_segments13
CMP	R2, #7
IT	EQ
BEQ	L_set_segments14
CMP	R2, #8
IT	EQ
BEQ	L_set_segments15
CMP	R2, #9
IT	EQ
BEQ	L_set_segments16
; num end address is: 8 (R2)
L_set_segments6:
;Seven_segment.c,141 :: 		}
L_end_set_segments:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _set_segments
_display_4digits:
;Seven_segment.c,147 :: 		unsigned int loops) {
; d2 start address is: 4 (R1)
; d1 start address is: 0 (R0)
SUB	SP, SP, #12
STR	LR, [SP, #0]
STRB	R2, [SP, #4]
STRB	R3, [SP, #8]
; d2 end address is: 4 (R1)
; d1 end address is: 0 (R0)
; d1 start address is: 0 (R0)
; d2 start address is: 4 (R1)
; loops start address is: 16 (R4)
LDRH	R4, [SP, #12]
;Seven_segment.c,151 :: 		for(i = 0; i < loops; i++) {
; i start address is: 40 (R10)
MOVW	R10, #0
; d1 end address is: 0 (R0)
; d2 end address is: 4 (R1)
; loops end address is: 16 (R4)
; i end address is: 40 (R10)
UXTB	R9, R0
UXTB	R8, R1
UXTH	R6, R4
UXTH	R5, R10
L_display_4digits17:
; d1 start address is: 36 (R9)
; d2 start address is: 32 (R8)
; i start address is: 20 (R5)
; loops start address is: 24 (R6)
; d2 start address is: 32 (R8)
; d2 end address is: 32 (R8)
; d1 start address is: 36 (R9)
; d1 end address is: 36 (R9)
CMP	R5, R6
IT	CS
BCS	L_display_4digits18
; d2 end address is: 32 (R8)
; d1 end address is: 36 (R9)
;Seven_segment.c,153 :: 		set_segments(d1);
; d1 start address is: 36 (R9)
; d2 start address is: 32 (R8)
UXTB	R0, R9
BL	_set_segments+0
;Seven_segment.c,154 :: 		digit_on(1);
MOVS	R0, #1
BL	_digit_on+0
;Seven_segment.c,155 :: 		Delay_ms(2);
MOVW	R7, #10665
MOVT	R7, #0
NOP
NOP
L_display_4digits20:
SUBS	R7, R7, #1
BNE	L_display_4digits20
NOP
NOP
;Seven_segment.c,157 :: 		set_segments(d2);
UXTB	R0, R8
BL	_set_segments+0
;Seven_segment.c,158 :: 		digit_on(2);
MOVS	R0, #2
BL	_digit_on+0
;Seven_segment.c,159 :: 		Delay_ms(2);
MOVW	R7, #10665
MOVT	R7, #0
NOP
NOP
L_display_4digits22:
SUBS	R7, R7, #1
BNE	L_display_4digits22
NOP
NOP
;Seven_segment.c,161 :: 		set_segments(d3);
LDRB	R0, [SP, #4]
BL	_set_segments+0
;Seven_segment.c,162 :: 		digit_on(3);
MOVS	R0, #3
BL	_digit_on+0
;Seven_segment.c,163 :: 		Delay_ms(2);
MOVW	R7, #10665
MOVT	R7, #0
NOP
NOP
L_display_4digits24:
SUBS	R7, R7, #1
BNE	L_display_4digits24
NOP
NOP
;Seven_segment.c,165 :: 		set_segments(d4);
LDRB	R0, [SP, #8]
BL	_set_segments+0
;Seven_segment.c,166 :: 		digit_on(4);
MOVS	R0, #4
BL	_digit_on+0
;Seven_segment.c,167 :: 		Delay_ms(2);
MOVW	R7, #10665
MOVT	R7, #0
NOP
NOP
L_display_4digits26:
SUBS	R7, R7, #1
BNE	L_display_4digits26
NOP
NOP
;Seven_segment.c,151 :: 		for(i = 0; i < loops; i++) {
ADDS	R4, R5, #1
; i end address is: 20 (R5)
; i start address is: 40 (R10)
UXTH	R10, R4
;Seven_segment.c,168 :: 		}
; loops end address is: 24 (R6)
; d2 end address is: 32 (R8)
; d1 end address is: 36 (R9)
; i end address is: 40 (R10)
UXTH	R5, R10
IT	AL
BAL	L_display_4digits17
L_display_4digits18:
;Seven_segment.c,170 :: 		all_digits_off();
BL	_all_digits_off+0
;Seven_segment.c,171 :: 		}
L_end_display_4digits:
LDR	LR, [SP, #0]
ADD	SP, SP, #12
BX	LR
; end of _display_4digits
_display_number:
;Seven_segment.c,176 :: 		void display_number(unsigned int value, unsigned int loops) {
; loops start address is: 4 (R1)
; value start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
UXTH	R8, R0
; loops end address is: 4 (R1)
; value end address is: 0 (R0)
; value start address is: 32 (R8)
; loops start address is: 4 (R1)
;Seven_segment.c,180 :: 		d1 = value / 1000;
MOVW	R2, #1000
UDIV	R5, R8, R2
; d1 start address is: 28 (R7)
UXTB	R7, R5
;Seven_segment.c,181 :: 		d2 = (value / 100) % 10;
MOVS	R2, #100
UDIV	R4, R8, R2
UXTH	R4, R4
MOVS	R3, #10
UDIV	R2, R4, R3
MLS	R2, R3, R2, R4
; d2 start address is: 24 (R6)
UXTB	R6, R2
;Seven_segment.c,182 :: 		d3 = (value / 10) % 10;
MOVS	R2, #10
UDIV	R4, R8, R2
UXTH	R4, R4
MOVS	R3, #10
UDIV	R2, R4, R3
MLS	R2, R3, R2, R4
; d3 start address is: 0 (R0)
UXTB	R0, R2
;Seven_segment.c,183 :: 		d4 = value % 10;
MOVS	R3, #10
UDIV	R2, R8, R3
MLS	R2, R3, R2, R8
; value end address is: 32 (R8)
; d4 start address is: 12 (R3)
UXTB	R3, R2
;Seven_segment.c,186 :: 		if(d1 == 0) d1 = 255;
UXTB	R2, R5
CMP	R2, #0
IT	NE
BNE	L__display_number49
; d1 end address is: 28 (R7)
; d1 start address is: 8 (R2)
MOVS	R2, #255
; d1 end address is: 8 (R2)
IT	AL
BAL	L_display_number28
L__display_number49:
UXTB	R2, R7
L_display_number28:
;Seven_segment.c,187 :: 		if(d1 == 255 && d2 == 0) d2 = 255;
; d1 start address is: 8 (R2)
CMP	R2, #255
IT	NE
BNE	L__display_number50
CMP	R6, #0
IT	NE
BNE	L__display_number51
; d2 end address is: 24 (R6)
L__display_number44:
; d2 start address is: 16 (R4)
MOVS	R4, #255
; d2 end address is: 16 (R4)
IT	AL
BAL	L__display_number46
L__display_number50:
UXTB	R4, R6
L__display_number46:
; d2 start address is: 16 (R4)
; d2 end address is: 16 (R4)
IT	AL
BAL	L__display_number45
L__display_number51:
UXTB	R4, R6
L__display_number45:
;Seven_segment.c,188 :: 		if(d2 == 255 && d3 == 0) d3 = 255;
; d2 start address is: 16 (R4)
CMP	R4, #255
IT	NE
BNE	L__display_number52
CMP	R0, #0
IT	NE
BNE	L__display_number53
; d3 end address is: 0 (R0)
L__display_number43:
; d3 start address is: 0 (R0)
MOVS	R0, #255
; d3 end address is: 0 (R0)
IT	AL
BAL	L__display_number48
L__display_number52:
L__display_number48:
; d3 start address is: 0 (R0)
; d3 end address is: 0 (R0)
IT	AL
BAL	L__display_number47
L__display_number53:
L__display_number47:
;Seven_segment.c,190 :: 		display_4digits(d1, d2, d3, d4, loops);
; d3 start address is: 0 (R0)
PUSH	(R1)
; d4 end address is: 12 (R3)
STRB	R2, [SP, #8]
UXTB	R1, R4
; d3 end address is: 0 (R0)
UXTB	R2, R0
; d2 end address is: 16 (R4)
LDRB	R0, [SP, #8]
; d1 end address is: 8 (R2)
; loops end address is: 4 (R1)
BL	_display_4digits+0
ADD	SP, SP, #4
;Seven_segment.c,191 :: 		}
L_end_display_number:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _display_number
_main:
;Seven_segment.c,193 :: 		void main() {
SUB	SP, SP, #4
;Seven_segment.c,198 :: 		GPIO_Digital_Output(&GPIOA_BASE, SEG_G_MASK);
MOVW	R1, #8192
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Output+0
;Seven_segment.c,202 :: 		DIG1_MASK|DIG2_MASK|DIG3_MASK|DIG4_MASK);
MOVW	R1, #62523
;Seven_segment.c,199 :: 		GPIO_Digital_Output(&GPIOB_BASE,
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
;Seven_segment.c,202 :: 		DIG1_MASK|DIG2_MASK|DIG3_MASK|DIG4_MASK);
BL	_GPIO_Digital_Output+0
;Seven_segment.c,204 :: 		all_digits_off();
BL	_all_digits_off+0
;Seven_segment.c,205 :: 		all_segments_off();
BL	_all_segments_off+0
;Seven_segment.c,207 :: 		while(1) {
L_main35:
;Seven_segment.c,210 :: 		for(i = 0; i <= 9; i++) {
MOVS	R0, #0
STRB	R0, [SP, #0]
L_main37:
LDRB	R0, [SP, #0]
CMP	R0, #9
IT	HI
BHI	L_main38
;Seven_segment.c,211 :: 		display_4digits(i, i, i, i, 125); // ~1 sec
MOVS	R0, #125
PUSH	(R0)
LDRB	R3, [SP, #4]
LDRB	R2, [SP, #4]
LDRB	R1, [SP, #4]
LDRB	R0, [SP, #4]
BL	_display_4digits+0
ADD	SP, SP, #4
;Seven_segment.c,210 :: 		for(i = 0; i <= 9; i++) {
LDRB	R0, [SP, #0]
ADDS	R0, R0, #1
STRB	R0, [SP, #0]
;Seven_segment.c,212 :: 		}
IT	AL
BAL	L_main37
L_main38:
;Seven_segment.c,215 :: 		for(count = 0; count <= 9999; count++) {
; count start address is: 44 (R11)
MOVW	R11, #0
; count end address is: 44 (R11)
L_main40:
; count start address is: 44 (R11)
MOVW	R0, #9999
CMP	R11, R0
IT	HI
BHI	L_main41
;Seven_segment.c,216 :: 		display_number(count, 13); // ~100 ms
MOVS	R1, #13
UXTH	R0, R11
BL	_display_number+0
;Seven_segment.c,215 :: 		for(count = 0; count <= 9999; count++) {
ADD	R11, R11, #1
UXTH	R11, R11
;Seven_segment.c,217 :: 		}
; count end address is: 44 (R11)
IT	AL
BAL	L_main40
L_main41:
;Seven_segment.c,218 :: 		}
IT	AL
BAL	L_main35
;Seven_segment.c,219 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
