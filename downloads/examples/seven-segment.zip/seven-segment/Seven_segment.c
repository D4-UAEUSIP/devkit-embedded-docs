/*
   ------------------------------------------------------------
   STM32F446RE - 4-Digit 7-Segment Display Test
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   SW18 : SV-D
   SW17 :  SV-DP if you need to use Dicmal Point

   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   Display:
     4-digit multiplexed 7-segment display
     Segments are active LOW
     Digit enables are active HIGH

   Segment pins:
     SEG_A -> PB0
     SEG_B -> PB1
     SEG_C -> PB3
     SEG_D -> PB4
     SEG_E -> PB5
     SEG_F -> PB10
     SEG_G -> PA13

   Digit enable pins:
     DIG1 -> PB12
     DIG2 -> PB13
     DIG3 -> PB14
     DIG4 -> PB15

   Program behavior:
     Test 1:
       Displays 0000, 1111, 2222 ... 9999
       Each value stays for about 1 second

     Test 2:
       Counts from 0 to 9999
       Leading zeros are blanked
       Count updates about every 100 ms

   Notes:
     - SEG_G moved to PA13
     - Leading zeros are blanked in test 2
*/

#define SEG_A_MASK   _GPIO_PINMASK_0    // PB0
#define SEG_B_MASK   _GPIO_PINMASK_1    // PB1
#define SEG_C_MASK   _GPIO_PINMASK_3    // PB3
#define SEG_D_MASK   _GPIO_PINMASK_4    // PB4
#define SEG_E_MASK   _GPIO_PINMASK_5    // PB5
#define SEG_F_MASK   _GPIO_PINMASK_10   // PB10
#define SEG_G_MASK   _GPIO_PINMASK_13   // PA13  <<< FIXED

#define DIG1_MASK    _GPIO_PINMASK_12
#define DIG2_MASK    _GPIO_PINMASK_13
#define DIG3_MASK    _GPIO_PINMASK_14
#define DIG4_MASK    _GPIO_PINMASK_15

#define ALL_SEG_B_MASK  (SEG_A_MASK | SEG_B_MASK | SEG_C_MASK | SEG_D_MASK | SEG_E_MASK | SEG_F_MASK)
#define ALL_DIG_MASK    (DIG1_MASK | DIG2_MASK | DIG3_MASK | DIG4_MASK)

void all_digits_off() {
  GPIOB_ODR &= ~ALL_DIG_MASK;
}

void all_segments_off() {
  GPIOB_ODR |= ALL_SEG_B_MASK;   // OFF (active LOW)
  GPIOA_ODR |= SEG_G_MASK;
}

void digit_on(unsigned short d) {
  all_digits_off();

  if(d == 1) GPIOB_ODR |= DIG1_MASK;
  if(d == 2) GPIOB_ODR |= DIG2_MASK;
  if(d == 3) GPIOB_ODR |= DIG3_MASK;
  if(d == 4) GPIOB_ODR |= DIG4_MASK;
}

/*
   num = 0..9
   num = 255 -> BLANK digit
*/
void set_segments(unsigned short num) {

  all_segments_off();

  if(num == 255) return;   // blank digit

  switch(num) {
    case 0:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK|SEG_E_MASK|SEG_F_MASK);
      break;

    case 1:
      GPIOB_ODR &= ~(SEG_B_MASK|SEG_C_MASK);
      break;

    case 2:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_D_MASK|SEG_E_MASK);
      GPIOA_ODR &= ~SEG_G_MASK;
      break;

    case 3:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK);
      GPIOA_ODR &= ~SEG_G_MASK;
      break;

    case 4:
      GPIOB_ODR &= ~(SEG_B_MASK|SEG_C_MASK|SEG_F_MASK);
      GPIOA_ODR &= ~SEG_G_MASK;
      break;

    case 5:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_C_MASK|SEG_D_MASK|SEG_F_MASK);
      GPIOA_ODR &= ~SEG_G_MASK;
      break;

    case 6:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_C_MASK|SEG_D_MASK|SEG_E_MASK|SEG_F_MASK);
      GPIOA_ODR &= ~SEG_G_MASK;
      break;

    case 7:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK);
      break;

    case 8:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK|SEG_E_MASK|SEG_F_MASK);
      GPIOA_ODR &= ~SEG_G_MASK;
      break;

    case 9:
      GPIOB_ODR &= ~(SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|SEG_D_MASK|SEG_F_MASK);
      GPIOA_ODR &= ~SEG_G_MASK;
      break;
  }
}

void display_4digits(unsigned short d1,
                     unsigned short d2,
                     unsigned short d3,
                     unsigned short d4,
                     unsigned int loops) {

  unsigned int i;

  for(i = 0; i < loops; i++) {

    set_segments(d1);
    digit_on(1);
    Delay_ms(2);

    set_segments(d2);
    digit_on(2);
    Delay_ms(2);

    set_segments(d3);
    digit_on(3);
    Delay_ms(2);

    set_segments(d4);
    digit_on(4);
    Delay_ms(2);
  }

  all_digits_off();
}

/*
   Display number with leading zero blanking
*/
void display_number(unsigned int value, unsigned int loops) {

  unsigned short d1, d2, d3, d4;

  d1 = value / 1000;
  d2 = (value / 100) % 10;
  d3 = (value / 10) % 10;
  d4 = value % 10;

  // Blank leading zeros
  if(d1 == 0) d1 = 255;
  if(d1 == 255 && d2 == 0) d2 = 255;
  if(d2 == 255 && d3 == 0) d3 = 255;

  display_4digits(d1, d2, d3, d4, loops);
}

void main() {

  unsigned short i;
  unsigned int count;

  GPIO_Digital_Output(&GPIOA_BASE, SEG_G_MASK);
  GPIO_Digital_Output(&GPIOB_BASE,
      SEG_A_MASK|SEG_B_MASK|SEG_C_MASK|
      SEG_D_MASK|SEG_E_MASK|SEG_F_MASK|
      DIG1_MASK|DIG2_MASK|DIG3_MASK|DIG4_MASK);

  all_digits_off();
  all_segments_off();

  while(1) {

    // -------- TEST 1 --------
    for(i = 0; i <= 9; i++) {
      display_4digits(i, i, i, i, 125); // ~1 sec
    }

    // -------- TEST 2 --------
    for(count = 0; count <= 9999; count++) {
      display_number(count, 13); // ~100 ms
    }
  }
}