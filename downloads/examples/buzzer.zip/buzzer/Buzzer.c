/*
   ------------------------------------------------------------
   STM32F446RE - Buzzer Test on PC6
   mikroC PRO for ARM
   ------------------------------------------------------------

   Buzzer pin:
     PC6

   Test sequence:
     1) Full ON for 1 second
     2) PWM duty from 0% to 100% in 2 seconds
     3) Generate tone for 6 seconds

   Notes:
     - This code uses software PWM / software tone generation.
     - Good for test purposes.
*/

sbit BUZZER at GPIOC_ODR.B6;


/*
   ------------------------------------------------------------
   Simple delay-based software PWM

   duty_percent : 0..100
   total_ms     : how long to run this duty

   PWM period here is about 1 ms:
     ON  time  = duty * 10 us
     OFF time  = (100-duty) * 10 us
*/
void Buzzer_PWM(unsigned short duty_percent, unsigned int total_ms) {
  unsigned int ms;
  unsigned short i;

  for(ms = 0; ms < total_ms; ms++) {
    for(i = 0; i < 100; i++) {
      if(i < duty_percent)
        BUZZER = 1;
      else
        BUZZER = 0;

      Delay_us(10);
    }
  }
}

/*
   ------------------------------------------------------------
   Full ON for specified time
*/
void Buzzer_On(unsigned int time_ms) {
  BUZZER = 1;
  VDelay_ms(time_ms);
  BUZZER = 0;
}

/*
   ------------------------------------------------------------
   Ramp PWM duty from 0% to 100% in about 2 seconds

   101 steps total
   Each step held for 20 ms
   Total ~ 2020 ms
*/
void Buzzer_Ramp_2s() {
  unsigned short duty;

  for(duty = 0; duty <= 100; duty++) {
    Buzzer_PWM(duty, 20);
  }

  BUZZER = 0;
}

/*
   ------------------------------------------------------------
   Generate square-wave tone

   freq_hz  : tone frequency
   time_ms  : how long to play

*/
void vDelay_us(unsigned int us) {
  while(us--) {
    Delay_us(1);
  }
}

void Buzzer_Tone(unsigned int freq_hz, unsigned int time_ms) {
  unsigned long cycles;
  unsigned int half_period_us;
  unsigned long i;

  half_period_us = 500000UL / freq_hz;
  cycles = ((unsigned long)freq_hz * time_ms) / 1000UL;

  for(i = 0; i < cycles; i++) {
    BUZZER = 1;
    vDelay_us(half_period_us);
    BUZZER = 0;
    vDelay_us(half_period_us);
  }
}

/*
   ------------------------------------------------------------
   Play simple melody / tone sequence for about 6 seconds

   Frequencies used:
     C5 = 523 Hz
     D5 = 587 Hz
     E5 = 659 Hz
     F5 = 698 Hz
     G5 = 784 Hz
     A5 = 880 Hz
*/
void Buzzer_Music_6s() {
  Buzzer_Tone(523, 500);   // C5
  Delay_ms(50);

  Buzzer_Tone(587, 500);   // D5
  Delay_ms(50);

  Buzzer_Tone(659, 500);   // E5
  Delay_ms(50);

  Buzzer_Tone(698, 500);   // F5
  Delay_ms(50);

  Buzzer_Tone(784, 500);   // G5
  Delay_ms(50);

  Buzzer_Tone(880, 500);   // A5
  Delay_ms(50);

  Buzzer_Tone(784, 500);   // G5
  Delay_ms(50);

  Buzzer_Tone(698, 500);   // F5
  Delay_ms(50);

  Buzzer_Tone(659, 500);   // E5
  Delay_ms(50);

  Buzzer_Tone(587, 500);   // D5
  Delay_ms(50);

  Buzzer_Tone(523, 500);   // C5
  Delay_ms(50);
}

void main() {
  // Configure PC6 as digital output
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_6);

  // Start with buzzer OFF
  BUZZER = 0;

  while(1) {
    // 1) Full ON for 1 second
    Buzzer_On(1000);
    Delay_ms(500);

    // 2) PWM from 0% to 100% in 2 seconds
    Buzzer_Ramp_2s();
    Delay_ms(500);

    // 3) Music tone for about 6 seconds
    Buzzer_Music_6s();
    Delay_ms(1000);
  }
}