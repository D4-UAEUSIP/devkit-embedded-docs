#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Buzzer.c"
#line 20 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Buzzer.c"
sbit BUZZER at GPIOC_ODR.B6;
#line 34 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Buzzer.c"
void Buzzer_PWM(unsigned short duty_percent, unsigned int total_ms) {
 unsigned int ms;
 unsigned short i;

 for(ms = 0; ms < total_ms; ms++) {
 for(i = 0; i < 100; i++) {
 if(i < duty_percent)
 BUZZER = 1;
 else
 BUZZER = 0;

 Delay_us(10);
 }
 }
}
#line 54 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Buzzer.c"
void Buzzer_On(unsigned int time_ms) {
 BUZZER = 1;
 VDelay_ms(time_ms);
 BUZZER = 0;
}
#line 68 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Buzzer.c"
void Buzzer_Ramp_2s() {
 unsigned short duty;

 for(duty = 0; duty <= 100; duty++) {
 Buzzer_PWM(duty, 20);
 }

 BUZZER = 0;
}
#line 86 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Buzzer.c"
void vDelay_us(unsigned int us) {
 while(us--) {
 Delay_us(1);
 }
}

void Buzzer_Tone(unsigned int freq_hz, unsigned int time_ms) {
 unsigned long cycles;
 unsigned int half_period_us;
 unsigned long i;

 half_period_us = 500000UL / freq_hz;
 cycles = ((unsigned long)freq_hz * time_ms) / 1000UL;

 for(i = 0; i < cycles; i++) {
 BUZZER = 1;
 vDelay_us(half_period_us);
 BUZZER = 0;
 vDelay_us(half_period_us);
 }
}
#line 120 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Buzzer.c"
void Buzzer_Music_6s() {
 Buzzer_Tone(523, 500);
 Delay_ms(50);

 Buzzer_Tone(587, 500);
 Delay_ms(50);

 Buzzer_Tone(659, 500);
 Delay_ms(50);

 Buzzer_Tone(698, 500);
 Delay_ms(50);

 Buzzer_Tone(784, 500);
 Delay_ms(50);

 Buzzer_Tone(880, 500);
 Delay_ms(50);

 Buzzer_Tone(784, 500);
 Delay_ms(50);

 Buzzer_Tone(698, 500);
 Delay_ms(50);

 Buzzer_Tone(659, 500);
 Delay_ms(50);

 Buzzer_Tone(587, 500);
 Delay_ms(50);

 Buzzer_Tone(523, 500);
 Delay_ms(50);
}

void main() {

 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_6);


 BUZZER = 0;

 while(1) {

 Buzzer_On(1000);
 Delay_ms(500);


 Buzzer_Ramp_2s();
 Delay_ms(500);


 Buzzer_Music_6s();
 Delay_ms(1000);
 }
}
