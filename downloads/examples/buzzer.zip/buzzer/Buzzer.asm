_Buzzer_PWM:
;Buzzer.c,34 :: 		void Buzzer_PWM(unsigned short duty_percent, unsigned int total_ms) {
; total_ms start address is: 4 (R1)
; duty_percent start address is: 0 (R0)
; total_ms end address is: 4 (R1)
; duty_percent end address is: 0 (R0)
; duty_percent start address is: 0 (R0)
; total_ms start address is: 4 (R1)
;Buzzer.c,38 :: 		for(ms = 0; ms < total_ms; ms++) {
; ms start address is: 16 (R4)
MOVS	R4, #0
; duty_percent end address is: 0 (R0)
; total_ms end address is: 4 (R1)
; ms end address is: 16 (R4)
UXTB	R3, R0
L_Buzzer_PWM0:
; ms start address is: 16 (R4)
; total_ms start address is: 4 (R1)
; duty_percent start address is: 12 (R3)
CMP	R4, R1
IT	CS
BCS	L_Buzzer_PWM1
;Buzzer.c,39 :: 		for(i = 0; i < 100; i++) {
; i start address is: 0 (R0)
MOVS	R0, #0
; duty_percent end address is: 12 (R3)
; i end address is: 0 (R0)
; total_ms end address is: 4 (R1)
; ms end address is: 16 (R4)
UXTB	R5, R0
UXTB	R0, R3
L_Buzzer_PWM3:
; i start address is: 20 (R5)
; duty_percent start address is: 0 (R0)
; total_ms start address is: 4 (R1)
; ms start address is: 16 (R4)
CMP	R5, #100
IT	CS
BCS	L_Buzzer_PWM4
;Buzzer.c,40 :: 		if(i < duty_percent)
CMP	R5, R0
IT	CS
BCS	L_Buzzer_PWM6
;Buzzer.c,41 :: 		BUZZER = 1;
MOVS	R3, #1
SXTB	R3, R3
MOVW	R2, #lo_addr(GPIOC_ODR+0)
MOVT	R2, #hi_addr(GPIOC_ODR+0)
_SX	[R2, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Buzzer_PWM7
L_Buzzer_PWM6:
;Buzzer.c,43 :: 		BUZZER = 0;
MOVS	R3, #0
SXTB	R3, R3
MOVW	R2, #lo_addr(GPIOC_ODR+0)
MOVT	R2, #hi_addr(GPIOC_ODR+0)
_SX	[R2, ByteOffset(GPIOC_ODR+0)]
L_Buzzer_PWM7:
;Buzzer.c,45 :: 		Delay_us(10);
MOVW	R7, #78
MOVT	R7, #0
NOP
NOP
L_Buzzer_PWM8:
SUBS	R7, R7, #1
BNE	L_Buzzer_PWM8
NOP
NOP
NOP
;Buzzer.c,39 :: 		for(i = 0; i < 100; i++) {
ADDS	R5, R5, #1
UXTB	R5, R5
;Buzzer.c,46 :: 		}
; i end address is: 20 (R5)
IT	AL
BAL	L_Buzzer_PWM3
L_Buzzer_PWM4:
;Buzzer.c,38 :: 		for(ms = 0; ms < total_ms; ms++) {
ADDS	R4, R4, #1
UXTH	R4, R4
;Buzzer.c,47 :: 		}
UXTB	R3, R0
; duty_percent end address is: 0 (R0)
; total_ms end address is: 4 (R1)
; ms end address is: 16 (R4)
IT	AL
BAL	L_Buzzer_PWM0
L_Buzzer_PWM1:
;Buzzer.c,48 :: 		}
L_end_Buzzer_PWM:
BX	LR
; end of _Buzzer_PWM
_Buzzer_On:
;Buzzer.c,54 :: 		void Buzzer_On(unsigned int time_ms) {
; time_ms start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; time_ms end address is: 0 (R0)
; time_ms start address is: 0 (R0)
;Buzzer.c,55 :: 		BUZZER = 1;
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
;Buzzer.c,56 :: 		VDelay_ms(time_ms);
; time_ms end address is: 0 (R0)
BL	_VDelay_ms+0
;Buzzer.c,57 :: 		BUZZER = 0;
MOVS	R2, #0
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
;Buzzer.c,58 :: 		}
L_end_Buzzer_On:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Buzzer_On
_Buzzer_Ramp_2s:
;Buzzer.c,68 :: 		void Buzzer_Ramp_2s() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Buzzer.c,71 :: 		for(duty = 0; duty <= 100; duty++) {
; duty start address is: 24 (R6)
MOVS	R6, #0
; duty end address is: 24 (R6)
L_Buzzer_Ramp_2s10:
; duty start address is: 24 (R6)
CMP	R6, #100
IT	HI
BHI	L_Buzzer_Ramp_2s11
;Buzzer.c,72 :: 		Buzzer_PWM(duty, 20);
MOVS	R1, #20
UXTB	R0, R6
BL	_Buzzer_PWM+0
;Buzzer.c,71 :: 		for(duty = 0; duty <= 100; duty++) {
ADDS	R6, R6, #1
UXTB	R6, R6
;Buzzer.c,73 :: 		}
; duty end address is: 24 (R6)
IT	AL
BAL	L_Buzzer_Ramp_2s10
L_Buzzer_Ramp_2s11:
;Buzzer.c,75 :: 		BUZZER = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Buzzer.c,76 :: 		}
L_end_Buzzer_Ramp_2s:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Buzzer_Ramp_2s
_vDelay_us:
;Buzzer.c,86 :: 		void vDelay_us(unsigned int us) {
; us start address is: 0 (R0)
; us end address is: 0 (R0)
; us start address is: 0 (R0)
;Buzzer.c,87 :: 		while(us--) {
L_vDelay_us13:
; us start address is: 0 (R0)
UXTH	R2, R0
SUBS	R1, R0, #1
UXTH	R0, R1
; us end address is: 0 (R0)
CMP	R2, #0
IT	EQ
BEQ	L_vDelay_us14
; us end address is: 0 (R0)
;Buzzer.c,88 :: 		Delay_us(1);
; us start address is: 0 (R0)
MOVW	R7, #6
MOVT	R7, #0
NOP
NOP
L_vDelay_us15:
SUBS	R7, R7, #1
BNE	L_vDelay_us15
NOP
NOP
NOP
;Buzzer.c,89 :: 		}
; us end address is: 0 (R0)
IT	AL
BAL	L_vDelay_us13
L_vDelay_us14:
;Buzzer.c,90 :: 		}
L_end_vDelay_us:
BX	LR
; end of _vDelay_us
_Buzzer_Tone:
;Buzzer.c,92 :: 		void Buzzer_Tone(unsigned int freq_hz, unsigned int time_ms) {
; time_ms start address is: 4 (R1)
; freq_hz start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTH	R3, R0
; time_ms end address is: 4 (R1)
; freq_hz end address is: 0 (R0)
; freq_hz start address is: 12 (R3)
; time_ms start address is: 4 (R1)
;Buzzer.c,97 :: 		half_period_us = 500000UL / freq_hz;
MOVW	R2, #41248
MOVT	R2, #7
UDIV	R2, R2, R3
; half_period_us start address is: 0 (R0)
UXTH	R0, R2
;Buzzer.c,98 :: 		cycles = ((unsigned long)freq_hz * time_ms) / 1000UL;
UXTH	R4, R3
; freq_hz end address is: 12 (R3)
MULS	R4, R1, R4
; time_ms end address is: 4 (R1)
MOV	R2, #1000
UDIV	R4, R4, R2
; cycles start address is: 16 (R4)
;Buzzer.c,100 :: 		for(i = 0; i < cycles; i++) {
; i start address is: 24 (R6)
MOVS	R6, #0
; half_period_us end address is: 0 (R0)
; cycles end address is: 16 (R4)
; i end address is: 24 (R6)
UXTH	R5, R0
L_Buzzer_Tone17:
; i start address is: 24 (R6)
; half_period_us start address is: 20 (R5)
; cycles start address is: 16 (R4)
; half_period_us start address is: 20 (R5)
; half_period_us end address is: 20 (R5)
CMP	R6, R4
IT	CS
BCS	L_Buzzer_Tone18
; half_period_us end address is: 20 (R5)
;Buzzer.c,101 :: 		BUZZER = 1;
; half_period_us start address is: 20 (R5)
MOVS	R3, #1
SXTB	R3, R3
MOVW	R2, #lo_addr(GPIOC_ODR+0)
MOVT	R2, #hi_addr(GPIOC_ODR+0)
_SX	[R2, ByteOffset(GPIOC_ODR+0)]
;Buzzer.c,102 :: 		vDelay_us(half_period_us);
UXTH	R0, R5
BL	_vDelay_us+0
;Buzzer.c,103 :: 		BUZZER = 0;
MOVS	R3, #0
SXTB	R3, R3
MOVW	R2, #lo_addr(GPIOC_ODR+0)
MOVT	R2, #hi_addr(GPIOC_ODR+0)
_SX	[R2, ByteOffset(GPIOC_ODR+0)]
;Buzzer.c,104 :: 		vDelay_us(half_period_us);
UXTH	R0, R5
BL	_vDelay_us+0
;Buzzer.c,100 :: 		for(i = 0; i < cycles; i++) {
ADDS	R6, R6, #1
;Buzzer.c,105 :: 		}
; cycles end address is: 16 (R4)
; half_period_us end address is: 20 (R5)
; i end address is: 24 (R6)
IT	AL
BAL	L_Buzzer_Tone17
L_Buzzer_Tone18:
;Buzzer.c,106 :: 		}
L_end_Buzzer_Tone:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Buzzer_Tone
_Buzzer_Music_6s:
;Buzzer.c,120 :: 		void Buzzer_Music_6s() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Buzzer.c,121 :: 		Buzzer_Tone(523, 500);   // C5
MOVW	R1, #500
MOVW	R0, #523
BL	_Buzzer_Tone+0
;Buzzer.c,122 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s20:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s20
NOP
NOP
NOP
;Buzzer.c,124 :: 		Buzzer_Tone(587, 500);   // D5
MOVW	R1, #500
MOVW	R0, #587
BL	_Buzzer_Tone+0
;Buzzer.c,125 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s22:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s22
NOP
NOP
NOP
;Buzzer.c,127 :: 		Buzzer_Tone(659, 500);   // E5
MOVW	R1, #500
MOVW	R0, #659
BL	_Buzzer_Tone+0
;Buzzer.c,128 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s24:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s24
NOP
NOP
NOP
;Buzzer.c,130 :: 		Buzzer_Tone(698, 500);   // F5
MOVW	R1, #500
MOVW	R0, #698
BL	_Buzzer_Tone+0
;Buzzer.c,131 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s26:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s26
NOP
NOP
NOP
;Buzzer.c,133 :: 		Buzzer_Tone(784, 500);   // G5
MOVW	R1, #500
MOVW	R0, #784
BL	_Buzzer_Tone+0
;Buzzer.c,134 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s28:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s28
NOP
NOP
NOP
;Buzzer.c,136 :: 		Buzzer_Tone(880, 500);   // A5
MOVW	R1, #500
MOVW	R0, #880
BL	_Buzzer_Tone+0
;Buzzer.c,137 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s30:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s30
NOP
NOP
NOP
;Buzzer.c,139 :: 		Buzzer_Tone(784, 500);   // G5
MOVW	R1, #500
MOVW	R0, #784
BL	_Buzzer_Tone+0
;Buzzer.c,140 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s32:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s32
NOP
NOP
NOP
;Buzzer.c,142 :: 		Buzzer_Tone(698, 500);   // F5
MOVW	R1, #500
MOVW	R0, #698
BL	_Buzzer_Tone+0
;Buzzer.c,143 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s34:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s34
NOP
NOP
NOP
;Buzzer.c,145 :: 		Buzzer_Tone(659, 500);   // E5
MOVW	R1, #500
MOVW	R0, #659
BL	_Buzzer_Tone+0
;Buzzer.c,146 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s36:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s36
NOP
NOP
NOP
;Buzzer.c,148 :: 		Buzzer_Tone(587, 500);   // D5
MOVW	R1, #500
MOVW	R0, #587
BL	_Buzzer_Tone+0
;Buzzer.c,149 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s38:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s38
NOP
NOP
NOP
;Buzzer.c,151 :: 		Buzzer_Tone(523, 500);   // C5
MOVW	R1, #500
MOVW	R0, #523
BL	_Buzzer_Tone+0
;Buzzer.c,152 :: 		Delay_ms(50);
MOVW	R7, #6782
MOVT	R7, #6
NOP
NOP
L_Buzzer_Music_6s40:
SUBS	R7, R7, #1
BNE	L_Buzzer_Music_6s40
NOP
NOP
NOP
;Buzzer.c,153 :: 		}
L_end_Buzzer_Music_6s:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Buzzer_Music_6s
_main:
;Buzzer.c,155 :: 		void main() {
;Buzzer.c,157 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_6);
MOVW	R1, #64
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;Buzzer.c,160 :: 		BUZZER = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Buzzer.c,162 :: 		while(1) {
L_main42:
;Buzzer.c,164 :: 		Buzzer_On(1000);
MOVW	R0, #1000
BL	_Buzzer_On+0
;Buzzer.c,165 :: 		Delay_ms(500);
MOVW	R7, #2302
MOVT	R7, #61
NOP
NOP
L_main44:
SUBS	R7, R7, #1
BNE	L_main44
NOP
NOP
NOP
;Buzzer.c,168 :: 		Buzzer_Ramp_2s();
BL	_Buzzer_Ramp_2s+0
;Buzzer.c,169 :: 		Delay_ms(500);
MOVW	R7, #2302
MOVT	R7, #61
NOP
NOP
L_main46:
SUBS	R7, R7, #1
BNE	L_main46
NOP
NOP
NOP
;Buzzer.c,172 :: 		Buzzer_Music_6s();
BL	_Buzzer_Music_6s+0
;Buzzer.c,173 :: 		Delay_ms(1000);
MOVW	R7, #4606
MOVT	R7, #122
NOP
NOP
L_main48:
SUBS	R7, R7, #1
BNE	L_main48
NOP
NOP
NOP
;Buzzer.c,174 :: 		}
IT	AL
BAL	L_main42
;Buzzer.c,175 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
