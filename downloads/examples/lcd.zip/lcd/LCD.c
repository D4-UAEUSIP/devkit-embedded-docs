/*
   ------------------------------------------------------------
   STM32F446RE - LCD 16x2 Test with Backlight Fade-In
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   
   SW19 : 2:ON   1 :off
   VR1: adujest it till  you see the text on LCD
   
   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side

   LCD connections from schematic:
     RS  -> PC8
     EN  -> PC9
     D4  -> PC2
     D5  -> PC3
     D6  -> PC4
     D7  -> PC5
     RW  -> GND

   LCD backlight control:
     LCD_PWM / LEDK driver -> PB4

   Hardware note:
     PB4 drives an NPN transistor as low-side switch.
     Therefore:
       PB4 HIGH  -> backlight ON
       PB4 LOW   -> backlight OFF

   Important:
     SW18 must connect PB4 to LCD_PWM path
     (not to seven-segment line PB4-SEV-D)

   Program sequence:
     1) Initialize LCD
     2) Fade backlight from 0% to 100% over 2 seconds
     3) Start scrolling text from right to left
*/

// ---------------- LCD pin mapping ----------------
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

// Direction declarations required by mikroC LCD library
sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

// ---------------- PWM output pin ----------------
sbit LCD_PWM_OUT at GPIOB_ODR.B4;

// Text to scroll
char text[] = "                United Arab Emirates University - SIP - District 4.0                ";

/*
   ------------------------------------------------------------
   Software PWM for LCD backlight
   ------------------------------------------------------------

   duty: 0..100
   cycles: how long to keep this duty

   One PWM period here is about:
     100 x (100 us ON/OFF slots) = about 10 ms

   So:
     cycles = 1   -> about 10 ms
     cycles = 2   -> about 20 ms
*/
void Backlight_PWM(unsigned short duty, unsigned int cycles) {
  unsigned int c;
  unsigned short i;

  for(c = 0; c < cycles; c++) {
    for(i = 0; i < 100; i++) {
      if(i < duty)
        LCD_PWM_OUT = 1;   // backlight ON
      else
        LCD_PWM_OUT = 0;   // backlight OFF

      Delay_us(100);
    }
  }
}

/*
   Fade LCD backlight from 0% to 100% in about 2 seconds

   101 steps total: 0..100
   Each step held about 20 ms
   Total fade time � 101 x 20 ms � 2.02 seconds
*/
void Backlight_FadeIn_2s() {
  unsigned short duty;

  for(duty = 0; duty <= 100; duty++) {
    Backlight_PWM(duty, 2);   // about 20 ms per brightness step
  }

  // Fully ON after fade
  LCD_PWM_OUT = 1;
}

void main() {
  unsigned int i;
  unsigned int text_len;

  // Configure LCD pins as outputs
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  // Configure PB4 as output for LCD backlight PWM
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_4);

  // Start backlight OFF
  LCD_PWM_OUT = 0;

  // Initialize LCD
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  // Fade backlight from 0% to 100% over 2 seconds
  Backlight_FadeIn_2s();

  // Calculate number of scroll positions
  text_len = strlen(text);

  while(1) {
    for(i = 0; i <= (text_len - 16); i++) {
      Lcd_Cmd(_LCD_CLEAR);
      Lcd_Out(1, 1, text + i);
      Delay_ms(250);
    }
  }
}