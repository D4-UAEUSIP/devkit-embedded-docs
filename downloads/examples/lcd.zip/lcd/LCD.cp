#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/LCD.c"
#line 44 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/LCD.c"
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;


sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;


sbit LCD_PWM_OUT at GPIOB_ODR.B4;


char text[] = "                United Arab Emirates University - SIP - District 4.0                ";
#line 80 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/LCD.c"
void Backlight_PWM(unsigned short duty, unsigned int cycles) {
 unsigned int c;
 unsigned short i;

 for(c = 0; c < cycles; c++) {
 for(i = 0; i < 100; i++) {
 if(i < duty)
 LCD_PWM_OUT = 1;
 else
 LCD_PWM_OUT = 0;

 Delay_us(100);
 }
 }
}
#line 103 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/LCD.c"
void Backlight_FadeIn_2s() {
 unsigned short duty;

 for(duty = 0; duty <= 100; duty++) {
 Backlight_PWM(duty, 2);
 }


 LCD_PWM_OUT = 1;
}

void main() {
 unsigned int i;
 unsigned int text_len;


 GPIO_Digital_Output(&GPIOC_BASE,
 _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
 _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
 _GPIO_PINMASK_8 | _GPIO_PINMASK_9);


 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_4);


 LCD_PWM_OUT = 0;


 Lcd_Init();
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Cmd(_LCD_CURSOR_OFF);


 Backlight_FadeIn_2s();


 text_len = strlen(text);

 while(1) {
 for(i = 0; i <= (text_len - 16); i++) {
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, text + i);
 Delay_ms(250);
 }
 }
}
