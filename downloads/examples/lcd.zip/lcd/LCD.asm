_Backlight_PWM:
;LCD.c,80 :: 		void Backlight_PWM(unsigned short duty, unsigned int cycles) {
; cycles start address is: 4 (R1)
; duty start address is: 0 (R0)
; cycles end address is: 4 (R1)
; duty end address is: 0 (R0)
; duty start address is: 0 (R0)
; cycles start address is: 4 (R1)
;LCD.c,84 :: 		for(c = 0; c < cycles; c++) {
; c start address is: 16 (R4)
MOVS	R4, #0
; duty end address is: 0 (R0)
; cycles end address is: 4 (R1)
; c end address is: 16 (R4)
UXTB	R3, R0
L_Backlight_PWM0:
; c start address is: 16 (R4)
; cycles start address is: 4 (R1)
; duty start address is: 12 (R3)
CMP	R4, R1
IT	CS
BCS	L_Backlight_PWM1
;LCD.c,85 :: 		for(i = 0; i < 100; i++) {
; i start address is: 0 (R0)
MOVS	R0, #0
; duty end address is: 12 (R3)
; i end address is: 0 (R0)
; cycles end address is: 4 (R1)
; c end address is: 16 (R4)
UXTB	R5, R0
UXTB	R0, R3
L_Backlight_PWM3:
; i start address is: 20 (R5)
; duty start address is: 0 (R0)
; cycles start address is: 4 (R1)
; c start address is: 16 (R4)
CMP	R5, #100
IT	CS
BCS	L_Backlight_PWM4
;LCD.c,86 :: 		if(i < duty)
CMP	R5, R0
IT	CS
BCS	L_Backlight_PWM6
;LCD.c,87 :: 		LCD_PWM_OUT = 1;   // backlight ON
MOVS	R3, #1
SXTB	R3, R3
MOVW	R2, #lo_addr(GPIOB_ODR+0)
MOVT	R2, #hi_addr(GPIOB_ODR+0)
_SX	[R2, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_Backlight_PWM7
L_Backlight_PWM6:
;LCD.c,89 :: 		LCD_PWM_OUT = 0;   // backlight OFF
MOVS	R3, #0
SXTB	R3, R3
MOVW	R2, #lo_addr(GPIOB_ODR+0)
MOVT	R2, #hi_addr(GPIOB_ODR+0)
_SX	[R2, ByteOffset(GPIOB_ODR+0)]
L_Backlight_PWM7:
;LCD.c,91 :: 		Delay_us(100);
MOVW	R7, #798
MOVT	R7, #0
NOP
NOP
L_Backlight_PWM8:
SUBS	R7, R7, #1
BNE	L_Backlight_PWM8
NOP
NOP
NOP
;LCD.c,85 :: 		for(i = 0; i < 100; i++) {
ADDS	R5, R5, #1
UXTB	R5, R5
;LCD.c,92 :: 		}
; i end address is: 20 (R5)
IT	AL
BAL	L_Backlight_PWM3
L_Backlight_PWM4:
;LCD.c,84 :: 		for(c = 0; c < cycles; c++) {
ADDS	R4, R4, #1
UXTH	R4, R4
;LCD.c,93 :: 		}
UXTB	R3, R0
; duty end address is: 0 (R0)
; cycles end address is: 4 (R1)
; c end address is: 16 (R4)
IT	AL
BAL	L_Backlight_PWM0
L_Backlight_PWM1:
;LCD.c,94 :: 		}
L_end_Backlight_PWM:
BX	LR
; end of _Backlight_PWM
_Backlight_FadeIn_2s:
;LCD.c,103 :: 		void Backlight_FadeIn_2s() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;LCD.c,106 :: 		for(duty = 0; duty <= 100; duty++) {
; duty start address is: 24 (R6)
MOVS	R6, #0
; duty end address is: 24 (R6)
L_Backlight_FadeIn_2s10:
; duty start address is: 24 (R6)
CMP	R6, #100
IT	HI
BHI	L_Backlight_FadeIn_2s11
;LCD.c,107 :: 		Backlight_PWM(duty, 2);   // about 20 ms per brightness step
MOVS	R1, #2
UXTB	R0, R6
BL	_Backlight_PWM+0
;LCD.c,106 :: 		for(duty = 0; duty <= 100; duty++) {
ADDS	R6, R6, #1
UXTB	R6, R6
;LCD.c,108 :: 		}
; duty end address is: 24 (R6)
IT	AL
BAL	L_Backlight_FadeIn_2s10
L_Backlight_FadeIn_2s11:
;LCD.c,111 :: 		LCD_PWM_OUT = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;LCD.c,112 :: 		}
L_end_Backlight_FadeIn_2s:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Backlight_FadeIn_2s
_main:
;LCD.c,114 :: 		void main() {
SUB	SP, SP, #4
;LCD.c,122 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;LCD.c,119 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;LCD.c,122 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;LCD.c,125 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_4);
MOVW	R1, #16
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;LCD.c,128 :: 		LCD_PWM_OUT = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;LCD.c,131 :: 		Lcd_Init();
BL	_Lcd_Init+0
;LCD.c,132 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LCD.c,133 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;LCD.c,136 :: 		Backlight_FadeIn_2s();
BL	_Backlight_FadeIn_2s+0
;LCD.c,139 :: 		text_len = strlen(text);
MOVW	R0, #lo_addr(_text+0)
MOVT	R0, #hi_addr(_text+0)
BL	_strlen+0
; text_len start address is: 4 (R1)
UXTH	R1, R0
; text_len end address is: 4 (R1)
UXTH	R6, R1
;LCD.c,141 :: 		while(1) {
L_main13:
;LCD.c,142 :: 		for(i = 0; i <= (text_len - 16); i++) {
; text_len start address is: 24 (R6)
MOVS	R0, #0
STRH	R0, [SP, #0]
; text_len end address is: 24 (R6)
L_main15:
; text_len start address is: 24 (R6)
SUBW	R1, R6, #16
UXTH	R1, R1
LDRH	R0, [SP, #0]
CMP	R0, R1
IT	HI
BHI	L_main16
;LCD.c,143 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LCD.c,144 :: 		Lcd_Out(1, 1, text + i);
LDRH	R1, [SP, #0]
MOVW	R0, #lo_addr(_text+0)
MOVT	R0, #hi_addr(_text+0)
ADDS	R0, R0, R1
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LCD.c,145 :: 		Delay_ms(250);
MOVW	R7, #33918
MOVT	R7, #30
NOP
NOP
L_main18:
SUBS	R7, R7, #1
BNE	L_main18
NOP
NOP
NOP
;LCD.c,142 :: 		for(i = 0; i <= (text_len - 16); i++) {
LDRH	R0, [SP, #0]
ADDS	R0, R0, #1
STRH	R0, [SP, #0]
;LCD.c,146 :: 		}
IT	AL
BAL	L_main15
L_main16:
;LCD.c,147 :: 		}
; text_len end address is: 24 (R6)
IT	AL
BAL	L_main13
;LCD.c,148 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
