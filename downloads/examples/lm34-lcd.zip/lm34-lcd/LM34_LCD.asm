_Read_ADC_Average:
;LM34_LCD.c,73 :: 		unsigned int Read_ADC_Average() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;LM34_LCD.c,74 :: 		adc_sum = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_adc_sum+0)
MOVT	R0, #hi_addr(_adc_sum+0)
STR	R1, [R0, #0]
;LM34_LCD.c,76 :: 		for(i = 0; i < 16; i++) {
MOVS	R1, #0
MOVW	R0, #lo_addr(_i+0)
MOVT	R0, #hi_addr(_i+0)
STRB	R1, [R0, #0]
L_Read_ADC_Average0:
MOVW	R0, #lo_addr(_i+0)
MOVT	R0, #hi_addr(_i+0)
LDRB	R0, [R0, #0]
CMP	R0, #16
IT	CS
BCS	L_Read_ADC_Average1
;LM34_LCD.c,77 :: 		adc_sum += ADC1_Get_Sample(10);
MOVS	R0, #10
BL	_ADC1_Get_Sample+0
MOVW	R2, #lo_addr(_adc_sum+0)
MOVT	R2, #hi_addr(_adc_sum+0)
LDR	R1, [R2, #0]
ADDS	R0, R1, R0
STR	R0, [R2, #0]
;LM34_LCD.c,78 :: 		Delay_ms(2);
MOVW	R7, #15998
MOVT	R7, #0
NOP
NOP
L_Read_ADC_Average3:
SUBS	R7, R7, #1
BNE	L_Read_ADC_Average3
NOP
NOP
NOP
;LM34_LCD.c,76 :: 		for(i = 0; i < 16; i++) {
MOVW	R1, #lo_addr(_i+0)
MOVT	R1, #hi_addr(_i+0)
LDRB	R0, [R1, #0]
ADDS	R0, R0, #1
STRB	R0, [R1, #0]
;LM34_LCD.c,79 :: 		}
IT	AL
BAL	L_Read_ADC_Average0
L_Read_ADC_Average1:
;LM34_LCD.c,81 :: 		return (unsigned int)(adc_sum / 16);
MOVW	R0, #lo_addr(_adc_sum+0)
MOVT	R0, #hi_addr(_adc_sum+0)
LDR	R0, [R0, #0]
LSRS	R0, R0, #4
UXTH	R0, R0
;LM34_LCD.c,82 :: 		}
L_end_Read_ADC_Average:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Read_ADC_Average
_main:
;LM34_LCD.c,84 :: 		void main() {
SUB	SP, SP, #4
;LM34_LCD.c,90 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;LM34_LCD.c,87 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;LM34_LCD.c,90 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;LM34_LCD.c,93 :: 		ADC_Set_Input_Channel(_ADC_CHANNEL_10);
MOVW	R0, #1024
BL	_ADC_Set_Input_Channel+0
;LM34_LCD.c,96 :: 		ADC1_Init();
BL	_ADC1_Init+0
;LM34_LCD.c,99 :: 		Lcd_Init();
BL	_Lcd_Init+0
;LM34_LCD.c,100 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LM34_LCD.c,101 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;LM34_LCD.c,103 :: 		while(1) {
L_main5:
;LM34_LCD.c,106 :: 		adc_avg = Read_ADC_Average();
BL	_Read_ADC_Average+0
MOVW	R1, #lo_addr(_adc_avg+0)
MOVT	R1, #hi_addr(_adc_avg+0)
STRH	R0, [R1, #0]
;LM34_LCD.c,109 :: 		voltage = (adc_avg * 3.3) / 4095.0;
VMOV	S1, R0
VCVT.F32	#0, S1, S1
MOVW	R0, #13107
MOVT	R0, #16467
VMOV	S0, R0
VMUL.F32	S1, S1, S0
MOVW	R0, #61440
MOVT	R0, #17791
VMOV	S0, R0
VDIV.F32	S1, S1, S0
MOVW	R0, #lo_addr(_voltage+0)
MOVT	R0, #hi_addr(_voltage+0)
VSTR	#1, S1, [R0, #0]
;LM34_LCD.c,112 :: 		temp_f = voltage * 100.0;
MOVW	R0, #0
MOVT	R0, #17096
VMOV	S0, R0
VMUL.F32	S1, S1, S0
MOVW	R0, #lo_addr(_temp_f+0)
MOVT	R0, #hi_addr(_temp_f+0)
VSTR	#1, S1, [R0, #0]
;LM34_LCD.c,115 :: 		temp_c = (temp_f - 32.0) * 5.0 / 9.0;
MOV	R0, #1107296256
VMOV	S0, R0
VSUB.F32	S1, S1, S0
VMOV.F32	S0, #5
VMUL.F32	S1, S1, S0
VMOV.F32	S0, #9
VDIV.F32	S1, S1, S0
MOVW	R0, #lo_addr(_temp_c+0)
MOVT	R0, #hi_addr(_temp_c+0)
VSTR	#1, S1, [R0, #0]
;LM34_LCD.c,118 :: 		temp_c_int  = (unsigned int)temp_c;
VCVT	#1, .F32, S0, S1
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_temp_c_int+0)
MOVT	R0, #hi_addr(_temp_c_int+0)
STRH	R1, [R0, #0]
;LM34_LCD.c,119 :: 		temp_c_frac = (unsigned int)((temp_c - temp_c_int) * 10.0);
VMOV	S0, R1
VCVT.F32	#0, S0, S0
VSUB.F32	S1, S1, S0
VMOV.F32	S0, #10
VMUL.F32	S0, S1, S0
VCVT	#1, .F32, S0, S0
VMOV	R1, S0
UXTH	R1, R1
MOVW	R0, #lo_addr(_temp_c_frac+0)
MOVT	R0, #hi_addr(_temp_c_frac+0)
STRH	R1, [R0, #0]
;LM34_LCD.c,122 :: 		Lcd_Out(1, 1, "Temperature:");
MOVW	R0, #lo_addr(?lstr1_LM34_LCD+0)
MOVT	R0, #hi_addr(?lstr1_LM34_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LM34_LCD.c,125 :: 		WordToStr(temp_c_int, txt);
MOVW	R0, #lo_addr(_temp_c_int+0)
MOVT	R0, #hi_addr(_temp_c_int+0)
LDRH	R0, [R0, #0]
MOVW	R1, #lo_addr(_txt+0)
MOVT	R1, #hi_addr(_txt+0)
BL	_WordToStr+0
;LM34_LCD.c,126 :: 		Ltrim(txt);
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_Ltrim+0
;LM34_LCD.c,129 :: 		Lcd_Out(2, 1, txt);
MOVW	R2, #lo_addr(_txt+0)
MOVT	R2, #hi_addr(_txt+0)
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LM34_LCD.c,130 :: 		Lcd_Chr(2, strlen(txt) + 1, '.');
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R0, R0, #1
MOVS	R2, #46
UXTB	R1, R0
MOVS	R0, #2
BL	_Lcd_Chr+0
;LM34_LCD.c,131 :: 		Lcd_Chr(2, strlen(txt) + 2, temp_c_frac + '0');
MOVW	R0, #lo_addr(_temp_c_frac+0)
MOVT	R0, #hi_addr(_temp_c_frac+0)
LDRH	R0, [R0, #0]
ADDS	R0, #48
STRH	R0, [SP, #0]
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R1, R0, #2
LDRH	R0, [SP, #0]
UXTB	R2, R0
UXTB	R1, R1
MOVS	R0, #2
BL	_Lcd_Chr+0
;LM34_LCD.c,132 :: 		Lcd_Chr(2, strlen(txt) + 4, 'C');
MOVW	R0, #lo_addr(_txt+0)
MOVT	R0, #hi_addr(_txt+0)
BL	_strlen+0
ADDS	R0, R0, #4
MOVS	R2, #67
UXTB	R1, R0
MOVS	R0, #2
BL	_Lcd_Chr+0
;LM34_LCD.c,134 :: 		Delay_ms(500);
MOVW	R7, #2302
MOVT	R7, #61
NOP
NOP
L_main7:
SUBS	R7, R7, #1
BNE	L_main7
NOP
NOP
NOP
;LM34_LCD.c,135 :: 		}
IT	AL
BAL	L_main5
;LM34_LCD.c,136 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
