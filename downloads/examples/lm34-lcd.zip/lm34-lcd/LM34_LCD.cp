#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/LM34_LCD.c"
#line 41 "D:/2026/UAEU/Traning Kit/Firmwares/Test/LM34_LCD.c"
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;


sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

unsigned int adc_avg;
unsigned long adc_sum;
unsigned short i;

float voltage;
float temp_f;
float temp_c;

unsigned int temp_c_int;
unsigned int temp_c_frac;

char txt[16];
#line 73 "D:/2026/UAEU/Traning Kit/Firmwares/Test/LM34_LCD.c"
unsigned int Read_ADC_Average() {
 adc_sum = 0;

 for(i = 0; i < 16; i++) {
 adc_sum += ADC1_Get_Sample(10);
 Delay_ms(2);
 }

 return (unsigned int)(adc_sum / 16);
}

void main() {


 GPIO_Digital_Output(&GPIOC_BASE,
 _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
 _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
 _GPIO_PINMASK_8 | _GPIO_PINMASK_9);


 ADC_Set_Input_Channel(_ADC_CHANNEL_10);


 ADC1_Init();


 Lcd_Init();
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Cmd(_LCD_CURSOR_OFF);

 while(1) {


 adc_avg = Read_ADC_Average();


 voltage = (adc_avg * 3.3) / 4095.0;


 temp_f = voltage * 100.0;


 temp_c = (temp_f - 32.0) * 5.0 / 9.0;


 temp_c_int = (unsigned int)temp_c;
 temp_c_frac = (unsigned int)((temp_c - temp_c_int) * 10.0);


 Lcd_Out(1, 1, "Temperature:");


 WordToStr(temp_c_int, txt);
 Ltrim(txt);


 Lcd_Out(2, 1, txt);
 Lcd_Chr(2, strlen(txt) + 1, '.');
 Lcd_Chr(2, strlen(txt) + 2, temp_c_frac + '0');
 Lcd_Chr(2, strlen(txt) + 4, 'C');

 Delay_ms(500);
 }
}
