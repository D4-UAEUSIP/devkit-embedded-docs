/*
   ------------------------------------------------------------
   STM32F446RE - LM34CZ Temperature on LCD
   Display in Celsius with ADC averaging
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   SW19 : 2:ON   1 :off
   SW4 :  LM34 side
   VR1: adujest it till  you see the text on LCD
   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   Sensor:
     LM34CZ output -> PC0

   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5

   LM34CZ:
     Output scale = 10mV per degree Fahrenheit

   ADC assumptions:
     - 12-bit ADC
     - Vref = 3.3V
     - ADC range = 0..4095

   Conversion:
     Voltage = ADC * 3.3 / 4095
     Temp_F  = Voltage * 100
     Temp_C  = (Temp_F - 32) * 5 / 9
*/

// LCD connections
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

// Direction declarations required by mikroC LCD library
sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

unsigned int adc_avg;
unsigned long adc_sum;
unsigned short i;

float voltage;
float temp_f;
float temp_c;

unsigned int temp_c_int;
unsigned int temp_c_frac;

char txt[16];

/*
   Read ADC channel 10 (PC0) and return averaged result.
   Here we average 16 samples for a more stable reading.
*/
unsigned int Read_ADC_Average() {
  adc_sum = 0;

  for(i = 0; i < 16; i++) {
    adc_sum += ADC1_Get_Sample(10);
    Delay_ms(2);
  }

  return (unsigned int)(adc_sum / 16);
}

void main() {

  // Configure LCD pins as outputs
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  // Configure PC0 as analog input
  ADC_Set_Input_Channel(_ADC_CHANNEL_10);

  // Initialize ADC
  ADC1_Init();

  // Initialize LCD
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  while(1) {

    // Read averaged ADC value
    adc_avg = Read_ADC_Average();

    // Convert ADC to voltage
    voltage = (adc_avg * 3.3) / 4095.0;

    // LM34: 10mV per degree Fahrenheit
    temp_f = voltage * 100.0;

    // Convert Fahrenheit to Celsius
    temp_c = (temp_f - 32.0) * 5.0 / 9.0;

    // Split into integer and 1 decimal digit
    temp_c_int  = (unsigned int)temp_c;
    temp_c_frac = (unsigned int)((temp_c - temp_c_int) * 10.0);

    // Display line 1
    Lcd_Out(1, 1, "Temperature:");

    // Convert integer part to text
    WordToStr(temp_c_int, txt);
    Ltrim(txt);

    // Display line 2
    Lcd_Out(2, 1, txt);
    Lcd_Chr(2, strlen(txt) + 1, '.');
    Lcd_Chr(2, strlen(txt) + 2, temp_c_frac + '0');
    Lcd_Chr(2, strlen(txt) + 4, 'C');

    Delay_ms(500);
  }
}