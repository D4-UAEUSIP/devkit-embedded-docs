_main:
;STM32_Web_Control.c,62 :: 		void main() {
SUB	SP, SP, #8
;STM32_Web_Control.c,66 :: 		Init_IO();
BL	_Init_IO+0
;STM32_Web_Control.c,67 :: 		UART4_Init_HW();
BL	_UART4_Init_HW+0
;STM32_Web_Control.c,68 :: 		Delay_ms(300);
MOVW	R7, #27134
MOVT	R7, #24
NOP
NOP
L_main0:
SUBS	R7, R7, #1
BNE	L_main0
NOP
NOP
NOP
;STM32_Web_Control.c,70 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
; i start address is: 16 (R4)
MOVS	R4, #0
; i end address is: 16 (R4)
L_main2:
; i start address is: 16 (R4)
CMP	R4, #4
IT	CS
BCS	L_main3
;STM32_Web_Control.c,71 :: 		ApplyLedState(i, 0);
MOVS	R1, #0
UXTB	R0, R4
BL	_ApplyLedState+0
;STM32_Web_Control.c,72 :: 		buttonStates[i] = ReadButtonState(i);
MOVW	R0, #lo_addr(_buttonStates+0)
MOVT	R0, #hi_addr(_buttonStates+0)
ADDS	R0, R0, R4
STR	R0, [SP, #4]
UXTB	R0, R4
BL	_ReadButtonState+0
LDR	R1, [SP, #4]
STRB	R0, [R1, #0]
;STM32_Web_Control.c,70 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
ADDS	R4, R4, #1
UXTB	R4, R4
;STM32_Web_Control.c,73 :: 		}
; i end address is: 16 (R4)
IT	AL
BAL	L_main2
L_main3:
;STM32_Web_Control.c,75 :: 		SendAllStates();
BL	_SendAllStates+0
;STM32_Web_Control.c,77 :: 		while(1) {
L_main5:
;STM32_Web_Control.c,78 :: 		while(UART4_ReadLine(uartLineBuffer, UART_LINE_BUFFER_SIZE)) {
L_main7:
MOVS	R1, #24
MOVW	R0, #lo_addr(_uartLineBuffer+0)
MOVT	R0, #hi_addr(_uartLineBuffer+0)
BL	_UART4_ReadLine+0
CMP	R0, #0
IT	EQ
BEQ	L_main8
;STM32_Web_Control.c,79 :: 		ProcessCommand(uartLineBuffer);
MOVW	R0, #lo_addr(_uartLineBuffer+0)
MOVT	R0, #hi_addr(_uartLineBuffer+0)
BL	_ProcessCommand+0
;STM32_Web_Control.c,80 :: 		}
IT	AL
BAL	L_main7
L_main8:
;STM32_Web_Control.c,82 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
L_main9:
; i start address is: 8 (R2)
CMP	R2, #4
IT	CS
BCS	L_main10
;STM32_Web_Control.c,83 :: 		currentButtonState = ReadButtonState(i);
UXTB	R0, R2
BL	_ReadButtonState+0
; currentButtonState start address is: 12 (R3)
UXTB	R3, R0
;STM32_Web_Control.c,85 :: 		if(currentButtonState != buttonStates[i]) {
MOVW	R1, #lo_addr(_buttonStates+0)
MOVT	R1, #hi_addr(_buttonStates+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
CMP	R0, R1
IT	EQ
BEQ	L_main12
;STM32_Web_Control.c,86 :: 		buttonStates[i] = currentButtonState;
MOVW	R0, #lo_addr(_buttonStates+0)
MOVT	R0, #hi_addr(_buttonStates+0)
ADDS	R0, R0, R2
STRB	R3, [R0, #0]
;STM32_Web_Control.c,87 :: 		SendButtonState(i, currentButtonState);
STRB	R2, [SP, #0]
; currentButtonState end address is: 12 (R3)
UXTB	R1, R3
UXTB	R0, R2
BL	_SendButtonState+0
LDRB	R2, [SP, #0]
;STM32_Web_Control.c,88 :: 		}
L_main12:
;STM32_Web_Control.c,82 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
ADDS	R2, R2, #1
UXTB	R2, R2
;STM32_Web_Control.c,89 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_main9
L_main10:
;STM32_Web_Control.c,90 :: 		}
IT	AL
BAL	L_main5
;STM32_Web_Control.c,91 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
_Init_IO:
;STM32_Web_Control.c,93 :: 		void Init_IO() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;STM32_Web_Control.c,94 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R1, #3072
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;STM32_Web_Control.c,95 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);
MOVW	R1, #192
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;STM32_Web_Control.c,97 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
MOVW	R1, #8320
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;STM32_Web_Control.c,98 :: 		GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);
MOVW	R1, #1536
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Input+0
;STM32_Web_Control.c,100 :: 		GPIOC_ODR.B10 = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;STM32_Web_Control.c,101 :: 		GPIOC_ODR.B11 = 0;
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;STM32_Web_Control.c,102 :: 		GPIOB_ODR.B6  = 0;
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM32_Web_Control.c,103 :: 		GPIOB_ODR.B7  = 0;
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM32_Web_Control.c,104 :: 		}
L_end_Init_IO:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Init_IO
_UART4_Init_HW:
;STM32_Web_Control.c,106 :: 		void UART4_Init_HW() {
;STM32_Web_Control.c,107 :: 		RCC_AHB1ENR |= 0x00000001;
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,108 :: 		RCC_APB1ENR |= 0x00080000;
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #524288
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,110 :: 		GPIOA_AFRL &= ~0x000000FF;
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
LDR	R0, [R0, #0]
AND	R1, R0, #0
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,111 :: 		GPIOA_AFRL |=  0x00000088;
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #136
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,113 :: 		GPIOA_MODER &= ~0x0000000F;
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
LDR	R1, [R0, #0]
MVN	R0, #15
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,114 :: 		GPIOA_MODER |=  0x0000000A;
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #10
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,116 :: 		UART4_BRR = 0x0683;
MOVW	R1, #1667
MOVW	R0, #lo_addr(UART4_BRR+0)
MOVT	R0, #hi_addr(UART4_BRR+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,117 :: 		UART4_CR1 = 0x000C;
MOVS	R1, #12
MOVW	R0, #lo_addr(UART4_CR1+0)
MOVT	R0, #hi_addr(UART4_CR1+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,118 :: 		UART4_CR2 = 0x0000;
MOVS	R1, #0
MOVW	R0, #lo_addr(UART4_CR2+0)
MOVT	R0, #hi_addr(UART4_CR2+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,119 :: 		UART4_CR3 = 0x0000;
MOVS	R1, #0
MOVW	R0, #lo_addr(UART4_CR3+0)
MOVT	R0, #hi_addr(UART4_CR3+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,120 :: 		UART4_CR1 |= 0x2000;
MOVW	R0, #lo_addr(UART4_CR1+0)
MOVT	R0, #hi_addr(UART4_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #8192
MOVW	R0, #lo_addr(UART4_CR1+0)
MOVT	R0, #hi_addr(UART4_CR1+0)
STR	R1, [R0, #0]
;STM32_Web_Control.c,121 :: 		}
L_end_UART4_Init_HW:
BX	LR
; end of _UART4_Init_HW
_UART4_WriteChar:
;STM32_Web_Control.c,123 :: 		void UART4_WriteChar(char ch) {
; ch start address is: 0 (R0)
; ch end address is: 0 (R0)
; ch start address is: 0 (R0)
; ch end address is: 0 (R0)
;STM32_Web_Control.c,124 :: 		while(!(UART4_SR & 0x0080)) {
L_UART4_WriteChar13:
; ch start address is: 0 (R0)
MOVW	R1, #lo_addr(UART4_SR+0)
MOVT	R1, #hi_addr(UART4_SR+0)
LDR	R1, [R1, #0]
AND	R1, R1, #128
CMP	R1, #0
IT	NE
BNE	L_UART4_WriteChar14
;STM32_Web_Control.c,125 :: 		}
IT	AL
BAL	L_UART4_WriteChar13
L_UART4_WriteChar14:
;STM32_Web_Control.c,127 :: 		UART4_DR = (ch & 0x00FF);
AND	R2, R0, #255
UXTB	R2, R2
; ch end address is: 0 (R0)
MOVW	R1, #lo_addr(UART4_DR+0)
MOVT	R1, #hi_addr(UART4_DR+0)
STR	R2, [R1, #0]
;STM32_Web_Control.c,128 :: 		}
L_end_UART4_WriteChar:
BX	LR
; end of _UART4_WriteChar
_UART4_WriteString:
;STM32_Web_Control.c,130 :: 		void UART4_WriteString(char *s) {
; s start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; s end address is: 0 (R0)
; s start address is: 0 (R0)
MOV	R3, R0
; s end address is: 0 (R0)
;STM32_Web_Control.c,131 :: 		while(*s) {
L_UART4_WriteString15:
; s start address is: 12 (R3)
LDRB	R1, [R3, #0]
CMP	R1, #0
IT	EQ
BEQ	L_UART4_WriteString16
;STM32_Web_Control.c,132 :: 		UART4_WriteChar(*s++);
LDRB	R1, [R3, #0]
UXTB	R0, R1
BL	_UART4_WriteChar+0
ADDS	R3, R3, #1
;STM32_Web_Control.c,133 :: 		}
; s end address is: 12 (R3)
IT	AL
BAL	L_UART4_WriteString15
L_UART4_WriteString16:
;STM32_Web_Control.c,134 :: 		}
L_end_UART4_WriteString:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _UART4_WriteString
_UART4_DataReady:
;STM32_Web_Control.c,136 :: 		char UART4_DataReady() {
;STM32_Web_Control.c,137 :: 		return (UART4_SR & 0x0020) != 0;
MOVW	R0, #lo_addr(UART4_SR+0)
MOVT	R0, #hi_addr(UART4_SR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #32
CMP	R0, #0
MOVW	R0, #0
BEQ	L__UART4_DataReady87
MOVS	R0, #1
L__UART4_DataReady87:
UXTB	R0, R0
;STM32_Web_Control.c,138 :: 		}
L_end_UART4_DataReady:
BX	LR
; end of _UART4_DataReady
_UART4_ReadChar:
;STM32_Web_Control.c,140 :: 		char UART4_ReadChar() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;STM32_Web_Control.c,141 :: 		while(!UART4_DataReady()) {
L_UART4_ReadChar17:
BL	_UART4_DataReady+0
CMP	R0, #0
IT	NE
BNE	L_UART4_ReadChar18
;STM32_Web_Control.c,142 :: 		}
IT	AL
BAL	L_UART4_ReadChar17
L_UART4_ReadChar18:
;STM32_Web_Control.c,144 :: 		return (char)(UART4_DR & 0x00FF);
MOVW	R0, #lo_addr(UART4_DR+0)
MOVT	R0, #hi_addr(UART4_DR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #255
UXTB	R0, R0
;STM32_Web_Control.c,145 :: 		}
L_end_UART4_ReadChar:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _UART4_ReadChar
_UART4_ReadLine:
;STM32_Web_Control.c,147 :: 		char UART4_ReadLine(char *buffer, unsigned short maxLen) {
; maxLen start address is: 4 (R1)
; buffer start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; maxLen end address is: 4 (R1)
; buffer end address is: 0 (R0)
; buffer start address is: 0 (R0)
; maxLen start address is: 4 (R1)
UXTB	R4, R1
; buffer end address is: 0 (R0)
; maxLen end address is: 4 (R1)
MOV	R1, R0
;STM32_Web_Control.c,150 :: 		while(UART4_DataReady()) {
L_UART4_ReadLine19:
; buffer start address is: 4 (R1)
; maxLen start address is: 16 (R4)
; maxLen start address is: 16 (R4)
; maxLen end address is: 16 (R4)
; buffer start address is: 4 (R1)
; buffer end address is: 4 (R1)
BL	_UART4_DataReady+0
CMP	R0, #0
IT	EQ
BEQ	L_UART4_ReadLine20
; maxLen end address is: 16 (R4)
; buffer end address is: 4 (R1)
;STM32_Web_Control.c,151 :: 		ch = UART4_ReadChar();
; buffer start address is: 4 (R1)
; maxLen start address is: 16 (R4)
BL	_UART4_ReadChar+0
; ch start address is: 20 (R5)
UXTB	R5, R0
;STM32_Web_Control.c,153 :: 		if((ch == '\r') || (ch == '\n')) {
CMP	R0, #13
IT	EQ
BEQ	L__UART4_ReadLine62
CMP	R5, #10
IT	EQ
BEQ	L__UART4_ReadLine61
IT	AL
BAL	L_UART4_ReadLine23
; ch end address is: 20 (R5)
L__UART4_ReadLine62:
L__UART4_ReadLine61:
;STM32_Web_Control.c,154 :: 		if(uartLineIndex > 0) {
MOVW	R2, #lo_addr(_uartLineIndex+0)
MOVT	R2, #hi_addr(_uartLineIndex+0)
LDRB	R2, [R2, #0]
CMP	R2, #0
IT	LS
BLS	L_UART4_ReadLine24
; maxLen end address is: 16 (R4)
;STM32_Web_Control.c,155 :: 		buffer[uartLineIndex] = 0;
MOVW	R4, #lo_addr(_uartLineIndex+0)
MOVT	R4, #hi_addr(_uartLineIndex+0)
LDRB	R2, [R4, #0]
ADDS	R3, R1, R2
; buffer end address is: 4 (R1)
MOVS	R2, #0
STRB	R2, [R3, #0]
;STM32_Web_Control.c,156 :: 		uartLineIndex = 0;
MOVS	R2, #0
STRB	R2, [R4, #0]
;STM32_Web_Control.c,157 :: 		return 1;
MOVS	R0, #1
IT	AL
BAL	L_end_UART4_ReadLine
;STM32_Web_Control.c,158 :: 		}
L_UART4_ReadLine24:
;STM32_Web_Control.c,159 :: 		}
; buffer start address is: 4 (R1)
; maxLen start address is: 16 (R4)
IT	AL
BAL	L_UART4_ReadLine25
L_UART4_ReadLine23:
;STM32_Web_Control.c,161 :: 		if(uartLineIndex < (maxLen - 1)) {
; ch start address is: 20 (R5)
SUBS	R3, R4, #1
SXTH	R3, R3
MOVW	R2, #lo_addr(_uartLineIndex+0)
MOVT	R2, #hi_addr(_uartLineIndex+0)
LDRB	R2, [R2, #0]
CMP	R2, R3
IT	GE
BGE	L_UART4_ReadLine26
;STM32_Web_Control.c,162 :: 		buffer[uartLineIndex++] = ch;
MOVW	R3, #lo_addr(_uartLineIndex+0)
MOVT	R3, #hi_addr(_uartLineIndex+0)
LDRB	R2, [R3, #0]
ADDS	R2, R1, R2
STRB	R5, [R2, #0]
; ch end address is: 20 (R5)
MOV	R2, R3
LDRB	R2, [R2, #0]
ADDS	R2, R2, #1
STRB	R2, [R3, #0]
;STM32_Web_Control.c,163 :: 		}
IT	AL
BAL	L_UART4_ReadLine27
L_UART4_ReadLine26:
;STM32_Web_Control.c,165 :: 		uartLineIndex = 0;
MOVS	R3, #0
MOVW	R2, #lo_addr(_uartLineIndex+0)
MOVT	R2, #hi_addr(_uartLineIndex+0)
STRB	R3, [R2, #0]
;STM32_Web_Control.c,166 :: 		}
L_UART4_ReadLine27:
;STM32_Web_Control.c,167 :: 		}
L_UART4_ReadLine25:
;STM32_Web_Control.c,168 :: 		}
; maxLen end address is: 16 (R4)
; buffer end address is: 4 (R1)
IT	AL
BAL	L_UART4_ReadLine19
L_UART4_ReadLine20:
;STM32_Web_Control.c,170 :: 		return 0;
MOVS	R0, #0
;STM32_Web_Control.c,171 :: 		}
L_end_UART4_ReadLine:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _UART4_ReadLine
_ReadButtonState:
;STM32_Web_Control.c,173 :: 		char ReadButtonState(unsigned short index) {
; index start address is: 0 (R0)
; index end address is: 0 (R0)
; index start address is: 0 (R0)
;STM32_Web_Control.c,174 :: 		switch(index) {
IT	AL
BAL	L_ReadButtonState28
; index end address is: 0 (R0)
;STM32_Web_Control.c,175 :: 		case 0: return GPIOA_IDR.B9;
L_ReadButtonState30:
MOVW	R1, #lo_addr(GPIOA_IDR+0)
MOVT	R1, #hi_addr(GPIOA_IDR+0)
_LX	[R1, ByteOffset(GPIOA_IDR+0)]
IT	AL
BAL	L_end_ReadButtonState
;STM32_Web_Control.c,177 :: 		case 1: return GPIOA_IDR.B10;
L_ReadButtonState31:
MOVW	R1, #lo_addr(GPIOA_IDR+0)
MOVT	R1, #hi_addr(GPIOA_IDR+0)
_LX	[R1, ByteOffset(GPIOA_IDR+0)]
IT	AL
BAL	L_end_ReadButtonState
;STM32_Web_Control.c,179 :: 		case 2: return GPIOC_IDR.B13;
L_ReadButtonState32:
MOVW	R1, #lo_addr(GPIOC_IDR+0)
MOVT	R1, #hi_addr(GPIOC_IDR+0)
_LX	[R1, ByteOffset(GPIOC_IDR+0)]
IT	AL
BAL	L_end_ReadButtonState
;STM32_Web_Control.c,181 :: 		case 3: return GPIOC_IDR.B7;
L_ReadButtonState33:
MOVW	R1, #lo_addr(GPIOC_IDR+0)
MOVT	R1, #hi_addr(GPIOC_IDR+0)
_LX	[R1, ByteOffset(GPIOC_IDR+0)]
IT	AL
BAL	L_end_ReadButtonState
;STM32_Web_Control.c,183 :: 		}
L_ReadButtonState28:
; index start address is: 0 (R0)
CMP	R0, #0
IT	EQ
BEQ	L_ReadButtonState30
CMP	R0, #1
IT	EQ
BEQ	L_ReadButtonState31
CMP	R0, #2
IT	EQ
BEQ	L_ReadButtonState32
CMP	R0, #3
IT	EQ
BEQ	L_ReadButtonState33
; index end address is: 0 (R0)
;STM32_Web_Control.c,185 :: 		return 0;
MOVS	R0, #0
;STM32_Web_Control.c,186 :: 		}
L_end_ReadButtonState:
BX	LR
; end of _ReadButtonState
_ApplyLedState:
;STM32_Web_Control.c,188 :: 		void ApplyLedState(unsigned short index, char state) {
; state start address is: 4 (R1)
; index start address is: 0 (R0)
; state end address is: 4 (R1)
; index end address is: 0 (R0)
; index start address is: 0 (R0)
; state start address is: 4 (R1)
;STM32_Web_Control.c,189 :: 		ledStates[index] = state ? 1 : 0;
MOVW	R2, #lo_addr(_ledStates+0)
MOVT	R2, #hi_addr(_ledStates+0)
ADDS	R2, R2, R0
CMP	R1, #0
IT	EQ
BEQ	L_ApplyLedState34
; state end address is: 4 (R1)
; ?FLOC___ApplyLedState?T72 start address is: 4 (R1)
MOVS	R1, #1
SXTB	R1, R1
; ?FLOC___ApplyLedState?T72 end address is: 4 (R1)
IT	AL
BAL	L_ApplyLedState35
L_ApplyLedState34:
; ?FLOC___ApplyLedState?T72 start address is: 4 (R1)
MOVS	R1, #0
SXTB	R1, R1
; ?FLOC___ApplyLedState?T72 end address is: 4 (R1)
L_ApplyLedState35:
; ?FLOC___ApplyLedState?T72 start address is: 4 (R1)
STRB	R1, [R2, #0]
; ?FLOC___ApplyLedState?T72 end address is: 4 (R1)
;STM32_Web_Control.c,191 :: 		switch(index) {
IT	AL
BAL	L_ApplyLedState36
;STM32_Web_Control.c,192 :: 		case 0: GPIOB_ODR.B6 = ledStates[index];
L_ApplyLedState38:
MOVW	R2, #lo_addr(_ledStates+0)
MOVT	R2, #hi_addr(_ledStates+0)
ADDS	R2, R2, R0
; index end address is: 0 (R0)
LDRB	R3, [R2, #0]
MOVW	R2, #lo_addr(GPIOB_ODR+0)
MOVT	R2, #hi_addr(GPIOB_ODR+0)
_SX	[R2, ByteOffset(GPIOB_ODR+0)]
;STM32_Web_Control.c,193 :: 		break;
IT	AL
BAL	L_ApplyLedState37
;STM32_Web_Control.c,194 :: 		case 1: GPIOB_ODR.B7 = ledStates[index];
L_ApplyLedState39:
; index start address is: 0 (R0)
MOVW	R2, #lo_addr(_ledStates+0)
MOVT	R2, #hi_addr(_ledStates+0)
ADDS	R2, R2, R0
; index end address is: 0 (R0)
LDRB	R3, [R2, #0]
MOVW	R2, #lo_addr(GPIOB_ODR+0)
MOVT	R2, #hi_addr(GPIOB_ODR+0)
_SX	[R2, ByteOffset(GPIOB_ODR+0)]
;STM32_Web_Control.c,195 :: 		break;
IT	AL
BAL	L_ApplyLedState37
;STM32_Web_Control.c,196 :: 		case 2: GPIOC_ODR.B10 = ledStates[index];
L_ApplyLedState40:
; index start address is: 0 (R0)
MOVW	R2, #lo_addr(_ledStates+0)
MOVT	R2, #hi_addr(_ledStates+0)
ADDS	R2, R2, R0
; index end address is: 0 (R0)
LDRB	R3, [R2, #0]
MOVW	R2, #lo_addr(GPIOC_ODR+0)
MOVT	R2, #hi_addr(GPIOC_ODR+0)
_SX	[R2, ByteOffset(GPIOC_ODR+0)]
;STM32_Web_Control.c,197 :: 		break;
IT	AL
BAL	L_ApplyLedState37
;STM32_Web_Control.c,198 :: 		case 3: GPIOC_ODR.B11 = ledStates[index];
L_ApplyLedState41:
; index start address is: 0 (R0)
MOVW	R2, #lo_addr(_ledStates+0)
MOVT	R2, #hi_addr(_ledStates+0)
ADDS	R2, R2, R0
; index end address is: 0 (R0)
LDRB	R3, [R2, #0]
MOVW	R2, #lo_addr(GPIOC_ODR+0)
MOVT	R2, #hi_addr(GPIOC_ODR+0)
_SX	[R2, ByteOffset(GPIOC_ODR+0)]
;STM32_Web_Control.c,199 :: 		break;
IT	AL
BAL	L_ApplyLedState37
;STM32_Web_Control.c,200 :: 		}
L_ApplyLedState36:
; index start address is: 0 (R0)
CMP	R0, #0
IT	EQ
BEQ	L_ApplyLedState38
CMP	R0, #1
IT	EQ
BEQ	L_ApplyLedState39
CMP	R0, #2
IT	EQ
BEQ	L_ApplyLedState40
CMP	R0, #3
IT	EQ
BEQ	L_ApplyLedState41
; index end address is: 0 (R0)
L_ApplyLedState37:
;STM32_Web_Control.c,201 :: 		}
L_end_ApplyLedState:
BX	LR
; end of _ApplyLedState
_SendLedState:
;STM32_Web_Control.c,203 :: 		void SendLedState(unsigned short index, char state) {
; state start address is: 4 (R1)
; index start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R4, R0
UXTB	R5, R1
; state end address is: 4 (R1)
; index end address is: 0 (R0)
; index start address is: 16 (R4)
; state start address is: 20 (R5)
;STM32_Web_Control.c,204 :: 		UART4_WriteString("LED");
MOVW	R2, #lo_addr(?lstr1_STM32_Web_Control+0)
MOVT	R2, #hi_addr(?lstr1_STM32_Web_Control+0)
MOV	R0, R2
BL	_UART4_WriteString+0
;STM32_Web_Control.c,205 :: 		UART4_WriteChar('1' + index);
ADDW	R2, R4, #49
; index end address is: 16 (R4)
UXTB	R0, R2
BL	_UART4_WriteChar+0
;STM32_Web_Control.c,206 :: 		UART4_WriteChar(':');
MOVS	R0, #58
BL	_UART4_WriteChar+0
;STM32_Web_Control.c,207 :: 		UART4_WriteChar(state ? '1' : '0');
CMP	R5, #0
IT	EQ
BEQ	L_SendLedState42
; state end address is: 20 (R5)
; ?FLOC___SendLedState?T104 start address is: 0 (R0)
MOVS	R0, #49
; ?FLOC___SendLedState?T104 end address is: 0 (R0)
IT	AL
BAL	L_SendLedState43
L_SendLedState42:
; ?FLOC___SendLedState?T104 start address is: 0 (R0)
MOVS	R0, #48
; ?FLOC___SendLedState?T104 end address is: 0 (R0)
L_SendLedState43:
; ?FLOC___SendLedState?T104 start address is: 0 (R0)
; ?FLOC___SendLedState?T104 end address is: 0 (R0)
BL	_UART4_WriteChar+0
;STM32_Web_Control.c,208 :: 		UART4_WriteString("\r\n");
MOVW	R2, #lo_addr(?lstr2_STM32_Web_Control+0)
MOVT	R2, #hi_addr(?lstr2_STM32_Web_Control+0)
MOV	R0, R2
BL	_UART4_WriteString+0
;STM32_Web_Control.c,209 :: 		}
L_end_SendLedState:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _SendLedState
_SendButtonState:
;STM32_Web_Control.c,211 :: 		void SendButtonState(unsigned short index, char state) {
; state start address is: 4 (R1)
; index start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R4, R0
UXTB	R5, R1
; state end address is: 4 (R1)
; index end address is: 0 (R0)
; index start address is: 16 (R4)
; state start address is: 20 (R5)
;STM32_Web_Control.c,212 :: 		UART4_WriteString("BTN");
MOVW	R2, #lo_addr(?lstr3_STM32_Web_Control+0)
MOVT	R2, #hi_addr(?lstr3_STM32_Web_Control+0)
MOV	R0, R2
BL	_UART4_WriteString+0
;STM32_Web_Control.c,213 :: 		UART4_WriteChar('1' + index);
ADDW	R2, R4, #49
; index end address is: 16 (R4)
UXTB	R0, R2
BL	_UART4_WriteChar+0
;STM32_Web_Control.c,214 :: 		UART4_WriteChar(':');
MOVS	R0, #58
BL	_UART4_WriteChar+0
;STM32_Web_Control.c,215 :: 		UART4_WriteChar(state ? '1' : '0');
CMP	R5, #0
IT	EQ
BEQ	L_SendButtonState44
; state end address is: 20 (R5)
; ?FLOC___SendButtonState?T110 start address is: 0 (R0)
MOVS	R0, #49
; ?FLOC___SendButtonState?T110 end address is: 0 (R0)
IT	AL
BAL	L_SendButtonState45
L_SendButtonState44:
; ?FLOC___SendButtonState?T110 start address is: 0 (R0)
MOVS	R0, #48
; ?FLOC___SendButtonState?T110 end address is: 0 (R0)
L_SendButtonState45:
; ?FLOC___SendButtonState?T110 start address is: 0 (R0)
; ?FLOC___SendButtonState?T110 end address is: 0 (R0)
BL	_UART4_WriteChar+0
;STM32_Web_Control.c,216 :: 		UART4_WriteString("\r\n");
MOVW	R2, #lo_addr(?lstr4_STM32_Web_Control+0)
MOVT	R2, #hi_addr(?lstr4_STM32_Web_Control+0)
MOV	R0, R2
BL	_UART4_WriteString+0
;STM32_Web_Control.c,217 :: 		}
L_end_SendButtonState:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _SendButtonState
_SendAllStates:
;STM32_Web_Control.c,219 :: 		void SendAllStates() {
SUB	SP, SP, #8
STR	LR, [SP, #0]
;STM32_Web_Control.c,222 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
; i start address is: 24 (R6)
MOVS	R6, #0
; i end address is: 24 (R6)
L_SendAllStates46:
; i start address is: 24 (R6)
CMP	R6, #4
IT	CS
BCS	L_SendAllStates47
;STM32_Web_Control.c,223 :: 		SendLedState(i, ledStates[i]);
MOVW	R0, #lo_addr(_ledStates+0)
MOVT	R0, #hi_addr(_ledStates+0)
ADDS	R0, R0, R6
LDRB	R0, [R0, #0]
UXTB	R1, R0
UXTB	R0, R6
BL	_SendLedState+0
;STM32_Web_Control.c,222 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
ADDS	R6, R6, #1
UXTB	R6, R6
;STM32_Web_Control.c,224 :: 		}
; i end address is: 24 (R6)
IT	AL
BAL	L_SendAllStates46
L_SendAllStates47:
;STM32_Web_Control.c,226 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
; i start address is: 24 (R6)
MOVS	R6, #0
; i end address is: 24 (R6)
L_SendAllStates49:
; i start address is: 24 (R6)
CMP	R6, #4
IT	CS
BCS	L_SendAllStates50
;STM32_Web_Control.c,227 :: 		buttonStates[i] = ReadButtonState(i);
MOVW	R0, #lo_addr(_buttonStates+0)
MOVT	R0, #hi_addr(_buttonStates+0)
ADDS	R0, R0, R6
STR	R0, [SP, #4]
UXTB	R0, R6
BL	_ReadButtonState+0
LDR	R1, [SP, #4]
STRB	R0, [R1, #0]
;STM32_Web_Control.c,228 :: 		SendButtonState(i, buttonStates[i]);
MOVW	R0, #lo_addr(_buttonStates+0)
MOVT	R0, #hi_addr(_buttonStates+0)
ADDS	R0, R0, R6
LDRB	R0, [R0, #0]
UXTB	R1, R0
UXTB	R0, R6
BL	_SendButtonState+0
;STM32_Web_Control.c,226 :: 		for(i = 0; i < DEVICE_COUNT; i++) {
ADDS	R6, R6, #1
UXTB	R6, R6
;STM32_Web_Control.c,229 :: 		}
; i end address is: 24 (R6)
IT	AL
BAL	L_SendAllStates49
L_SendAllStates50:
;STM32_Web_Control.c,230 :: 		}
L_end_SendAllStates:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _SendAllStates
_ProcessCommand:
;STM32_Web_Control.c,232 :: 		void ProcessCommand(char *line) {
; line start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
MOV	R6, R0
; line end address is: 0 (R0)
; line start address is: 24 (R6)
;STM32_Web_Control.c,236 :: 		if((line[0] == 'S') && (line[1] == 'Y') && (line[2] == 'N') && (line[3] == 'C') && (line[4] == 0)) {
LDRB	R1, [R6, #0]
CMP	R1, #83
IT	NE
BNE	L__ProcessCommand70
ADDS	R1, R6, #1
LDRB	R1, [R1, #0]
CMP	R1, #89
IT	NE
BNE	L__ProcessCommand69
ADDS	R1, R6, #2
LDRB	R1, [R1, #0]
CMP	R1, #78
IT	NE
BNE	L__ProcessCommand68
ADDS	R1, R6, #3
LDRB	R1, [R1, #0]
CMP	R1, #67
IT	NE
BNE	L__ProcessCommand67
ADDS	R1, R6, #4
LDRB	R1, [R1, #0]
CMP	R1, #0
IT	NE
BNE	L__ProcessCommand66
; line end address is: 24 (R6)
L__ProcessCommand65:
;STM32_Web_Control.c,237 :: 		SendAllStates();
BL	_SendAllStates+0
;STM32_Web_Control.c,238 :: 		return;
IT	AL
BAL	L_end_ProcessCommand
;STM32_Web_Control.c,236 :: 		if((line[0] == 'S') && (line[1] == 'Y') && (line[2] == 'N') && (line[3] == 'C') && (line[4] == 0)) {
L__ProcessCommand70:
; line start address is: 24 (R6)
L__ProcessCommand69:
L__ProcessCommand68:
L__ProcessCommand67:
L__ProcessCommand66:
;STM32_Web_Control.c,241 :: 		if((line[0] == 'L') && (line[1] == 'E') && (line[2] == 'D') &&
LDRB	R1, [R6, #0]
CMP	R1, #76
IT	NE
BNE	L__ProcessCommand79
ADDS	R1, R6, #1
LDRB	R1, [R1, #0]
CMP	R1, #69
IT	NE
BNE	L__ProcessCommand78
ADDS	R1, R6, #2
LDRB	R1, [R1, #0]
CMP	R1, #68
IT	NE
BNE	L__ProcessCommand77
;STM32_Web_Control.c,242 :: 		(line[3] >= '1') && (line[3] <= '4') &&
ADDS	R1, R6, #3
LDRB	R1, [R1, #0]
CMP	R1, #49
IT	CC
BCC	L__ProcessCommand76
ADDS	R1, R6, #3
LDRB	R1, [R1, #0]
CMP	R1, #52
IT	HI
BHI	L__ProcessCommand75
;STM32_Web_Control.c,243 :: 		(line[4] == ':') &&
ADDS	R1, R6, #4
LDRB	R1, [R1, #0]
CMP	R1, #58
IT	NE
BNE	L__ProcessCommand74
;STM32_Web_Control.c,244 :: 		((line[5] == '0') || (line[5] == '1')) &&
ADDS	R1, R6, #5
LDRB	R1, [R1, #0]
CMP	R1, #48
IT	EQ
BEQ	L__ProcessCommand72
ADDS	R1, R6, #5
LDRB	R1, [R1, #0]
CMP	R1, #49
IT	EQ
BEQ	L__ProcessCommand71
; line end address is: 24 (R6)
IT	AL
BAL	L_ProcessCommand59
L__ProcessCommand72:
; line start address is: 24 (R6)
L__ProcessCommand71:
;STM32_Web_Control.c,245 :: 		(line[6] == 0)) {
ADDS	R1, R6, #6
LDRB	R1, [R1, #0]
CMP	R1, #0
IT	NE
BNE	L__ProcessCommand73
L__ProcessCommand63:
;STM32_Web_Control.c,247 :: 		index = line[3] - '1';
ADDS	R1, R6, #3
LDRB	R1, [R1, #0]
SUBW	R2, R1, #49
; index start address is: 16 (R4)
UXTB	R4, R2
;STM32_Web_Control.c,248 :: 		state = line[5] - '0';
ADDS	R1, R6, #5
; line end address is: 24 (R6)
LDRB	R1, [R1, #0]
SUBS	R1, #48
;STM32_Web_Control.c,250 :: 		ApplyLedState(index, state);
UXTB	R1, R1
UXTB	R0, R2
BL	_ApplyLedState+0
;STM32_Web_Control.c,251 :: 		SendLedState(index, ledStates[index]);
MOVW	R1, #lo_addr(_ledStates+0)
MOVT	R1, #hi_addr(_ledStates+0)
ADDS	R1, R1, R4
LDRB	R1, [R1, #0]
UXTB	R0, R4
; index end address is: 16 (R4)
BL	_SendLedState+0
;STM32_Web_Control.c,252 :: 		}
L_ProcessCommand59:
;STM32_Web_Control.c,241 :: 		if((line[0] == 'L') && (line[1] == 'E') && (line[2] == 'D') &&
L__ProcessCommand79:
L__ProcessCommand78:
L__ProcessCommand77:
;STM32_Web_Control.c,242 :: 		(line[3] >= '1') && (line[3] <= '4') &&
L__ProcessCommand76:
L__ProcessCommand75:
;STM32_Web_Control.c,243 :: 		(line[4] == ':') &&
L__ProcessCommand74:
;STM32_Web_Control.c,245 :: 		(line[6] == 0)) {
L__ProcessCommand73:
;STM32_Web_Control.c,253 :: 		}
L_end_ProcessCommand:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _ProcessCommand
