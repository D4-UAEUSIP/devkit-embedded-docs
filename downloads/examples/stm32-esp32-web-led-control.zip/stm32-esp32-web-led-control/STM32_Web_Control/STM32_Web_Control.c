/*
   ------------------------------------------------------------
   STM32F446RE - ESP32 Web LED/Button Bridge
   mikroC PRO for ARM
   ------------------------------------------------------------

   LED outputs:
     LED1 -> PC10
     LED2 -> PC11
     LED3 -> PB6
     LED4 -> PB7

   Push button inputs:
     PUSH1 -> PC7
     PUSH2 -> PC13
     PUSH3 -> PA9
     PUSH4 -> PA10

   UART link to ESP32:
     UART4_TX -> PA0  -> ESP32 GPIO27 (UART2 RX)
     UART4_RX -> PA1  -> ESP32 GPIO26 (UART2 TX)

   Protocol:
     ESP32 -> STM32:
       LED1:1   turn LED1 on
       LED1:0   turn LED1 off
       SYNC     request all button/LED states

     STM32 -> ESP32:
       LED1:1   current LED state
       BTN1:1   button pressed state

   Notes:
     - Buttons are active LOW.
     - Web buttons control STM32 LEDs.
     - STM32 push buttons update the LED indicators on the web page.
*/

#define DEVICE_COUNT 4
#define UART_LINE_BUFFER_SIZE 24

char uartLineBuffer[UART_LINE_BUFFER_SIZE];
unsigned short uartLineIndex = 0;
char ledStates[DEVICE_COUNT];
char buttonStates[DEVICE_COUNT];

void UART4_Init_HW();
void UART4_WriteChar(char ch);
void UART4_WriteString(char *s);
char UART4_DataReady();
char UART4_ReadChar();
char UART4_ReadLine(char *buffer, unsigned short maxLen);

void Init_IO();
char ReadButtonState(unsigned short index);
void ApplyLedState(unsigned short index, char state);
void SendLedState(unsigned short index, char state);
void SendButtonState(unsigned short index, char state);
void SendAllStates();
void ProcessCommand(char *line);

void main() {
  unsigned short i;
  char currentButtonState;

  Init_IO();
  UART4_Init_HW();
  Delay_ms(300);

  for(i = 0; i < DEVICE_COUNT; i++) {
    ApplyLedState(i, 0);
    buttonStates[i] = ReadButtonState(i);
  }

  SendAllStates();

  while(1) {
    while(UART4_ReadLine(uartLineBuffer, UART_LINE_BUFFER_SIZE)) {
      ProcessCommand(uartLineBuffer);
    }

    for(i = 0; i < DEVICE_COUNT; i++) {
      currentButtonState = ReadButtonState(i);

      if(currentButtonState != buttonStates[i]) {
        buttonStates[i] = currentButtonState;
        SendButtonState(i, currentButtonState);
      }
    }
  }
}

void Init_IO() {
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
  GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);

  GPIOC_ODR.B10 = 0;
  GPIOC_ODR.B11 = 0;
  GPIOB_ODR.B6  = 0;
  GPIOB_ODR.B7  = 0;
}

void UART4_Init_HW() {
  RCC_AHB1ENR |= 0x00000001;
  RCC_APB1ENR |= 0x00080000;

  GPIOA_AFRL &= ~0x000000FF;
  GPIOA_AFRL |=  0x00000088;

  GPIOA_MODER &= ~0x0000000F;
  GPIOA_MODER |=  0x0000000A;

  UART4_BRR = 0x0683;
  UART4_CR1 = 0x000C;
  UART4_CR2 = 0x0000;
  UART4_CR3 = 0x0000;
  UART4_CR1 |= 0x2000;
}

void UART4_WriteChar(char ch) {
  while(!(UART4_SR & 0x0080)) {
  }

  UART4_DR = (ch & 0x00FF);
}

void UART4_WriteString(char *s) {
  while(*s) {
    UART4_WriteChar(*s++);
  }
}

char UART4_DataReady() {
  return (UART4_SR & 0x0020) != 0;
}

char UART4_ReadChar() {
  while(!UART4_DataReady()) {
  }

  return (char)(UART4_DR & 0x00FF);
}

char UART4_ReadLine(char *buffer, unsigned short maxLen) {
  char ch;

  while(UART4_DataReady()) {
    ch = UART4_ReadChar();

    if((ch == '\r') || (ch == '\n')) {
      if(uartLineIndex > 0) {
        buffer[uartLineIndex] = 0;
        uartLineIndex = 0;
        return 1;
      }
    }
    else {
      if(uartLineIndex < (maxLen - 1)) {
        buffer[uartLineIndex++] = ch;
      }
      else {
        uartLineIndex = 0;
      }
    }
  }

  return 0;
}

char ReadButtonState(unsigned short index) {
  switch(index) {
    case 0: return GPIOA_IDR.B9;
    break;
    case 1: return GPIOA_IDR.B10;
    break;
    case 2: return GPIOC_IDR.B13;
    break;
    case 3: return GPIOC_IDR.B7;
    break;
  }

  return 0;
}

void ApplyLedState(unsigned short index, char state) {
  ledStates[index] = state ? 1 : 0;

  switch(index) {
    case 0: GPIOB_ODR.B6 = ledStates[index];
      break;
    case 1: GPIOB_ODR.B7 = ledStates[index];
      break;
    case 2: GPIOC_ODR.B10 = ledStates[index];
      break;
    case 3: GPIOC_ODR.B11 = ledStates[index];
      break;
  }
}

void SendLedState(unsigned short index, char state) {
  UART4_WriteString("LED");
  UART4_WriteChar('1' + index);
  UART4_WriteChar(':');
  UART4_WriteChar(state ? '1' : '0');
  UART4_WriteString("\r\n");
}

void SendButtonState(unsigned short index, char state) {
  UART4_WriteString("BTN");
  UART4_WriteChar('1' + index);
  UART4_WriteChar(':');
  UART4_WriteChar(state ? '1' : '0');
  UART4_WriteString("\r\n");
}

void SendAllStates() {
  unsigned short i;

  for(i = 0; i < DEVICE_COUNT; i++) {
    SendLedState(i, ledStates[i]);
  }

  for(i = 0; i < DEVICE_COUNT; i++) {
    buttonStates[i] = ReadButtonState(i);
    SendButtonState(i, buttonStates[i]);
  }
}

void ProcessCommand(char *line) {
  unsigned short index;
  char state;

  if((line[0] == 'S') && (line[1] == 'Y') && (line[2] == 'N') && (line[3] == 'C') && (line[4] == 0)) {
    SendAllStates();
    return;
  }

  if((line[0] == 'L') && (line[1] == 'E') && (line[2] == 'D') &&
     (line[3] >= '1') && (line[3] <= '4') &&
     (line[4] == ':') &&
     ((line[5] == '0') || (line[5] == '1')) &&
     (line[6] == 0)) {

    index = line[3] - '1';
    state = line[5] - '0';

    ApplyLedState(index, state);
    SendLedState(index, ledStates[index]);
  }
}