# STM32 + ESP32 Web LED Control

This folder contains a new two-board demo:

- The ESP32 hosts a web page with 4 control buttons and 4 live indicator LEDs.
- The 4 web buttons control the 4 physical LEDs on the STM32.
- The 4 indicator LEDs on the page show the live state of the 4 physical push buttons on the STM32.

## Folder Layout

- `ESP32_Web_Control/ESP32_Web_Control.ino`
- `ESP32_Web_Control/dashboard.html`
- `ESP32_Web_Control/dashboard_html_gz.h`
- `STM32_Web_Control/STM32_Web_Control.c`

## STM32 Pin Map

- `LED1 -> PC10`
- `LED2 -> PC11`
- `LED3 -> PB6`
- `LED4 -> PB7`
- `PUSH1 -> PC7`
- `PUSH2 -> PC13`
- `PUSH3 -> PA9`
- `PUSH4 -> PA10`
- `UART4_TX -> PA0`
- `UART4_RX -> PA1`

## ESP32 Pin Map

- `UART2_RX -> GPIO27`
- `UART2_TX -> GPIO26`

## Board-to-Board Wiring

- `STM32 PA0 (UART4_TX)  -> ESP32 GPIO27 (UART2_RX)`
- `STM32 PA1 (UART4_RX)  <- ESP32 GPIO26 (UART2_TX)`
- `GND <-> GND`

## Wi-Fi Access Point

The ESP32 sketch starts a SoftAP by default:

- `SSID: STM32-ESP32-Control`
- `Password: stm32demo`

After uploading the ESP32 sketch:

1. Connect a phone or laptop to that Wi-Fi network.
2. Open the IP printed in the Arduino Serial Monitor, usually `http://192.168.4.1`.
3. Use the 4 web buttons to toggle the STM32 LEDs.
4. Press any STM32 push button to see the matching web indicator light up.

## UART Protocol

- `LED1:1` turns LED1 on
- `LED1:0` turns LED1 off
- `BTN1:1` means PUSH1 is pressed
- `BTN1:0` means PUSH1 is released
- `SYNC` asks the STM32 to resend all current LED and button states

## Assumptions

- STM32 push buttons are active LOW, matching `PUSH_LEDS.c`.
- STM32 LED outputs are active HIGH.
- Both UART links run at `9600` baud.
- The ESP32 webpage polls the ESP32 locally for fresh state, while the ESP32 and STM32 exchange the state over UART.

## UI Notes

- The readable webpage source is stored in `dashboard.html`.
- The ESP32 sketch serves the precompressed `dashboard_html_gz.h` asset with gzip enabled.
