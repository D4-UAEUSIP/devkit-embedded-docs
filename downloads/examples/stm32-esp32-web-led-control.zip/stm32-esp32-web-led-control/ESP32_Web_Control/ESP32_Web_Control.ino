#include <WiFi.h>
#include <WebServer.h>

#include "dashboard_html_gz.h"

const char* AP_SSID = "STM32-ESP32-Control";
const char* AP_PASSWORD = "stm32demo";

const uint8_t STM32_UART_RX_PIN = 27;
const uint8_t STM32_UART_TX_PIN = 26;
const unsigned long SYNC_RETRY_MS = 2000;

HardwareSerial STM32_UART(2);
WebServer server(80);

bool ledStates[4] = {false, false, false, false};
bool buttonStates[4] = {false, false, false, false};
bool stm32Online = false;

char uartLine[24];
size_t uartLineIndex = 0;
unsigned long lastSyncAttemptMs = 0;

void sendNoCache() {
  server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  server.sendHeader("Pragma", "no-cache");
  server.sendHeader("Expires", "-1");
}

String buildStateJson() {
  String json = "{\"leds\":[";

  for (uint8_t i = 0; i < 4; i++) {
    if (i > 0) {
      json += ",";
    }
    json += ledStates[i] ? "1" : "0";
  }

  json += "],\"buttons\":[";

  for (uint8_t i = 0; i < 4; i++) {
    if (i > 0) {
      json += ",";
    }
    json += buttonStates[i] ? "1" : "0";
  }

  json += "]}";
  return json;
}

void sendStateLine(const char* prefix, uint8_t index, bool state) {
  STM32_UART.print(prefix);
  STM32_UART.print(index);
  STM32_UART.print(':');
  STM32_UART.print(state ? '1' : '0');
  STM32_UART.print("\r\n");
}

void requestSyncFromStm32() {
  STM32_UART.print("SYNC\r\n");
  lastSyncAttemptMs = millis();
}

bool parseStateLine(const char* line, const char* prefix, bool* targetStates) {
  if (line[0] == prefix[0] &&
      line[1] == prefix[1] &&
      line[2] == prefix[2] &&
      line[3] >= '1' &&
      line[3] <= '4' &&
      line[4] == ':' &&
      (line[5] == '0' || line[5] == '1') &&
      line[6] == '\0') {

    targetStates[line[3] - '1'] = (line[5] == '1');
    stm32Online = true;
    return true;
  }

  return false;
}

void processStm32Line(const char* line) {
  if (parseStateLine(line, "LED", ledStates)) {
    return;
  }

  if (parseStateLine(line, "BTN", buttonStates)) {
    return;
  }

  Serial.print("Ignored UART line: ");
  Serial.println(line);
}

void pumpStm32Uart() {
  while (STM32_UART.available()) {
    const char c = static_cast<char>(STM32_UART.read());

    if (c == '\r' || c == '\n') {
      if (uartLineIndex > 0) {
        uartLine[uartLineIndex] = '\0';
        processStm32Line(uartLine);
        uartLineIndex = 0;
      }
    } else if (uartLineIndex < (sizeof(uartLine) - 1)) {
      uartLine[uartLineIndex++] = c;
    } else {
      uartLineIndex = 0;
    }
  }
}

void handleRoot() {
  sendNoCache();
  server.sendHeader("Content-Encoding", "gzip");
  server.sendHeader("Content-Length", String(dashboard_html_gz_len));
  server.sendHeader("Vary", "Accept-Encoding");
  server.send_P(200, "text/html", reinterpret_cast<PGM_P>(dashboard_html_gz), dashboard_html_gz_len);
}

void handleState() {
  sendNoCache();
  server.send(200, "application/json", buildStateJson());
}

void handleLedRequest() {
  if (!server.hasArg("index") || !server.hasArg("state")) {
    sendNoCache();
    server.send(400, "application/json", "{\"error\":\"index and state are required\"}");
    return;
  }

  const int index = server.arg("index").toInt();
  const int requestedState = server.arg("state").toInt();

  if (index < 1 || index > 4 || (requestedState != 0 && requestedState != 1)) {
    sendNoCache();
    server.send(400, "application/json", "{\"error\":\"invalid index or state\"}");
    return;
  }

  sendStateLine("LED", static_cast<uint8_t>(index), requestedState == 1);
  Serial.print("Sent to STM32: LED");
  Serial.print(index);
  Serial.print(':');
  Serial.println(requestedState);

  sendNoCache();
  server.send(200, "application/json", buildStateJson());
}

void handleNotFound() {
  sendNoCache();
  server.send(404, "text/plain", "Not found");
}

void setup() {
  Serial.begin(115200);
  delay(300);

  STM32_UART.begin(9600, SERIAL_8N1, STM32_UART_RX_PIN, STM32_UART_TX_PIN);

  WiFi.mode(WIFI_AP);
  WiFi.setSleep(false);
  WiFi.softAP(AP_SSID, AP_PASSWORD);

  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/state", HTTP_GET, handleState);
  server.on("/api/led", HTTP_POST, handleLedRequest);
  server.onNotFound(handleNotFound);
  server.begin();

  Serial.println();
  Serial.println("ESP32 web control started");
  Serial.print("AP SSID: ");
  Serial.println(AP_SSID);
  Serial.print("AP Password: ");
  Serial.println(AP_PASSWORD);
  Serial.print("Open: http://");
  Serial.println(WiFi.softAPIP());
  Serial.print("Gzipped UI bytes: ");
  Serial.println(dashboard_html_gz_len);

  requestSyncFromStm32();
}

void loop() {
  server.handleClient();
  pumpStm32Uart();

  if (!stm32Online && (millis() - lastSyncAttemptMs >= SYNC_RETRY_MS)) {
    requestSyncFromStm32();
  }
}
