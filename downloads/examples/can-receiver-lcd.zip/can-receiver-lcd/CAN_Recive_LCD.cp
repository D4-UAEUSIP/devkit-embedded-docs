#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN_Recive_LCD.c"
#line 40 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN_Recive_LCD.c"
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;


unsigned long Can_Init_Flags;
unsigned char Can_Rcv_Flags;
unsigned char Rx_Data_Len;
char RxTx_Data[8];
char Msg_Rcvd;
long Rx_ID;


void ByteToDec3(unsigned short value, char *out) {
 out[0] = (value / 100) + '0';
 out[1] = ((value / 10) % 10) + '0';
 out[2] = (value % 10) + '0';
 out[3] = 0;
}

void ShowReceivedValue(unsigned short value) {
 char txt[4];

 ByteToDec3(value, txt);

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "CAN RX ID:777");
 Lcd_Out(2, 1, "DATA0:");
 Lcd_Out(2, 7, txt);
}

void main() {


 GPIO_Digital_Output(&GPIOC_BASE,
 _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
 _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
 _GPIO_PINMASK_8 | _GPIO_PINMASK_9);


 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6 | _GPIO_PINMASK_7);

 GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIOB_ODR &= ~(_GPIO_PINMASK_6 | _GPIO_PINMASK_7);


 Lcd_Init();
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Cmd(_LCD_CURSOR_OFF);
 Lcd_Out(1, 1, "CAN Receiver");
 Lcd_Out(2, 1, "Initializing");
 Delay_ms(1000);


 Can_Init_Flags = 0;
 Can_Rcv_Flags = 0;


 Can_Init_Flags = _CAN_CONFIG_AUTOMATIC_RETRANSMISSION &
 _CAN_CONFIG_RX_FIFO_NOT_LOCKED_ON_OVERRUN &
 _CAN_CONFIG_TIME_TRIGGERED_MODE_DISABLED &
 _CAN_CONFIG_TX_FIFO_PRIORITY_BY_IDINTIFIER &
 _CAN_CONFIG_WAKE_UP;
#line 124 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN_Recive_LCD.c"
 CAN1InitializeAdvanced(1, 5, 4, 4, 1, Can_Init_Flags, &_GPIO_MODULE_CAN1_PB89);


 CAN1SetOperationMode(_CAN_OperatingMode_Initialization);
#line 133 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/CAN_Recive_LCD.c"
 CANSetFilterScale32(0,
 _CAN_FILTER_ENABLED &
 _CAN_FILTER_ID_MASK_MODE &
 _CAN_FILTER_STD_MSG,
 0x777,
 -1);


 CAN1SetOperationMode(_CAN_OperatingMode_Normal);

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Waiting CAN...");
 Lcd_Out(2, 1, "ID 0x777");

 while(1) {
 Msg_Rcvd = CAN1Read(0, &Rx_ID, RxTx_Data, &Rx_Data_Len, &Can_Rcv_Flags);

 if(Msg_Rcvd) {
 if((Rx_ID == 0x777) && (Rx_Data_Len >= 1)) {
 ShowReceivedValue((unsigned short)(unsigned char)RxTx_Data[0]);


 GPIOC_ODR ^= _GPIO_PINMASK_10;
 }
 }
 }
}
