/*
   ------------------------------------------------------------
   STM32F446RE - CAN Receive and LCD Display
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:

   SW19 : 2:ON   1 :off
   VR1: adujest it till  you see the text on LCD

   on Module Board:
   there is 4 DIP Switches Make sure it is in the CAN Side
   
   Function:
     - Receive CAN frame from previous transmitter
     - Expect Standard ID = 0x777
     - Read byte0
     - Display received counter on LCD


   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5

   CAN:
     Example below uses CAN1 on PD0/PD1


   Display:
     line1: "CAN RX ID:777"
     line2: "DATA0:xxx"
*/

// ---------------- LCD connections ----------------
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

// ---------------- CAN globals ----------------
unsigned long Can_Init_Flags;
unsigned char Can_Rcv_Flags;
unsigned char Rx_Data_Len;
char RxTx_Data[8];
char Msg_Rcvd;
long Rx_ID;

// ---------------- helpers ----------------
void ByteToDec3(unsigned short value, char *out) {
  out[0] = (value / 100) + '0';
  out[1] = ((value / 10) % 10) + '0';
  out[2] = (value % 10) + '0';
  out[3] = 0;
}

void ShowReceivedValue(unsigned short value) {
  char txt[4];

  ByteToDec3(value, txt);

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "CAN RX ID:777");
  Lcd_Out(2, 1, "DATA0:");
  Lcd_Out(2, 7, txt);
}

void main() {

  // LCD pins as outputs
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  // Optional LEDs
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIOB_ODR &= ~(_GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  // LCD init
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);
  Lcd_Out(1, 1, "CAN Receiver");
  Lcd_Out(2, 1, "Initializing");
  Delay_ms(1000);

  // Clear flags
  Can_Init_Flags = 0;
  Can_Rcv_Flags  = 0;

  // CAN init flags
  Can_Init_Flags = _CAN_CONFIG_AUTOMATIC_RETRANSMISSION &
                   _CAN_CONFIG_RX_FIFO_NOT_LOCKED_ON_OVERRUN &
                   _CAN_CONFIG_TIME_TRIGGERED_MODE_DISABLED &
                   _CAN_CONFIG_TX_FIFO_PRIORITY_BY_IDINTIFIER &
                   _CAN_CONFIG_WAKE_UP;

  /*
     Initialize CAN1

     These timing parameters are copied from your previous example.
     If bitrate does not match your network, adjust them.

     Example mapping below uses PD0/PD1.
     Change &_GPIO_MODULE_CAN1_PD01 if your hardware uses another CAN1 pin pair.
  */
  CAN1InitializeAdvanced(1, 5, 4, 4, 1, Can_Init_Flags, &_GPIO_MODULE_CAN1_PB89);

  // Set initialization mode
  CAN1SetOperationMode(_CAN_OperatingMode_Initialization);

  /*
     Filter to accept standard ID 0x777
     Using 32-bit filter, mask mode, standard frame
  */
  CANSetFilterScale32(0,
                      _CAN_FILTER_ENABLED &
                      _CAN_FILTER_ID_MASK_MODE &
                      _CAN_FILTER_STD_MSG,
                      0x777,
                      -1);

  // Normal mode
  CAN1SetOperationMode(_CAN_OperatingMode_Normal);

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "Waiting CAN...");
  Lcd_Out(2, 1, "ID 0x777");

  while(1) {
    Msg_Rcvd = CAN1Read(0, &Rx_ID, RxTx_Data, &Rx_Data_Len, &Can_Rcv_Flags);

    if(Msg_Rcvd) {
      if((Rx_ID == 0x777) && (Rx_Data_Len >= 1)) {
        ShowReceivedValue((unsigned short)(unsigned char)RxTx_Data[0]);

        // Optional activity LED blink
        GPIOC_ODR ^= _GPIO_PINMASK_10;
      }
    }
  }
}