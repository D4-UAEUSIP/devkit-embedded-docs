_ByteToDec3:
;CAN_Recive_LCD.c,63 :: 		void ByteToDec3(unsigned short value, char *out) {
; out start address is: 4 (R1)
; value start address is: 0 (R0)
; out end address is: 4 (R1)
; value end address is: 0 (R0)
; value start address is: 0 (R0)
; out start address is: 4 (R1)
;CAN_Recive_LCD.c,64 :: 		out[0] = (value / 100) + '0';
MOVS	R2, #100
UDIV	R2, R0, R2
UXTB	R2, R2
ADDS	R2, #48
STRB	R2, [R1, #0]
;CAN_Recive_LCD.c,65 :: 		out[1] = ((value / 10) % 10) + '0';
ADDS	R5, R1, #1
MOVS	R2, #10
UDIV	R4, R0, R2
UXTB	R4, R4
MOVS	R3, #10
UDIV	R2, R4, R3
MLS	R2, R3, R2, R4
UXTB	R2, R2
ADDS	R2, #48
STRB	R2, [R5, #0]
;CAN_Recive_LCD.c,66 :: 		out[2] = (value % 10) + '0';
ADDS	R4, R1, #2
MOVS	R3, #10
UDIV	R2, R0, R3
MLS	R2, R3, R2, R0
UXTB	R2, R2
; value end address is: 0 (R0)
ADDS	R2, #48
STRB	R2, [R4, #0]
;CAN_Recive_LCD.c,67 :: 		out[3] = 0;
ADDS	R3, R1, #3
; out end address is: 4 (R1)
MOVS	R2, #0
STRB	R2, [R3, #0]
;CAN_Recive_LCD.c,68 :: 		}
L_end_ByteToDec3:
BX	LR
; end of _ByteToDec3
_ShowReceivedValue:
;CAN_Recive_LCD.c,70 :: 		void ShowReceivedValue(unsigned short value) {
; value start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
; value end address is: 0 (R0)
; value start address is: 0 (R0)
;CAN_Recive_LCD.c,73 :: 		ByteToDec3(value, txt);
ADD	R1, SP, #4
; value end address is: 0 (R0)
BL	_ByteToDec3+0
;CAN_Recive_LCD.c,75 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;CAN_Recive_LCD.c,76 :: 		Lcd_Out(1, 1, "CAN RX ID:777");
MOVW	R1, #lo_addr(?lstr1_CAN_Recive_LCD+0)
MOVT	R1, #hi_addr(?lstr1_CAN_Recive_LCD+0)
MOV	R2, R1
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;CAN_Recive_LCD.c,77 :: 		Lcd_Out(2, 1, "DATA0:");
MOVW	R1, #lo_addr(?lstr2_CAN_Recive_LCD+0)
MOVT	R1, #hi_addr(?lstr2_CAN_Recive_LCD+0)
MOV	R2, R1
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;CAN_Recive_LCD.c,78 :: 		Lcd_Out(2, 7, txt);
ADD	R1, SP, #4
MOV	R2, R1
MOVS	R1, #7
MOVS	R0, #2
BL	_Lcd_Out+0
;CAN_Recive_LCD.c,79 :: 		}
L_end_ShowReceivedValue:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _ShowReceivedValue
_main:
;CAN_Recive_LCD.c,81 :: 		void main() {
;CAN_Recive_LCD.c,87 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;CAN_Recive_LCD.c,84 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;CAN_Recive_LCD.c,87 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;CAN_Recive_LCD.c,90 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R1, #3072
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;CAN_Recive_LCD.c,91 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);
MOVW	R1, #192
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;CAN_Recive_LCD.c,93 :: 		GPIOC_ODR &= ~(_GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
LDR	R1, [R0, #0]
MVN	R0, #3072
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
STR	R1, [R0, #0]
;CAN_Recive_LCD.c,94 :: 		GPIOB_ODR &= ~(_GPIO_PINMASK_6  | _GPIO_PINMASK_7);
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
LDR	R1, [R0, #0]
MVN	R0, #192
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
STR	R1, [R0, #0]
;CAN_Recive_LCD.c,97 :: 		Lcd_Init();
BL	_Lcd_Init+0
;CAN_Recive_LCD.c,98 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;CAN_Recive_LCD.c,99 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;CAN_Recive_LCD.c,100 :: 		Lcd_Out(1, 1, "CAN Receiver");
MOVW	R0, #lo_addr(?lstr3_CAN_Recive_LCD+0)
MOVT	R0, #hi_addr(?lstr3_CAN_Recive_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;CAN_Recive_LCD.c,101 :: 		Lcd_Out(2, 1, "Initializing");
MOVW	R0, #lo_addr(?lstr4_CAN_Recive_LCD+0)
MOVT	R0, #hi_addr(?lstr4_CAN_Recive_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;CAN_Recive_LCD.c,102 :: 		Delay_ms(1000);
MOVW	R7, #24915
MOVT	R7, #81
NOP
NOP
L_main0:
SUBS	R7, R7, #1
BNE	L_main0
NOP
NOP
NOP
NOP
;CAN_Recive_LCD.c,105 :: 		Can_Init_Flags = 0;
MOVS	R0, #0
MOVW	R2, #lo_addr(_Can_Init_Flags+0)
MOVT	R2, #hi_addr(_Can_Init_Flags+0)
STR	R0, [R2, #0]
;CAN_Recive_LCD.c,106 :: 		Can_Rcv_Flags  = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_Can_Rcv_Flags+0)
MOVT	R0, #hi_addr(_Can_Rcv_Flags+0)
STRB	R1, [R0, #0]
;CAN_Recive_LCD.c,113 :: 		_CAN_CONFIG_WAKE_UP;
MOV	R0, #-1
STR	R0, [R2, #0]
;CAN_Recive_LCD.c,124 :: 		CAN1InitializeAdvanced(1, 5, 4, 4, 1, Can_Init_Flags, &_GPIO_MODULE_CAN1_PB89);
MOVW	R2, #lo_addr(__GPIO_MODULE_CAN1_PB89+0)
MOVT	R2, #hi_addr(__GPIO_MODULE_CAN1_PB89+0)
MOV	R1, #-1
MOVS	R0, #1
PUSH	(R2)
PUSH	(R1)
PUSH	(R0)
MOVS	R3, #4
MOVS	R2, #4
MOVS	R1, #5
MOVS	R0, #1
BL	_CAN1InitializeAdvanced+0
ADD	SP, SP, #12
;CAN_Recive_LCD.c,127 :: 		CAN1SetOperationMode(_CAN_OperatingMode_Initialization);
MOVS	R0, #0
BL	_CAN1SetOperationMode+0
;CAN_Recive_LCD.c,138 :: 		-1);
MOV	R3, #-1
;CAN_Recive_LCD.c,137 :: 		0x777,
MOVW	R2, #1911
;CAN_Recive_LCD.c,136 :: 		_CAN_FILTER_STD_MSG,
MOVS	R1, #247
;CAN_Recive_LCD.c,133 :: 		CANSetFilterScale32(0,
MOVS	R0, #0
;CAN_Recive_LCD.c,138 :: 		-1);
BL	_CANSetFilterScale32+0
;CAN_Recive_LCD.c,141 :: 		CAN1SetOperationMode(_CAN_OperatingMode_Normal);
MOVS	R0, #1
BL	_CAN1SetOperationMode+0
;CAN_Recive_LCD.c,143 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;CAN_Recive_LCD.c,144 :: 		Lcd_Out(1, 1, "Waiting CAN...");
MOVW	R0, #lo_addr(?lstr5_CAN_Recive_LCD+0)
MOVT	R0, #hi_addr(?lstr5_CAN_Recive_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;CAN_Recive_LCD.c,145 :: 		Lcd_Out(2, 1, "ID 0x777");
MOVW	R0, #lo_addr(?lstr6_CAN_Recive_LCD+0)
MOVT	R0, #hi_addr(?lstr6_CAN_Recive_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;CAN_Recive_LCD.c,147 :: 		while(1) {
L_main2:
;CAN_Recive_LCD.c,148 :: 		Msg_Rcvd = CAN1Read(0, &Rx_ID, RxTx_Data, &Rx_Data_Len, &Can_Rcv_Flags);
MOVW	R0, #lo_addr(_Can_Rcv_Flags+0)
MOVT	R0, #hi_addr(_Can_Rcv_Flags+0)
PUSH	(R0)
MOVW	R3, #lo_addr(_Rx_Data_Len+0)
MOVT	R3, #hi_addr(_Rx_Data_Len+0)
MOVW	R2, #lo_addr(_RxTx_Data+0)
MOVT	R2, #hi_addr(_RxTx_Data+0)
MOVW	R1, #lo_addr(_Rx_ID+0)
MOVT	R1, #hi_addr(_Rx_ID+0)
MOVS	R0, #0
BL	_CAN1Read+0
ADD	SP, SP, #4
MOVW	R1, #lo_addr(_Msg_Rcvd+0)
MOVT	R1, #hi_addr(_Msg_Rcvd+0)
STRB	R0, [R1, #0]
;CAN_Recive_LCD.c,150 :: 		if(Msg_Rcvd) {
CMP	R0, #0
IT	EQ
BEQ	L_main4
;CAN_Recive_LCD.c,151 :: 		if((Rx_ID == 0x777) && (Rx_Data_Len >= 1)) {
MOVW	R0, #lo_addr(_Rx_ID+0)
MOVT	R0, #hi_addr(_Rx_ID+0)
LDR	R1, [R0, #0]
MOVW	R0, #1911
CMP	R1, R0
IT	NE
BNE	L__main10
MOVW	R0, #lo_addr(_Rx_Data_Len+0)
MOVT	R0, #hi_addr(_Rx_Data_Len+0)
LDRB	R0, [R0, #0]
CMP	R0, #1
IT	CC
BCC	L__main9
L__main8:
;CAN_Recive_LCD.c,152 :: 		ShowReceivedValue((unsigned short)(unsigned char)RxTx_Data[0]);
MOVW	R0, #lo_addr(_RxTx_Data+0)
MOVT	R0, #hi_addr(_RxTx_Data+0)
LDRB	R0, [R0, #0]
BL	_ShowReceivedValue+0
;CAN_Recive_LCD.c,155 :: 		GPIOC_ODR ^= _GPIO_PINMASK_10;
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
LDR	R0, [R0, #0]
EOR	R1, R0, #1024
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
STR	R1, [R0, #0]
;CAN_Recive_LCD.c,151 :: 		if((Rx_ID == 0x777) && (Rx_Data_Len >= 1)) {
L__main10:
L__main9:
;CAN_Recive_LCD.c,157 :: 		}
L_main4:
;CAN_Recive_LCD.c,158 :: 		}
IT	AL
BAL	L_main2
;CAN_Recive_LCD.c,159 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
