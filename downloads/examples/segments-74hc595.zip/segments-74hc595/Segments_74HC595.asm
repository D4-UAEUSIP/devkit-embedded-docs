_pulse_srclk:
;Segments_74HC595.c,100 :: 		void pulse_srclk() {
;Segments_74HC595.c,101 :: 		SR_SRCLK = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Segments_74HC595.c,102 :: 		Delay_us(1);
MOVW	R7, #6
MOVT	R7, #0
NOP
NOP
L_pulse_srclk0:
SUBS	R7, R7, #1
BNE	L_pulse_srclk0
NOP
NOP
NOP
;Segments_74HC595.c,103 :: 		SR_SRCLK = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Segments_74HC595.c,104 :: 		Delay_us(1);
MOVW	R7, #6
MOVT	R7, #0
NOP
NOP
L_pulse_srclk2:
SUBS	R7, R7, #1
BNE	L_pulse_srclk2
NOP
NOP
NOP
;Segments_74HC595.c,105 :: 		}
L_end_pulse_srclk:
BX	LR
; end of _pulse_srclk
_pulse_rclk:
;Segments_74HC595.c,111 :: 		void pulse_rclk() {
;Segments_74HC595.c,112 :: 		SR_RCLK = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Segments_74HC595.c,113 :: 		Delay_us(1);
MOVW	R7, #6
MOVT	R7, #0
NOP
NOP
L_pulse_rclk4:
SUBS	R7, R7, #1
BNE	L_pulse_rclk4
NOP
NOP
NOP
;Segments_74HC595.c,114 :: 		SR_RCLK = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Segments_74HC595.c,115 :: 		Delay_us(1);
MOVW	R7, #6
MOVT	R7, #0
NOP
NOP
L_pulse_rclk6:
SUBS	R7, R7, #1
BNE	L_pulse_rclk6
NOP
NOP
NOP
;Segments_74HC595.c,116 :: 		}
L_end_pulse_rclk:
BX	LR
; end of _pulse_rclk
_shift_out_byte:
;Segments_74HC595.c,122 :: 		void shift_out_byte(unsigned char value) {
; value start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; value end address is: 0 (R0)
; value start address is: 0 (R0)
;Segments_74HC595.c,125 :: 		for(i = 0; i < 8; i++) {
; i start address is: 12 (R3)
MOVS	R3, #0
; value end address is: 0 (R0)
; i end address is: 12 (R3)
UXTB	R4, R0
L_shift_out_byte8:
; i start address is: 12 (R3)
; value start address is: 16 (R4)
CMP	R3, #8
IT	CS
BCS	L_shift_out_byte9
;Segments_74HC595.c,126 :: 		if(value & 0x80)
AND	R1, R4, #128
UXTB	R1, R1
CMP	R1, #0
IT	EQ
BEQ	L_shift_out_byte11
;Segments_74HC595.c,127 :: 		SR_SER = 1;
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
_SX	[R1, ByteOffset(GPIOA_ODR+0)]
IT	AL
BAL	L_shift_out_byte12
L_shift_out_byte11:
;Segments_74HC595.c,129 :: 		SR_SER = 0;
MOVS	R2, #0
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOA_ODR+0)
MOVT	R1, #hi_addr(GPIOA_ODR+0)
_SX	[R1, ByteOffset(GPIOA_ODR+0)]
L_shift_out_byte12:
;Segments_74HC595.c,131 :: 		pulse_srclk();
BL	_pulse_srclk+0
;Segments_74HC595.c,132 :: 		value <<= 1;
LSLS	R1, R4, #1
UXTB	R4, R1
;Segments_74HC595.c,125 :: 		for(i = 0; i < 8; i++) {
ADDS	R3, R3, #1
UXTB	R3, R3
;Segments_74HC595.c,133 :: 		}
; value end address is: 16 (R4)
; i end address is: 12 (R3)
IT	AL
BAL	L_shift_out_byte8
L_shift_out_byte9:
;Segments_74HC595.c,134 :: 		}
L_end_shift_out_byte:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _shift_out_byte
_display_raw_4:
;Segments_74HC595.c,154 :: 		void display_raw_4(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
; d4 start address is: 12 (R3)
; d3 start address is: 8 (R2)
; d2 start address is: 4 (R1)
; d1 start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R5, R0
UXTB	R6, R1
UXTB	R8, R2
; d4 end address is: 12 (R3)
; d3 end address is: 8 (R2)
; d2 end address is: 4 (R1)
; d1 end address is: 0 (R0)
; d1 start address is: 20 (R5)
; d2 start address is: 24 (R6)
; d3 start address is: 32 (R8)
; d4 start address is: 12 (R3)
;Segments_74HC595.c,155 :: 		shift_out_byte(d4);
UXTB	R0, R3
; d4 end address is: 12 (R3)
BL	_shift_out_byte+0
;Segments_74HC595.c,156 :: 		shift_out_byte(d3);
UXTB	R0, R8
; d3 end address is: 32 (R8)
BL	_shift_out_byte+0
;Segments_74HC595.c,157 :: 		shift_out_byte(d2);
UXTB	R0, R6
; d2 end address is: 24 (R6)
BL	_shift_out_byte+0
;Segments_74HC595.c,158 :: 		shift_out_byte(d1);
UXTB	R0, R5
; d1 end address is: 20 (R5)
BL	_shift_out_byte+0
;Segments_74HC595.c,159 :: 		pulse_rclk();
BL	_pulse_rclk+0
;Segments_74HC595.c,160 :: 		}
L_end_display_raw_4:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _display_raw_4
_display_digits:
;Segments_74HC595.c,165 :: 		void display_digits(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
; d4 start address is: 12 (R3)
; d3 start address is: 8 (R2)
; d2 start address is: 4 (R1)
; d1 start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; d4 end address is: 12 (R3)
; d3 end address is: 8 (R2)
; d2 end address is: 4 (R1)
; d1 end address is: 0 (R0)
; d1 start address is: 0 (R0)
; d2 start address is: 4 (R1)
; d3 start address is: 8 (R2)
; d4 start address is: 12 (R3)
;Segments_74HC595.c,166 :: 		display_raw_4(seg_code[d1], seg_code[d2], seg_code[d3], seg_code[d4]);
MOVW	R4, #lo_addr(_seg_code+0)
MOVT	R4, #hi_addr(_seg_code+0)
ADDS	R4, R4, R3
; d4 end address is: 12 (R3)
LDRB	R4, [R4, #0]
UXTB	R7, R4
MOVW	R4, #lo_addr(_seg_code+0)
MOVT	R4, #hi_addr(_seg_code+0)
ADDS	R4, R4, R2
; d3 end address is: 8 (R2)
LDRB	R4, [R4, #0]
UXTB	R6, R4
MOVW	R4, #lo_addr(_seg_code+0)
MOVT	R4, #hi_addr(_seg_code+0)
ADDS	R4, R4, R1
; d2 end address is: 4 (R1)
LDRB	R4, [R4, #0]
UXTB	R5, R4
MOVW	R4, #lo_addr(_seg_code+0)
MOVT	R4, #hi_addr(_seg_code+0)
ADDS	R4, R4, R0
; d1 end address is: 0 (R0)
LDRB	R4, [R4, #0]
UXTB	R3, R7
UXTB	R2, R6
UXTB	R1, R5
UXTB	R0, R4
BL	_display_raw_4+0
;Segments_74HC595.c,167 :: 		}
L_end_display_digits:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _display_digits
_display_number:
;Segments_74HC595.c,172 :: 		void display_number(unsigned int value) {
; value start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
; value end address is: 0 (R0)
; value start address is: 0 (R0)
;Segments_74HC595.c,176 :: 		d1 = value / 1000;
MOVW	R1, #1000
UDIV	R6, R0, R1
UXTH	R6, R6
;Segments_74HC595.c,177 :: 		d2 = (value / 100) % 10;
MOVS	R1, #100
UDIV	R2, R0, R1
UXTH	R2, R2
MOVS	R1, #10
UDIV	R5, R2, R1
MLS	R5, R1, R5, R2
UXTH	R5, R5
;Segments_74HC595.c,178 :: 		d3 = (value / 10) % 10;
MOVS	R1, #10
UDIV	R2, R0, R1
UXTH	R2, R2
MOVS	R1, #10
UDIV	R4, R2, R1
MLS	R4, R1, R4, R2
UXTH	R4, R4
;Segments_74HC595.c,179 :: 		d4 = value % 10;
MOVS	R1, #10
UDIV	R3, R0, R1
MLS	R3, R1, R3, R0
UXTH	R3, R3
;Segments_74HC595.c,181 :: 		b1 = seg_code[d1];
UXTB	R2, R6
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
; b1 start address is: 24 (R6)
UXTB	R6, R1
;Segments_74HC595.c,182 :: 		b2 = seg_code[d2];
UXTB	R2, R5
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R5, [R1, #0]
; b2 start address is: 20 (R5)
;Segments_74HC595.c,183 :: 		b3 = seg_code[d3];
UXTB	R2, R4
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
; b3 start address is: 16 (R4)
UXTB	R4, R1
;Segments_74HC595.c,184 :: 		b4 = seg_code[d4];
UXTB	R2, R3
MOVW	R1, #lo_addr(_seg_code+0)
MOVT	R1, #hi_addr(_seg_code+0)
ADDS	R1, R1, R2
LDRB	R1, [R1, #0]
; b4 start address is: 8 (R2)
UXTB	R2, R1
;Segments_74HC595.c,196 :: 		if(value < 1000) b1 = BLANK_DIGIT;
CMP	R0, #1000
IT	CS
BCS	L__display_number28
; b1 end address is: 24 (R6)
; b1 start address is: 12 (R3)
MOVS	R3, #0
; b1 end address is: 12 (R3)
IT	AL
BAL	L_display_number13
L__display_number28:
UXTB	R3, R6
L_display_number13:
;Segments_74HC595.c,197 :: 		if(value < 100)  b2 = BLANK_DIGIT;
; b1 start address is: 12 (R3)
CMP	R0, #100
IT	CS
BCS	L__display_number29
MOVS	R5, #0
; b2 end address is: 20 (R5)
IT	AL
BAL	L_display_number14
L__display_number29:
L_display_number14:
;Segments_74HC595.c,198 :: 		if(value < 10)   b3 = BLANK_DIGIT;
; b2 start address is: 20 (R5)
CMP	R0, #10
IT	CS
BCS	L__display_number30
; value end address is: 0 (R0)
; b3 end address is: 16 (R4)
; b3 start address is: 0 (R0)
MOVS	R0, #0
; b3 end address is: 0 (R0)
IT	AL
BAL	L_display_number15
L__display_number30:
UXTB	R0, R4
L_display_number15:
;Segments_74HC595.c,200 :: 		display_raw_4(b1, b2, b3, b4);
; b3 start address is: 0 (R0)
STRB	R0, [SP, #4]
; b4 end address is: 8 (R2)
UXTB	R1, R5
UXTB	R0, R3
; b3 end address is: 0 (R0)
UXTB	R3, R2
; b2 end address is: 20 (R5)
LDRB	R2, [SP, #4]
; b1 end address is: 12 (R3)
BL	_display_raw_4+0
;Segments_74HC595.c,201 :: 		}
L_end_display_number:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _display_number
_clear_display:
;Segments_74HC595.c,206 :: 		void clear_display() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;Segments_74HC595.c,207 :: 		display_raw_4(0x00, 0x00, 0x00, 0x00);
MOVS	R3, #0
MOVS	R2, #0
MOVS	R1, #0
MOVS	R0, #0
BL	_display_raw_4+0
;Segments_74HC595.c,208 :: 		}
L_end_clear_display:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _clear_display
_main:
;Segments_74HC595.c,210 :: 		void main() {
SUB	SP, SP, #4
;Segments_74HC595.c,217 :: 		GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_8 | _GPIO_PINMASK_14 | _GPIO_PINMASK_15);
MOVW	R1, #49408
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Output+0
;Segments_74HC595.c,222 :: 		SR_SER   = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Segments_74HC595.c,223 :: 		SR_SRCLK = 0;
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Segments_74HC595.c,224 :: 		SR_RCLK  = 0;
MOVW	R0, #lo_addr(GPIOA_ODR+0)
MOVT	R0, #hi_addr(GPIOA_ODR+0)
_SX	[R0, ByteOffset(GPIOA_ODR+0)]
;Segments_74HC595.c,226 :: 		clear_display();
BL	_clear_display+0
;Segments_74HC595.c,228 :: 		while(1) {
L_main16:
;Segments_74HC595.c,237 :: 		for(i = 0; i <= 9; i++) {
MOVS	R0, #0
STRB	R0, [SP, #0]
L_main18:
LDRB	R0, [SP, #0]
CMP	R0, #9
IT	HI
BHI	L_main19
;Segments_74HC595.c,238 :: 		display_digits(i, i, i, i);
LDRB	R3, [SP, #0]
LDRB	R2, [SP, #0]
LDRB	R1, [SP, #0]
LDRB	R0, [SP, #0]
BL	_display_digits+0
;Segments_74HC595.c,239 :: 		Delay_ms(1000);
MOVW	R7, #4606
MOVT	R7, #122
NOP
NOP
L_main21:
SUBS	R7, R7, #1
BNE	L_main21
NOP
NOP
NOP
;Segments_74HC595.c,237 :: 		for(i = 0; i <= 9; i++) {
LDRB	R0, [SP, #0]
ADDS	R0, R0, #1
STRB	R0, [SP, #0]
;Segments_74HC595.c,240 :: 		}
IT	AL
BAL	L_main18
L_main19:
;Segments_74HC595.c,250 :: 		for(count = 0; count <= 9999; count++) {
; count start address is: 36 (R9)
MOVW	R9, #0
; count end address is: 36 (R9)
L_main23:
; count start address is: 36 (R9)
MOVW	R0, #9999
CMP	R9, R0
IT	HI
BHI	L_main24
;Segments_74HC595.c,251 :: 		display_number(count);
UXTH	R0, R9
BL	_display_number+0
;Segments_74HC595.c,252 :: 		Delay_ms(100);
MOVW	R7, #13566
MOVT	R7, #12
NOP
NOP
L_main26:
SUBS	R7, R7, #1
BNE	L_main26
NOP
NOP
NOP
;Segments_74HC595.c,250 :: 		for(count = 0; count <= 9999; count++) {
ADD	R9, R9, #1
UXTH	R9, R9
;Segments_74HC595.c,253 :: 		}
; count end address is: 36 (R9)
IT	AL
BAL	L_main23
L_main24:
;Segments_74HC595.c,254 :: 		}
IT	AL
BAL	L_main16
;Segments_74HC595.c,255 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
