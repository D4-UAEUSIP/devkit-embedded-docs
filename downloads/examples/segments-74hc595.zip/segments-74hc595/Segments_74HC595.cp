#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
#line 84 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
const unsigned char seg_code[10] = {
 0x3F,
 0x06,
 0x5B,
 0x4F,
 0x66,
 0x6D,
 0x7D,
 0x07,
 0x7F,
 0x6F
};
#line 100 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
void pulse_srclk() {
  GPIOA_ODR.B14  = 1;
 Delay_us(1);
  GPIOA_ODR.B14  = 0;
 Delay_us(1);
}
#line 111 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
void pulse_rclk() {
  GPIOA_ODR.B15  = 1;
 Delay_us(1);
  GPIOA_ODR.B15  = 0;
 Delay_us(1);
}
#line 122 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
void shift_out_byte(unsigned char value) {
 unsigned char i;

 for(i = 0; i < 8; i++) {
 if(value & 0x80)
  GPIOA_ODR.B8  = 1;
 else
  GPIOA_ODR.B8  = 0;

 pulse_srclk();
 value <<= 1;
 }
}
#line 154 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
void display_raw_4(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
 shift_out_byte(d4);
 shift_out_byte(d3);
 shift_out_byte(d2);
 shift_out_byte(d1);
 pulse_rclk();
}
#line 165 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
void display_digits(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
 display_raw_4(seg_code[d1], seg_code[d2], seg_code[d3], seg_code[d4]);
}
#line 172 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
void display_number(unsigned int value) {
 unsigned char d1, d2, d3, d4;
 unsigned char b1, b2, b3, b4;

 d1 = value / 1000;
 d2 = (value / 100) % 10;
 d3 = (value / 10) % 10;
 d4 = value % 10;

 b1 = seg_code[d1];
 b2 = seg_code[d2];
 b3 = seg_code[d3];
 b4 = seg_code[d4];
#line 196 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
 if(value < 1000) b1 =  0x00 ;
 if(value < 100) b2 =  0x00 ;
 if(value < 10) b3 =  0x00 ;

 display_raw_4(b1, b2, b3, b4);
}
#line 206 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
void clear_display() {
 display_raw_4(0x00, 0x00, 0x00, 0x00);
}

void main() {
 unsigned char i;
 unsigned int count;
#line 217 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
 GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_8 | _GPIO_PINMASK_14 | _GPIO_PINMASK_15);
#line 222 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
  GPIOA_ODR.B8  = 0;
  GPIOA_ODR.B14  = 0;
  GPIOA_ODR.B15  = 0;

 clear_display();

 while(1) {
#line 237 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
 for(i = 0; i <= 9; i++) {
 display_digits(i, i, i, i);
 Delay_ms(1000);
 }
#line 250 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Segments_74HC595.c"
 for(count = 0; count <= 9999; count++) {
 display_number(count);
 Delay_ms(100);
 }
 }
}
