/*
   ------------------------------------------------------------
   STM32F446RE - 4x Seven Segment Test via SN74HC595
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   SW26 : ON   SV-EN
   SW27:  SRCLK side
   SW15 : SPI-SCK
   SW17 : SER side
   SW3 :  JTAG-DIS side
   VR1: adujest it till  you see the text on LCD
   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   Control pins:
     SER   -> PA8
     SRCLK -> PA14
     RCLK  -> PA15

   Hardware notes:
   ------------------------------------------------------------
   - 4 x SN74HC595 are daisy chained
   - each 74HC595 drives one common-cathode seven segment display
   - display commons are tied to GND
   - therefore segment ON = logic HIGH
   - no multiplexing is needed

   Assumed 74HC595 output mapping:
   ------------------------------------------------------------
     QA -> A
     QB -> B
     QC -> C
     QD -> D
     QE -> E
     QF -> F
     QG -> G
     QH -> DP

   Segment byte format used in this code:
   ------------------------------------------------------------
     bit0 -> A
     bit1 -> B
     bit2 -> C
     bit3 -> D
     bit4 -> E
     bit5 -> F
     bit6 -> G
     bit7 -> DP

   Test sequence:
   ------------------------------------------------------------
   1) show same digit on all displays:
        0000, 1111, 2222 ... 9999
      delay 1 second

   2) count from:
        0000 to 9999
      with leading zero blanking:
           1 shown as "   1"
          12 shown as "  12"
         123 shown as " 123"
      delay 100 ms
*/

#define SR_SER    GPIOA_ODR.B8
#define SR_SRCLK  GPIOA_ODR.B14
#define SR_RCLK   GPIOA_ODR.B15

#define BLANK_DIGIT  0x00

/*
   Segment codes for digits 0..9
   Common cathode display
   Segment ON = 1

   bit order:
     dp g f e d c b a
   but we define values as:
     bit0=a bit1=b bit2=c bit3=d bit4=e bit5=f bit6=g bit7=dp
*/

const unsigned char seg_code[10] = {
  0x3F,   // 0 = a b c d e f
  0x06,   // 1 = b c
  0x5B,   // 2 = a b d e g
  0x4F,   // 3 = a b c d g
  0x66,   // 4 = b c f g
  0x6D,   // 5 = a c d f g
  0x7D,   // 6 = a c d e f g
  0x07,   // 7 = a b c
  0x7F,   // 8 = a b c d e f g
  0x6F    // 9 = a b c d f g
};

/*
   Small clock pulse for SRCLK
*/
void pulse_srclk() {
  SR_SRCLK = 1;
  Delay_us(1);
  SR_SRCLK = 0;
  Delay_us(1);
}

/*
   Small clock pulse for RCLK
   This latches shifted data to outputs
*/
void pulse_rclk() {
  SR_RCLK = 1;
  Delay_us(1);
  SR_RCLK = 0;
  Delay_us(1);
}

/*
   Shift one byte to the 74HC595 chain
   MSB first
*/
void shift_out_byte(unsigned char value) {
  unsigned char i;

  for(i = 0; i < 8; i++) {
    if(value & 0x80)
      SR_SER = 1;
    else
      SR_SER = 0;

    pulse_srclk();
    value <<= 1;
  }
}

/*
   Send 4 bytes to the 4 daisy-chained registers

   IMPORTANT:
   The first shifted byte ends up in the farthest register.
   The last shifted byte ends up in the nearest register.

   This code assumes:
     - register for digit4 is farthest
     - register for digit1 is nearest

   Therefore order is:
     d4, d3, d2, d1

   If the digits appear reversed on hardware,
   change the shift order to:
     d1, d2, d3, d4
*/
void display_raw_4(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
  shift_out_byte(d4);
  shift_out_byte(d3);
  shift_out_byte(d2);
  shift_out_byte(d1);
  pulse_rclk();
}

/*
   Display 4 numeric digits directly
*/
void display_digits(unsigned char d1, unsigned char d2, unsigned char d3, unsigned char d4) {
  display_raw_4(seg_code[d1], seg_code[d2], seg_code[d3], seg_code[d4]);
}

/*
   Display one number 0..9999 with leading zero blanking
*/
void display_number(unsigned int value) {
  unsigned char d1, d2, d3, d4;
  unsigned char b1, b2, b3, b4;

  d1 = value / 1000;
  d2 = (value / 100) % 10;
  d3 = (value / 10) % 10;
  d4 = value % 10;

  b1 = seg_code[d1];
  b2 = seg_code[d2];
  b3 = seg_code[d3];
  b4 = seg_code[d4];

  /*
     Leading zero blanking for test 2
     Example:
       0001 -> "   1"
       0012 -> "  12"
       0123 -> " 123"
       1234 -> "1234"

     If you want 0000 to appear as 0 only, this code already does that.
  */
  if(value < 1000) b1 = BLANK_DIGIT;
  if(value < 100)  b2 = BLANK_DIGIT;
  if(value < 10)   b3 = BLANK_DIGIT;

  display_raw_4(b1, b2, b3, b4);
}

/*
   Optional function to clear all displays
*/
void clear_display() {
  display_raw_4(0x00, 0x00, 0x00, 0x00);
}

void main() {
  unsigned char i;
  unsigned int count;

  /*
     Configure PA8, PA14, PA15 as digital outputs
  */
  GPIO_Digital_Output(&GPIOA_BASE, _GPIO_PINMASK_8 | _GPIO_PINMASK_14 | _GPIO_PINMASK_15);

  /*
     Initial pin states
  */
  SR_SER   = 0;
  SR_SRCLK = 0;
  SR_RCLK  = 0;

  clear_display();

  while(1) {

    /*
       --------------------------------------------------------
       TEST 1
       Show same digit on all displays from 0 to 9
       each for 1 second
       --------------------------------------------------------
    */
    for(i = 0; i <= 9; i++) {
      display_digits(i, i, i, i);
      Delay_ms(1000);
    }

    /*
       --------------------------------------------------------
       TEST 2
       Count from 0000 to 9999
       with leading zero blanking
       update every 100 ms
       --------------------------------------------------------
    */
    for(count = 0; count <= 9999; count++) {
      display_number(count);
      Delay_ms(100);
    }
  }
}