#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/STM_EXTI0.c"




void EXTI0_ISR() iv IVT_INT_EXTI0 ics ICS_AUTO {
 EXTI_PR.B0 = 1;
}

void enter_sleep() {
  (*((volatile unsigned long *)0xE000ED10))  &= ~ 0x00000004 ;
 asm {
 WFI
 }
}

void main() {
 RCC_AHB1ENR.B0 = 1;
 RCC_AHB1ENR.B1 = 1;
 SYSCFGEN_bit = 1;

 GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6);

 SYSCFG_EXTICR1 &= 0xFFF0;
 EXTI_IMR.B0 = 1;
 EXTI_RTSR.B0 = 1;
 EXTI_FTSR.B0 = 0;

 NVIC_IntEnable(IVT_INT_EXTI0);

 while (1) {
  GPIOB_ODR.B6  = 0;
 enter_sleep();
  GPIOB_ODR.B6  = 1;
 Delay_ms(200);
 }
}
