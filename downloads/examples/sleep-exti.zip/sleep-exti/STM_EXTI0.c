#define SCB_SCR_REG (*((volatile unsigned long *)0xE000ED10))
#define SLEEPDEEP   0x00000004
#define LED GPIOB_ODR.B6

void EXTI0_ISR() iv IVT_INT_EXTI0 ics ICS_AUTO {
    EXTI_PR.B0 = 1;   // clear EXTI0 pending
}

void enter_sleep() {
    SCB_SCR_REG &= ~SLEEPDEEP;  // normal sleep, not deep sleep
    asm {
        WFI
    }
}

void main() {
    RCC_AHB1ENR.B0 = 1; // GPIOA
    RCC_AHB1ENR.B1 = 1; // GPIOB
    SYSCFGEN_bit = 1;   // SYSCFG

    GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);    // PA0 input
    GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6);   // PB6 output

    SYSCFG_EXTICR1 &= 0xFFF0;  // EXTI0 -> PA0
    EXTI_IMR.B0 = 1;
    EXTI_RTSR.B0 = 1;          // rising edge
    EXTI_FTSR.B0 = 0;

    NVIC_IntEnable(IVT_INT_EXTI0);

    while (1) {
        LED = 0;
        enter_sleep();         // wakes on PA0 interrupt
        LED = 1;
        Delay_ms(200);
    }
}
