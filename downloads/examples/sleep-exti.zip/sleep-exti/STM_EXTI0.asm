_EXTI0_ISR:
;STM_EXTI0.c,5 :: 		void EXTI0_ISR() iv IVT_INT_EXTI0 ics ICS_AUTO {
;STM_EXTI0.c,6 :: 		EXTI_PR.B0 = 1;   // clear EXTI0 pending
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(EXTI_PR+0)
MOVT	R0, #hi_addr(EXTI_PR+0)
_SX	[R0, ByteOffset(EXTI_PR+0)]
;STM_EXTI0.c,7 :: 		}
L_end_EXTI0_ISR:
BX	LR
; end of _EXTI0_ISR
_enter_sleep:
;STM_EXTI0.c,9 :: 		void enter_sleep() {
;STM_EXTI0.c,10 :: 		SCB_SCR_REG &= ~SLEEPDEEP;  // normal sleep, not deep sleep
MOVW	R0, -536810224
MOVT	R0, 57344
LDR	R1, [R0, #0]
MVN	R0, #4
ANDS	R1, R0
MOVW	R0, -536810224
MOVT	R0, 57344
STR	R1, [R0, #0]
;STM_EXTI0.c,12 :: 		WFI
WFI
;STM_EXTI0.c,14 :: 		}
L_end_enter_sleep:
BX	LR
; end of _enter_sleep
_main:
;STM_EXTI0.c,16 :: 		void main() {
;STM_EXTI0.c,17 :: 		RCC_AHB1ENR.B0 = 1; // GPIOA
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
_SX	[R0, ByteOffset(RCC_AHB1ENR+0)]
;STM_EXTI0.c,18 :: 		RCC_AHB1ENR.B1 = 1; // GPIOB
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
_SX	[R0, ByteOffset(RCC_AHB1ENR+0)]
;STM_EXTI0.c,19 :: 		SYSCFGEN_bit = 1;   // SYSCFG
MOVW	R0, #lo_addr(SYSCFGEN_bit+0)
MOVT	R0, #hi_addr(SYSCFGEN_bit+0)
_SX	[R0, ByteOffset(SYSCFGEN_bit+0)]
;STM_EXTI0.c,21 :: 		GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);    // PA0 input
MOVW	R1, #1
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Input+0
;STM_EXTI0.c,22 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6);   // PB6 output
MOVW	R1, #64
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;STM_EXTI0.c,24 :: 		SYSCFG_EXTICR1 &= 0xFFF0;  // EXTI0 -> PA0
MOVW	R0, #lo_addr(SYSCFG_EXTICR1+0)
MOVT	R0, #hi_addr(SYSCFG_EXTICR1+0)
LDR	R1, [R0, #0]
MOVW	R0, #65520
ANDS	R1, R0
MOVW	R0, #lo_addr(SYSCFG_EXTICR1+0)
MOVT	R0, #hi_addr(SYSCFG_EXTICR1+0)
STR	R1, [R0, #0]
;STM_EXTI0.c,25 :: 		EXTI_IMR.B0 = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(EXTI_IMR+0)
MOVT	R0, #hi_addr(EXTI_IMR+0)
_SX	[R0, ByteOffset(EXTI_IMR+0)]
;STM_EXTI0.c,26 :: 		EXTI_RTSR.B0 = 1;          // rising edge
MOVW	R0, #lo_addr(EXTI_RTSR+0)
MOVT	R0, #hi_addr(EXTI_RTSR+0)
_SX	[R0, ByteOffset(EXTI_RTSR+0)]
;STM_EXTI0.c,27 :: 		EXTI_FTSR.B0 = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(EXTI_FTSR+0)
MOVT	R0, #hi_addr(EXTI_FTSR+0)
_SX	[R0, ByteOffset(EXTI_FTSR+0)]
;STM_EXTI0.c,29 :: 		NVIC_IntEnable(IVT_INT_EXTI0);
MOVW	R0, #22
BL	_NVIC_IntEnable+0
;STM_EXTI0.c,31 :: 		while (1) {
L_main0:
;STM_EXTI0.c,32 :: 		LED = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM_EXTI0.c,33 :: 		enter_sleep();         // wakes on PA0 interrupt
BL	_enter_sleep+0
;STM_EXTI0.c,34 :: 		LED = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM_EXTI0.c,35 :: 		Delay_ms(200);
MOVW	R7, #18089
MOVT	R7, #16
NOP
NOP
L_main2:
SUBS	R7, R7, #1
BNE	L_main2
NOP
NOP
;STM_EXTI0.c,36 :: 		}
IT	AL
BAL	L_main0
;STM_EXTI0.c,37 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
