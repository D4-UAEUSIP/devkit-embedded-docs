#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/STM32_Internal_RTC_LCD_Keypad.c"
#line 69 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/STM32_Internal_RTC_LCD_Keypad.c"
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;


sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;


const char keymap[4][4] = {
 {'1','2','3','A'},
 {'4','5','6','B'},
 {'7','8','9','C'},
 {'*','0','#','D'}
};




char rtc_digits[13];
unsigned short rtc_pos;




void delayMs(unsigned int n) {
 unsigned int i;
 for(; n > 0; n--) {
 for(i = 0; i < 3195; i++) {
 asm nop;
 }
 }
}




unsigned short Parse2Digits(char high, char low) {
 return ((high - '0') * 10) + (low - '0');
}

unsigned short IsLeapYear(unsigned short year) {
 unsigned int full_year = 2000 + year;

 if((full_year % 400) == 0) return 1;
 if((full_year % 100) == 0) return 0;
 if((full_year % 4) == 0) return 1;
 return 0;
}

unsigned short DaysInMonth(unsigned short month, unsigned short year) {
 switch(month) {
 case 1: return 31;
 case 2: return IsLeapYear(year) ? 29 : 28;
 case 3: return 31;
 case 4: return 30;
 case 5: return 31;
 case 6: return 30;
 case 7: return 31;
 case 8: return 31;
 case 9: return 30;
 case 10: return 31;
 case 11: return 30;
 case 12: return 31;
 }

 return 0;
}

unsigned short ValidateDateTime(unsigned short day,
 unsigned short month,
 unsigned short year,
 unsigned short hour,
 unsigned short minute,
 unsigned short second) {
 unsigned short max_day;

 if(month < 1 || month > 12) return 0;

 max_day = DaysInMonth(month, year);
 if(day < 1 || day > max_day) return 0;

 if(hour > 23) return 0;
 if(minute > 59) return 0;
 if(second > 59) return 0;

 return 1;
}

unsigned short CalcWeekDay(unsigned short day,
 unsigned short month,
 unsigned short year) {
 unsigned int y = 2000 + year;
 unsigned short w;

 switch(month) {
 case 1: month = 13; y--; break;
 case 2: month = 14; y--; break;
 default: break;
 }

 w = (unsigned short)((day + ((13 * (month + 1)) / 5) + y + (y / 4) - (y / 100) + (y / 400)) % 7);

 switch(w) {
 case 0: return 6;
 case 1: return 7;
 case 2: return 1;
 case 3: return 2;
 case 4: return 3;
 case 5: return 4;
 default: return 5;
 }
}




void Keypad_AllColumns_Low() {
 GPIOC_ODR.B12 = 0;
 GPIOC_ODR.B1 = 0;
 GPIOB_ODR.B2 = 0;
 GPIOD_ODR.B2 = 0;
}

void Keypad_SelectColumn(unsigned short col) {
 Keypad_AllColumns_Low();

 switch(col) {
 case 0: GPIOC_ODR.B12 = 1; break;
 case 1: GPIOC_ODR.B1 = 1; break;
 case 2: GPIOB_ODR.B2 = 1; break;
 case 3: GPIOD_ODR.B2 = 1; break;
 }
}

unsigned short Keypad_ReadRow() {
 if(GPIOC_IDR.B7 == 1) return 0;
 if(GPIOC_IDR.B13 == 1) return 1;
 if(GPIOA_IDR.B9 == 1) return 2;
 if(GPIOA_IDR.B10 == 1) return 3;

 return 255;
}

char Keypad_GetKey() {
 unsigned short row, col;

 for(col = 0; col < 4; col++) {
 Keypad_SelectColumn(col);
 Delay_ms(1);

 row = Keypad_ReadRow();
 if(row != 255) {
 Keypad_AllColumns_Low();
 return keymap[row][col];
 }
 }

 Keypad_AllColumns_Low();
 return 0;
}

char Keypad_GetKey_Click() {
 char key;

 while(1) {
 key = Keypad_GetKey();

 if(key != 0) {
 Delay_ms(20);

 if(Keypad_GetKey() == key) {
 while(Keypad_GetKey() != 0) {
 Delay_ms(10);
 }
 Delay_ms(20);
 return key;
 }
 }
 }
}




void RTC_WriteProtectOff() {
 RTC_WPR = 0xCA;
 RTC_WPR = 0x53;
}

void RTC_WriteProtectOn() {
 RTC_WPR = 0xFF;
}

void RTC_EnterInitMode() {
 RTC_ISR |= 0x00000080;
 while((RTC_ISR & 0x00000040) == 0) {
 }
}

void RTC_ExitInitMode() {
 RTC_ISR &= ~0x00000080;
}

void RTC_EnableAccess() {
 RCC_APB1ENR |= 0x10000000;
 PWR_CR |= 0x00000100;
}

void RTC_SetDateTime(unsigned short day,
 unsigned short month,
 unsigned short year,
 unsigned short hour,
 unsigned short minute,
 unsigned short second) {
 unsigned short weekday;
 unsigned long tr;
 unsigned long dr;

 weekday = CalcWeekDay(day, month, year);

 tr = 0;
 tr |= ((unsigned long)(hour / 10) << 20);
 tr |= ((unsigned long)(hour % 10) << 16);
 tr |= ((unsigned long)(minute / 10) << 12);
 tr |= ((unsigned long)(minute % 10) << 8);
 tr |= ((unsigned long)(second / 10) << 4);
 tr |= ((unsigned long)(second % 10));

 dr = 0;
 dr |= ((unsigned long)(year / 10) << 20);
 dr |= ((unsigned long)(year % 10) << 16);
 dr |= ((unsigned long)(weekday & 7) << 13);
 dr |= ((unsigned long)(month / 10) << 12);
 dr |= ((unsigned long)(month % 10) << 8);
 dr |= ((unsigned long)(day / 10) << 4);
 dr |= ((unsigned long)(day % 10));

 RTC_EnableAccess();
 RTC_WriteProtectOff();
 RTC_EnterInitMode();

 RTC_TR = tr;
 RTC_DR = dr;
 RTC_BKP0R =  0x32F2 ;

 RTC_ExitInitMode();
 RTC_WriteProtectOn();
}

void RTC_GetDateTime(unsigned short *day,
 unsigned short *month,
 unsigned short *year,
 unsigned short *hour,
 unsigned short *minute,
 unsigned short *second) {
 unsigned long tr;
 unsigned long dr;

 tr = RTC_TR;
 dr = RTC_DR;

 *second = (unsigned short)((((tr >> 4) & 0x7) * 10) + ((tr >> 0) & 0xF));
 *minute = (unsigned short)((((tr >> 12) & 0x7) * 10) + ((tr >> 8) & 0xF));
 *hour = (unsigned short)((((tr >> 20) & 0x3) * 10) + ((tr >> 16) & 0xF));
 *day = (unsigned short)((((dr >> 4) & 0x3) * 10) + ((dr >> 0) & 0xF));
 *month = (unsigned short)((((dr >> 12) & 0x1) * 10) + ((dr >> 8) & 0xF));
 *year = (unsigned short)((((dr >> 20) & 0xF) * 10) + ((dr >> 16) & 0xF));
}

void RTC_Init_LSE() {
 unsigned short rtc_needs_init = 0;

 RTC_EnableAccess();

 RCC_BDCR &= ~0x00000004;
 RCC_BDCR |= 0x00000001;
 while((RCC_BDCR & 0x00000002) == 0) {
 }

 if((RCC_BDCR & 0x00008000) == 0) {
 rtc_needs_init = 1;
 }
 else if((RCC_BDCR & 0x00000300) != 0x00000100) {
 rtc_needs_init = 1;
 }
 else if(RTC_BKP0R !=  0x32F2 ) {
 rtc_needs_init = 1;
 }

 if(rtc_needs_init) {

 RCC_BDCR |= 0x00010000;
 RCC_BDCR &= ~0x00010000;

 RCC_BDCR &= ~0x00000004;
 RCC_BDCR |= 0x00000001;
 while((RCC_BDCR & 0x00000002) == 0) {
 }

 RCC_BDCR &= ~0x00000300;
 RCC_BDCR |= 0x00000100;
 RCC_BDCR |= 0x00008000;

 RTC_WriteProtectOff();
 RTC_EnterInitMode();

 RTC_CR |= 0x00000020;
 RTC_CR &= ~0x00000040;
 RTC_PRER =  0x007F00FF ;
 RTC_TR = 0x00000000;
 RTC_DR = 0x00242101;
 RTC_BKP0R =  0x32F2 ;

 RTC_ExitInitMode();
 RTC_WriteProtectOn();
 }

 RTC_WriteProtectOff();
 RTC_CR |= 0x00000020;
 RTC_CR &= ~0x00000040;
 RTC_WriteProtectOn();
}




void ShowMainMenu() {
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "A:Adjust D:Show");
 Lcd_Out(2, 1, "Select option");
}

void BuildAdjustScreen() {
 char line1[17];
 char line2[17];
 unsigned short i;

 for(i = 0; i < 16; i++) {
 line1[i] = ' ';
 line2[i] = ' ';
 }
 line1[16] = 0;
 line2[16] = 0;

 line1[0] = 'D';
 line1[1] = ':';
 line1[2] = rtc_digits[0] ? rtc_digits[0] : '_';
 line1[3] = rtc_digits[1] ? rtc_digits[1] : '_';
 line1[4] = '/';
 line1[5] = rtc_digits[2] ? rtc_digits[2] : '_';
 line1[6] = rtc_digits[3] ? rtc_digits[3] : '_';
 line1[7] = '/';
 line1[8] = rtc_digits[4] ? rtc_digits[4] : '_';
 line1[9] = rtc_digits[5] ? rtc_digits[5] : '_';

 line2[0] = 'T';
 line2[1] = ':';
 line2[2] = rtc_digits[6] ? rtc_digits[6] : '_';
 line2[3] = rtc_digits[7] ? rtc_digits[7] : '_';
 line2[4] = ':';
 line2[5] = rtc_digits[8] ? rtc_digits[8] : '_';
 line2[6] = rtc_digits[9] ? rtc_digits[9] : '_';
 line2[7] = ':';
 line2[8] = rtc_digits[10] ? rtc_digits[10] : '_';
 line2[9] = rtc_digits[11] ? rtc_digits[11] : '_';

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, line1);
 Lcd_Out(2, 1, line2);
}

void AdjustMode() {
 char key;
 unsigned short day, month, year, hour, minute, second;
 unsigned short i;

 for(i = 0; i < 12; i++) rtc_digits[i] = 0;
 rtc_digits[12] = 0;
 rtc_pos = 0;

 BuildAdjustScreen();

 while(1) {
 key = Keypad_GetKey_Click();

 if((key >= '0') && (key <= '9')) {
 if(rtc_pos < 12) {
 rtc_digits[rtc_pos] = key;
 rtc_pos++;
 BuildAdjustScreen();
 }
 }
 else if(key == '*') {
 if(rtc_pos > 0) {
 rtc_pos--;
 rtc_digits[rtc_pos] = 0;
 BuildAdjustScreen();
 }
 }
 else if(key == 'B') {
 return;
 }
 else if(key == '#') {
 if(rtc_pos == 12) {
 day = Parse2Digits(rtc_digits[0], rtc_digits[1]);
 month = Parse2Digits(rtc_digits[2], rtc_digits[3]);
 year = Parse2Digits(rtc_digits[4], rtc_digits[5]);
 hour = Parse2Digits(rtc_digits[6], rtc_digits[7]);
 minute = Parse2Digits(rtc_digits[8], rtc_digits[9]);
 second = Parse2Digits(rtc_digits[10], rtc_digits[11]);

 if(ValidateDateTime(day, month, year, hour, minute, second)) {
 RTC_SetDateTime(day, month, year, hour, minute, second);

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Saved OK");
 Lcd_Out(2, 1, "B:Back");
 }
 else {
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Invalid DateTime");
 Lcd_Out(2, 1, "B:Back");
 }

 while(1) {
 key = Keypad_GetKey_Click();
 if(key == 'B') return;
 }
 }
 else {
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Need 12 digits");
 Lcd_Out(2, 1, "# retry B back");

 while(1) {
 key = Keypad_GetKey_Click();
 if(key == 'B') return;
 if(key == '#') {
 BuildAdjustScreen();
 break;
 }
 }
 }
 }
 }
}

void DisplayMode() {
 unsigned short day, month, year, hour, minute, second;
 char key;
 char line1[17];
 char line2[17];

 while(1) {
 RTC_GetDateTime(&day, &month, &year, &hour, &minute, &second);

 line1[0] = (day / 10) + '0';
 line1[1] = (day % 10) + '0';
 line1[2] = '/';
 line1[3] = (month / 10) + '0';
 line1[4] = (month % 10) + '0';
 line1[5] = '/';
 line1[6] = (year / 10) + '0';
 line1[7] = (year % 10) + '0';
 line1[8] = 0;

 line2[0] = (hour / 10) + '0';
 line2[1] = (hour % 10) + '0';
 line2[2] = ':';
 line2[3] = (minute / 10) + '0';
 line2[4] = (minute % 10) + '0';
 line2[5] = ':';
 line2[6] = (second / 10) + '0';
 line2[7] = (second % 10) + '0';
 line2[8] = 0;

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, line1);
 Lcd_Out(2, 1, line2);

 key = Keypad_GetKey();
 if(key == 'B') {
 Delay_ms(20);
 if(Keypad_GetKey() == 'B') {
 while(Keypad_GetKey() != 0) Delay_ms(10);
 return;
 }
 }

 Delay_ms(250);
 }
}




void main() {
 char key;

 GPIO_Digital_Output(&GPIOC_BASE,
 _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
 _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
 _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

 GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
 GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);

 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
 GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);

 Keypad_AllColumns_Low();

 Lcd_Init();
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Cmd(_LCD_CURSOR_OFF);

 Lcd_Out(1, 1, "INT RTC SYSTEM");
 Lcd_Out(2, 1, "Initializing...");
 delayMs(1000);

 RTC_Init_LSE();

 while(1) {
 ShowMainMenu();
 key = Keypad_GetKey_Click();

 if(key == 'A') {
 AdjustMode();
 }
 else if(key == 'D') {
 DisplayMode();
 }
 }
}
