_delayMs:
;STM32_Internal_RTC_LCD_Keypad.c,101 :: 		void delayMs(unsigned int n) {
; n start address is: 0 (R0)
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,103 :: 		for(; n > 0; n--) {
L_delayMs0:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs1
;STM32_Internal_RTC_LCD_Keypad.c,104 :: 		for(i = 0; i < 3195; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs3:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
MOVW	R1, #3195
CMP	R2, R1
IT	CS
BCS	L_delayMs4
;STM32_Internal_RTC_LCD_Keypad.c,105 :: 		asm nop;
NOP
;STM32_Internal_RTC_LCD_Keypad.c,104 :: 		for(i = 0; i < 3195; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;STM32_Internal_RTC_LCD_Keypad.c,106 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs3
L_delayMs4:
;STM32_Internal_RTC_LCD_Keypad.c,103 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;STM32_Internal_RTC_LCD_Keypad.c,107 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs0
L_delayMs1:
;STM32_Internal_RTC_LCD_Keypad.c,108 :: 		}
L_end_delayMs:
BX	LR
; end of _delayMs
_Parse2Digits:
;STM32_Internal_RTC_LCD_Keypad.c,113 :: 		unsigned short Parse2Digits(char high, char low) {
; low start address is: 4 (R1)
; high start address is: 0 (R0)
; low end address is: 4 (R1)
; high end address is: 0 (R0)
; high start address is: 0 (R0)
; low start address is: 4 (R1)
;STM32_Internal_RTC_LCD_Keypad.c,114 :: 		return ((high - '0') * 10) + (low - '0');
SUBW	R3, R0, #48
SXTH	R3, R3
; high end address is: 0 (R0)
MOVS	R2, #10
SXTH	R2, R2
MULS	R3, R2, R3
SXTH	R3, R3
SUBW	R2, R1, #48
SXTH	R2, R2
; low end address is: 4 (R1)
ADDS	R2, R3, R2
UXTB	R0, R2
;STM32_Internal_RTC_LCD_Keypad.c,115 :: 		}
L_end_Parse2Digits:
BX	LR
; end of _Parse2Digits
_IsLeapYear:
;STM32_Internal_RTC_LCD_Keypad.c,117 :: 		unsigned short IsLeapYear(unsigned short year) {
; year start address is: 0 (R0)
; year end address is: 0 (R0)
; year start address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,118 :: 		unsigned int full_year = 2000 + year;
ADD	R1, R0, #2000
; year end address is: 0 (R0)
; full_year start address is: 0 (R0)
UXTH	R0, R1
;STM32_Internal_RTC_LCD_Keypad.c,120 :: 		if((full_year % 400) == 0) return 1;
UXTH	R3, R1
MOVW	R2, #400
UDIV	R1, R3, R2
MLS	R1, R2, R1, R3
UXTH	R1, R1
CMP	R1, #0
IT	NE
BNE	L_IsLeapYear6
; full_year end address is: 0 (R0)
MOVS	R0, #1
IT	AL
BAL	L_end_IsLeapYear
L_IsLeapYear6:
;STM32_Internal_RTC_LCD_Keypad.c,121 :: 		if((full_year % 100) == 0) return 0;
; full_year start address is: 0 (R0)
MOVS	R2, #100
UDIV	R1, R0, R2
MLS	R1, R2, R1, R0
UXTH	R1, R1
CMP	R1, #0
IT	NE
BNE	L_IsLeapYear7
; full_year end address is: 0 (R0)
MOVS	R0, #0
IT	AL
BAL	L_end_IsLeapYear
L_IsLeapYear7:
;STM32_Internal_RTC_LCD_Keypad.c,122 :: 		if((full_year % 4) == 0) return 1;
; full_year start address is: 0 (R0)
AND	R1, R0, #3
UXTH	R1, R1
; full_year end address is: 0 (R0)
CMP	R1, #0
IT	NE
BNE	L_IsLeapYear8
MOVS	R0, #1
IT	AL
BAL	L_end_IsLeapYear
L_IsLeapYear8:
;STM32_Internal_RTC_LCD_Keypad.c,123 :: 		return 0;
MOVS	R0, #0
;STM32_Internal_RTC_LCD_Keypad.c,124 :: 		}
L_end_IsLeapYear:
BX	LR
; end of _IsLeapYear
_DaysInMonth:
;STM32_Internal_RTC_LCD_Keypad.c,126 :: 		unsigned short DaysInMonth(unsigned short month, unsigned short year) {
; year start address is: 4 (R1)
; month start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; year end address is: 4 (R1)
; month end address is: 0 (R0)
; month start address is: 0 (R0)
; year start address is: 4 (R1)
;STM32_Internal_RTC_LCD_Keypad.c,127 :: 		switch(month) {
IT	AL
BAL	L_DaysInMonth9
; month end address is: 0 (R0)
; year end address is: 4 (R1)
;STM32_Internal_RTC_LCD_Keypad.c,128 :: 		case 1:  return 31;
L_DaysInMonth11:
MOVS	R0, #31
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,129 :: 		case 2:  return IsLeapYear(year) ? 29 : 28;
L_DaysInMonth12:
; year start address is: 4 (R1)
UXTB	R0, R1
; year end address is: 4 (R1)
BL	_IsLeapYear+0
CMP	R0, #0
IT	EQ
BEQ	L_DaysInMonth13
; ?FLOC___DaysInMonth?T15 start address is: 0 (R0)
MOVS	R0, #29
SXTB	R0, R0
; ?FLOC___DaysInMonth?T15 end address is: 0 (R0)
IT	AL
BAL	L_DaysInMonth14
L_DaysInMonth13:
; ?FLOC___DaysInMonth?T15 start address is: 0 (R0)
MOVS	R0, #28
SXTB	R0, R0
; ?FLOC___DaysInMonth?T15 end address is: 0 (R0)
L_DaysInMonth14:
; ?FLOC___DaysInMonth?T15 start address is: 0 (R0)
UXTB	R0, R0
; ?FLOC___DaysInMonth?T15 end address is: 0 (R0)
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,130 :: 		case 3:  return 31;
L_DaysInMonth15:
MOVS	R0, #31
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,131 :: 		case 4:  return 30;
L_DaysInMonth16:
MOVS	R0, #30
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,132 :: 		case 5:  return 31;
L_DaysInMonth17:
MOVS	R0, #31
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,133 :: 		case 6:  return 30;
L_DaysInMonth18:
MOVS	R0, #30
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,134 :: 		case 7:  return 31;
L_DaysInMonth19:
MOVS	R0, #31
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,135 :: 		case 8:  return 31;
L_DaysInMonth20:
MOVS	R0, #31
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,136 :: 		case 9:  return 30;
L_DaysInMonth21:
MOVS	R0, #30
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,137 :: 		case 10: return 31;
L_DaysInMonth22:
MOVS	R0, #31
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,138 :: 		case 11: return 30;
L_DaysInMonth23:
MOVS	R0, #30
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,139 :: 		case 12: return 31;
L_DaysInMonth24:
MOVS	R0, #31
IT	AL
BAL	L_end_DaysInMonth
;STM32_Internal_RTC_LCD_Keypad.c,140 :: 		}
L_DaysInMonth9:
; year start address is: 4 (R1)
; month start address is: 0 (R0)
CMP	R0, #1
IT	EQ
BEQ	L_DaysInMonth11
CMP	R0, #2
IT	EQ
BEQ	L_DaysInMonth12
; year end address is: 4 (R1)
CMP	R0, #3
IT	EQ
BEQ	L_DaysInMonth15
CMP	R0, #4
IT	EQ
BEQ	L_DaysInMonth16
CMP	R0, #5
IT	EQ
BEQ	L_DaysInMonth17
CMP	R0, #6
IT	EQ
BEQ	L_DaysInMonth18
CMP	R0, #7
IT	EQ
BEQ	L_DaysInMonth19
CMP	R0, #8
IT	EQ
BEQ	L_DaysInMonth20
CMP	R0, #9
IT	EQ
BEQ	L_DaysInMonth21
CMP	R0, #10
IT	EQ
BEQ	L_DaysInMonth22
CMP	R0, #11
IT	EQ
BEQ	L_DaysInMonth23
CMP	R0, #12
IT	EQ
BEQ	L_DaysInMonth24
; month end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,142 :: 		return 0;
MOVS	R0, #0
;STM32_Internal_RTC_LCD_Keypad.c,143 :: 		}
L_end_DaysInMonth:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _DaysInMonth
_ValidateDateTime:
;STM32_Internal_RTC_LCD_Keypad.c,150 :: 		unsigned short second) {
; hour start address is: 12 (R3)
; year start address is: 8 (R2)
; month start address is: 4 (R1)
; day start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R5, R0
UXTB	R6, R3
; hour end address is: 12 (R3)
; year end address is: 8 (R2)
; month end address is: 4 (R1)
; day end address is: 0 (R0)
; day start address is: 20 (R5)
; month start address is: 4 (R1)
; year start address is: 8 (R2)
; hour start address is: 24 (R6)
; minute start address is: 28 (R7)
LDRB	R7, [SP, #4]
; second start address is: 32 (R8)
LDRB	R8, [SP, #8]
;STM32_Internal_RTC_LCD_Keypad.c,153 :: 		if(month < 1 || month > 12) return 0;
CMP	R1, #1
IT	CC
BCC	L__ValidateDateTime162
CMP	R1, #12
IT	HI
BHI	L__ValidateDateTime161
IT	AL
BAL	L_ValidateDateTime27
; day end address is: 20 (R5)
; month end address is: 4 (R1)
; year end address is: 8 (R2)
; hour end address is: 24 (R6)
; minute end address is: 28 (R7)
; second end address is: 32 (R8)
L__ValidateDateTime162:
L__ValidateDateTime161:
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime27:
;STM32_Internal_RTC_LCD_Keypad.c,155 :: 		max_day = DaysInMonth(month, year);
; second start address is: 32 (R8)
; minute start address is: 28 (R7)
; hour start address is: 24 (R6)
; year start address is: 8 (R2)
; month start address is: 4 (R1)
; day start address is: 20 (R5)
UXTB	R0, R1
; year end address is: 8 (R2)
UXTB	R1, R2
; month end address is: 4 (R1)
BL	_DaysInMonth+0
; max_day start address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,156 :: 		if(day < 1 || day > max_day) return 0;
CMP	R5, #1
IT	CC
BCC	L__ValidateDateTime164
CMP	R5, R0
IT	HI
BHI	L__ValidateDateTime163
; day end address is: 20 (R5)
; max_day end address is: 0 (R0)
IT	AL
BAL	L_ValidateDateTime30
; hour end address is: 24 (R6)
; minute end address is: 28 (R7)
; second end address is: 32 (R8)
L__ValidateDateTime164:
L__ValidateDateTime163:
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime30:
;STM32_Internal_RTC_LCD_Keypad.c,158 :: 		if(hour > 23) return 0;
; second start address is: 32 (R8)
; minute start address is: 28 (R7)
; hour start address is: 24 (R6)
CMP	R6, #23
IT	LS
BLS	L_ValidateDateTime31
; hour end address is: 24 (R6)
; minute end address is: 28 (R7)
; second end address is: 32 (R8)
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime31:
;STM32_Internal_RTC_LCD_Keypad.c,159 :: 		if(minute > 59) return 0;
; second start address is: 32 (R8)
; minute start address is: 28 (R7)
CMP	R7, #59
IT	LS
BLS	L_ValidateDateTime32
; minute end address is: 28 (R7)
; second end address is: 32 (R8)
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime32:
;STM32_Internal_RTC_LCD_Keypad.c,160 :: 		if(second > 59) return 0;
; second start address is: 32 (R8)
CMP	R8, #59
IT	LS
BLS	L_ValidateDateTime33
; second end address is: 32 (R8)
MOVS	R0, #0
IT	AL
BAL	L_end_ValidateDateTime
L_ValidateDateTime33:
;STM32_Internal_RTC_LCD_Keypad.c,162 :: 		return 1;
MOVS	R0, #1
;STM32_Internal_RTC_LCD_Keypad.c,163 :: 		}
L_end_ValidateDateTime:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _ValidateDateTime
_CalcWeekDay:
;STM32_Internal_RTC_LCD_Keypad.c,167 :: 		unsigned short year) {
; year start address is: 8 (R2)
; month start address is: 4 (R1)
; day start address is: 0 (R0)
; year end address is: 8 (R2)
; month end address is: 4 (R1)
; day end address is: 0 (R0)
; day start address is: 0 (R0)
; month start address is: 4 (R1)
; year start address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,168 :: 		unsigned int y = 2000 + year;
ADD	R2, R2, #2000
UXTH	R2, R2
; year end address is: 8 (R2)
; y start address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,171 :: 		switch(month) {
IT	AL
BAL	L_CalcWeekDay34
; month end address is: 4 (R1)
;STM32_Internal_RTC_LCD_Keypad.c,172 :: 		case 1:  month = 13; y--; break;
L_CalcWeekDay36:
; month start address is: 4 (R1)
MOVS	R1, #13
SUBS	R2, R2, #1
UXTH	R2, R2
; month end address is: 4 (R1)
IT	AL
BAL	L_CalcWeekDay35
;STM32_Internal_RTC_LCD_Keypad.c,173 :: 		case 2:  month = 14; y--; break;
L_CalcWeekDay37:
; month start address is: 4 (R1)
MOVS	R1, #14
SUBS	R2, R2, #1
UXTH	R2, R2
IT	AL
BAL	L_CalcWeekDay35
;STM32_Internal_RTC_LCD_Keypad.c,174 :: 		default: break;
L_CalcWeekDay38:
IT	AL
BAL	L_CalcWeekDay35
;STM32_Internal_RTC_LCD_Keypad.c,175 :: 		}
L_CalcWeekDay34:
CMP	R1, #1
IT	EQ
BEQ	L_CalcWeekDay36
CMP	R1, #2
IT	EQ
BEQ	L_CalcWeekDay37
IT	AL
BAL	L_CalcWeekDay38
; y end address is: 8 (R2)
; month end address is: 4 (R1)
L_CalcWeekDay35:
;STM32_Internal_RTC_LCD_Keypad.c,177 :: 		w = (unsigned short)((day + ((13 * (month + 1)) / 5) + y + (y / 4) - (y / 100) + (y / 400)) % 7);
; y start address is: 8 (R2)
; month start address is: 4 (R1)
ADDS	R4, R1, #1
SXTH	R4, R4
; month end address is: 4 (R1)
MOVS	R3, #13
SXTH	R3, R3
MULS	R4, R3, R4
SXTH	R4, R4
MOVS	R3, #5
SXTH	R3, R3
SDIV	R3, R4, R3
SXTH	R3, R3
ADDS	R3, R0, R3
SXTH	R3, R3
; day end address is: 0 (R0)
ADDS	R4, R3, R2
UXTH	R4, R4
LSRS	R3, R2, #2
UXTH	R3, R3
ADDS	R4, R4, R3
UXTH	R4, R4
MOVS	R3, #100
UDIV	R3, R2, R3
UXTH	R3, R3
SUB	R4, R4, R3
UXTH	R4, R4
MOVW	R3, #400
UDIV	R3, R2, R3
UXTH	R3, R3
; y end address is: 8 (R2)
ADDS	R5, R4, R3
UXTH	R5, R5
MOVS	R4, #7
UDIV	R3, R5, R4
MLS	R3, R4, R3, R5
; w start address is: 0 (R0)
UXTB	R0, R3
;STM32_Internal_RTC_LCD_Keypad.c,179 :: 		switch(w) {
IT	AL
BAL	L_CalcWeekDay39
; w end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,180 :: 		case 0: return 6; // Saturday
L_CalcWeekDay41:
MOVS	R0, #6
IT	AL
BAL	L_end_CalcWeekDay
;STM32_Internal_RTC_LCD_Keypad.c,181 :: 		case 1: return 7; // Sunday
L_CalcWeekDay42:
MOVS	R0, #7
IT	AL
BAL	L_end_CalcWeekDay
;STM32_Internal_RTC_LCD_Keypad.c,182 :: 		case 2: return 1; // Monday
L_CalcWeekDay43:
MOVS	R0, #1
IT	AL
BAL	L_end_CalcWeekDay
;STM32_Internal_RTC_LCD_Keypad.c,183 :: 		case 3: return 2; // Tuesday
L_CalcWeekDay44:
MOVS	R0, #2
IT	AL
BAL	L_end_CalcWeekDay
;STM32_Internal_RTC_LCD_Keypad.c,184 :: 		case 4: return 3; // Wednesday
L_CalcWeekDay45:
MOVS	R0, #3
IT	AL
BAL	L_end_CalcWeekDay
;STM32_Internal_RTC_LCD_Keypad.c,185 :: 		case 5: return 4; // Thursday
L_CalcWeekDay46:
MOVS	R0, #4
IT	AL
BAL	L_end_CalcWeekDay
;STM32_Internal_RTC_LCD_Keypad.c,186 :: 		default: return 5; // Friday
L_CalcWeekDay47:
MOVS	R0, #5
IT	AL
BAL	L_end_CalcWeekDay
;STM32_Internal_RTC_LCD_Keypad.c,187 :: 		}
L_CalcWeekDay39:
; w start address is: 0 (R0)
CMP	R0, #0
IT	EQ
BEQ	L_CalcWeekDay41
CMP	R0, #1
IT	EQ
BEQ	L_CalcWeekDay42
CMP	R0, #2
IT	EQ
BEQ	L_CalcWeekDay43
CMP	R0, #3
IT	EQ
BEQ	L_CalcWeekDay44
CMP	R0, #4
IT	EQ
BEQ	L_CalcWeekDay45
CMP	R0, #5
IT	EQ
BEQ	L_CalcWeekDay46
; w end address is: 0 (R0)
IT	AL
BAL	L_CalcWeekDay47
;STM32_Internal_RTC_LCD_Keypad.c,188 :: 		}
L_end_CalcWeekDay:
BX	LR
; end of _CalcWeekDay
_Keypad_AllColumns_Low:
;STM32_Internal_RTC_LCD_Keypad.c,193 :: 		void Keypad_AllColumns_Low() {
;STM32_Internal_RTC_LCD_Keypad.c,194 :: 		GPIOC_ODR.B12 = 0;   // C1
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;STM32_Internal_RTC_LCD_Keypad.c,195 :: 		GPIOC_ODR.B1  = 0;   // C2
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;STM32_Internal_RTC_LCD_Keypad.c,196 :: 		GPIOB_ODR.B2  = 0;   // C3
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;STM32_Internal_RTC_LCD_Keypad.c,197 :: 		GPIOD_ODR.B2  = 0;   // C4
MOVW	R0, #lo_addr(GPIOD_ODR+0)
MOVT	R0, #hi_addr(GPIOD_ODR+0)
_SX	[R0, ByteOffset(GPIOD_ODR+0)]
;STM32_Internal_RTC_LCD_Keypad.c,198 :: 		}
L_end_Keypad_AllColumns_Low:
BX	LR
; end of _Keypad_AllColumns_Low
_Keypad_SelectColumn:
;STM32_Internal_RTC_LCD_Keypad.c,200 :: 		void Keypad_SelectColumn(unsigned short col) {
; col start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R2, R0
; col end address is: 0 (R0)
; col start address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,201 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;STM32_Internal_RTC_LCD_Keypad.c,203 :: 		switch(col) {
IT	AL
BAL	L_Keypad_SelectColumn48
; col end address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,204 :: 		case 0: GPIOC_ODR.B12 = 1; break;   // C1
L_Keypad_SelectColumn50:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn49
;STM32_Internal_RTC_LCD_Keypad.c,205 :: 		case 1: GPIOC_ODR.B1  = 1; break;   // C2
L_Keypad_SelectColumn51:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOC_ODR+0)
MOVT	R1, #hi_addr(GPIOC_ODR+0)
_SX	[R1, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn49
;STM32_Internal_RTC_LCD_Keypad.c,206 :: 		case 2: GPIOB_ODR.B2  = 1; break;   // C3
L_Keypad_SelectColumn52:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOB_ODR+0)
MOVT	R1, #hi_addr(GPIOB_ODR+0)
_SX	[R1, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn49
;STM32_Internal_RTC_LCD_Keypad.c,207 :: 		case 3: GPIOD_ODR.B2  = 1; break;   // C4
L_Keypad_SelectColumn53:
MOVS	R2, #1
SXTB	R2, R2
MOVW	R1, #lo_addr(GPIOD_ODR+0)
MOVT	R1, #hi_addr(GPIOD_ODR+0)
_SX	[R1, ByteOffset(GPIOD_ODR+0)]
IT	AL
BAL	L_Keypad_SelectColumn49
;STM32_Internal_RTC_LCD_Keypad.c,208 :: 		}
L_Keypad_SelectColumn48:
; col start address is: 8 (R2)
CMP	R2, #0
IT	EQ
BEQ	L_Keypad_SelectColumn50
CMP	R2, #1
IT	EQ
BEQ	L_Keypad_SelectColumn51
CMP	R2, #2
IT	EQ
BEQ	L_Keypad_SelectColumn52
CMP	R2, #3
IT	EQ
BEQ	L_Keypad_SelectColumn53
; col end address is: 8 (R2)
L_Keypad_SelectColumn49:
;STM32_Internal_RTC_LCD_Keypad.c,209 :: 		}
L_end_Keypad_SelectColumn:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_SelectColumn
_Keypad_ReadRow:
;STM32_Internal_RTC_LCD_Keypad.c,211 :: 		unsigned short Keypad_ReadRow() {
;STM32_Internal_RTC_LCD_Keypad.c,212 :: 		if(GPIOC_IDR.B7  == 1) return 0;   // R1
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow54
MOVS	R0, #0
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow54:
;STM32_Internal_RTC_LCD_Keypad.c,213 :: 		if(GPIOC_IDR.B13 == 1) return 1;   // R2
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow55
MOVS	R0, #1
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow55:
;STM32_Internal_RTC_LCD_Keypad.c,214 :: 		if(GPIOA_IDR.B9  == 1) return 2;   // R3
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow56
MOVS	R0, #2
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow56:
;STM32_Internal_RTC_LCD_Keypad.c,215 :: 		if(GPIOA_IDR.B10 == 1) return 3;   // R4
MOVW	R0, #lo_addr(GPIOA_IDR+0)
MOVT	R0, #hi_addr(GPIOA_IDR+0)
_LX	[R0, ByteOffset(GPIOA_IDR+0)]
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_ReadRow57
MOVS	R0, #3
IT	AL
BAL	L_end_Keypad_ReadRow
L_Keypad_ReadRow57:
;STM32_Internal_RTC_LCD_Keypad.c,217 :: 		return 255;
MOVS	R0, #255
;STM32_Internal_RTC_LCD_Keypad.c,218 :: 		}
L_end_Keypad_ReadRow:
BX	LR
; end of _Keypad_ReadRow
_Keypad_GetKey:
;STM32_Internal_RTC_LCD_Keypad.c,220 :: 		char Keypad_GetKey() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;STM32_Internal_RTC_LCD_Keypad.c,223 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
MOVS	R3, #0
; col end address is: 12 (R3)
L_Keypad_GetKey58:
; col start address is: 12 (R3)
CMP	R3, #4
IT	CS
BCS	L_Keypad_GetKey59
;STM32_Internal_RTC_LCD_Keypad.c,224 :: 		Keypad_SelectColumn(col);
UXTB	R0, R3
BL	_Keypad_SelectColumn+0
;STM32_Internal_RTC_LCD_Keypad.c,225 :: 		Delay_ms(1);
MOVW	R7, #5331
MOVT	R7, #0
NOP
NOP
L_Keypad_GetKey61:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey61
NOP
NOP
NOP
NOP
;STM32_Internal_RTC_LCD_Keypad.c,227 :: 		row = Keypad_ReadRow();
BL	_Keypad_ReadRow+0
; row start address is: 8 (R2)
UXTB	R2, R0
;STM32_Internal_RTC_LCD_Keypad.c,228 :: 		if(row != 255) {
CMP	R0, #255
IT	EQ
BEQ	L_Keypad_GetKey63
;STM32_Internal_RTC_LCD_Keypad.c,229 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;STM32_Internal_RTC_LCD_Keypad.c,230 :: 		return keymap[row][col];
LSLS	R1, R2, #2
; row end address is: 8 (R2)
MOVW	R0, #lo_addr(_keymap+0)
MOVT	R0, #hi_addr(_keymap+0)
ADDS	R0, R0, R1
ADDS	R0, R0, R3
; col end address is: 12 (R3)
LDRB	R0, [R0, #0]
IT	AL
BAL	L_end_Keypad_GetKey
;STM32_Internal_RTC_LCD_Keypad.c,231 :: 		}
L_Keypad_GetKey63:
;STM32_Internal_RTC_LCD_Keypad.c,223 :: 		for(col = 0; col < 4; col++) {
; col start address is: 12 (R3)
ADDS	R3, R3, #1
UXTB	R3, R3
;STM32_Internal_RTC_LCD_Keypad.c,232 :: 		}
; col end address is: 12 (R3)
IT	AL
BAL	L_Keypad_GetKey58
L_Keypad_GetKey59:
;STM32_Internal_RTC_LCD_Keypad.c,234 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;STM32_Internal_RTC_LCD_Keypad.c,235 :: 		return 0;
MOVS	R0, #0
;STM32_Internal_RTC_LCD_Keypad.c,236 :: 		}
L_end_Keypad_GetKey:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_GetKey
_Keypad_GetKey_Click:
;STM32_Internal_RTC_LCD_Keypad.c,238 :: 		char Keypad_GetKey_Click() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;STM32_Internal_RTC_LCD_Keypad.c,241 :: 		while(1) {
L_Keypad_GetKey_Click64:
;STM32_Internal_RTC_LCD_Keypad.c,242 :: 		key = Keypad_GetKey();
BL	_Keypad_GetKey+0
; key start address is: 16 (R4)
UXTB	R4, R0
;STM32_Internal_RTC_LCD_Keypad.c,244 :: 		if(key != 0) {
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_GetKey_Click66
;STM32_Internal_RTC_LCD_Keypad.c,245 :: 		Delay_ms(20);
MOVW	R7, #41129
MOVT	R7, #1
NOP
NOP
L_Keypad_GetKey_Click67:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click67
NOP
NOP
;STM32_Internal_RTC_LCD_Keypad.c,247 :: 		if(Keypad_GetKey() == key) {
BL	_Keypad_GetKey+0
CMP	R0, R4
IT	NE
BNE	L_Keypad_GetKey_Click69
; key end address is: 16 (R4)
;STM32_Internal_RTC_LCD_Keypad.c,248 :: 		while(Keypad_GetKey() != 0) {
L_Keypad_GetKey_Click70:
; key start address is: 16 (R4)
BL	_Keypad_GetKey+0
CMP	R0, #0
IT	EQ
BEQ	L_Keypad_GetKey_Click71
;STM32_Internal_RTC_LCD_Keypad.c,249 :: 		Delay_ms(10);
MOVW	R7, #53331
MOVT	R7, #0
NOP
NOP
L_Keypad_GetKey_Click72:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click72
NOP
NOP
NOP
NOP
;STM32_Internal_RTC_LCD_Keypad.c,250 :: 		}
IT	AL
BAL	L_Keypad_GetKey_Click70
L_Keypad_GetKey_Click71:
;STM32_Internal_RTC_LCD_Keypad.c,251 :: 		Delay_ms(20);
MOVW	R7, #41129
MOVT	R7, #1
NOP
NOP
L_Keypad_GetKey_Click74:
SUBS	R7, R7, #1
BNE	L_Keypad_GetKey_Click74
NOP
NOP
;STM32_Internal_RTC_LCD_Keypad.c,252 :: 		return key;
UXTB	R0, R4
; key end address is: 16 (R4)
IT	AL
BAL	L_end_Keypad_GetKey_Click
;STM32_Internal_RTC_LCD_Keypad.c,253 :: 		}
L_Keypad_GetKey_Click69:
;STM32_Internal_RTC_LCD_Keypad.c,254 :: 		}
L_Keypad_GetKey_Click66:
;STM32_Internal_RTC_LCD_Keypad.c,255 :: 		}
IT	AL
BAL	L_Keypad_GetKey_Click64
;STM32_Internal_RTC_LCD_Keypad.c,256 :: 		}
L_end_Keypad_GetKey_Click:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _Keypad_GetKey_Click
_RTC_WriteProtectOff:
;STM32_Internal_RTC_LCD_Keypad.c,261 :: 		void RTC_WriteProtectOff() {
;STM32_Internal_RTC_LCD_Keypad.c,262 :: 		RTC_WPR = 0xCA;
MOVS	R1, #202
MOVW	R0, #lo_addr(RTC_WPR+0)
MOVT	R0, #hi_addr(RTC_WPR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,263 :: 		RTC_WPR = 0x53;
MOVS	R1, #83
MOVW	R0, #lo_addr(RTC_WPR+0)
MOVT	R0, #hi_addr(RTC_WPR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,264 :: 		}
L_end_RTC_WriteProtectOff:
BX	LR
; end of _RTC_WriteProtectOff
_RTC_WriteProtectOn:
;STM32_Internal_RTC_LCD_Keypad.c,266 :: 		void RTC_WriteProtectOn() {
;STM32_Internal_RTC_LCD_Keypad.c,267 :: 		RTC_WPR = 0xFF;
MOVS	R1, #255
MOVW	R0, #lo_addr(RTC_WPR+0)
MOVT	R0, #hi_addr(RTC_WPR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,268 :: 		}
L_end_RTC_WriteProtectOn:
BX	LR
; end of _RTC_WriteProtectOn
_RTC_EnterInitMode:
;STM32_Internal_RTC_LCD_Keypad.c,270 :: 		void RTC_EnterInitMode() {
;STM32_Internal_RTC_LCD_Keypad.c,271 :: 		RTC_ISR |= 0x00000080;            // INIT
MOVW	R0, #lo_addr(RTC_ISR+0)
MOVT	R0, #hi_addr(RTC_ISR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #128
MOVW	R0, #lo_addr(RTC_ISR+0)
MOVT	R0, #hi_addr(RTC_ISR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,272 :: 		while((RTC_ISR & 0x00000040) == 0) {
L_RTC_EnterInitMode76:
MOVW	R0, #lo_addr(RTC_ISR+0)
MOVT	R0, #hi_addr(RTC_ISR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #64
CMP	R0, #0
IT	NE
BNE	L_RTC_EnterInitMode77
;STM32_Internal_RTC_LCD_Keypad.c,273 :: 		}
IT	AL
BAL	L_RTC_EnterInitMode76
L_RTC_EnterInitMode77:
;STM32_Internal_RTC_LCD_Keypad.c,274 :: 		}
L_end_RTC_EnterInitMode:
BX	LR
; end of _RTC_EnterInitMode
_RTC_ExitInitMode:
;STM32_Internal_RTC_LCD_Keypad.c,276 :: 		void RTC_ExitInitMode() {
;STM32_Internal_RTC_LCD_Keypad.c,277 :: 		RTC_ISR &= ~0x00000080;           // clear INIT
MOVW	R0, #lo_addr(RTC_ISR+0)
MOVT	R0, #hi_addr(RTC_ISR+0)
LDR	R0, [R0, #0]
AND	R1, R0, #127
MOVW	R0, #lo_addr(RTC_ISR+0)
MOVT	R0, #hi_addr(RTC_ISR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,278 :: 		}
L_end_RTC_ExitInitMode:
BX	LR
; end of _RTC_ExitInitMode
_RTC_EnableAccess:
;STM32_Internal_RTC_LCD_Keypad.c,280 :: 		void RTC_EnableAccess() {
;STM32_Internal_RTC_LCD_Keypad.c,281 :: 		RCC_APB1ENR |= 0x10000000;        // PWR clock enable
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #268435456
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,282 :: 		PWR_CR |= 0x00000100;             // DBP: backup domain write enable
MOVW	R0, #lo_addr(PWR_CR+0)
MOVT	R0, #hi_addr(PWR_CR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #256
MOVW	R0, #lo_addr(PWR_CR+0)
MOVT	R0, #hi_addr(PWR_CR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,283 :: 		}
L_end_RTC_EnableAccess:
BX	LR
; end of _RTC_EnableAccess
_RTC_SetDateTime:
;STM32_Internal_RTC_LCD_Keypad.c,290 :: 		unsigned short second) {
; hour start address is: 12 (R3)
; year start address is: 8 (R2)
; month start address is: 4 (R1)
; day start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R7, R0
UXTB	R8, R1
UXTB	R9, R2
UXTB	R12, R3
; hour end address is: 12 (R3)
; year end address is: 8 (R2)
; month end address is: 4 (R1)
; day end address is: 0 (R0)
; day start address is: 28 (R7)
; month start address is: 32 (R8)
; year start address is: 36 (R9)
; hour start address is: 48 (R12)
; minute start address is: 40 (R10)
LDRB	R10, [SP, #4]
; second start address is: 44 (R11)
LDRB	R11, [SP, #8]
;STM32_Internal_RTC_LCD_Keypad.c,295 :: 		weekday = CalcWeekDay(day, month, year);
UXTB	R2, R9
UXTB	R1, R8
UXTB	R0, R7
BL	_CalcWeekDay+0
;STM32_Internal_RTC_LCD_Keypad.c,298 :: 		tr |= ((unsigned long)(hour / 10)   << 20);
MOVS	R4, #10
UDIV	R4, R12, R4
UXTB	R4, R4
LSLS	R6, R4, #20
;STM32_Internal_RTC_LCD_Keypad.c,299 :: 		tr |= ((unsigned long)(hour % 10)   << 16);
MOVS	R5, #10
UDIV	R4, R12, R5
MLS	R4, R5, R4, R12
UXTB	R4, R4
; hour end address is: 48 (R12)
LSLS	R4, R4, #16
ORR	R5, R6, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,300 :: 		tr |= ((unsigned long)(minute / 10) << 12);
MOVS	R4, #10
UDIV	R4, R10, R4
UXTB	R4, R4
LSLS	R4, R4, #12
ORR	R6, R5, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,301 :: 		tr |= ((unsigned long)(minute % 10) << 8);
MOVS	R5, #10
UDIV	R4, R10, R5
MLS	R4, R5, R4, R10
UXTB	R4, R4
; minute end address is: 40 (R10)
LSLS	R4, R4, #8
ORR	R5, R6, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,302 :: 		tr |= ((unsigned long)(second / 10) << 4);
MOVS	R4, #10
UDIV	R4, R11, R4
UXTB	R4, R4
LSLS	R4, R4, #4
ORR	R6, R5, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,303 :: 		tr |= ((unsigned long)(second % 10));
MOVS	R5, #10
UDIV	R4, R11, R5
MLS	R4, R5, R4, R11
UXTB	R4, R4
; second end address is: 44 (R11)
ORR	R4, R6, R4, LSL #0
; tr start address is: 8 (R2)
MOV	R2, R4
;STM32_Internal_RTC_LCD_Keypad.c,306 :: 		dr |= ((unsigned long)(year / 10)   << 20);
MOVS	R4, #10
UDIV	R4, R9, R4
UXTB	R4, R4
LSLS	R6, R4, #20
;STM32_Internal_RTC_LCD_Keypad.c,307 :: 		dr |= ((unsigned long)(year % 10)   << 16);
MOVS	R5, #10
UDIV	R4, R9, R5
MLS	R4, R5, R4, R9
UXTB	R4, R4
; year end address is: 36 (R9)
LSLS	R4, R4, #16
ORR	R5, R6, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,308 :: 		dr |= ((unsigned long)(weekday & 7) << 13);
AND	R4, R0, #7
UXTB	R4, R4
LSLS	R4, R4, #13
ORRS	R5, R4
;STM32_Internal_RTC_LCD_Keypad.c,309 :: 		dr |= ((unsigned long)(month / 10)  << 12);
MOVS	R4, #10
UDIV	R4, R8, R4
UXTB	R4, R4
LSLS	R4, R4, #12
ORR	R6, R5, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,310 :: 		dr |= ((unsigned long)(month % 10)  << 8);
MOVS	R5, #10
UDIV	R4, R8, R5
MLS	R4, R5, R4, R8
UXTB	R4, R4
; month end address is: 32 (R8)
LSLS	R4, R4, #8
ORR	R5, R6, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,311 :: 		dr |= ((unsigned long)(day / 10)    << 4);
MOVS	R4, #10
UDIV	R4, R7, R4
UXTB	R4, R4
LSLS	R4, R4, #4
ORR	R6, R5, R4, LSL #0
;STM32_Internal_RTC_LCD_Keypad.c,312 :: 		dr |= ((unsigned long)(day % 10));
MOVS	R5, #10
UDIV	R4, R7, R5
MLS	R4, R5, R4, R7
UXTB	R4, R4
; day end address is: 28 (R7)
ORR	R4, R6, R4, LSL #0
; dr start address is: 12 (R3)
MOV	R3, R4
;STM32_Internal_RTC_LCD_Keypad.c,314 :: 		RTC_EnableAccess();
BL	_RTC_EnableAccess+0
;STM32_Internal_RTC_LCD_Keypad.c,315 :: 		RTC_WriteProtectOff();
BL	_RTC_WriteProtectOff+0
;STM32_Internal_RTC_LCD_Keypad.c,316 :: 		RTC_EnterInitMode();
BL	_RTC_EnterInitMode+0
;STM32_Internal_RTC_LCD_Keypad.c,318 :: 		RTC_TR = tr;
MOVW	R4, #lo_addr(RTC_TR+0)
MOVT	R4, #hi_addr(RTC_TR+0)
STR	R2, [R4, #0]
; tr end address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,319 :: 		RTC_DR = dr;
MOVW	R4, #lo_addr(RTC_DR+0)
MOVT	R4, #hi_addr(RTC_DR+0)
STR	R3, [R4, #0]
; dr end address is: 12 (R3)
;STM32_Internal_RTC_LCD_Keypad.c,320 :: 		RTC_BKP0R = RTC_MAGIC;
MOVW	R5, #13042
MOVW	R4, #lo_addr(RTC_BKP0R+0)
MOVT	R4, #hi_addr(RTC_BKP0R+0)
STR	R5, [R4, #0]
;STM32_Internal_RTC_LCD_Keypad.c,322 :: 		RTC_ExitInitMode();
BL	_RTC_ExitInitMode+0
;STM32_Internal_RTC_LCD_Keypad.c,323 :: 		RTC_WriteProtectOn();
BL	_RTC_WriteProtectOn+0
;STM32_Internal_RTC_LCD_Keypad.c,324 :: 		}
L_end_RTC_SetDateTime:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _RTC_SetDateTime
_RTC_GetDateTime:
;STM32_Internal_RTC_LCD_Keypad.c,331 :: 		unsigned short *second) {
; hour start address is: 12 (R3)
; year start address is: 8 (R2)
; month start address is: 4 (R1)
; day start address is: 0 (R0)
; hour end address is: 12 (R3)
; year end address is: 8 (R2)
; month end address is: 4 (R1)
; day end address is: 0 (R0)
; day start address is: 0 (R0)
; month start address is: 4 (R1)
; year start address is: 8 (R2)
; hour start address is: 12 (R3)
; minute start address is: 24 (R6)
LDR	R6, [SP, #0]
; second start address is: 28 (R7)
LDR	R7, [SP, #4]
;STM32_Internal_RTC_LCD_Keypad.c,335 :: 		tr = RTC_TR;
MOVW	R4, #lo_addr(RTC_TR+0)
MOVT	R4, #hi_addr(RTC_TR+0)
; tr start address is: 32 (R8)
LDR	R8, [R4, #0]
;STM32_Internal_RTC_LCD_Keypad.c,336 :: 		dr = RTC_DR;
MOVW	R4, #lo_addr(RTC_DR+0)
MOVT	R4, #hi_addr(RTC_DR+0)
; dr start address is: 36 (R9)
LDR	R9, [R4, #0]
;STM32_Internal_RTC_LCD_Keypad.c,338 :: 		*second = (unsigned short)((((tr >> 4)  & 0x7) * 10) + ((tr >> 0)  & 0xF));
LSR	R4, R8, #4
AND	R5, R4, #7
MOVS	R4, #10
MULS	R5, R4, R5
AND	R4, R8, #15
ADDS	R4, R5, R4
UXTB	R4, R4
STRB	R4, [R7, #0]
; second end address is: 28 (R7)
;STM32_Internal_RTC_LCD_Keypad.c,339 :: 		*minute = (unsigned short)((((tr >> 12) & 0x7) * 10) + ((tr >> 8)  & 0xF));
LSR	R4, R8, #12
AND	R5, R4, #7
MOVS	R4, #10
MULS	R5, R4, R5
LSR	R4, R8, #8
AND	R4, R4, #15
ADDS	R4, R5, R4
UXTB	R4, R4
STRB	R4, [R6, #0]
; minute end address is: 24 (R6)
;STM32_Internal_RTC_LCD_Keypad.c,340 :: 		*hour   = (unsigned short)((((tr >> 20) & 0x3) * 10) + ((tr >> 16) & 0xF));
LSR	R4, R8, #20
AND	R5, R4, #3
MOVS	R4, #10
MULS	R5, R4, R5
LSR	R4, R8, #16
; tr end address is: 32 (R8)
AND	R4, R4, #15
ADDS	R4, R5, R4
UXTB	R4, R4
STRB	R4, [R3, #0]
; hour end address is: 12 (R3)
;STM32_Internal_RTC_LCD_Keypad.c,341 :: 		*day    = (unsigned short)((((dr >> 4)  & 0x3) * 10) + ((dr >> 0)  & 0xF));
LSR	R4, R9, #4
AND	R5, R4, #3
MOVS	R4, #10
MULS	R5, R4, R5
AND	R4, R9, #15
ADDS	R4, R5, R4
UXTB	R4, R4
STRB	R4, [R0, #0]
; day end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,342 :: 		*month  = (unsigned short)((((dr >> 12) & 0x1) * 10) + ((dr >> 8)  & 0xF));
LSR	R4, R9, #12
AND	R5, R4, #1
MOVS	R4, #10
MULS	R5, R4, R5
LSR	R4, R9, #8
AND	R4, R4, #15
ADDS	R4, R5, R4
UXTB	R4, R4
STRB	R4, [R1, #0]
; month end address is: 4 (R1)
;STM32_Internal_RTC_LCD_Keypad.c,343 :: 		*year   = (unsigned short)((((dr >> 20) & 0xF) * 10) + ((dr >> 16) & 0xF));
LSR	R4, R9, #20
AND	R5, R4, #15
MOVS	R4, #10
MULS	R5, R4, R5
LSR	R4, R9, #16
; dr end address is: 36 (R9)
AND	R4, R4, #15
ADDS	R4, R5, R4
UXTB	R4, R4
STRB	R4, [R2, #0]
; year end address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,344 :: 		}
L_end_RTC_GetDateTime:
BX	LR
; end of _RTC_GetDateTime
_RTC_Init_LSE:
;STM32_Internal_RTC_LCD_Keypad.c,346 :: 		void RTC_Init_LSE() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;STM32_Internal_RTC_LCD_Keypad.c,347 :: 		unsigned short rtc_needs_init = 0;
; rtc_needs_init start address is: 8 (R2)
MOVS	R2, #0
;STM32_Internal_RTC_LCD_Keypad.c,349 :: 		RTC_EnableAccess();
BL	_RTC_EnableAccess+0
;STM32_Internal_RTC_LCD_Keypad.c,351 :: 		RCC_BDCR &= ~0x00000004;          // LSEBYP = 0, use crystal
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R1, [R0, #0]
MVN	R0, #4
ANDS	R1, R0
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,352 :: 		RCC_BDCR |= 0x00000001;           // LSEON
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
; rtc_needs_init end address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,353 :: 		while((RCC_BDCR & 0x00000002) == 0) {
L_RTC_Init_LSE78:
; rtc_needs_init start address is: 8 (R2)
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #2
CMP	R0, #0
IT	NE
BNE	L_RTC_Init_LSE79
;STM32_Internal_RTC_LCD_Keypad.c,354 :: 		}
IT	AL
BAL	L_RTC_Init_LSE78
L_RTC_Init_LSE79:
;STM32_Internal_RTC_LCD_Keypad.c,356 :: 		if((RCC_BDCR & 0x00008000) == 0) {
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #32768
CMP	R0, #0
IT	NE
BNE	L_RTC_Init_LSE80
; rtc_needs_init end address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,357 :: 		rtc_needs_init = 1;
; rtc_needs_init start address is: 0 (R0)
MOVS	R0, #1
;STM32_Internal_RTC_LCD_Keypad.c,358 :: 		}
; rtc_needs_init end address is: 0 (R0)
IT	AL
BAL	L_RTC_Init_LSE81
L_RTC_Init_LSE80:
;STM32_Internal_RTC_LCD_Keypad.c,359 :: 		else if((RCC_BDCR & 0x00000300) != 0x00000100) {
; rtc_needs_init start address is: 8 (R2)
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #768
CMP	R0, #256
IT	EQ
BEQ	L_RTC_Init_LSE82
; rtc_needs_init end address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,360 :: 		rtc_needs_init = 1;
; rtc_needs_init start address is: 0 (R0)
MOVS	R0, #1
;STM32_Internal_RTC_LCD_Keypad.c,361 :: 		}
; rtc_needs_init end address is: 0 (R0)
IT	AL
BAL	L_RTC_Init_LSE83
L_RTC_Init_LSE82:
;STM32_Internal_RTC_LCD_Keypad.c,362 :: 		else if(RTC_BKP0R != RTC_MAGIC) {
; rtc_needs_init start address is: 8 (R2)
MOVW	R0, #lo_addr(RTC_BKP0R+0)
MOVT	R0, #hi_addr(RTC_BKP0R+0)
LDR	R1, [R0, #0]
MOVW	R0, #13042
CMP	R1, R0
IT	EQ
BEQ	L__RTC_Init_LSE165
; rtc_needs_init end address is: 8 (R2)
;STM32_Internal_RTC_LCD_Keypad.c,363 :: 		rtc_needs_init = 1;
; rtc_needs_init start address is: 0 (R0)
MOVS	R0, #1
; rtc_needs_init end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,364 :: 		}
IT	AL
BAL	L_RTC_Init_LSE84
L__RTC_Init_LSE165:
;STM32_Internal_RTC_LCD_Keypad.c,362 :: 		else if(RTC_BKP0R != RTC_MAGIC) {
UXTB	R0, R2
;STM32_Internal_RTC_LCD_Keypad.c,364 :: 		}
L_RTC_Init_LSE84:
; rtc_needs_init start address is: 0 (R0)
; rtc_needs_init end address is: 0 (R0)
L_RTC_Init_LSE83:
; rtc_needs_init start address is: 0 (R0)
; rtc_needs_init end address is: 0 (R0)
L_RTC_Init_LSE81:
;STM32_Internal_RTC_LCD_Keypad.c,366 :: 		if(rtc_needs_init) {
; rtc_needs_init start address is: 0 (R0)
CMP	R0, #0
IT	EQ
BEQ	L_RTC_Init_LSE85
; rtc_needs_init end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,368 :: 		RCC_BDCR |= 0x00010000;         // BDRST
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #65536
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,369 :: 		RCC_BDCR &= ~0x00010000;
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R1, [R0, #0]
MVN	R0, #65536
ANDS	R1, R0
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,371 :: 		RCC_BDCR &= ~0x00000004;        // LSEBYP = 0, use crystal
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R1, [R0, #0]
MVN	R0, #4
ANDS	R1, R0
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,372 :: 		RCC_BDCR |= 0x00000001;         // LSEON
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,373 :: 		while((RCC_BDCR & 0x00000002) == 0) {
L_RTC_Init_LSE86:
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #2
CMP	R0, #0
IT	NE
BNE	L_RTC_Init_LSE87
;STM32_Internal_RTC_LCD_Keypad.c,374 :: 		}
IT	AL
BAL	L_RTC_Init_LSE86
L_RTC_Init_LSE87:
;STM32_Internal_RTC_LCD_Keypad.c,376 :: 		RCC_BDCR &= ~0x00000300;        // clear RTCSEL
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R1, [R0, #0]
MVN	R0, #768
ANDS	R1, R0
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,377 :: 		RCC_BDCR |=  0x00000100;        // RTCSEL = LSE
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #256
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,378 :: 		RCC_BDCR |=  0x00008000;        // RTCEN
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #32768
MOVW	R0, #lo_addr(RCC_BDCR+0)
MOVT	R0, #hi_addr(RCC_BDCR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,380 :: 		RTC_WriteProtectOff();
BL	_RTC_WriteProtectOff+0
;STM32_Internal_RTC_LCD_Keypad.c,381 :: 		RTC_EnterInitMode();
BL	_RTC_EnterInitMode+0
;STM32_Internal_RTC_LCD_Keypad.c,383 :: 		RTC_CR |= 0x00000020;           // BYPSHAD
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #32
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,384 :: 		RTC_CR &= ~0x00000040;          // 24-hour format
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
LDR	R1, [R0, #0]
MVN	R0, #64
ANDS	R1, R0
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,385 :: 		RTC_PRER = RTC_PRER_LSE;        // 32768 / (128 * 256) = 1 Hz
MOVW	R1, #255
MOVT	R1, #127
MOVW	R0, #lo_addr(RTC_PRER+0)
MOVT	R0, #hi_addr(RTC_PRER+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,386 :: 		RTC_TR = 0x00000000;            // 00:00:00
MOVS	R1, #0
MOVW	R0, #lo_addr(RTC_TR+0)
MOVT	R0, #hi_addr(RTC_TR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,387 :: 		RTC_DR = 0x00242101;            // Monday 01/01/24
MOVW	R1, #8449
MOVT	R1, #36
MOVW	R0, #lo_addr(RTC_DR+0)
MOVT	R0, #hi_addr(RTC_DR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,388 :: 		RTC_BKP0R = RTC_MAGIC;
MOVW	R1, #13042
MOVW	R0, #lo_addr(RTC_BKP0R+0)
MOVT	R0, #hi_addr(RTC_BKP0R+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,390 :: 		RTC_ExitInitMode();
BL	_RTC_ExitInitMode+0
;STM32_Internal_RTC_LCD_Keypad.c,391 :: 		RTC_WriteProtectOn();
BL	_RTC_WriteProtectOn+0
;STM32_Internal_RTC_LCD_Keypad.c,392 :: 		}
L_RTC_Init_LSE85:
;STM32_Internal_RTC_LCD_Keypad.c,394 :: 		RTC_WriteProtectOff();
BL	_RTC_WriteProtectOff+0
;STM32_Internal_RTC_LCD_Keypad.c,395 :: 		RTC_CR |= 0x00000020;             // keep direct calendar reads enabled
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #32
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,396 :: 		RTC_CR &= ~0x00000040;            // keep 24-hour format
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
LDR	R1, [R0, #0]
MVN	R0, #64
ANDS	R1, R0
MOVW	R0, #lo_addr(RTC_CR+0)
MOVT	R0, #hi_addr(RTC_CR+0)
STR	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,397 :: 		RTC_WriteProtectOn();
BL	_RTC_WriteProtectOn+0
;STM32_Internal_RTC_LCD_Keypad.c,398 :: 		}
L_end_RTC_Init_LSE:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _RTC_Init_LSE
_ShowMainMenu:
;STM32_Internal_RTC_LCD_Keypad.c,403 :: 		void ShowMainMenu() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;STM32_Internal_RTC_LCD_Keypad.c,404 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,405 :: 		Lcd_Out(1, 1, "A:Adjust D:Show");
MOVW	R0, #lo_addr(?lstr1_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr1_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,406 :: 		Lcd_Out(2, 1, "Select option");
MOVW	R0, #lo_addr(?lstr2_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr2_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,407 :: 		}
L_end_ShowMainMenu:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _ShowMainMenu
_BuildAdjustScreen:
;STM32_Internal_RTC_LCD_Keypad.c,409 :: 		void BuildAdjustScreen() {
SUB	SP, SP, #40
STR	LR, [SP, #0]
;STM32_Internal_RTC_LCD_Keypad.c,414 :: 		for(i = 0; i < 16; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
L_BuildAdjustScreen88:
; i start address is: 8 (R2)
CMP	R2, #16
IT	CS
BCS	L_BuildAdjustScreen89
;STM32_Internal_RTC_LCD_Keypad.c,415 :: 		line1[i] = ' ';
ADD	R0, SP, #4
ADDS	R1, R0, R2
MOVS	R0, #32
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,416 :: 		line2[i] = ' ';
ADD	R0, SP, #21
ADDS	R1, R0, R2
MOVS	R0, #32
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,414 :: 		for(i = 0; i < 16; i++) {
ADDS	R2, R2, #1
UXTB	R2, R2
;STM32_Internal_RTC_LCD_Keypad.c,417 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_BuildAdjustScreen88
L_BuildAdjustScreen89:
;STM32_Internal_RTC_LCD_Keypad.c,418 :: 		line1[16] = 0;
ADD	R2, SP, #4
ADDW	R1, R2, #16
MOVS	R0, #0
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,419 :: 		line2[16] = 0;
ADD	R0, SP, #21
ADDW	R1, R0, #16
MOVS	R0, #0
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,421 :: 		line1[0] = 'D';
MOVS	R0, #68
STRB	R0, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,422 :: 		line1[1] = ':';
ADDS	R1, R2, #1
MOVS	R0, #58
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,423 :: 		line1[2] = rtc_digits[0]  ? rtc_digits[0]  : '_';
ADDS	R1, R2, #2
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen91
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
; ?FLOC___BuildAdjustScreen?T258 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T258 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen92
L_BuildAdjustScreen91:
; ?FLOC___BuildAdjustScreen?T258 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T258 end address is: 0 (R0)
L_BuildAdjustScreen92:
; ?FLOC___BuildAdjustScreen?T258 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T258 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,424 :: 		line1[3] = rtc_digits[1]  ? rtc_digits[1]  : '_';
ADD	R0, SP, #4
ADDS	R1, R0, #3
MOVW	R0, #lo_addr(_rtc_digits+1)
MOVT	R0, #hi_addr(_rtc_digits+1)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen93
MOVW	R0, #lo_addr(_rtc_digits+1)
MOVT	R0, #hi_addr(_rtc_digits+1)
; ?FLOC___BuildAdjustScreen?T264 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T264 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen94
L_BuildAdjustScreen93:
; ?FLOC___BuildAdjustScreen?T264 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T264 end address is: 0 (R0)
L_BuildAdjustScreen94:
; ?FLOC___BuildAdjustScreen?T264 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T264 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,425 :: 		line1[4] = '/';
ADD	R2, SP, #4
ADDS	R1, R2, #4
MOVS	R0, #47
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,426 :: 		line1[5] = rtc_digits[2]  ? rtc_digits[2]  : '_';
ADDS	R1, R2, #5
MOVW	R0, #lo_addr(_rtc_digits+2)
MOVT	R0, #hi_addr(_rtc_digits+2)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen95
MOVW	R0, #lo_addr(_rtc_digits+2)
MOVT	R0, #hi_addr(_rtc_digits+2)
; ?FLOC___BuildAdjustScreen?T273 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T273 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen96
L_BuildAdjustScreen95:
; ?FLOC___BuildAdjustScreen?T273 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T273 end address is: 0 (R0)
L_BuildAdjustScreen96:
; ?FLOC___BuildAdjustScreen?T273 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T273 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,427 :: 		line1[6] = rtc_digits[3]  ? rtc_digits[3]  : '_';
ADD	R0, SP, #4
ADDS	R1, R0, #6
MOVW	R0, #lo_addr(_rtc_digits+3)
MOVT	R0, #hi_addr(_rtc_digits+3)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen97
MOVW	R0, #lo_addr(_rtc_digits+3)
MOVT	R0, #hi_addr(_rtc_digits+3)
; ?FLOC___BuildAdjustScreen?T279 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T279 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen98
L_BuildAdjustScreen97:
; ?FLOC___BuildAdjustScreen?T279 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T279 end address is: 0 (R0)
L_BuildAdjustScreen98:
; ?FLOC___BuildAdjustScreen?T279 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T279 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,428 :: 		line1[7] = '/';
ADD	R2, SP, #4
ADDS	R1, R2, #7
MOVS	R0, #47
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,429 :: 		line1[8] = rtc_digits[4]  ? rtc_digits[4]  : '_';
ADDW	R1, R2, #8
MOVW	R0, #lo_addr(_rtc_digits+4)
MOVT	R0, #hi_addr(_rtc_digits+4)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen99
MOVW	R0, #lo_addr(_rtc_digits+4)
MOVT	R0, #hi_addr(_rtc_digits+4)
; ?FLOC___BuildAdjustScreen?T288 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T288 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen100
L_BuildAdjustScreen99:
; ?FLOC___BuildAdjustScreen?T288 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T288 end address is: 0 (R0)
L_BuildAdjustScreen100:
; ?FLOC___BuildAdjustScreen?T288 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T288 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,430 :: 		line1[9] = rtc_digits[5]  ? rtc_digits[5]  : '_';
ADD	R0, SP, #4
ADDW	R1, R0, #9
MOVW	R0, #lo_addr(_rtc_digits+5)
MOVT	R0, #hi_addr(_rtc_digits+5)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen101
MOVW	R0, #lo_addr(_rtc_digits+5)
MOVT	R0, #hi_addr(_rtc_digits+5)
; ?FLOC___BuildAdjustScreen?T294 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T294 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen102
L_BuildAdjustScreen101:
; ?FLOC___BuildAdjustScreen?T294 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T294 end address is: 0 (R0)
L_BuildAdjustScreen102:
; ?FLOC___BuildAdjustScreen?T294 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T294 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,432 :: 		line2[0] = 'T';
ADD	R2, SP, #21
MOVS	R0, #84
STRB	R0, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,433 :: 		line2[1] = ':';
ADDS	R1, R2, #1
MOVS	R0, #58
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,434 :: 		line2[2] = rtc_digits[6]  ? rtc_digits[6]  : '_';
ADDS	R1, R2, #2
MOVW	R0, #lo_addr(_rtc_digits+6)
MOVT	R0, #hi_addr(_rtc_digits+6)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen103
MOVW	R0, #lo_addr(_rtc_digits+6)
MOVT	R0, #hi_addr(_rtc_digits+6)
; ?FLOC___BuildAdjustScreen?T306 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T306 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen104
L_BuildAdjustScreen103:
; ?FLOC___BuildAdjustScreen?T306 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T306 end address is: 0 (R0)
L_BuildAdjustScreen104:
; ?FLOC___BuildAdjustScreen?T306 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T306 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,435 :: 		line2[3] = rtc_digits[7]  ? rtc_digits[7]  : '_';
ADD	R0, SP, #21
ADDS	R1, R0, #3
MOVW	R0, #lo_addr(_rtc_digits+7)
MOVT	R0, #hi_addr(_rtc_digits+7)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen105
MOVW	R0, #lo_addr(_rtc_digits+7)
MOVT	R0, #hi_addr(_rtc_digits+7)
; ?FLOC___BuildAdjustScreen?T312 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T312 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen106
L_BuildAdjustScreen105:
; ?FLOC___BuildAdjustScreen?T312 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T312 end address is: 0 (R0)
L_BuildAdjustScreen106:
; ?FLOC___BuildAdjustScreen?T312 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T312 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,436 :: 		line2[4] = ':';
ADD	R2, SP, #21
ADDS	R1, R2, #4
MOVS	R0, #58
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,437 :: 		line2[5] = rtc_digits[8]  ? rtc_digits[8]  : '_';
ADDS	R1, R2, #5
MOVW	R0, #lo_addr(_rtc_digits+8)
MOVT	R0, #hi_addr(_rtc_digits+8)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen107
MOVW	R0, #lo_addr(_rtc_digits+8)
MOVT	R0, #hi_addr(_rtc_digits+8)
; ?FLOC___BuildAdjustScreen?T321 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T321 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen108
L_BuildAdjustScreen107:
; ?FLOC___BuildAdjustScreen?T321 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T321 end address is: 0 (R0)
L_BuildAdjustScreen108:
; ?FLOC___BuildAdjustScreen?T321 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T321 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,438 :: 		line2[6] = rtc_digits[9]  ? rtc_digits[9]  : '_';
ADD	R0, SP, #21
ADDS	R1, R0, #6
MOVW	R0, #lo_addr(_rtc_digits+9)
MOVT	R0, #hi_addr(_rtc_digits+9)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen109
MOVW	R0, #lo_addr(_rtc_digits+9)
MOVT	R0, #hi_addr(_rtc_digits+9)
; ?FLOC___BuildAdjustScreen?T327 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T327 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen110
L_BuildAdjustScreen109:
; ?FLOC___BuildAdjustScreen?T327 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T327 end address is: 0 (R0)
L_BuildAdjustScreen110:
; ?FLOC___BuildAdjustScreen?T327 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T327 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,439 :: 		line2[7] = ':';
ADD	R2, SP, #21
ADDS	R1, R2, #7
MOVS	R0, #58
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,440 :: 		line2[8] = rtc_digits[10] ? rtc_digits[10] : '_';
ADDW	R1, R2, #8
MOVW	R0, #lo_addr(_rtc_digits+10)
MOVT	R0, #hi_addr(_rtc_digits+10)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen111
MOVW	R0, #lo_addr(_rtc_digits+10)
MOVT	R0, #hi_addr(_rtc_digits+10)
; ?FLOC___BuildAdjustScreen?T336 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T336 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen112
L_BuildAdjustScreen111:
; ?FLOC___BuildAdjustScreen?T336 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T336 end address is: 0 (R0)
L_BuildAdjustScreen112:
; ?FLOC___BuildAdjustScreen?T336 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T336 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,441 :: 		line2[9] = rtc_digits[11] ? rtc_digits[11] : '_';
ADD	R0, SP, #21
ADDW	R1, R0, #9
MOVW	R0, #lo_addr(_rtc_digits+11)
MOVT	R0, #hi_addr(_rtc_digits+11)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	EQ
BEQ	L_BuildAdjustScreen113
MOVW	R0, #lo_addr(_rtc_digits+11)
MOVT	R0, #hi_addr(_rtc_digits+11)
; ?FLOC___BuildAdjustScreen?T342 start address is: 0 (R0)
LDRB	R0, [R0, #0]
; ?FLOC___BuildAdjustScreen?T342 end address is: 0 (R0)
IT	AL
BAL	L_BuildAdjustScreen114
L_BuildAdjustScreen113:
; ?FLOC___BuildAdjustScreen?T342 start address is: 0 (R0)
MOVS	R0, #95
; ?FLOC___BuildAdjustScreen?T342 end address is: 0 (R0)
L_BuildAdjustScreen114:
; ?FLOC___BuildAdjustScreen?T342 start address is: 0 (R0)
STRB	R0, [R1, #0]
; ?FLOC___BuildAdjustScreen?T342 end address is: 0 (R0)
;STM32_Internal_RTC_LCD_Keypad.c,443 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,444 :: 		Lcd_Out(1, 1, line1);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,445 :: 		Lcd_Out(2, 1, line2);
ADD	R0, SP, #21
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,446 :: 		}
L_end_BuildAdjustScreen:
LDR	LR, [SP, #0]
ADD	SP, SP, #40
BX	LR
; end of _BuildAdjustScreen
_AdjustMode:
;STM32_Internal_RTC_LCD_Keypad.c,448 :: 		void AdjustMode() {
SUB	SP, SP, #12
STR	LR, [SP, #0]
;STM32_Internal_RTC_LCD_Keypad.c,453 :: 		for(i = 0; i < 12; i++) rtc_digits[i] = 0;
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
L_AdjustMode115:
; i start address is: 8 (R2)
CMP	R2, #12
IT	CS
BCS	L_AdjustMode116
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
ADDS	R1, R0, R2
MOVS	R0, #0
STRB	R0, [R1, #0]
ADDS	R2, R2, #1
UXTB	R2, R2
; i end address is: 8 (R2)
IT	AL
BAL	L_AdjustMode115
L_AdjustMode116:
;STM32_Internal_RTC_LCD_Keypad.c,454 :: 		rtc_digits[12] = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_rtc_digits+12)
MOVT	R0, #hi_addr(_rtc_digits+12)
STRB	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,455 :: 		rtc_pos = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
STRB	R1, [R0, #0]
;STM32_Internal_RTC_LCD_Keypad.c,457 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;STM32_Internal_RTC_LCD_Keypad.c,459 :: 		while(1) {
L_AdjustMode118:
;STM32_Internal_RTC_LCD_Keypad.c,460 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
STRB	R0, [SP, #8]
;STM32_Internal_RTC_LCD_Keypad.c,462 :: 		if((key >= '0') && (key <= '9')) {
CMP	R0, #48
IT	CC
BCC	L__AdjustMode168
LDRB	R0, [SP, #8]
CMP	R0, #57
IT	HI
BHI	L__AdjustMode167
L__AdjustMode166:
;STM32_Internal_RTC_LCD_Keypad.c,463 :: 		if(rtc_pos < 12) {
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
LDRB	R0, [R0, #0]
CMP	R0, #12
IT	CS
BCS	L_AdjustMode123
;STM32_Internal_RTC_LCD_Keypad.c,464 :: 		rtc_digits[rtc_pos] = key;
MOVW	R2, #lo_addr(_rtc_pos+0)
MOVT	R2, #hi_addr(_rtc_pos+0)
LDRB	R1, [R2, #0]
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
ADDS	R1, R0, R1
LDRB	R0, [SP, #8]
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,465 :: 		rtc_pos++;
MOV	R0, R2
LDRB	R0, [R0, #0]
ADDS	R0, R0, #1
STRB	R0, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,466 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;STM32_Internal_RTC_LCD_Keypad.c,467 :: 		}
L_AdjustMode123:
;STM32_Internal_RTC_LCD_Keypad.c,468 :: 		}
IT	AL
BAL	L_AdjustMode124
;STM32_Internal_RTC_LCD_Keypad.c,462 :: 		if((key >= '0') && (key <= '9')) {
L__AdjustMode168:
L__AdjustMode167:
;STM32_Internal_RTC_LCD_Keypad.c,469 :: 		else if(key == '*') {
LDRB	R0, [SP, #8]
CMP	R0, #42
IT	NE
BNE	L_AdjustMode125
;STM32_Internal_RTC_LCD_Keypad.c,470 :: 		if(rtc_pos > 0) {
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	LS
BLS	L_AdjustMode126
;STM32_Internal_RTC_LCD_Keypad.c,471 :: 		rtc_pos--;
MOVW	R2, #lo_addr(_rtc_pos+0)
MOVT	R2, #hi_addr(_rtc_pos+0)
LDRB	R0, [R2, #0]
SUBS	R1, R0, #1
UXTB	R1, R1
STRB	R1, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,472 :: 		rtc_digits[rtc_pos] = 0;
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
ADDS	R1, R0, R1
MOVS	R0, #0
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,473 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;STM32_Internal_RTC_LCD_Keypad.c,474 :: 		}
L_AdjustMode126:
;STM32_Internal_RTC_LCD_Keypad.c,475 :: 		}
IT	AL
BAL	L_AdjustMode127
L_AdjustMode125:
;STM32_Internal_RTC_LCD_Keypad.c,476 :: 		else if(key == 'B') {
LDRB	R0, [SP, #8]
CMP	R0, #66
IT	NE
BNE	L_AdjustMode128
;STM32_Internal_RTC_LCD_Keypad.c,477 :: 		return;
IT	AL
BAL	L_end_AdjustMode
;STM32_Internal_RTC_LCD_Keypad.c,478 :: 		}
L_AdjustMode128:
;STM32_Internal_RTC_LCD_Keypad.c,479 :: 		else if(key == '#') {
LDRB	R0, [SP, #8]
CMP	R0, #35
IT	NE
BNE	L_AdjustMode130
;STM32_Internal_RTC_LCD_Keypad.c,480 :: 		if(rtc_pos == 12) {
MOVW	R0, #lo_addr(_rtc_pos+0)
MOVT	R0, #hi_addr(_rtc_pos+0)
LDRB	R0, [R0, #0]
CMP	R0, #12
IT	NE
BNE	L_AdjustMode131
;STM32_Internal_RTC_LCD_Keypad.c,481 :: 		day    = Parse2Digits(rtc_digits[0],  rtc_digits[1]);
MOVW	R0, #lo_addr(_rtc_digits+1)
MOVT	R0, #hi_addr(_rtc_digits+1)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+0)
MOVT	R0, #hi_addr(_rtc_digits+0)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; day start address is: 36 (R9)
UXTB	R9, R0
;STM32_Internal_RTC_LCD_Keypad.c,482 :: 		month  = Parse2Digits(rtc_digits[2],  rtc_digits[3]);
MOVW	R0, #lo_addr(_rtc_digits+3)
MOVT	R0, #hi_addr(_rtc_digits+3)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+2)
MOVT	R0, #hi_addr(_rtc_digits+2)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; month start address is: 40 (R10)
UXTB	R10, R0
;STM32_Internal_RTC_LCD_Keypad.c,483 :: 		year   = Parse2Digits(rtc_digits[4],  rtc_digits[5]);
MOVW	R0, #lo_addr(_rtc_digits+5)
MOVT	R0, #hi_addr(_rtc_digits+5)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+4)
MOVT	R0, #hi_addr(_rtc_digits+4)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; year start address is: 44 (R11)
UXTB	R11, R0
;STM32_Internal_RTC_LCD_Keypad.c,484 :: 		hour   = Parse2Digits(rtc_digits[6],  rtc_digits[7]);
MOVW	R0, #lo_addr(_rtc_digits+7)
MOVT	R0, #hi_addr(_rtc_digits+7)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+6)
MOVT	R0, #hi_addr(_rtc_digits+6)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; hour start address is: 48 (R12)
UXTB	R12, R0
;STM32_Internal_RTC_LCD_Keypad.c,485 :: 		minute = Parse2Digits(rtc_digits[8],  rtc_digits[9]);
MOVW	R0, #lo_addr(_rtc_digits+9)
MOVT	R0, #hi_addr(_rtc_digits+9)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+8)
MOVT	R0, #hi_addr(_rtc_digits+8)
LDRB	R0, [R0, #0]
BL	_Parse2Digits+0
; minute start address is: 8 (R2)
UXTB	R2, R0
;STM32_Internal_RTC_LCD_Keypad.c,486 :: 		second = Parse2Digits(rtc_digits[10], rtc_digits[11]);
MOVW	R0, #lo_addr(_rtc_digits+11)
MOVT	R0, #hi_addr(_rtc_digits+11)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_rtc_digits+10)
MOVT	R0, #hi_addr(_rtc_digits+10)
LDRB	R0, [R0, #0]
STRB	R2, [SP, #4]
BL	_Parse2Digits+0
LDRB	R2, [SP, #4]
; second start address is: 12 (R3)
UXTB	R3, R0
;STM32_Internal_RTC_LCD_Keypad.c,488 :: 		if(ValidateDateTime(day, month, year, hour, minute, second)) {
UXTB	R1, R0
UXTB	R0, R2
STRB	R3, [SP, #4]
STRB	R2, [SP, #5]
PUSH	(R1)
PUSH	(R0)
UXTB	R3, R12
UXTB	R2, R11
UXTB	R1, R10
UXTB	R0, R9
BL	_ValidateDateTime+0
ADD	SP, SP, #8
LDRB	R2, [SP, #5]
LDRB	R3, [SP, #4]
CMP	R0, #0
IT	EQ
BEQ	L_AdjustMode132
;STM32_Internal_RTC_LCD_Keypad.c,489 :: 		RTC_SetDateTime(day, month, year, hour, minute, second);
UXTB	R1, R3
; second end address is: 12 (R3)
UXTB	R0, R2
; minute end address is: 8 (R2)
PUSH	(R1)
; hour end address is: 48 (R12)
PUSH	(R0)
UXTB	R3, R12
UXTB	R2, R11
; year end address is: 44 (R11)
UXTB	R1, R10
; month end address is: 40 (R10)
UXTB	R0, R9
; day end address is: 36 (R9)
BL	_RTC_SetDateTime+0
ADD	SP, SP, #8
;STM32_Internal_RTC_LCD_Keypad.c,491 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,492 :: 		Lcd_Out(1, 1, "Saved OK");
MOVW	R0, #lo_addr(?lstr3_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr3_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,493 :: 		Lcd_Out(2, 1, "B:Back");
MOVW	R0, #lo_addr(?lstr4_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr4_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,494 :: 		}
IT	AL
BAL	L_AdjustMode133
L_AdjustMode132:
;STM32_Internal_RTC_LCD_Keypad.c,496 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,497 :: 		Lcd_Out(1, 1, "Invalid DateTime");
MOVW	R0, #lo_addr(?lstr5_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr5_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,498 :: 		Lcd_Out(2, 1, "B:Back");
MOVW	R0, #lo_addr(?lstr6_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr6_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,499 :: 		}
L_AdjustMode133:
;STM32_Internal_RTC_LCD_Keypad.c,501 :: 		while(1) {
L_AdjustMode134:
;STM32_Internal_RTC_LCD_Keypad.c,502 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
STRB	R0, [SP, #8]
;STM32_Internal_RTC_LCD_Keypad.c,503 :: 		if(key == 'B') return;
CMP	R0, #66
IT	NE
BNE	L_AdjustMode136
IT	AL
BAL	L_end_AdjustMode
L_AdjustMode136:
;STM32_Internal_RTC_LCD_Keypad.c,504 :: 		}
IT	AL
BAL	L_AdjustMode134
;STM32_Internal_RTC_LCD_Keypad.c,505 :: 		}
L_AdjustMode131:
;STM32_Internal_RTC_LCD_Keypad.c,507 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,508 :: 		Lcd_Out(1, 1, "Need 12 digits");
MOVW	R0, #lo_addr(?lstr7_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr7_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,509 :: 		Lcd_Out(2, 1, "# retry B back");
MOVW	R0, #lo_addr(?lstr8_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr8_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,511 :: 		while(1) {
L_AdjustMode138:
;STM32_Internal_RTC_LCD_Keypad.c,512 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
STRB	R0, [SP, #8]
;STM32_Internal_RTC_LCD_Keypad.c,513 :: 		if(key == 'B') return;
CMP	R0, #66
IT	NE
BNE	L_AdjustMode140
IT	AL
BAL	L_end_AdjustMode
L_AdjustMode140:
;STM32_Internal_RTC_LCD_Keypad.c,514 :: 		if(key == '#') {
LDRB	R0, [SP, #8]
CMP	R0, #35
IT	NE
BNE	L_AdjustMode141
;STM32_Internal_RTC_LCD_Keypad.c,515 :: 		BuildAdjustScreen();
BL	_BuildAdjustScreen+0
;STM32_Internal_RTC_LCD_Keypad.c,516 :: 		break;
IT	AL
BAL	L_AdjustMode139
;STM32_Internal_RTC_LCD_Keypad.c,517 :: 		}
L_AdjustMode141:
;STM32_Internal_RTC_LCD_Keypad.c,518 :: 		}
IT	AL
BAL	L_AdjustMode138
L_AdjustMode139:
;STM32_Internal_RTC_LCD_Keypad.c,520 :: 		}
L_AdjustMode130:
L_AdjustMode127:
L_AdjustMode124:
;STM32_Internal_RTC_LCD_Keypad.c,521 :: 		}
IT	AL
BAL	L_AdjustMode118
;STM32_Internal_RTC_LCD_Keypad.c,522 :: 		}
L_end_AdjustMode:
LDR	LR, [SP, #0]
ADD	SP, SP, #12
BX	LR
; end of _AdjustMode
_DisplayMode:
;STM32_Internal_RTC_LCD_Keypad.c,524 :: 		void DisplayMode() {
SUB	SP, SP, #44
STR	LR, [SP, #0]
;STM32_Internal_RTC_LCD_Keypad.c,530 :: 		while(1) {
L_DisplayMode142:
;STM32_Internal_RTC_LCD_Keypad.c,531 :: 		RTC_GetDateTime(&day, &month, &year, &hour, &minute, &second);
ADD	R5, SP, #9
ADD	R4, SP, #8
ADD	R3, SP, #7
ADD	R2, SP, #6
ADD	R1, SP, #5
ADD	R0, SP, #4
PUSH	(R5)
PUSH	(R4)
BL	_RTC_GetDateTime+0
ADD	SP, SP, #8
;STM32_Internal_RTC_LCD_Keypad.c,533 :: 		line1[0] = (day / 10) + '0';
ADD	R4, SP, #10
LDRB	R1, [SP, #4]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R4, #0]
;STM32_Internal_RTC_LCD_Keypad.c,534 :: 		line1[1] = (day % 10) + '0';
ADDS	R3, R4, #1
LDRB	R2, [SP, #4]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;STM32_Internal_RTC_LCD_Keypad.c,535 :: 		line1[2] = '/';
ADDS	R1, R4, #2
MOVS	R0, #47
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,536 :: 		line1[3] = (month / 10) + '0';
ADDS	R2, R4, #3
LDRB	R1, [SP, #5]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,537 :: 		line1[4] = (month % 10) + '0';
ADDS	R3, R4, #4
LDRB	R2, [SP, #5]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;STM32_Internal_RTC_LCD_Keypad.c,538 :: 		line1[5] = '/';
ADDS	R1, R4, #5
MOVS	R0, #47
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,539 :: 		line1[6] = (year / 10) + '0';
ADDS	R2, R4, #6
LDRB	R1, [SP, #6]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,540 :: 		line1[7] = (year % 10) + '0';
ADDS	R3, R4, #7
LDRB	R2, [SP, #6]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;STM32_Internal_RTC_LCD_Keypad.c,541 :: 		line1[8] = 0;
ADDW	R1, R4, #8
MOVS	R0, #0
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,543 :: 		line2[0] = (hour / 10) + '0';
ADD	R4, SP, #27
LDRB	R1, [SP, #7]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R4, #0]
;STM32_Internal_RTC_LCD_Keypad.c,544 :: 		line2[1] = (hour % 10) + '0';
ADDS	R3, R4, #1
LDRB	R2, [SP, #7]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;STM32_Internal_RTC_LCD_Keypad.c,545 :: 		line2[2] = ':';
ADDS	R1, R4, #2
MOVS	R0, #58
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,546 :: 		line2[3] = (minute / 10) + '0';
ADDS	R2, R4, #3
LDRB	R1, [SP, #8]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,547 :: 		line2[4] = (minute % 10) + '0';
ADDS	R3, R4, #4
LDRB	R2, [SP, #8]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;STM32_Internal_RTC_LCD_Keypad.c,548 :: 		line2[5] = ':';
ADDS	R1, R4, #5
MOVS	R0, #58
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,549 :: 		line2[6] = (second / 10) + '0';
ADDS	R2, R4, #6
LDRB	R1, [SP, #9]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R2, #0]
;STM32_Internal_RTC_LCD_Keypad.c,550 :: 		line2[7] = (second % 10) + '0';
ADDS	R3, R4, #7
LDRB	R2, [SP, #9]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;STM32_Internal_RTC_LCD_Keypad.c,551 :: 		line2[8] = 0;
ADDW	R1, R4, #8
MOVS	R0, #0
STRB	R0, [R1, #0]
;STM32_Internal_RTC_LCD_Keypad.c,553 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,554 :: 		Lcd_Out(1, 1, line1);
ADD	R0, SP, #10
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,555 :: 		Lcd_Out(2, 1, line2);
ADD	R0, SP, #27
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,557 :: 		key = Keypad_GetKey();
BL	_Keypad_GetKey+0
;STM32_Internal_RTC_LCD_Keypad.c,558 :: 		if(key == 'B') {
CMP	R0, #66
IT	NE
BNE	L_DisplayMode144
;STM32_Internal_RTC_LCD_Keypad.c,559 :: 		Delay_ms(20);
MOVW	R7, #41129
MOVT	R7, #1
NOP
NOP
L_DisplayMode145:
SUBS	R7, R7, #1
BNE	L_DisplayMode145
NOP
NOP
;STM32_Internal_RTC_LCD_Keypad.c,560 :: 		if(Keypad_GetKey() == 'B') {
BL	_Keypad_GetKey+0
CMP	R0, #66
IT	NE
BNE	L_DisplayMode147
;STM32_Internal_RTC_LCD_Keypad.c,561 :: 		while(Keypad_GetKey() != 0) Delay_ms(10);
L_DisplayMode148:
BL	_Keypad_GetKey+0
CMP	R0, #0
IT	EQ
BEQ	L_DisplayMode149
MOVW	R7, #53331
MOVT	R7, #0
NOP
NOP
L_DisplayMode150:
SUBS	R7, R7, #1
BNE	L_DisplayMode150
NOP
NOP
NOP
NOP
IT	AL
BAL	L_DisplayMode148
L_DisplayMode149:
;STM32_Internal_RTC_LCD_Keypad.c,562 :: 		return;
IT	AL
BAL	L_end_DisplayMode
;STM32_Internal_RTC_LCD_Keypad.c,563 :: 		}
L_DisplayMode147:
;STM32_Internal_RTC_LCD_Keypad.c,564 :: 		}
L_DisplayMode144:
;STM32_Internal_RTC_LCD_Keypad.c,566 :: 		Delay_ms(250);
MOVW	R7, #22611
MOVT	R7, #20
NOP
NOP
L_DisplayMode152:
SUBS	R7, R7, #1
BNE	L_DisplayMode152
NOP
NOP
NOP
NOP
;STM32_Internal_RTC_LCD_Keypad.c,567 :: 		}
IT	AL
BAL	L_DisplayMode142
;STM32_Internal_RTC_LCD_Keypad.c,568 :: 		}
L_end_DisplayMode:
LDR	LR, [SP, #0]
ADD	SP, SP, #44
BX	LR
; end of _DisplayMode
_main:
;STM32_Internal_RTC_LCD_Keypad.c,573 :: 		void main() {
;STM32_Internal_RTC_LCD_Keypad.c,579 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;STM32_Internal_RTC_LCD_Keypad.c,576 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;STM32_Internal_RTC_LCD_Keypad.c,579 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;STM32_Internal_RTC_LCD_Keypad.c,581 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_7 | _GPIO_PINMASK_13);
MOVW	R1, #8320
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Input+0
;STM32_Internal_RTC_LCD_Keypad.c,582 :: 		GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_9 | _GPIO_PINMASK_10);
MOVW	R1, #1536
MOVW	R0, #lo_addr(GPIOA_BASE+0)
MOVT	R0, #hi_addr(GPIOA_BASE+0)
BL	_GPIO_Digital_Input+0
;STM32_Internal_RTC_LCD_Keypad.c,584 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_12 | _GPIO_PINMASK_1);
MOVW	R1, #4098
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;STM32_Internal_RTC_LCD_Keypad.c,585 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;STM32_Internal_RTC_LCD_Keypad.c,586 :: 		GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_2);
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOD_BASE+0)
MOVT	R0, #hi_addr(GPIOD_BASE+0)
BL	_GPIO_Digital_Output+0
;STM32_Internal_RTC_LCD_Keypad.c,588 :: 		Keypad_AllColumns_Low();
BL	_Keypad_AllColumns_Low+0
;STM32_Internal_RTC_LCD_Keypad.c,590 :: 		Lcd_Init();
BL	_Lcd_Init+0
;STM32_Internal_RTC_LCD_Keypad.c,591 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,592 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;STM32_Internal_RTC_LCD_Keypad.c,594 :: 		Lcd_Out(1, 1, "INT RTC SYSTEM");
MOVW	R0, #lo_addr(?lstr9_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr9_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,595 :: 		Lcd_Out(2, 1, "Initializing...");
MOVW	R0, #lo_addr(?lstr10_STM32_Internal_RTC_LCD_Keypad+0)
MOVT	R0, #hi_addr(?lstr10_STM32_Internal_RTC_LCD_Keypad+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;STM32_Internal_RTC_LCD_Keypad.c,596 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;STM32_Internal_RTC_LCD_Keypad.c,598 :: 		RTC_Init_LSE();
BL	_RTC_Init_LSE+0
;STM32_Internal_RTC_LCD_Keypad.c,600 :: 		while(1) {
L_main154:
;STM32_Internal_RTC_LCD_Keypad.c,601 :: 		ShowMainMenu();
BL	_ShowMainMenu+0
;STM32_Internal_RTC_LCD_Keypad.c,602 :: 		key = Keypad_GetKey_Click();
BL	_Keypad_GetKey_Click+0
; key start address is: 4 (R1)
UXTB	R1, R0
;STM32_Internal_RTC_LCD_Keypad.c,604 :: 		if(key == 'A') {
CMP	R0, #65
IT	NE
BNE	L_main156
; key end address is: 4 (R1)
;STM32_Internal_RTC_LCD_Keypad.c,605 :: 		AdjustMode();
BL	_AdjustMode+0
;STM32_Internal_RTC_LCD_Keypad.c,606 :: 		}
IT	AL
BAL	L_main157
L_main156:
;STM32_Internal_RTC_LCD_Keypad.c,607 :: 		else if(key == 'D') {
; key start address is: 4 (R1)
CMP	R1, #68
IT	NE
BNE	L_main158
; key end address is: 4 (R1)
;STM32_Internal_RTC_LCD_Keypad.c,608 :: 		DisplayMode();
BL	_DisplayMode+0
;STM32_Internal_RTC_LCD_Keypad.c,609 :: 		}
L_main158:
L_main157:
;STM32_Internal_RTC_LCD_Keypad.c,610 :: 		}
IT	AL
BAL	L_main154
;STM32_Internal_RTC_LCD_Keypad.c,611 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
