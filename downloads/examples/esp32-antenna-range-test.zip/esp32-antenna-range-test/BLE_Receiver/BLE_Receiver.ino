#include <BLEAdvertisedDevice.h>
#include <BLEDevice.h>
#include <BLEScan.h>
#include <BLEUtils.h>

const char *TARGET_DEVICE_NAME = "ESP32-BLE-RANGE";
const char *TARGET_SERVICE_UUID = "7d5b1c7e-1b38-4f9f-9b47-2d41b7c4a801";
const unsigned long SCAN_TIME_SECONDS = 4;
const unsigned long BETWEEN_SCANS_MS = 1000;

BLEScan *bleScan = nullptr;
unsigned long scanPass = 0;
unsigned long lastSeenMs = 0;
long rssiSum = 0;
int sampleCount = 0;
int bestRssi = -127;
int worstRssi = -127;
bool targetSeen = false;

bool matchesTarget(const BLEAdvertisedDevice &advertisedDevice) {
  if (advertisedDevice.haveName()) {
    String name = advertisedDevice.getName().c_str();
    if (name == TARGET_DEVICE_NAME) {
      return true;
    }
  }

  if (advertisedDevice.haveServiceUUID()) {
    BLEUUID targetUuid(TARGET_SERVICE_UUID);
    if (advertisedDevice.isAdvertisingService(targetUuid)) {
      return true;
    }
  }

  return false;
}

void resetScanStats() {
  rssiSum = 0;
  sampleCount = 0;
  bestRssi = -127;
  worstRssi = -127;
  targetSeen = false;
}

class RangeCallbacks : public BLEAdvertisedDeviceCallbacks {
  void onResult(BLEAdvertisedDevice advertisedDevice) {
    if (!matchesTarget(advertisedDevice)) {
      return;
    }

    int rssi = advertisedDevice.getRSSI();

    if (!targetSeen) {
      bestRssi = rssi;
      worstRssi = rssi;
    } else {
      if (rssi > bestRssi) {
        bestRssi = rssi;
      }
      if (rssi < worstRssi) {
        worstRssi = rssi;
      }
    }

    targetSeen = true;
    sampleCount++;
    rssiSum += rssi;
    lastSeenMs = millis();
  }
};

void printScanSummary() {
  if (targetSeen && sampleCount > 0) {
    int avgRssi = static_cast<int>(rssiSum / sampleCount);
    Serial.printf(
      "%lu,BLE_RX,FOUND,scan=%lu,samples=%d,avg_rssi=%d,best_rssi=%d,worst_rssi=%d,last_seen_ms=%lu\n",
      millis(),
      scanPass,
      sampleCount,
      avgRssi,
      bestRssi,
      worstRssi,
      lastSeenMs
    );
  } else {
    Serial.printf(
      "%lu,BLE_RX,NOT_FOUND,scan=%lu,samples=0\n",
      millis(),
      scanPass
    );
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("ESP32 BLE range test receiver");
  Serial.printf("Looking for device name: %s\n", TARGET_DEVICE_NAME);

  BLEDevice::init("");
  bleScan = BLEDevice::getScan();
  bleScan->setAdvertisedDeviceCallbacks(new RangeCallbacks(), false);
  bleScan->setActiveScan(true);
  bleScan->setInterval(100);
  bleScan->setWindow(99);
}

void loop() {
  resetScanStats();
  scanPass++;

  bleScan->start(SCAN_TIME_SECONDS, false);
  printScanSummary();
  bleScan->clearResults();

  delay(BETWEEN_SCANS_MS);
}
