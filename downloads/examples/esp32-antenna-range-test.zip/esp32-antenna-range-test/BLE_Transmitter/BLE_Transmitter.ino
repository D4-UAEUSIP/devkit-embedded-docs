#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

const char *DEVICE_NAME = "ESP32-BLE-RANGE";
const char *SERVICE_UUID = "7d5b1c7e-1b38-4f9f-9b47-2d41b7c4a801";
const char *CHARACTERISTIC_UUID = "7d5b1c7e-1b38-4f9f-9b47-2d41b7c4a802";
const unsigned long STATUS_INTERVAL_MS = 2000;

BLECharacteristic *statusCharacteristic = nullptr;
unsigned long lastStatusPrint = 0;
unsigned long heartbeatCounter = 0;

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("ESP32 BLE range test transmitter");

  BLEDevice::init(DEVICE_NAME);

  BLEServer *server = BLEDevice::createServer();
  BLEService *service = server->createService(SERVICE_UUID);

  statusCharacteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ
  );
  statusCharacteristic->setValue("boot");

  service->start();

  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  advertising->setMinPreferred(0x06);
  advertising->setMinPreferred(0x12);

  BLEDevice::startAdvertising();

  Serial.printf("Advertising name: %s\n", DEVICE_NAME);
  Serial.printf("Service UUID: %s\n", SERVICE_UUID);
  Serial.println("Leave this board in one place and move the BLE receiver board away.");
}

void loop() {
  if (millis() - lastStatusPrint >= STATUS_INTERVAL_MS) {
    lastStatusPrint = millis();
    heartbeatCounter++;

    char payload[24];
    snprintf(payload, sizeof(payload), "beat=%lu", heartbeatCounter);
    statusCharacteristic->setValue(payload);

    Serial.printf("%lu,BLE_TX,ACTIVE,payload=%s\n", millis(), payload);
  }
}
