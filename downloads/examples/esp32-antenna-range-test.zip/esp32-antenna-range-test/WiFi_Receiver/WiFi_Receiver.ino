#include <WiFi.h>

const char *TARGET_SSID = "ESP32_RANGE_TEST";
const char *TARGET_PASSWORD = "RangeTest123";
const unsigned long CONNECT_TIMEOUT_MS = 15000;
const unsigned long RECONNECT_INTERVAL_MS = 5000;
const unsigned long STATUS_INTERVAL_MS = 1000;

unsigned long lastReconnectAttempt = 0;
unsigned long lastStatusPrint = 0;

void printConnectionDetails() {
  String ipAddress = WiFi.localIP().toString();
  Serial.printf(
    "%lu,WIFI_STA,CONNECTED,rssi=%d,channel=%d,ip=%s\n",
    millis(),
    WiFi.RSSI(),
    WiFi.channel(),
    ipAddress.c_str()
  );
}

void connectToAccessPoint() {
  Serial.printf("Connecting to SSID: %s\n", TARGET_SSID);

  WiFi.disconnect();
  delay(200);
  WiFi.begin(TARGET_SSID, TARGET_PASSWORD);

  unsigned long startAttempt = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < CONNECT_TIMEOUT_MS) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Connection successful.");
    printConnectionDetails();
  } else {
    Serial.println("Connection timed out. I will retry automatically.");
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("ESP32 Wi-Fi range test receiver");

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);

  connectToAccessPoint();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    if (millis() - lastReconnectAttempt >= RECONNECT_INTERVAL_MS) {
      lastReconnectAttempt = millis();
      Serial.println("Wi-Fi link lost or not connected. Retrying...");
      connectToAccessPoint();
    }
    return;
  }

  if (millis() - lastStatusPrint >= STATUS_INTERVAL_MS) {
    lastStatusPrint = millis();
    printConnectionDetails();
  }
}
