# ESP32 Antenna Range Test Kit

This folder contains Arduino sketches to compare ESP32 antenna performance for both BLE and Wi-Fi.

Assumption:
You have two ESP32 boards. One board acts as the transmitter and the second board acts as the receiver during each test.

## Folder Contents

- `BLE_Transmitter/BLE_Transmitter.ino`
- `BLE_Receiver/BLE_Receiver.ino`
- `WiFi_Transmitter/WiFi_Transmitter.ino`
- `WiFi_Receiver/WiFi_Receiver.ino`

## BLE Test

1. Flash `BLE_Transmitter.ino` to ESP32 board A.
2. Flash `BLE_Receiver.ino` to ESP32 board B.
3. Open both Serial Monitors at `115200` baud.
4. Keep board A fixed.
5. Move board B farther away and watch the RSSI printed by the receiver.

Receiver output:

- `FOUND` means the transmitter was detected.
- `avg_rssi` is the average signal strength during one scan pass.
- `best_rssi` is the strongest reading in that pass.
- `worst_rssi` is the weakest reading in that pass.
- `NOT_FOUND` means the signal was not detected in that scan window.

## Wi-Fi Test

1. Flash `WiFi_Transmitter.ino` to ESP32 board A.
2. Flash `WiFi_Receiver.ino` to ESP32 board B.
3. Open both Serial Monitors at `115200` baud.
4. Keep board A fixed.
5. Move board B farther away and watch the RSSI printed by the receiver.

Wi-Fi settings used by the sketches:

- SSID: `ESP32_RANGE_TEST`
- Password: `RangeTest123`
- Channel: `6`

Receiver output:

- `CONNECTED` means board B is still connected to the Wi-Fi transmitter.
- `rssi` shows link strength in dBm.
- If the link drops, the receiver retries automatically.

## Quick RSSI Guide

- Around `-45 dBm` to `-60 dBm`: very strong
- Around `-61 dBm` to `-70 dBm`: good
- Around `-71 dBm` to `-80 dBm`: weak but usually usable
- Below `-85 dBm`: edge of reliable operation

## Notes

- Test in an open area first, then compare with indoor testing.
- Keep both boards at the same orientation while walking away.
- BLE and Wi-Fi share the same 2.4 GHz radio, so test them one at a time for clearer results.
- If the Arduino IDE cannot find `BLEDevice.h`, make sure the ESP32 board package is installed and selected.
