#include <WiFi.h>

const char *AP_SSID = "ESP32_RANGE_TEST";
const char *AP_PASSWORD = "RangeTest123";
const int AP_CHANNEL = 6;
const bool AP_HIDDEN = false;
const int MAX_CONNECTIONS = 1;
const unsigned long STATUS_INTERVAL_MS = 3000;

unsigned long lastStatusPrint = 0;

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("ESP32 Wi-Fi range test transmitter");

  WiFi.mode(WIFI_AP);
  WiFi.setSleep(false);
  WiFi.setTxPower(WIFI_POWER_19_5dBm);

  bool started = WiFi.softAP(AP_SSID, AP_PASSWORD, AP_CHANNEL, AP_HIDDEN, MAX_CONNECTIONS);
  if (!started) {
    Serial.println("SoftAP start failed. Restarting in 5 seconds.");
    delay(5000);
    ESP.restart();
  }

  String apIp = WiFi.softAPIP().toString();
  Serial.printf("SSID: %s\n", AP_SSID);
  Serial.printf("Password: %s\n", AP_PASSWORD);
  Serial.printf("Channel: %d\n", AP_CHANNEL);
  Serial.printf("AP IP: %s\n", apIp.c_str());
  Serial.println("Leave this board fixed and move the Wi-Fi receiver board away.");
}

void loop() {
  if (millis() - lastStatusPrint >= STATUS_INTERVAL_MS) {
    lastStatusPrint = millis();
    Serial.printf(
      "%lu,WIFI_AP,ACTIVE,stations=%d\n",
      millis(),
      WiFi.softAPgetStationNum()
    );
  }
}
