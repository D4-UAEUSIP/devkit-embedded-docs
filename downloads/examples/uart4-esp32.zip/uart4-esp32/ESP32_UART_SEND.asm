_main:
;ESP32_UART_SEND.c,34 :: 		void main() {
SUB	SP, SP, #64
;ESP32_UART_SEND.c,39 :: 		UART4_Init_HW();
BL	_UART4_Init_HW+0
;ESP32_UART_SEND.c,41 :: 		for(i = 0; i < 10; i++) {
; i start address is: 16 (R4)
MOVS	R4, #0
; i end address is: 16 (R4)
L_main0:
; i start address is: 16 (R4)
CMP	R4, #10
IT	CS
BCS	L_main1
;ESP32_UART_SEND.c,42 :: 		UART4_WriteString("hello\r\n");
MOVW	R0, #lo_addr(?lstr1_ESP32_UART_SEND+0)
MOVT	R0, #hi_addr(?lstr1_ESP32_UART_SEND+0)
BL	_UART4_WriteString+0
;ESP32_UART_SEND.c,43 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;ESP32_UART_SEND.c,41 :: 		for(i = 0; i < 10; i++) {
ADDS	R4, R4, #1
UXTB	R4, R4
;ESP32_UART_SEND.c,44 :: 		}
; i end address is: 16 (R4)
IT	AL
BAL	L_main0
L_main1:
;ESP32_UART_SEND.c,46 :: 		while(1) {
L_main3:
;ESP32_UART_SEND.c,47 :: 		receivedLength = UART4_ReadMessage(rxBuffer, RX_BUFFER_SIZE);
ADD	R0, SP, #0
MOVS	R1, #64
BL	_UART4_ReadMessage+0
;ESP32_UART_SEND.c,49 :: 		if(receivedLength > 0) {
CMP	R0, #0
IT	LS
BLS	L_main5
;ESP32_UART_SEND.c,50 :: 		UART4_WriteString("Received By STM32: ");
MOVW	R0, #lo_addr(?lstr2_ESP32_UART_SEND+0)
MOVT	R0, #hi_addr(?lstr2_ESP32_UART_SEND+0)
BL	_UART4_WriteString+0
;ESP32_UART_SEND.c,51 :: 		UART4_WriteString(rxBuffer);
ADD	R0, SP, #0
BL	_UART4_WriteString+0
;ESP32_UART_SEND.c,52 :: 		UART4_WriteString("\r\n");
MOVW	R0, #lo_addr(?lstr3_ESP32_UART_SEND+0)
MOVT	R0, #hi_addr(?lstr3_ESP32_UART_SEND+0)
BL	_UART4_WriteString+0
;ESP32_UART_SEND.c,53 :: 		}
L_main5:
;ESP32_UART_SEND.c,54 :: 		}
IT	AL
BAL	L_main3
;ESP32_UART_SEND.c,55 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
_UART4_Init_HW:
;ESP32_UART_SEND.c,60 :: 		void UART4_Init_HW() {
;ESP32_UART_SEND.c,62 :: 		RCC_AHB1ENR |= 0x00000001;
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,65 :: 		RCC_APB1ENR |= 0x00080000;
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #524288
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,68 :: 		GPIOA_AFRL &= ~0x000000FF;
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
LDR	R0, [R0, #0]
AND	R1, R0, #0
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,69 :: 		GPIOA_AFRL |=  0x00000088;   // AF8 for UART4 on PA0/PA1
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #136
MOVW	R0, #lo_addr(GPIOA_AFRL+0)
MOVT	R0, #hi_addr(GPIOA_AFRL+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,71 :: 		GPIOA_MODER &= ~0x0000000F;
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
LDR	R1, [R0, #0]
MVN	R0, #15
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,72 :: 		GPIOA_MODER |=  0x0000000A;  // alternate function mode for PA0/PA1
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #10
MOVW	R0, #lo_addr(GPIOA_MODER+0)
MOVT	R0, #hi_addr(GPIOA_MODER+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,75 :: 		UART4_BRR = 0x0683;          // 9600 baud @ 16 MHz
MOVW	R1, #1667
MOVW	R0, #lo_addr(UART4_BRR+0)
MOVT	R0, #hi_addr(UART4_BRR+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,76 :: 		UART4_CR1 = 0x000C;          // TE + RE = transmitter/receiver enable
MOVS	R1, #12
MOVW	R0, #lo_addr(UART4_CR1+0)
MOVT	R0, #hi_addr(UART4_CR1+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,77 :: 		UART4_CR2 = 0x0000;          // 1 stop bit
MOVS	R1, #0
MOVW	R0, #lo_addr(UART4_CR2+0)
MOVT	R0, #hi_addr(UART4_CR2+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,78 :: 		UART4_CR3 = 0x0000;          // no flow control
MOVS	R1, #0
MOVW	R0, #lo_addr(UART4_CR3+0)
MOVT	R0, #hi_addr(UART4_CR3+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,79 :: 		UART4_CR1 |= 0x2000;         // UE = UART4 enable
MOVW	R0, #lo_addr(UART4_CR1+0)
MOVT	R0, #hi_addr(UART4_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #8192
MOVW	R0, #lo_addr(UART4_CR1+0)
MOVT	R0, #hi_addr(UART4_CR1+0)
STR	R1, [R0, #0]
;ESP32_UART_SEND.c,80 :: 		}
L_end_UART4_Init_HW:
BX	LR
; end of _UART4_Init_HW
_UART4_WriteChar:
;ESP32_UART_SEND.c,85 :: 		void UART4_WriteChar(char ch) {
; ch start address is: 0 (R0)
; ch end address is: 0 (R0)
; ch start address is: 0 (R0)
; ch end address is: 0 (R0)
;ESP32_UART_SEND.c,86 :: 		while(!(UART4_SR & 0x0080)) {
L_UART4_WriteChar6:
; ch start address is: 0 (R0)
MOVW	R1, #lo_addr(UART4_SR+0)
MOVT	R1, #hi_addr(UART4_SR+0)
LDR	R1, [R1, #0]
AND	R1, R1, #128
CMP	R1, #0
IT	NE
BNE	L_UART4_WriteChar7
;ESP32_UART_SEND.c,88 :: 		}
IT	AL
BAL	L_UART4_WriteChar6
L_UART4_WriteChar7:
;ESP32_UART_SEND.c,90 :: 		UART4_DR = (ch & 0xFF);
AND	R2, R0, #255
UXTB	R2, R2
; ch end address is: 0 (R0)
MOVW	R1, #lo_addr(UART4_DR+0)
MOVT	R1, #hi_addr(UART4_DR+0)
STR	R2, [R1, #0]
;ESP32_UART_SEND.c,91 :: 		}
L_end_UART4_WriteChar:
BX	LR
; end of _UART4_WriteChar
_UART4_WriteString:
;ESP32_UART_SEND.c,96 :: 		void UART4_WriteString(char *s) {
; s start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
; s end address is: 0 (R0)
; s start address is: 0 (R0)
MOV	R3, R0
; s end address is: 0 (R0)
;ESP32_UART_SEND.c,97 :: 		while(*s) {
L_UART4_WriteString8:
; s start address is: 12 (R3)
LDRB	R1, [R3, #0]
CMP	R1, #0
IT	EQ
BEQ	L_UART4_WriteString9
;ESP32_UART_SEND.c,98 :: 		UART4_WriteChar(*s++);
LDRB	R1, [R3, #0]
UXTB	R0, R1
BL	_UART4_WriteChar+0
ADDS	R3, R3, #1
;ESP32_UART_SEND.c,99 :: 		}
; s end address is: 12 (R3)
IT	AL
BAL	L_UART4_WriteString8
L_UART4_WriteString9:
;ESP32_UART_SEND.c,100 :: 		}
L_end_UART4_WriteString:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _UART4_WriteString
_UART4_DataReady:
;ESP32_UART_SEND.c,105 :: 		char UART4_DataReady() {
;ESP32_UART_SEND.c,106 :: 		return (UART4_SR & 0x0020) != 0;
MOVW	R0, #lo_addr(UART4_SR+0)
MOVT	R0, #hi_addr(UART4_SR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #32
CMP	R0, #0
MOVW	R0, #0
BEQ	L__UART4_DataReady44
MOVS	R0, #1
L__UART4_DataReady44:
UXTB	R0, R0
;ESP32_UART_SEND.c,107 :: 		}
L_end_UART4_DataReady:
BX	LR
; end of _UART4_DataReady
_UART4_ReadChar:
;ESP32_UART_SEND.c,112 :: 		char UART4_ReadChar() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;ESP32_UART_SEND.c,113 :: 		while(!UART4_DataReady()) {
L_UART4_ReadChar10:
BL	_UART4_DataReady+0
CMP	R0, #0
IT	NE
BNE	L_UART4_ReadChar11
;ESP32_UART_SEND.c,115 :: 		}
IT	AL
BAL	L_UART4_ReadChar10
L_UART4_ReadChar11:
;ESP32_UART_SEND.c,117 :: 		return (char)(UART4_DR & 0x00FF);
MOVW	R0, #lo_addr(UART4_DR+0)
MOVT	R0, #hi_addr(UART4_DR+0)
LDR	R0, [R0, #0]
AND	R0, R0, #255
UXTB	R0, R0
;ESP32_UART_SEND.c,118 :: 		}
L_end_UART4_ReadChar:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _UART4_ReadChar
_UART4_ReadMessage:
;ESP32_UART_SEND.c,124 :: 		unsigned short UART4_ReadMessage(char *buffer, unsigned short maxLen) {
; maxLen start address is: 4 (R1)
; buffer start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
; maxLen end address is: 4 (R1)
; buffer end address is: 0 (R0)
; buffer start address is: 0 (R0)
; maxLen start address is: 4 (R1)
;ESP32_UART_SEND.c,125 :: 		unsigned short index = 0;
; index start address is: 16 (R4)
; index start address is: 16 (R4)
MOVS	R4, #0
; buffer end address is: 0 (R0)
; index end address is: 16 (R4)
MOV	R3, R0
;ESP32_UART_SEND.c,129 :: 		while(1) {
L_UART4_ReadMessage12:
;ESP32_UART_SEND.c,130 :: 		ch = UART4_ReadChar();
; buffer start address is: 12 (R3)
; index start address is: 16 (R4)
; index end address is: 16 (R4)
; maxLen start address is: 4 (R1)
; maxLen end address is: 4 (R1)
; buffer start address is: 12 (R3)
; buffer end address is: 12 (R3)
BL	_UART4_ReadChar+0
; ch start address is: 20 (R5)
UXTB	R5, R0
;ESP32_UART_SEND.c,132 :: 		if((ch != '\r') && (ch != '\n')) {
CMP	R0, #13
IT	EQ
BEQ	L__UART4_ReadMessage34
; index end address is: 16 (R4)
; buffer end address is: 12 (R3)
; maxLen end address is: 4 (R1)
; maxLen start address is: 4 (R1)
; buffer start address is: 12 (R3)
; index start address is: 16 (R4)
CMP	R5, #10
IT	EQ
BEQ	L__UART4_ReadMessage33
L__UART4_ReadMessage32:
;ESP32_UART_SEND.c,133 :: 		buffer[index++] = ch;
ADDS	R2, R3, R4
STRB	R5, [R2, #0]
; ch end address is: 20 (R5)
ADDS	R0, R4, #1
UXTB	R0, R0
; index end address is: 16 (R4)
; index start address is: 0 (R0)
;ESP32_UART_SEND.c,134 :: 		break;
IT	AL
BAL	L_UART4_ReadMessage13
; index end address is: 0 (R0)
;ESP32_UART_SEND.c,132 :: 		if((ch != '\r') && (ch != '\n')) {
L__UART4_ReadMessage34:
; index start address is: 16 (R4)
L__UART4_ReadMessage33:
;ESP32_UART_SEND.c,136 :: 		}
; index end address is: 16 (R4)
IT	AL
BAL	L_UART4_ReadMessage12
L_UART4_ReadMessage13:
;ESP32_UART_SEND.c,138 :: 		while(index < (maxLen - 1)) {
; index start address is: 0 (R0)
; maxLen end address is: 4 (R1)
; index end address is: 0 (R0)
L_UART4_ReadMessage17:
; buffer end address is: 12 (R3)
; index start address is: 0 (R0)
; buffer start address is: 12 (R3)
; maxLen start address is: 4 (R1)
SUBS	R2, R1, #1
SXTH	R2, R2
CMP	R0, R2
IT	GE
BGE	L__UART4_ReadMessage37
;ESP32_UART_SEND.c,139 :: 		idleCounter = 0;
MOVS	R2, #0
STR	R2, [SP, #4]
; buffer end address is: 12 (R3)
; maxLen end address is: 4 (R1)
; index end address is: 0 (R0)
UXTB	R5, R0
MOV	R4, R3
;ESP32_UART_SEND.c,141 :: 		while(!UART4_DataReady()) {
L_UART4_ReadMessage19:
; maxLen start address is: 4 (R1)
; buffer start address is: 16 (R4)
; index start address is: 20 (R5)
BL	_UART4_DataReady+0
CMP	R0, #0
IT	NE
BNE	L_UART4_ReadMessage20
;ESP32_UART_SEND.c,142 :: 		idleCounter++;
LDR	R2, [SP, #4]
ADDS	R3, R2, #1
STR	R3, [SP, #4]
;ESP32_UART_SEND.c,144 :: 		if(idleCounter >= RX_IDLE_LIMIT) {
MOVW	R2, #19264
MOVT	R2, #76
CMP	R3, R2
IT	CC
BCC	L_UART4_ReadMessage21
; maxLen end address is: 4 (R1)
;ESP32_UART_SEND.c,145 :: 		buffer[index] = 0;
ADDS	R3, R4, R5
; buffer end address is: 16 (R4)
MOVS	R2, #0
STRB	R2, [R3, #0]
;ESP32_UART_SEND.c,146 :: 		return index;
UXTB	R0, R5
; index end address is: 20 (R5)
IT	AL
BAL	L_end_UART4_ReadMessage
;ESP32_UART_SEND.c,147 :: 		}
L_UART4_ReadMessage21:
;ESP32_UART_SEND.c,148 :: 		}
; index start address is: 20 (R5)
; buffer start address is: 16 (R4)
; maxLen start address is: 4 (R1)
IT	AL
BAL	L_UART4_ReadMessage19
L_UART4_ReadMessage20:
;ESP32_UART_SEND.c,150 :: 		ch = UART4_ReadChar();
BL	_UART4_ReadChar+0
; ch start address is: 12 (R3)
UXTB	R3, R0
;ESP32_UART_SEND.c,152 :: 		if((ch == '\r') || (ch == '\n')) {
CMP	R0, #13
IT	EQ
BEQ	L__UART4_ReadMessage36
CMP	R3, #10
IT	EQ
BEQ	L__UART4_ReadMessage35
IT	AL
BAL	L_UART4_ReadMessage24
; maxLen end address is: 4 (R1)
; ch end address is: 12 (R3)
L__UART4_ReadMessage36:
L__UART4_ReadMessage35:
;ESP32_UART_SEND.c,153 :: 		break;
UXTB	R0, R5
MOV	R1, R4
IT	AL
BAL	L_UART4_ReadMessage18
;ESP32_UART_SEND.c,154 :: 		}
L_UART4_ReadMessage24:
;ESP32_UART_SEND.c,156 :: 		buffer[index++] = ch;
; ch start address is: 12 (R3)
; maxLen start address is: 4 (R1)
ADDS	R2, R4, R5
STRB	R3, [R2, #0]
; ch end address is: 12 (R3)
ADDS	R0, R5, #1
UXTB	R0, R0
; index end address is: 20 (R5)
; index start address is: 0 (R0)
;ESP32_UART_SEND.c,157 :: 		}
; maxLen end address is: 4 (R1)
; buffer end address is: 16 (R4)
; index end address is: 0 (R0)
MOV	R3, R4
IT	AL
BAL	L_UART4_ReadMessage17
L__UART4_ReadMessage37:
;ESP32_UART_SEND.c,138 :: 		while(index < (maxLen - 1)) {
MOV	R1, R3
;ESP32_UART_SEND.c,157 :: 		}
L_UART4_ReadMessage18:
;ESP32_UART_SEND.c,159 :: 		buffer[index] = 0;
; buffer start address is: 4 (R1)
; index start address is: 0 (R0)
ADDS	R3, R1, R0
; buffer end address is: 4 (R1)
MOVS	R2, #0
STRB	R2, [R3, #0]
;ESP32_UART_SEND.c,160 :: 		return index;
; index end address is: 0 (R0)
;ESP32_UART_SEND.c,161 :: 		}
L_end_UART4_ReadMessage:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _UART4_ReadMessage
_delayMs:
;ESP32_UART_SEND.c,166 :: 		void delayMs(unsigned int n) {
; n start address is: 0 (R0)
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;ESP32_UART_SEND.c,169 :: 		for(; n > 0; n--) {
L_delayMs25:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs26
;ESP32_UART_SEND.c,170 :: 		for(i = 0; i < 2000; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs28:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
CMP	R2, #2000
IT	CS
BCS	L_delayMs29
;ESP32_UART_SEND.c,171 :: 		asm nop;
NOP
;ESP32_UART_SEND.c,170 :: 		for(i = 0; i < 2000; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;ESP32_UART_SEND.c,172 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs28
L_delayMs29:
;ESP32_UART_SEND.c,169 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;ESP32_UART_SEND.c,173 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs25
L_delayMs26:
;ESP32_UART_SEND.c,174 :: 		}
L_end_delayMs:
BX	LR
; end of _delayMs
