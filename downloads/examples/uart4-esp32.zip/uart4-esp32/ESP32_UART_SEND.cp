#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
#line 26 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
void delayMs(unsigned int n);
void UART4_Init_HW();
void UART4_WriteChar(char ch);
void UART4_WriteString(char *s);
char UART4_DataReady();
char UART4_ReadChar();
unsigned short UART4_ReadMessage(char *buffer, unsigned short maxLen);

void main() {
 char rxBuffer[ 64 ];
 unsigned short i;
 unsigned short receivedLength;

 UART4_Init_HW();

 for(i = 0; i < 10; i++) {
 UART4_WriteString("hello\r\n");
 delayMs(1000);
 }

 while(1) {
 receivedLength = UART4_ReadMessage(rxBuffer,  64 );

 if(receivedLength > 0) {
 UART4_WriteString("Received By STM32: ");
 UART4_WriteString(rxBuffer);
 UART4_WriteString("\r\n");
 }
 }
}
#line 60 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
void UART4_Init_HW() {

 RCC_AHB1ENR |= 0x00000001;


 RCC_APB1ENR |= 0x00080000;


 GPIOA_AFRL &= ~0x000000FF;
 GPIOA_AFRL |= 0x00000088;

 GPIOA_MODER &= ~0x0000000F;
 GPIOA_MODER |= 0x0000000A;


 UART4_BRR = 0x0683;
 UART4_CR1 = 0x000C;
 UART4_CR2 = 0x0000;
 UART4_CR3 = 0x0000;
 UART4_CR1 |= 0x2000;
}
#line 85 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
void UART4_WriteChar(char ch) {
 while(!(UART4_SR & 0x0080)) {

 }

 UART4_DR = (ch & 0xFF);
}
#line 96 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
void UART4_WriteString(char *s) {
 while(*s) {
 UART4_WriteChar(*s++);
 }
}
#line 105 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
char UART4_DataReady() {
 return (UART4_SR & 0x0020) != 0;
}
#line 112 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
char UART4_ReadChar() {
 while(!UART4_DataReady()) {

 }

 return (char)(UART4_DR & 0x00FF);
}
#line 124 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
unsigned short UART4_ReadMessage(char *buffer, unsigned short maxLen) {
 unsigned short index = 0;
 unsigned long idleCounter;
 char ch;

 while(1) {
 ch = UART4_ReadChar();

 if((ch != '\r') && (ch != '\n')) {
 buffer[index++] = ch;
 break;
 }
 }

 while(index < (maxLen - 1)) {
 idleCounter = 0;

 while(!UART4_DataReady()) {
 idleCounter++;

 if(idleCounter >=  5000000UL ) {
 buffer[index] = 0;
 return index;
 }
 }

 ch = UART4_ReadChar();

 if((ch == '\r') || (ch == '\n')) {
 break;
 }

 buffer[index++] = ch;
 }

 buffer[index] = 0;
 return index;
}
#line 166 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/ESP32_UART_SEND.c"
void delayMs(unsigned int n) {
 unsigned int i;

 for(; n > 0; n--) {
 for(i = 0; i < 2000; i++) {
 asm nop;
 }
 }
}
