/*
   ------------------------------------------------------------
   STM32F446RE - UART4 Send/Receive Test
   mikroC PRO for ARM
   ------------------------------------------------------------

   UART4:
     PA0 -> UART4_TX   (AF8)
     PA1 -> UART4_RX   (AF8)

   Clock:
     Default 16 MHz

   Baud rate:
     9600

   Function:
     Send "hello" 10 times, then wait for received data.
     When data is received, send:
       Received By STM32: <received data>
*/

#define RX_BUFFER_SIZE 64
#define RX_IDLE_LIMIT 5000000UL

void delayMs(unsigned int n);
void UART4_Init_HW();
void UART4_WriteChar(char ch);
void UART4_WriteString(char *s);
char UART4_DataReady();
char UART4_ReadChar();
unsigned short UART4_ReadMessage(char *buffer, unsigned short maxLen);

void main() {
  char rxBuffer[RX_BUFFER_SIZE];
  unsigned short i;
  unsigned short receivedLength;

  UART4_Init_HW();

  for(i = 0; i < 10; i++) {
    UART4_WriteString("hello\r\n");
    delayMs(1000);
  }

  while(1) {
    receivedLength = UART4_ReadMessage(rxBuffer, RX_BUFFER_SIZE);

    if(receivedLength > 0) {
      UART4_WriteString("Received By STM32: ");
      UART4_WriteString(rxBuffer);
      UART4_WriteString("\r\n");
    }
  }
}

/*
   Initialize UART4 on PA0/PA1
*/
void UART4_Init_HW() {
  // Enable GPIOA clock
  RCC_AHB1ENR |= 0x00000001;

  // Enable UART4 clock
  RCC_APB1ENR |= 0x00080000;

  // Configure PA0 and PA1 as alternate function AF8
  GPIOA_AFRL &= ~0x000000FF;
  GPIOA_AFRL |=  0x00000088;   // AF8 for UART4 on PA0/PA1

  GPIOA_MODER &= ~0x0000000F;
  GPIOA_MODER |=  0x0000000A;  // alternate function mode for PA0/PA1

  // UART4 configuration
  UART4_BRR = 0x0683;          // 9600 baud @ 16 MHz
  UART4_CR1 = 0x000C;          // TE + RE = transmitter/receiver enable
  UART4_CR2 = 0x0000;          // 1 stop bit
  UART4_CR3 = 0x0000;          // no flow control
  UART4_CR1 |= 0x2000;         // UE = UART4 enable
}

/*
   Write one character to UART4
*/
void UART4_WriteChar(char ch) {
  while(!(UART4_SR & 0x0080)) {
    // wait until TXE = transmit data register empty
  }

  UART4_DR = (ch & 0xFF);
}

/*
   Write a null-terminated string to UART4
*/
void UART4_WriteString(char *s) {
  while(*s) {
    UART4_WriteChar(*s++);
  }
}

/*
   Check if a byte has been received
*/
char UART4_DataReady() {
  return (UART4_SR & 0x0020) != 0;
}

/*
   Read one character from UART4
*/
char UART4_ReadChar() {
  while(!UART4_DataReady()) {
    // wait until RXNE = received data ready
  }

  return (char)(UART4_DR & 0x00FF);
}

/*
   Read one UART message.
   The message ends on CR/LF or after a short idle timeout.
*/
unsigned short UART4_ReadMessage(char *buffer, unsigned short maxLen) {
  unsigned short index = 0;
  unsigned long idleCounter;
  char ch;

  while(1) {
    ch = UART4_ReadChar();

    if((ch != '\r') && (ch != '\n')) {
      buffer[index++] = ch;
      break;
    }
  }

  while(index < (maxLen - 1)) {
    idleCounter = 0;

    while(!UART4_DataReady()) {
      idleCounter++;

      if(idleCounter >= RX_IDLE_LIMIT) {
        buffer[index] = 0;
        return index;
      }
    }

    ch = UART4_ReadChar();

    if((ch == '\r') || (ch == '\n')) {
      break;
    }

    buffer[index++] = ch;
  }

  buffer[index] = 0;
  return index;
}

/*
   Simple delay for 16 MHz clock
*/
void delayMs(unsigned int n) {
  unsigned int i;

  for(; n > 0; n--) {
    for(i = 0; i < 2000; i++) {
      asm nop;
    }
  }
}
