/*
   ------------------------------------------------------------
   STM32F446RE + LIS2DW12TR IMU + LCD 16x2
   mikroC PRO for ARM
   Register-level I2C1 access
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   SW19 : 2:ON   1 :of
   SW4 :  POT side
   VR1: adujest it till  you see the text on LCD
   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   I2C1:
     PB8 -> SCL
     PB9 -> SDA

   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5

   LIS2DW12:
     I2C address = 0x19

   Display behavior:
     Page 1 once:
       WHO_AM_I + STATUS

     Then live page forever:
       X, Y, Z, T all on one page
*/

// ---------------- LCD connections ----------------
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

// ---------------- LIS2DW12 registers ----------------
#define LIS2DW12_ADDR     0x19

#define REG_OUT_T_L       0x0D
#define REG_OUT_T_H       0x0E
#define REG_WHO_AM_I      0x0F
#define REG_CTRL1         0x20
#define REG_CTRL2         0x21
#define REG_CTRL6         0x25
#define REG_STATUS        0x27
#define REG_OUT_X_L       0x28
#define REG_OUT_X_H       0x29
#define REG_OUT_Y_L       0x2A
#define REG_OUT_Y_H       0x2B
#define REG_OUT_Z_L       0x2C
#define REG_OUT_Z_H       0x2D

unsigned short who_reg;
unsigned short status_reg;
unsigned short temp_buf[2];
unsigned short xyz_buf[6];

signed int temp_raw;
signed int x_raw, y_raw, z_raw;

signed long temp_c_x10;
signed long x_mg, y_mg, z_mg;

// --------------------------------------------------
// Delay
// --------------------------------------------------
void delayMs(unsigned int n) {
  unsigned int i;
  for(; n > 0; n--) {
    for(i = 0; i < 3195; i++) {
      asm nop;
    }
  }
}

// --------------------------------------------------
// Helpers
// --------------------------------------------------
char HexDigit(unsigned short v) {
  if(v < 10) return '0' + v;
  return 'A' + (v - 10);
}

void ByteToHex(unsigned short value, char *out) {
  out[0] = '0';
  out[1] = 'x';
  out[2] = HexDigit((value >> 4) & 0x0F);
  out[3] = HexDigit(value & 0x0F);
  out[4] = 0;
}

void SIntToStr(signed long value, char *out) {
  unsigned long absval;
  char tmp[12];
  unsigned short i = 0;
  unsigned short j = 0;

  if(value == 0) {
    out[0] = '0';
    out[1] = 0;
    return;
  }

  if(value < 0) {
    out[j++] = '-';
    absval = (unsigned long)(-value);
  } else {
    absval = (unsigned long)value;
  }

  while(absval > 0) {
    tmp[i++] = (absval % 10) + '0';
    absval /= 10;
  }

  while(i > 0) {
    out[j++] = tmp[--i];
  }

  out[j] = 0;
}

signed int MakeSigned16(unsigned short lo, unsigned short hi) {
  unsigned int v;

  v = ((unsigned int)hi << 8) | lo;

  if(v > 32767)
    return (signed int)(v - 65536);
  else
    return (signed int)v;
}

// --------------------------------------------------
// I2C1 init
// --------------------------------------------------
void I2C1_HW_Init() {
  RCC_AHB1ENR |= 0x00000002;      // GPIOB clock enable
  RCC_APB1ENR |= 0x00200000;      // I2C1 clock enable

  GPIOB_AFRH &= ~0x000000FF;
  GPIOB_AFRH |=  0x00000044;      // PB8, PB9 -> AF4

  GPIOB_MODER &= ~0x000F0000;
  GPIOB_MODER |=  0x000A0000;     // alternate function

  GPIOB_OTYPER |= 0x00000300;     // open drain

  GPIOB_PUPDR &= ~0x000F0000;
  GPIOB_PUPDR |=  0x00050000;     // pull-up

  I2C1_CR1 = 0x8000;              // software reset
  I2C1_CR1 &= ~0x8000;

  I2C1_CR2 = 16;                  // APB1 = 16 MHz
  I2C1_CCR = 80;                  // 100 kHz
  I2C1_TRISE = 17;

  I2C1_CR1 |= 0x0001;             // enable I2C1
}

// --------------------------------------------------
// I2C helpers with timeout
// --------------------------------------------------
unsigned short I2C1_WaitWhileBusy() {
  unsigned long timeout = 60000;
  while((I2C1_SR2 & 2) && timeout) timeout--;
  return (timeout != 0);
}

unsigned short I2C1_WaitTXE() {
  unsigned long timeout = 60000;
  while(!(I2C1_SR1 & 0x80) && timeout) timeout--;
  return (timeout != 0);
}

unsigned short I2C1_WaitRXNE() {
  unsigned long timeout = 60000;
  while(!(I2C1_SR1 & 0x40) && timeout) timeout--;
  return (timeout != 0);
}

unsigned short I2C1_Start_WriteAddr(unsigned short saddr) {
  volatile unsigned int tmp;
  unsigned long timeout;

  I2C1_CR1 |= 0x0100;                 // START
  timeout = 60000;
  while(!(I2C1_SR1 & 1) && timeout) timeout--;
  if(timeout == 0) return 0;

  I2C1_DR = saddr << 1;               // address + write

  timeout = 60000;
  while(timeout) {
    if(I2C1_SR1 & 2) {
      tmp = I2C1_SR2;                 // clear ADDR
      return 1;
    }
    if(I2C1_SR1 & 0x0400) {
      I2C1_SR1 &= ~0x0400;            // clear AF
      I2C1_CR1 |= 0x0200;             // STOP
      return 0;
    }
    timeout--;
  }

  I2C1_CR1 |= 0x0200;
  return 0;
}

unsigned short I2C1_ReadByte_Reg(unsigned short saddr,
                                 unsigned short reg_addr,
                                 unsigned short *value) {
  volatile unsigned int tmp;

  if(!I2C1_WaitWhileBusy()) return 0;
  I2C1_CR1 &= ~0x0800;

  if(!I2C1_Start_WriteAddr(saddr)) return 0;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_DR = reg_addr;
  if(!I2C1_WaitTXE()) return 0;

  I2C1_CR1 |= 0x0100;                 // repeated START
  {
    unsigned long timeout = 60000;
    while(!(I2C1_SR1 & 1) && timeout) timeout--;
    if(timeout == 0) return 0;
  }

  I2C1_DR = (saddr << 1) | 1;         // address + read
  {
    unsigned long timeout = 60000;
    while(timeout) {
      if(I2C1_SR1 & 2) break;
      if(I2C1_SR1 & 0x0400) {
        I2C1_SR1 &= ~0x0400;
        I2C1_CR1 |= 0x0200;
        return 0;
      }
      timeout--;
    }
    if(timeout == 0) {
      I2C1_CR1 |= 0x0200;
      return 0;
    }
  }

  I2C1_CR1 &= ~0x0400;                // ACK disable
  tmp = I2C1_SR2;                     // clear ADDR
  I2C1_CR1 |= 0x0200;                 // STOP

  if(!I2C1_WaitRXNE()) return 0;
  *value = I2C1_DR;
  return 1;
}

unsigned short I2C1_WriteByte_Reg(unsigned short saddr,
                                  unsigned short reg_addr,
                                  unsigned short value) {
  if(!I2C1_WaitWhileBusy()) return 0;
  if(!I2C1_Start_WriteAddr(saddr)) return 0;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_DR = reg_addr;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_DR = value;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_CR1 |= 0x0200;                 // STOP
  return 1;
}

unsigned short I2C1_BurstRead(unsigned short saddr,
                              unsigned short start_reg,
                              unsigned short count,
                              unsigned short data_buf[]) {
  volatile unsigned int tmp;
  unsigned short i;

  if(!I2C1_WaitWhileBusy()) return 0;

  I2C1_CR1 &= ~0x0800;
  if(!I2C1_Start_WriteAddr(saddr)) return 0;

  if(!I2C1_WaitTXE()) return 0;
  I2C1_DR = start_reg;
  if(!I2C1_WaitTXE()) return 0;

  I2C1_CR1 |= 0x0100;                 // repeated START
  {
    unsigned long timeout = 60000;
    while(!(I2C1_SR1 & 1) && timeout) timeout--;
    if(timeout == 0) return 0;
  }

  I2C1_DR = (saddr << 1) | 1;
  {
    unsigned long timeout = 60000;
    while(timeout) {
      if(I2C1_SR1 & 2) break;
      if(I2C1_SR1 & 0x0400) {
        I2C1_SR1 &= ~0x0400;
        I2C1_CR1 |= 0x0200;
        return 0;
      }
      timeout--;
    }
    if(timeout == 0) {
      I2C1_CR1 |= 0x0200;
      return 0;
    }
  }

  tmp = I2C1_SR2;                     // clear ADDR
  I2C1_CR1 |= 0x0400;                 // ACK enable

  for(i = 0; i < count; i++) {
    if(i == (count - 1)) {
      I2C1_CR1 &= ~0x0400;
      I2C1_CR1 |=  0x0200;
    }

    if(!I2C1_WaitRXNE()) return 0;
    data_buf[i] = I2C1_DR;
  }

  return 1;
}

// --------------------------------------------------
// LIS2DW12
// --------------------------------------------------
unsigned short LIS2DW12_Detect() {
  if(!I2C1_ReadByte_Reg(LIS2DW12_ADDR, REG_WHO_AM_I, &who_reg)) return 0;
  if(who_reg != 0x44) return 0;
  return 1;
}

unsigned short LIS2DW12_Init() {
  // CTRL1 = 0x54 -> 100 Hz, high performance
  // CTRL2 = 0x0C -> BDU + auto increment
  // CTRL6 = 0x00 -> FS = 2g
  if(!I2C1_WriteByte_Reg(LIS2DW12_ADDR, REG_CTRL1, 0x54)) return 0;
  if(!I2C1_WriteByte_Reg(LIS2DW12_ADDR, REG_CTRL2, 0x0C)) return 0;
  if(!I2C1_WriteByte_Reg(LIS2DW12_ADDR, REG_CTRL6, 0x00)) return 0;

  return 1;
}

unsigned short LIS2DW12_ReadAll() {
  if(!I2C1_ReadByte_Reg(LIS2DW12_ADDR, REG_WHO_AM_I, &who_reg)) return 0;
  if(!I2C1_ReadByte_Reg(LIS2DW12_ADDR, REG_STATUS, &status_reg)) return 0;

  if(!I2C1_BurstRead(LIS2DW12_ADDR, REG_OUT_T_L, 2, temp_buf)) return 0;
  if(!I2C1_BurstRead(LIS2DW12_ADDR, REG_OUT_X_L, 6, xyz_buf)) return 0;

  temp_raw = MakeSigned16(temp_buf[0], temp_buf[1]);
  x_raw    = MakeSigned16(xyz_buf[0], xyz_buf[1]);
  y_raw    = MakeSigned16(xyz_buf[2], xyz_buf[3]);
  z_raw    = MakeSigned16(xyz_buf[4], xyz_buf[5]);

  // Temperature: raw/256 + 25
  temp_c_x10 = ((temp_raw * 10L) / 256L) + 250L;

  // FS=2g sensitivity = 0.244 mg/LSB
  x_mg = (x_raw * 244L) / 1000L;
  y_mg = (y_raw * 244L) / 1000L;
  z_mg = (z_raw * 244L) / 1000L;

  return 1;
}

// --------------------------------------------------
// LCD pages
// --------------------------------------------------
void ShowPage1() {
  char who_txt[5];
  char st_txt[5];

  ByteToHex(who_reg, who_txt);
  ByteToHex(status_reg, st_txt);

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "WHO=");
  Lcd_Out(1, 5, who_txt);
  Lcd_Out(2, 1, "STS=");
  Lcd_Out(2, 5, st_txt);
}

void ShowLivePageXYZT() {
  char num_txt[12];
  signed long xs, ys, zs;
  signed long ti;

  // smaller scale for x,y,z
  xs = x_mg / 10;
  ys = y_mg / 10;
  zs = z_mg / 10;

  // integer temperature only
  ti = temp_c_x10 / 10;

  Lcd_Cmd(_LCD_CLEAR);

  SIntToStr(xs, num_txt);
  Lcd_Out(1, 1, "X=");
  Lcd_Out(1, 3, num_txt);

  SIntToStr(ys, num_txt);
  Lcd_Out(1, 9, "Y=");
  Lcd_Out(1, 11, num_txt);

  SIntToStr(zs, num_txt);
  Lcd_Out(2, 1, "Z=");
  Lcd_Out(2, 3, num_txt);

  SIntToStr(ti, num_txt);
  Lcd_Out(2, 9, "T=");
  Lcd_Out(2, 11, num_txt);
}

// --------------------------------------------------
// Main
// --------------------------------------------------
void main() {
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1, 1, "LIS2DW12 TEST");
  Lcd_Out(2, 1, "Init I2C...");
  delayMs(1000);

  I2C1_HW_Init();

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "Detect IMU...");
  Lcd_Out(2, 1, "Addr 0x19");
  delayMs(800);

  if(!LIS2DW12_Detect()) {
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Out(1, 1, "IMU NOT FOUND");
    Lcd_Out(2, 1, "CHK 0x19/WIRE");
    while(1);
  }

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "WHO_AM_I OK");
  Lcd_Out(2, 1, "Init IMU...");
  delayMs(800);

  if(!LIS2DW12_Init()) {
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Out(1, 1, "IMU INIT FAIL");
    Lcd_Out(2, 1, "CTRL write err");
    while(1);
  }

  // show first page once
  if(!LIS2DW12_ReadAll()) {
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Out(1, 1, "IMU READ FAIL");
    Lcd_Out(2, 1, "CHK BUS");
    while(1);
  }

  ShowPage1();
  delayMs(1500);

  // live page forever
  while(1) {
    if(!LIS2DW12_ReadAll()) {
      Lcd_Cmd(_LCD_CLEAR);
      Lcd_Out(1, 1, "IMU READ FAIL");
      Lcd_Out(2, 1, "CHK BUS");
      while(1);
    }

    ShowLivePageXYZT();
    delayMs(200);
  }
}