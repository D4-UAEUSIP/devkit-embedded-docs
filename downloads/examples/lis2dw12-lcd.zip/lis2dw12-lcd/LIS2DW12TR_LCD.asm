_delayMs:
;LIS2DW12TR_LCD.c,84 :: 		void delayMs(unsigned int n) {
; n start address is: 0 (R0)
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;LIS2DW12TR_LCD.c,86 :: 		for(; n > 0; n--) {
L_delayMs0:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs1
;LIS2DW12TR_LCD.c,87 :: 		for(i = 0; i < 3195; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs3:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
MOVW	R1, #3195
CMP	R2, R1
IT	CS
BCS	L_delayMs4
;LIS2DW12TR_LCD.c,88 :: 		asm nop;
NOP
;LIS2DW12TR_LCD.c,87 :: 		for(i = 0; i < 3195; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;LIS2DW12TR_LCD.c,89 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs3
L_delayMs4:
;LIS2DW12TR_LCD.c,86 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;LIS2DW12TR_LCD.c,90 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs0
L_delayMs1:
;LIS2DW12TR_LCD.c,91 :: 		}
L_end_delayMs:
BX	LR
; end of _delayMs
_HexDigit:
;LIS2DW12TR_LCD.c,96 :: 		char HexDigit(unsigned short v) {
; v start address is: 0 (R0)
; v end address is: 0 (R0)
; v start address is: 0 (R0)
;LIS2DW12TR_LCD.c,97 :: 		if(v < 10) return '0' + v;
CMP	R0, #10
IT	CS
BCS	L_HexDigit6
ADDW	R1, R0, #48
; v end address is: 0 (R0)
UXTB	R0, R1
IT	AL
BAL	L_end_HexDigit
L_HexDigit6:
;LIS2DW12TR_LCD.c,98 :: 		return 'A' + (v - 10);
; v start address is: 0 (R0)
SUBW	R1, R0, #10
SXTH	R1, R1
; v end address is: 0 (R0)
ADDS	R1, #65
UXTB	R0, R1
;LIS2DW12TR_LCD.c,99 :: 		}
L_end_HexDigit:
BX	LR
; end of _HexDigit
_ByteToHex:
;LIS2DW12TR_LCD.c,101 :: 		void ByteToHex(unsigned short value, char *out) {
; out start address is: 4 (R1)
; value start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
UXTB	R4, R0
MOV	R5, R1
; out end address is: 4 (R1)
; value end address is: 0 (R0)
; value start address is: 16 (R4)
; out start address is: 20 (R5)
;LIS2DW12TR_LCD.c,102 :: 		out[0] = '0';
MOVS	R2, #48
STRB	R2, [R5, #0]
;LIS2DW12TR_LCD.c,103 :: 		out[1] = 'x';
ADDS	R3, R5, #1
MOVS	R2, #120
STRB	R2, [R3, #0]
;LIS2DW12TR_LCD.c,104 :: 		out[2] = HexDigit((value >> 4) & 0x0F);
ADDS	R2, R5, #2
STR	R2, [SP, #4]
LSRS	R2, R4, #4
UXTB	R2, R2
AND	R2, R2, #15
UXTB	R0, R2
BL	_HexDigit+0
LDR	R2, [SP, #4]
STRB	R0, [R2, #0]
;LIS2DW12TR_LCD.c,105 :: 		out[3] = HexDigit(value & 0x0F);
ADDS	R2, R5, #3
STR	R2, [SP, #4]
AND	R2, R4, #15
; value end address is: 16 (R4)
UXTB	R0, R2
BL	_HexDigit+0
LDR	R2, [SP, #4]
STRB	R0, [R2, #0]
;LIS2DW12TR_LCD.c,106 :: 		out[4] = 0;
ADDS	R3, R5, #4
; out end address is: 20 (R5)
MOVS	R2, #0
STRB	R2, [R3, #0]
;LIS2DW12TR_LCD.c,107 :: 		}
L_end_ByteToHex:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _ByteToHex
_SIntToStr:
;LIS2DW12TR_LCD.c,109 :: 		void SIntToStr(signed long value, char *out) {
; out start address is: 4 (R1)
; value start address is: 0 (R0)
SUB	SP, SP, #16
MOV	R4, R0
; out end address is: 4 (R1)
; value end address is: 0 (R0)
; value start address is: 16 (R4)
; out start address is: 4 (R1)
;LIS2DW12TR_LCD.c,112 :: 		unsigned short i = 0;
; i start address is: 0 (R0)
MOVS	R0, #0
;LIS2DW12TR_LCD.c,113 :: 		unsigned short j = 0;
; j start address is: 20 (R5)
MOVS	R5, #0
;LIS2DW12TR_LCD.c,115 :: 		if(value == 0) {
CMP	R4, #0
IT	NE
BNE	L_SIntToStr7
; value end address is: 16 (R4)
; i end address is: 0 (R0)
; j end address is: 20 (R5)
;LIS2DW12TR_LCD.c,116 :: 		out[0] = '0';
MOVS	R2, #48
STRB	R2, [R1, #0]
;LIS2DW12TR_LCD.c,117 :: 		out[1] = 0;
ADDS	R3, R1, #1
; out end address is: 4 (R1)
MOVS	R2, #0
STRB	R2, [R3, #0]
;LIS2DW12TR_LCD.c,118 :: 		return;
IT	AL
BAL	L_end_SIntToStr
;LIS2DW12TR_LCD.c,119 :: 		}
L_SIntToStr7:
;LIS2DW12TR_LCD.c,121 :: 		if(value < 0) {
; out start address is: 4 (R1)
; j start address is: 20 (R5)
; i start address is: 0 (R0)
; value start address is: 16 (R4)
CMP	R4, #0
IT	GE
BGE	L_SIntToStr8
;LIS2DW12TR_LCD.c,122 :: 		out[j++] = '-';
ADDS	R3, R1, R5
MOVS	R2, #45
STRB	R2, [R3, #0]
ADDS	R2, R5, #1
; j end address is: 20 (R5)
; j start address is: 12 (R3)
UXTB	R3, R2
;LIS2DW12TR_LCD.c,123 :: 		absval = (unsigned long)(-value);
RSBS	R2, R4, #0
; value end address is: 16 (R4)
; absval start address is: 8 (R2)
MOV	R2, R2
;LIS2DW12TR_LCD.c,124 :: 		} else {
MOV	R5, R2
; j end address is: 12 (R3)
; absval end address is: 8 (R2)
UXTB	R2, R3
IT	AL
BAL	L_SIntToStr9
L_SIntToStr8:
;LIS2DW12TR_LCD.c,125 :: 		absval = (unsigned long)value;
; absval start address is: 8 (R2)
; j start address is: 20 (R5)
; value start address is: 16 (R4)
MOV	R2, R4
; value end address is: 16 (R4)
; j end address is: 20 (R5)
; absval end address is: 8 (R2)
STR	R2, [SP, #0]
UXTB	R2, R5
LDR	R5, [SP, #0]
;LIS2DW12TR_LCD.c,126 :: 		}
L_SIntToStr9:
;LIS2DW12TR_LCD.c,128 :: 		while(absval > 0) {
; absval start address is: 20 (R5)
; j start address is: 8 (R2)
; i end address is: 0 (R0)
; j end address is: 8 (R2)
; out end address is: 4 (R1)
; absval end address is: 20 (R5)
UXTB	R6, R0
UXTB	R0, R2
L_SIntToStr10:
; j start address is: 0 (R0)
; absval start address is: 20 (R5)
; i start address is: 24 (R6)
; out start address is: 4 (R1)
CMP	R5, #0
IT	LS
BLS	L_SIntToStr11
;LIS2DW12TR_LCD.c,129 :: 		tmp[i++] = (absval % 10) + '0';
ADD	R2, SP, #4
ADDS	R4, R2, R6
MOVS	R3, #10
UDIV	R2, R5, R3
MLS	R2, R3, R2, R5
ADDS	R2, #48
STRB	R2, [R4, #0]
ADDS	R6, R6, #1
UXTB	R6, R6
;LIS2DW12TR_LCD.c,130 :: 		absval /= 10;
MOVS	R2, #10
UDIV	R5, R5, R2
;LIS2DW12TR_LCD.c,131 :: 		}
; absval end address is: 20 (R5)
IT	AL
BAL	L_SIntToStr10
L_SIntToStr11:
;LIS2DW12TR_LCD.c,133 :: 		while(i > 0) {
STR	R1, [SP, #0]
; out end address is: 4 (R1)
; i end address is: 24 (R6)
UXTB	R1, R0
UXTB	R5, R6
LDR	R0, [SP, #0]
L_SIntToStr12:
; j end address is: 0 (R0)
; out start address is: 0 (R0)
; i start address is: 20 (R5)
; j start address is: 4 (R1)
CMP	R5, #0
IT	LS
BLS	L_SIntToStr13
;LIS2DW12TR_LCD.c,134 :: 		out[j++] = tmp[--i];
ADDS	R4, R0, R1
SUBS	R3, R5, #1
UXTB	R3, R3
UXTB	R5, R3
ADD	R2, SP, #4
ADDS	R2, R2, R3
LDRB	R2, [R2, #0]
STRB	R2, [R4, #0]
ADDS	R1, R1, #1
UXTB	R1, R1
;LIS2DW12TR_LCD.c,135 :: 		}
; i end address is: 20 (R5)
IT	AL
BAL	L_SIntToStr12
L_SIntToStr13:
;LIS2DW12TR_LCD.c,137 :: 		out[j] = 0;
ADDS	R3, R0, R1
; out end address is: 0 (R0)
; j end address is: 4 (R1)
MOVS	R2, #0
STRB	R2, [R3, #0]
;LIS2DW12TR_LCD.c,138 :: 		}
L_end_SIntToStr:
ADD	SP, SP, #16
BX	LR
; end of _SIntToStr
_MakeSigned16:
;LIS2DW12TR_LCD.c,140 :: 		signed int MakeSigned16(unsigned short lo, unsigned short hi) {
; hi start address is: 4 (R1)
; lo start address is: 0 (R0)
; hi end address is: 4 (R1)
; lo end address is: 0 (R0)
; lo start address is: 0 (R0)
; hi start address is: 4 (R1)
;LIS2DW12TR_LCD.c,143 :: 		v = ((unsigned int)hi << 8) | lo;
UXTB	R2, R1
; hi end address is: 4 (R1)
LSLS	R2, R2, #8
UXTH	R2, R2
ORR	R3, R2, R0, LSL #0
UXTH	R3, R3
; lo end address is: 0 (R0)
; v start address is: 0 (R0)
UXTH	R0, R3
;LIS2DW12TR_LCD.c,145 :: 		if(v > 32767)
MOVW	R2, #32767
CMP	R3, R2
IT	LS
BLS	L_MakeSigned1614
;LIS2DW12TR_LCD.c,146 :: 		return (signed int)(v - 65536);
SUB	R2, R0, #65536
; v end address is: 0 (R0)
SXTH	R0, R2
IT	AL
BAL	L_end_MakeSigned16
L_MakeSigned1614:
;LIS2DW12TR_LCD.c,148 :: 		return (signed int)v;
; v start address is: 0 (R0)
SXTH	R0, R0
; v end address is: 0 (R0)
;LIS2DW12TR_LCD.c,149 :: 		}
L_end_MakeSigned16:
BX	LR
; end of _MakeSigned16
_I2C1_HW_Init:
;LIS2DW12TR_LCD.c,154 :: 		void I2C1_HW_Init() {
;LIS2DW12TR_LCD.c,155 :: 		RCC_AHB1ENR |= 0x00000002;      // GPIOB clock enable
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,156 :: 		RCC_APB1ENR |= 0x00200000;      // I2C1 clock enable
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2097152
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,158 :: 		GPIOB_AFRH &= ~0x000000FF;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
AND	R1, R0, #0
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,159 :: 		GPIOB_AFRH |=  0x00000044;      // PB8, PB9 -> AF4
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #68
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,161 :: 		GPIOB_MODER &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,162 :: 		GPIOB_MODER |=  0x000A0000;     // alternate function
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #655360
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,164 :: 		GPIOB_OTYPER |= 0x00000300;     // open drain
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #768
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,166 :: 		GPIOB_PUPDR &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,167 :: 		GPIOB_PUPDR |=  0x00050000;     // pull-up
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #327680
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,169 :: 		I2C1_CR1 = 0x8000;              // software reset
MOVW	R1, #32768
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,170 :: 		I2C1_CR1 &= ~0x8000;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R1, [R0, #0]
MOVW	R0, #32767
ANDS	R1, R0
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,172 :: 		I2C1_CR2 = 16;                  // APB1 = 16 MHz
MOVS	R1, #16
MOVW	R0, #lo_addr(I2C1_CR2+0)
MOVT	R0, #hi_addr(I2C1_CR2+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,173 :: 		I2C1_CCR = 80;                  // 100 kHz
MOVS	R1, #80
MOVW	R0, #lo_addr(I2C1_CCR+0)
MOVT	R0, #hi_addr(I2C1_CCR+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,174 :: 		I2C1_TRISE = 17;
MOVS	R1, #17
MOVW	R0, #lo_addr(I2C1_TRISE+0)
MOVT	R0, #hi_addr(I2C1_TRISE+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,176 :: 		I2C1_CR1 |= 0x0001;             // enable I2C1
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,177 :: 		}
L_end_I2C1_HW_Init:
BX	LR
; end of _I2C1_HW_Init
_I2C1_WaitWhileBusy:
;LIS2DW12TR_LCD.c,182 :: 		unsigned short I2C1_WaitWhileBusy() {
;LIS2DW12TR_LCD.c,183 :: 		unsigned long timeout = 60000;
; timeout start address is: 4 (R1)
MOVW	R1, #60000
MOVT	R1, #0
; timeout end address is: 4 (R1)
;LIS2DW12TR_LCD.c,184 :: 		while((I2C1_SR2 & 2) && timeout) timeout--;
L_I2C1_WaitWhileBusy16:
; timeout start address is: 4 (R1)
MOVW	R0, #lo_addr(I2C1_SR2+0)
MOVT	R0, #hi_addr(I2C1_SR2+0)
LDR	R0, [R0, #0]
AND	R0, R0, #2
CMP	R0, #0
IT	EQ
BEQ	L__I2C1_WaitWhileBusy101
CMP	R1, #0
IT	EQ
BEQ	L__I2C1_WaitWhileBusy100
L__I2C1_WaitWhileBusy99:
SUBS	R1, R1, #1
IT	AL
BAL	L_I2C1_WaitWhileBusy16
L__I2C1_WaitWhileBusy101:
L__I2C1_WaitWhileBusy100:
;LIS2DW12TR_LCD.c,185 :: 		return (timeout != 0);
CMP	R1, #0
MOVW	R0, #0
BEQ	L__I2C1_WaitWhileBusy124
MOVS	R0, #1
L__I2C1_WaitWhileBusy124:
; timeout end address is: 4 (R1)
UXTB	R0, R0
;LIS2DW12TR_LCD.c,186 :: 		}
L_end_I2C1_WaitWhileBusy:
BX	LR
; end of _I2C1_WaitWhileBusy
_I2C1_WaitTXE:
;LIS2DW12TR_LCD.c,188 :: 		unsigned short I2C1_WaitTXE() {
;LIS2DW12TR_LCD.c,189 :: 		unsigned long timeout = 60000;
; timeout start address is: 4 (R1)
MOVW	R1, #60000
MOVT	R1, #0
; timeout end address is: 4 (R1)
;LIS2DW12TR_LCD.c,190 :: 		while(!(I2C1_SR1 & 0x80) && timeout) timeout--;
L_I2C1_WaitTXE20:
; timeout start address is: 4 (R1)
MOVW	R0, #lo_addr(I2C1_SR1+0)
MOVT	R0, #hi_addr(I2C1_SR1+0)
LDR	R0, [R0, #0]
AND	R0, R0, #128
CMP	R0, #0
IT	NE
BNE	L__I2C1_WaitTXE104
CMP	R1, #0
IT	EQ
BEQ	L__I2C1_WaitTXE103
L__I2C1_WaitTXE102:
SUBS	R1, R1, #1
IT	AL
BAL	L_I2C1_WaitTXE20
L__I2C1_WaitTXE104:
L__I2C1_WaitTXE103:
;LIS2DW12TR_LCD.c,191 :: 		return (timeout != 0);
CMP	R1, #0
MOVW	R0, #0
BEQ	L__I2C1_WaitTXE126
MOVS	R0, #1
L__I2C1_WaitTXE126:
; timeout end address is: 4 (R1)
UXTB	R0, R0
;LIS2DW12TR_LCD.c,192 :: 		}
L_end_I2C1_WaitTXE:
BX	LR
; end of _I2C1_WaitTXE
_I2C1_WaitRXNE:
;LIS2DW12TR_LCD.c,194 :: 		unsigned short I2C1_WaitRXNE() {
;LIS2DW12TR_LCD.c,195 :: 		unsigned long timeout = 60000;
; timeout start address is: 4 (R1)
MOVW	R1, #60000
MOVT	R1, #0
; timeout end address is: 4 (R1)
;LIS2DW12TR_LCD.c,196 :: 		while(!(I2C1_SR1 & 0x40) && timeout) timeout--;
L_I2C1_WaitRXNE24:
; timeout start address is: 4 (R1)
MOVW	R0, #lo_addr(I2C1_SR1+0)
MOVT	R0, #hi_addr(I2C1_SR1+0)
LDR	R0, [R0, #0]
AND	R0, R0, #64
CMP	R0, #0
IT	NE
BNE	L__I2C1_WaitRXNE107
CMP	R1, #0
IT	EQ
BEQ	L__I2C1_WaitRXNE106
L__I2C1_WaitRXNE105:
SUBS	R1, R1, #1
IT	AL
BAL	L_I2C1_WaitRXNE24
L__I2C1_WaitRXNE107:
L__I2C1_WaitRXNE106:
;LIS2DW12TR_LCD.c,197 :: 		return (timeout != 0);
CMP	R1, #0
MOVW	R0, #0
BEQ	L__I2C1_WaitRXNE128
MOVS	R0, #1
L__I2C1_WaitRXNE128:
; timeout end address is: 4 (R1)
UXTB	R0, R0
;LIS2DW12TR_LCD.c,198 :: 		}
L_end_I2C1_WaitRXNE:
BX	LR
; end of _I2C1_WaitRXNE
_I2C1_Start_WriteAddr:
;LIS2DW12TR_LCD.c,200 :: 		unsigned short I2C1_Start_WriteAddr(unsigned short saddr) {
; saddr start address is: 0 (R0)
; saddr end address is: 0 (R0)
; saddr start address is: 0 (R0)
;LIS2DW12TR_LCD.c,204 :: 		I2C1_CR1 |= 0x0100;                 // START
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #256
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,205 :: 		timeout = 60000;
; timeout start address is: 8 (R2)
MOVW	R2, #60000
; saddr end address is: 0 (R0)
; timeout end address is: 8 (R2)
;LIS2DW12TR_LCD.c,206 :: 		while(!(I2C1_SR1 & 1) && timeout) timeout--;
L_I2C1_Start_WriteAddr28:
; timeout start address is: 8 (R2)
; saddr start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #1
CMP	R1, #0
IT	NE
BNE	L__I2C1_Start_WriteAddr110
CMP	R2, #0
IT	EQ
BEQ	L__I2C1_Start_WriteAddr109
L__I2C1_Start_WriteAddr108:
SUBS	R2, R2, #1
IT	AL
BAL	L_I2C1_Start_WriteAddr28
L__I2C1_Start_WriteAddr110:
L__I2C1_Start_WriteAddr109:
;LIS2DW12TR_LCD.c,207 :: 		if(timeout == 0) return 0;
CMP	R2, #0
IT	NE
BNE	L_I2C1_Start_WriteAddr32
; saddr end address is: 0 (R0)
; timeout end address is: 8 (R2)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_Start_WriteAddr
L_I2C1_Start_WriteAddr32:
;LIS2DW12TR_LCD.c,209 :: 		I2C1_DR = saddr << 1;               // address + write
; saddr start address is: 0 (R0)
LSLS	R2, R0, #1
UXTH	R2, R2
; saddr end address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_DR+0)
MOVT	R1, #hi_addr(I2C1_DR+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,211 :: 		timeout = 60000;
; timeout start address is: 0 (R0)
MOVW	R0, #60000
; timeout end address is: 0 (R0)
;LIS2DW12TR_LCD.c,212 :: 		while(timeout) {
L_I2C1_Start_WriteAddr33:
; timeout start address is: 0 (R0)
CMP	R0, #0
IT	EQ
BEQ	L_I2C1_Start_WriteAddr34
;LIS2DW12TR_LCD.c,213 :: 		if(I2C1_SR1 & 2) {
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #2
CMP	R1, #0
IT	EQ
BEQ	L_I2C1_Start_WriteAddr35
; timeout end address is: 0 (R0)
;LIS2DW12TR_LCD.c,214 :: 		tmp = I2C1_SR2;                 // clear ADDR
MOVW	R1, #lo_addr(I2C1_SR2+0)
MOVT	R1, #hi_addr(I2C1_SR2+0)
; tmp start address is: 4 (R1)
LDR	R1, [R1, #0]
; tmp end address is: 4 (R1)
;LIS2DW12TR_LCD.c,215 :: 		return 1;
MOVS	R0, #1
IT	AL
BAL	L_end_I2C1_Start_WriteAddr
;LIS2DW12TR_LCD.c,216 :: 		}
L_I2C1_Start_WriteAddr35:
;LIS2DW12TR_LCD.c,217 :: 		if(I2C1_SR1 & 0x0400) {
; timeout start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #1024
CMP	R1, #0
IT	EQ
BEQ	L_I2C1_Start_WriteAddr36
; timeout end address is: 0 (R0)
;LIS2DW12TR_LCD.c,218 :: 		I2C1_SR1 &= ~0x0400;            // clear AF
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R2, [R1, #0]
MVN	R1, #1024
ANDS	R2, R1
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,219 :: 		I2C1_CR1 |= 0x0200;             // STOP
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #512
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,220 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_Start_WriteAddr
;LIS2DW12TR_LCD.c,221 :: 		}
L_I2C1_Start_WriteAddr36:
;LIS2DW12TR_LCD.c,222 :: 		timeout--;
; timeout start address is: 0 (R0)
SUBS	R0, R0, #1
;LIS2DW12TR_LCD.c,223 :: 		}
; timeout end address is: 0 (R0)
IT	AL
BAL	L_I2C1_Start_WriteAddr33
L_I2C1_Start_WriteAddr34:
;LIS2DW12TR_LCD.c,225 :: 		I2C1_CR1 |= 0x0200;
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #512
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,226 :: 		return 0;
MOVS	R0, #0
;LIS2DW12TR_LCD.c,227 :: 		}
L_end_I2C1_Start_WriteAddr:
BX	LR
; end of _I2C1_Start_WriteAddr
_I2C1_ReadByte_Reg:
;LIS2DW12TR_LCD.c,231 :: 		unsigned short *value) {
; value start address is: 8 (R2)
; reg_addr start address is: 4 (R1)
; saddr start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R5, R0
UXTB	R7, R1
MOV	R6, R2
; value end address is: 8 (R2)
; reg_addr end address is: 4 (R1)
; saddr end address is: 0 (R0)
; saddr start address is: 20 (R5)
; reg_addr start address is: 28 (R7)
; value start address is: 24 (R6)
;LIS2DW12TR_LCD.c,234 :: 		if(!I2C1_WaitWhileBusy()) return 0;
BL	_I2C1_WaitWhileBusy+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_ReadByte_Reg37
; saddr end address is: 20 (R5)
; reg_addr end address is: 28 (R7)
; value end address is: 24 (R6)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
L_I2C1_ReadByte_Reg37:
;LIS2DW12TR_LCD.c,235 :: 		I2C1_CR1 &= ~0x0800;
; value start address is: 24 (R6)
; reg_addr start address is: 28 (R7)
; saddr start address is: 20 (R5)
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R4, [R3, #0]
MVN	R3, #2048
ANDS	R4, R3
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,237 :: 		if(!I2C1_Start_WriteAddr(saddr)) return 0;
UXTB	R0, R5
BL	_I2C1_Start_WriteAddr+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_ReadByte_Reg38
; saddr end address is: 20 (R5)
; reg_addr end address is: 28 (R7)
; value end address is: 24 (R6)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
L_I2C1_ReadByte_Reg38:
;LIS2DW12TR_LCD.c,239 :: 		if(!I2C1_WaitTXE()) return 0;
; value start address is: 24 (R6)
; reg_addr start address is: 28 (R7)
; saddr start address is: 20 (R5)
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_ReadByte_Reg39
; saddr end address is: 20 (R5)
; reg_addr end address is: 28 (R7)
; value end address is: 24 (R6)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
L_I2C1_ReadByte_Reg39:
;LIS2DW12TR_LCD.c,240 :: 		I2C1_DR = reg_addr;
; value start address is: 24 (R6)
; reg_addr start address is: 28 (R7)
; saddr start address is: 20 (R5)
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R7, [R3, #0]
; reg_addr end address is: 28 (R7)
;LIS2DW12TR_LCD.c,241 :: 		if(!I2C1_WaitTXE()) return 0;
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_ReadByte_Reg40
; saddr end address is: 20 (R5)
; value end address is: 24 (R6)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
L_I2C1_ReadByte_Reg40:
;LIS2DW12TR_LCD.c,243 :: 		I2C1_CR1 |= 0x0100;                 // repeated START
; value start address is: 24 (R6)
; saddr start address is: 20 (R5)
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #256
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,245 :: 		unsigned long timeout = 60000;
; timeout start address is: 16 (R4)
MOVW	R4, #60000
MOVT	R4, #0
; saddr end address is: 20 (R5)
; value end address is: 24 (R6)
; timeout end address is: 16 (R4)
UXTB	R2, R5
MOV	R0, R6
;LIS2DW12TR_LCD.c,246 :: 		while(!(I2C1_SR1 & 1) && timeout) timeout--;
L_I2C1_ReadByte_Reg41:
; timeout start address is: 16 (R4)
; value start address is: 0 (R0)
; saddr start address is: 8 (R2)
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #1
CMP	R3, #0
IT	NE
BNE	L__I2C1_ReadByte_Reg113
CMP	R4, #0
IT	EQ
BEQ	L__I2C1_ReadByte_Reg112
L__I2C1_ReadByte_Reg111:
SUBS	R4, R4, #1
IT	AL
BAL	L_I2C1_ReadByte_Reg41
L__I2C1_ReadByte_Reg113:
L__I2C1_ReadByte_Reg112:
;LIS2DW12TR_LCD.c,247 :: 		if(timeout == 0) return 0;
CMP	R4, #0
IT	NE
BNE	L_I2C1_ReadByte_Reg45
; value end address is: 0 (R0)
; saddr end address is: 8 (R2)
; timeout end address is: 16 (R4)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
L_I2C1_ReadByte_Reg45:
;LIS2DW12TR_LCD.c,250 :: 		I2C1_DR = (saddr << 1) | 1;         // address + read
; saddr start address is: 8 (R2)
; value start address is: 0 (R0)
LSLS	R3, R2, #1
UXTH	R3, R3
; saddr end address is: 8 (R2)
ORR	R4, R3, #1
UXTH	R4, R4
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,252 :: 		unsigned long timeout = 60000;
; timeout start address is: 4 (R1)
MOVW	R1, #60000
MOVT	R1, #0
; value end address is: 0 (R0)
; timeout end address is: 4 (R1)
MOV	R2, R0
MOV	R0, R1
;LIS2DW12TR_LCD.c,253 :: 		while(timeout) {
L_I2C1_ReadByte_Reg46:
; timeout start address is: 0 (R0)
; value start address is: 8 (R2)
CMP	R0, #0
IT	EQ
BEQ	L_I2C1_ReadByte_Reg47
;LIS2DW12TR_LCD.c,254 :: 		if(I2C1_SR1 & 2) break;
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #2
CMP	R3, #0
IT	EQ
BEQ	L_I2C1_ReadByte_Reg48
IT	AL
BAL	L_I2C1_ReadByte_Reg47
L_I2C1_ReadByte_Reg48:
;LIS2DW12TR_LCD.c,255 :: 		if(I2C1_SR1 & 0x0400) {
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R3, [R3, #0]
AND	R3, R3, #1024
CMP	R3, #0
IT	EQ
BEQ	L_I2C1_ReadByte_Reg49
; value end address is: 8 (R2)
; timeout end address is: 0 (R0)
;LIS2DW12TR_LCD.c,256 :: 		I2C1_SR1 &= ~0x0400;
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
LDR	R4, [R3, #0]
MVN	R3, #1024
ANDS	R4, R3
MOVW	R3, #lo_addr(I2C1_SR1+0)
MOVT	R3, #hi_addr(I2C1_SR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,257 :: 		I2C1_CR1 |= 0x0200;
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #512
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,258 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
;LIS2DW12TR_LCD.c,259 :: 		}
L_I2C1_ReadByte_Reg49:
;LIS2DW12TR_LCD.c,260 :: 		timeout--;
; timeout start address is: 0 (R0)
; value start address is: 8 (R2)
SUBS	R0, R0, #1
;LIS2DW12TR_LCD.c,261 :: 		}
IT	AL
BAL	L_I2C1_ReadByte_Reg46
L_I2C1_ReadByte_Reg47:
;LIS2DW12TR_LCD.c,262 :: 		if(timeout == 0) {
CMP	R0, #0
IT	NE
BNE	L_I2C1_ReadByte_Reg50
; value end address is: 8 (R2)
; timeout end address is: 0 (R0)
;LIS2DW12TR_LCD.c,263 :: 		I2C1_CR1 |= 0x0200;
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #512
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,264 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
;LIS2DW12TR_LCD.c,265 :: 		}
L_I2C1_ReadByte_Reg50:
;LIS2DW12TR_LCD.c,268 :: 		I2C1_CR1 &= ~0x0400;                // ACK disable
; value start address is: 8 (R2)
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R4, [R3, #0]
MVN	R3, #1024
ANDS	R4, R3
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,269 :: 		tmp = I2C1_SR2;                     // clear ADDR
MOVW	R3, #lo_addr(I2C1_SR2+0)
MOVT	R3, #hi_addr(I2C1_SR2+0)
; tmp start address is: 4 (R1)
LDR	R1, [R3, #0]
; tmp end address is: 4 (R1)
;LIS2DW12TR_LCD.c,270 :: 		I2C1_CR1 |= 0x0200;                 // STOP
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #512
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,272 :: 		if(!I2C1_WaitRXNE()) return 0;
BL	_I2C1_WaitRXNE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_ReadByte_Reg51
; value end address is: 8 (R2)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_ReadByte_Reg
L_I2C1_ReadByte_Reg51:
;LIS2DW12TR_LCD.c,273 :: 		*value = I2C1_DR;
; value start address is: 8 (R2)
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
LDR	R3, [R3, #0]
STRB	R3, [R2, #0]
; value end address is: 8 (R2)
;LIS2DW12TR_LCD.c,274 :: 		return 1;
MOVS	R0, #1
;LIS2DW12TR_LCD.c,275 :: 		}
L_end_I2C1_ReadByte_Reg:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _I2C1_ReadByte_Reg
_I2C1_WriteByte_Reg:
;LIS2DW12TR_LCD.c,279 :: 		unsigned short value) {
; value start address is: 8 (R2)
; reg_addr start address is: 4 (R1)
; saddr start address is: 0 (R0)
SUB	SP, SP, #4
STR	LR, [SP, #0]
UXTB	R5, R2
UXTB	R2, R0
UXTB	R4, R1
; value end address is: 8 (R2)
; reg_addr end address is: 4 (R1)
; saddr end address is: 0 (R0)
; saddr start address is: 8 (R2)
; reg_addr start address is: 16 (R4)
; value start address is: 20 (R5)
;LIS2DW12TR_LCD.c,280 :: 		if(!I2C1_WaitWhileBusy()) return 0;
BL	_I2C1_WaitWhileBusy+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg52
; saddr end address is: 8 (R2)
; reg_addr end address is: 16 (R4)
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg52:
;LIS2DW12TR_LCD.c,281 :: 		if(!I2C1_Start_WriteAddr(saddr)) return 0;
; value start address is: 20 (R5)
; reg_addr start address is: 16 (R4)
; saddr start address is: 8 (R2)
UXTB	R0, R2
; saddr end address is: 8 (R2)
BL	_I2C1_Start_WriteAddr+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg53
; reg_addr end address is: 16 (R4)
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg53:
;LIS2DW12TR_LCD.c,283 :: 		if(!I2C1_WaitTXE()) return 0;
; value start address is: 20 (R5)
; reg_addr start address is: 16 (R4)
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg54
; reg_addr end address is: 16 (R4)
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg54:
;LIS2DW12TR_LCD.c,284 :: 		I2C1_DR = reg_addr;
; value start address is: 20 (R5)
; reg_addr start address is: 16 (R4)
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R4, [R3, #0]
; reg_addr end address is: 16 (R4)
;LIS2DW12TR_LCD.c,286 :: 		if(!I2C1_WaitTXE()) return 0;
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg55
; value end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg55:
;LIS2DW12TR_LCD.c,287 :: 		I2C1_DR = value;
; value start address is: 20 (R5)
MOVW	R3, #lo_addr(I2C1_DR+0)
MOVT	R3, #hi_addr(I2C1_DR+0)
STR	R5, [R3, #0]
; value end address is: 20 (R5)
;LIS2DW12TR_LCD.c,289 :: 		if(!I2C1_WaitTXE()) return 0;
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_WriteByte_Reg56
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_WriteByte_Reg
L_I2C1_WriteByte_Reg56:
;LIS2DW12TR_LCD.c,290 :: 		I2C1_CR1 |= 0x0200;                 // STOP
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
LDR	R3, [R3, #0]
ORR	R4, R3, #512
MOVW	R3, #lo_addr(I2C1_CR1+0)
MOVT	R3, #hi_addr(I2C1_CR1+0)
STR	R4, [R3, #0]
;LIS2DW12TR_LCD.c,291 :: 		return 1;
MOVS	R0, #1
;LIS2DW12TR_LCD.c,292 :: 		}
L_end_I2C1_WriteByte_Reg:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _I2C1_WriteByte_Reg
_I2C1_BurstRead:
;LIS2DW12TR_LCD.c,297 :: 		unsigned short data_buf[]) {
; data_buf start address is: 12 (R3)
; count start address is: 8 (R2)
; start_reg start address is: 4 (R1)
; saddr start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
MOV	R7, R3
UXTB	R3, R0
UXTB	R8, R1
UXTB	R6, R2
; data_buf end address is: 12 (R3)
; count end address is: 8 (R2)
; start_reg end address is: 4 (R1)
; saddr end address is: 0 (R0)
; saddr start address is: 12 (R3)
; start_reg start address is: 32 (R8)
; count start address is: 24 (R6)
; data_buf start address is: 28 (R7)
;LIS2DW12TR_LCD.c,301 :: 		if(!I2C1_WaitWhileBusy()) return 0;
BL	_I2C1_WaitWhileBusy+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead57
; start_reg end address is: 32 (R8)
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead57:
;LIS2DW12TR_LCD.c,303 :: 		I2C1_CR1 &= ~0x0800;
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
; start_reg start address is: 32 (R8)
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #2048
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,304 :: 		if(!I2C1_Start_WriteAddr(saddr)) return 0;
UXTB	R0, R3
BL	_I2C1_Start_WriteAddr+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead58
; start_reg end address is: 32 (R8)
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead58:
;LIS2DW12TR_LCD.c,306 :: 		if(!I2C1_WaitTXE()) return 0;
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
; start_reg start address is: 32 (R8)
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead59
; start_reg end address is: 32 (R8)
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead59:
;LIS2DW12TR_LCD.c,307 :: 		I2C1_DR = start_reg;
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
; start_reg start address is: 32 (R8)
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R8, [R4, #0]
; start_reg end address is: 32 (R8)
;LIS2DW12TR_LCD.c,308 :: 		if(!I2C1_WaitTXE()) return 0;
BL	_I2C1_WaitTXE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead60
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; saddr end address is: 12 (R3)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead60:
;LIS2DW12TR_LCD.c,310 :: 		I2C1_CR1 |= 0x0100;                 // repeated START
; saddr start address is: 12 (R3)
; data_buf start address is: 28 (R7)
; count start address is: 24 (R6)
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #256
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,312 :: 		unsigned long timeout = 60000;
; timeout start address is: 0 (R0)
MOVW	R0, #60000
MOVT	R0, #0
; count end address is: 24 (R6)
; data_buf end address is: 28 (R7)
; timeout end address is: 0 (R0)
; saddr end address is: 12 (R3)
UXTB	R2, R6
MOV	R1, R7
MOV	R5, R0
;LIS2DW12TR_LCD.c,313 :: 		while(!(I2C1_SR1 & 1) && timeout) timeout--;
L_I2C1_BurstRead61:
; timeout start address is: 20 (R5)
; data_buf start address is: 4 (R1)
; count start address is: 8 (R2)
; saddr start address is: 12 (R3)
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1
CMP	R4, #0
IT	NE
BNE	L__I2C1_BurstRead116
CMP	R5, #0
IT	EQ
BEQ	L__I2C1_BurstRead115
L__I2C1_BurstRead114:
SUBS	R5, R5, #1
IT	AL
BAL	L_I2C1_BurstRead61
L__I2C1_BurstRead116:
L__I2C1_BurstRead115:
;LIS2DW12TR_LCD.c,314 :: 		if(timeout == 0) return 0;
CMP	R5, #0
IT	NE
BNE	L_I2C1_BurstRead65
; data_buf end address is: 4 (R1)
; count end address is: 8 (R2)
; saddr end address is: 12 (R3)
; timeout end address is: 20 (R5)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead65:
;LIS2DW12TR_LCD.c,317 :: 		I2C1_DR = (saddr << 1) | 1;
; saddr start address is: 12 (R3)
; count start address is: 8 (R2)
; data_buf start address is: 4 (R1)
LSLS	R4, R3, #1
UXTH	R4, R4
; saddr end address is: 12 (R3)
ORR	R5, R4, #1
UXTH	R5, R5
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,319 :: 		unsigned long timeout = 60000;
; timeout start address is: 12 (R3)
MOVW	R3, #60000
MOVT	R3, #0
; data_buf end address is: 4 (R1)
; count end address is: 8 (R2)
; timeout end address is: 12 (R3)
STRB	R2, [SP, #4]
MOV	R2, R1
LDRB	R1, [SP, #4]
;LIS2DW12TR_LCD.c,320 :: 		while(timeout) {
L_I2C1_BurstRead66:
; timeout start address is: 12 (R3)
; count start address is: 4 (R1)
; data_buf start address is: 8 (R2)
CMP	R3, #0
IT	EQ
BEQ	L_I2C1_BurstRead67
;LIS2DW12TR_LCD.c,321 :: 		if(I2C1_SR1 & 2) break;
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	EQ
BEQ	L_I2C1_BurstRead68
IT	AL
BAL	L_I2C1_BurstRead67
L_I2C1_BurstRead68:
;LIS2DW12TR_LCD.c,322 :: 		if(I2C1_SR1 & 0x0400) {
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1024
CMP	R4, #0
IT	EQ
BEQ	L_I2C1_BurstRead69
; count end address is: 4 (R1)
; timeout end address is: 12 (R3)
; data_buf end address is: 8 (R2)
;LIS2DW12TR_LCD.c,323 :: 		I2C1_SR1 &= ~0x0400;
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R5, [R4, #0]
MVN	R4, #1024
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,324 :: 		I2C1_CR1 |= 0x0200;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,325 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
;LIS2DW12TR_LCD.c,326 :: 		}
L_I2C1_BurstRead69:
;LIS2DW12TR_LCD.c,327 :: 		timeout--;
; data_buf start address is: 8 (R2)
; timeout start address is: 12 (R3)
; count start address is: 4 (R1)
SUBS	R3, R3, #1
;LIS2DW12TR_LCD.c,328 :: 		}
IT	AL
BAL	L_I2C1_BurstRead66
L_I2C1_BurstRead67:
;LIS2DW12TR_LCD.c,329 :: 		if(timeout == 0) {
CMP	R3, #0
IT	NE
BNE	L_I2C1_BurstRead70
; count end address is: 4 (R1)
; timeout end address is: 12 (R3)
; data_buf end address is: 8 (R2)
;LIS2DW12TR_LCD.c,330 :: 		I2C1_CR1 |= 0x0200;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,331 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
;LIS2DW12TR_LCD.c,332 :: 		}
L_I2C1_BurstRead70:
;LIS2DW12TR_LCD.c,335 :: 		tmp = I2C1_SR2;                     // clear ADDR
; data_buf start address is: 8 (R2)
; count start address is: 4 (R1)
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R4, #0]
; tmp end address is: 0 (R0)
;LIS2DW12TR_LCD.c,336 :: 		I2C1_CR1 |= 0x0400;                 // ACK enable
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #1024
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,338 :: 		for(i = 0; i < count; i++) {
; i start address is: 24 (R6)
MOVS	R6, #0
; count end address is: 4 (R1)
; i end address is: 24 (R6)
UXTB	R3, R1
L_I2C1_BurstRead71:
; i start address is: 24 (R6)
; data_buf start address is: 8 (R2)
; data_buf end address is: 8 (R2)
; count start address is: 12 (R3)
CMP	R6, R3
IT	CS
BCS	L_I2C1_BurstRead72
; data_buf end address is: 8 (R2)
;LIS2DW12TR_LCD.c,339 :: 		if(i == (count - 1)) {
; data_buf start address is: 8 (R2)
SUBS	R4, R3, #1
SXTH	R4, R4
CMP	R6, R4
IT	NE
BNE	L_I2C1_BurstRead74
;LIS2DW12TR_LCD.c,340 :: 		I2C1_CR1 &= ~0x0400;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #1024
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,341 :: 		I2C1_CR1 |=  0x0200;
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;LIS2DW12TR_LCD.c,342 :: 		}
L_I2C1_BurstRead74:
;LIS2DW12TR_LCD.c,344 :: 		if(!I2C1_WaitRXNE()) return 0;
BL	_I2C1_WaitRXNE+0
CMP	R0, #0
IT	NE
BNE	L_I2C1_BurstRead75
; data_buf end address is: 8 (R2)
; count end address is: 12 (R3)
; i end address is: 24 (R6)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_BurstRead
L_I2C1_BurstRead75:
;LIS2DW12TR_LCD.c,345 :: 		data_buf[i] = I2C1_DR;
; i start address is: 24 (R6)
; count start address is: 12 (R3)
; data_buf start address is: 8 (R2)
ADDS	R5, R2, R6
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
LDR	R4, [R4, #0]
STRB	R4, [R5, #0]
;LIS2DW12TR_LCD.c,338 :: 		for(i = 0; i < count; i++) {
ADDS	R6, R6, #1
UXTB	R6, R6
;LIS2DW12TR_LCD.c,346 :: 		}
; data_buf end address is: 8 (R2)
; count end address is: 12 (R3)
; i end address is: 24 (R6)
IT	AL
BAL	L_I2C1_BurstRead71
L_I2C1_BurstRead72:
;LIS2DW12TR_LCD.c,348 :: 		return 1;
MOVS	R0, #1
;LIS2DW12TR_LCD.c,349 :: 		}
L_end_I2C1_BurstRead:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _I2C1_BurstRead
_LIS2DW12_Detect:
;LIS2DW12TR_LCD.c,354 :: 		unsigned short LIS2DW12_Detect() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;LIS2DW12TR_LCD.c,355 :: 		if(!I2C1_ReadByte_Reg(LIS2DW12_ADDR, REG_WHO_AM_I, &who_reg)) return 0;
MOVW	R2, #lo_addr(_who_reg+0)
MOVT	R2, #hi_addr(_who_reg+0)
MOVS	R1, #15
MOVS	R0, #25
BL	_I2C1_ReadByte_Reg+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_Detect76
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_Detect
L_LIS2DW12_Detect76:
;LIS2DW12TR_LCD.c,356 :: 		if(who_reg != 0x44) return 0;
MOVW	R0, #lo_addr(_who_reg+0)
MOVT	R0, #hi_addr(_who_reg+0)
LDRB	R0, [R0, #0]
CMP	R0, #68
IT	EQ
BEQ	L_LIS2DW12_Detect77
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_Detect
L_LIS2DW12_Detect77:
;LIS2DW12TR_LCD.c,357 :: 		return 1;
MOVS	R0, #1
;LIS2DW12TR_LCD.c,358 :: 		}
L_end_LIS2DW12_Detect:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _LIS2DW12_Detect
_LIS2DW12_Init:
;LIS2DW12TR_LCD.c,360 :: 		unsigned short LIS2DW12_Init() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;LIS2DW12TR_LCD.c,364 :: 		if(!I2C1_WriteByte_Reg(LIS2DW12_ADDR, REG_CTRL1, 0x54)) return 0;
MOVS	R2, #84
MOVS	R1, #32
MOVS	R0, #25
BL	_I2C1_WriteByte_Reg+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_Init78
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_Init
L_LIS2DW12_Init78:
;LIS2DW12TR_LCD.c,365 :: 		if(!I2C1_WriteByte_Reg(LIS2DW12_ADDR, REG_CTRL2, 0x0C)) return 0;
MOVS	R2, #12
MOVS	R1, #33
MOVS	R0, #25
BL	_I2C1_WriteByte_Reg+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_Init79
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_Init
L_LIS2DW12_Init79:
;LIS2DW12TR_LCD.c,366 :: 		if(!I2C1_WriteByte_Reg(LIS2DW12_ADDR, REG_CTRL6, 0x00)) return 0;
MOVS	R2, #0
MOVS	R1, #37
MOVS	R0, #25
BL	_I2C1_WriteByte_Reg+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_Init80
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_Init
L_LIS2DW12_Init80:
;LIS2DW12TR_LCD.c,368 :: 		return 1;
MOVS	R0, #1
;LIS2DW12TR_LCD.c,369 :: 		}
L_end_LIS2DW12_Init:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _LIS2DW12_Init
_LIS2DW12_ReadAll:
;LIS2DW12TR_LCD.c,371 :: 		unsigned short LIS2DW12_ReadAll() {
SUB	SP, SP, #4
STR	LR, [SP, #0]
;LIS2DW12TR_LCD.c,372 :: 		if(!I2C1_ReadByte_Reg(LIS2DW12_ADDR, REG_WHO_AM_I, &who_reg)) return 0;
MOVW	R2, #lo_addr(_who_reg+0)
MOVT	R2, #hi_addr(_who_reg+0)
MOVS	R1, #15
MOVS	R0, #25
BL	_I2C1_ReadByte_Reg+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_ReadAll81
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_ReadAll
L_LIS2DW12_ReadAll81:
;LIS2DW12TR_LCD.c,373 :: 		if(!I2C1_ReadByte_Reg(LIS2DW12_ADDR, REG_STATUS, &status_reg)) return 0;
MOVW	R2, #lo_addr(_status_reg+0)
MOVT	R2, #hi_addr(_status_reg+0)
MOVS	R1, #39
MOVS	R0, #25
BL	_I2C1_ReadByte_Reg+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_ReadAll82
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_ReadAll
L_LIS2DW12_ReadAll82:
;LIS2DW12TR_LCD.c,375 :: 		if(!I2C1_BurstRead(LIS2DW12_ADDR, REG_OUT_T_L, 2, temp_buf)) return 0;
MOVW	R3, #lo_addr(_temp_buf+0)
MOVT	R3, #hi_addr(_temp_buf+0)
MOVS	R2, #2
MOVS	R1, #13
MOVS	R0, #25
BL	_I2C1_BurstRead+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_ReadAll83
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_ReadAll
L_LIS2DW12_ReadAll83:
;LIS2DW12TR_LCD.c,376 :: 		if(!I2C1_BurstRead(LIS2DW12_ADDR, REG_OUT_X_L, 6, xyz_buf)) return 0;
MOVW	R3, #lo_addr(_xyz_buf+0)
MOVT	R3, #hi_addr(_xyz_buf+0)
MOVS	R2, #6
MOVS	R1, #40
MOVS	R0, #25
BL	_I2C1_BurstRead+0
CMP	R0, #0
IT	NE
BNE	L_LIS2DW12_ReadAll84
MOVS	R0, #0
IT	AL
BAL	L_end_LIS2DW12_ReadAll
L_LIS2DW12_ReadAll84:
;LIS2DW12TR_LCD.c,378 :: 		temp_raw = MakeSigned16(temp_buf[0], temp_buf[1]);
MOVW	R0, #lo_addr(_temp_buf+1)
MOVT	R0, #hi_addr(_temp_buf+1)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_temp_buf+0)
MOVT	R0, #hi_addr(_temp_buf+0)
LDRB	R0, [R0, #0]
BL	_MakeSigned16+0
MOVW	R1, #lo_addr(_temp_raw+0)
MOVT	R1, #hi_addr(_temp_raw+0)
STRH	R0, [R1, #0]
;LIS2DW12TR_LCD.c,379 :: 		x_raw    = MakeSigned16(xyz_buf[0], xyz_buf[1]);
MOVW	R0, #lo_addr(_xyz_buf+1)
MOVT	R0, #hi_addr(_xyz_buf+1)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_xyz_buf+0)
MOVT	R0, #hi_addr(_xyz_buf+0)
LDRB	R0, [R0, #0]
BL	_MakeSigned16+0
MOVW	R1, #lo_addr(_x_raw+0)
MOVT	R1, #hi_addr(_x_raw+0)
STRH	R0, [R1, #0]
;LIS2DW12TR_LCD.c,380 :: 		y_raw    = MakeSigned16(xyz_buf[2], xyz_buf[3]);
MOVW	R0, #lo_addr(_xyz_buf+3)
MOVT	R0, #hi_addr(_xyz_buf+3)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_xyz_buf+2)
MOVT	R0, #hi_addr(_xyz_buf+2)
LDRB	R0, [R0, #0]
BL	_MakeSigned16+0
MOVW	R1, #lo_addr(_y_raw+0)
MOVT	R1, #hi_addr(_y_raw+0)
STRH	R0, [R1, #0]
;LIS2DW12TR_LCD.c,381 :: 		z_raw    = MakeSigned16(xyz_buf[4], xyz_buf[5]);
MOVW	R0, #lo_addr(_xyz_buf+5)
MOVT	R0, #hi_addr(_xyz_buf+5)
LDRB	R1, [R0, #0]
MOVW	R0, #lo_addr(_xyz_buf+4)
MOVT	R0, #hi_addr(_xyz_buf+4)
LDRB	R0, [R0, #0]
BL	_MakeSigned16+0
MOVW	R1, #lo_addr(_z_raw+0)
MOVT	R1, #hi_addr(_z_raw+0)
STRH	R0, [R1, #0]
;LIS2DW12TR_LCD.c,384 :: 		temp_c_x10 = ((temp_raw * 10L) / 256L) + 250L;
MOVW	R1, #lo_addr(_temp_raw+0)
MOVT	R1, #hi_addr(_temp_raw+0)
LDRSH	R2, [R1, #0]
MOV	R1, #10
MULS	R2, R1, R2
MOV	R1, #256
SDIV	R1, R2, R1
ADDW	R2, R1, #250
MOVW	R1, #lo_addr(_temp_c_x10+0)
MOVT	R1, #hi_addr(_temp_c_x10+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,387 :: 		x_mg = (x_raw * 244L) / 1000L;
MOVW	R1, #lo_addr(_x_raw+0)
MOVT	R1, #hi_addr(_x_raw+0)
LDRSH	R2, [R1, #0]
MOV	R1, #244
MULS	R2, R1, R2
MOV	R1, #1000
UDIV	R2, R2, R1
MOVW	R1, #lo_addr(_x_mg+0)
MOVT	R1, #hi_addr(_x_mg+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,388 :: 		y_mg = (y_raw * 244L) / 1000L;
MOVW	R1, #lo_addr(_y_raw+0)
MOVT	R1, #hi_addr(_y_raw+0)
LDRSH	R2, [R1, #0]
MOV	R1, #244
MULS	R2, R1, R2
MOV	R1, #1000
UDIV	R2, R2, R1
MOVW	R1, #lo_addr(_y_mg+0)
MOVT	R1, #hi_addr(_y_mg+0)
STR	R2, [R1, #0]
;LIS2DW12TR_LCD.c,389 :: 		z_mg = (z_raw * 244L) / 1000L;
MOV	R1, #244
MULS	R1, R0, R1
MOV	R0, #1000
UDIV	R1, R1, R0
MOVW	R0, #lo_addr(_z_mg+0)
MOVT	R0, #hi_addr(_z_mg+0)
STR	R1, [R0, #0]
;LIS2DW12TR_LCD.c,391 :: 		return 1;
MOVS	R0, #1
;LIS2DW12TR_LCD.c,392 :: 		}
L_end_LIS2DW12_ReadAll:
LDR	LR, [SP, #0]
ADD	SP, SP, #4
BX	LR
; end of _LIS2DW12_ReadAll
_ShowPage1:
;LIS2DW12TR_LCD.c,397 :: 		void ShowPage1() {
SUB	SP, SP, #16
STR	LR, [SP, #0]
;LIS2DW12TR_LCD.c,401 :: 		ByteToHex(who_reg, who_txt);
ADD	R1, SP, #4
MOVW	R0, #lo_addr(_who_reg+0)
MOVT	R0, #hi_addr(_who_reg+0)
LDRB	R0, [R0, #0]
BL	_ByteToHex+0
;LIS2DW12TR_LCD.c,402 :: 		ByteToHex(status_reg, st_txt);
ADD	R1, SP, #9
MOVW	R0, #lo_addr(_status_reg+0)
MOVT	R0, #hi_addr(_status_reg+0)
LDRB	R0, [R0, #0]
BL	_ByteToHex+0
;LIS2DW12TR_LCD.c,404 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,405 :: 		Lcd_Out(1, 1, "WHO=");
MOVW	R0, #lo_addr(?lstr1_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr1_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,406 :: 		Lcd_Out(1, 5, who_txt);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #5
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,407 :: 		Lcd_Out(2, 1, "STS=");
MOVW	R0, #lo_addr(?lstr2_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr2_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,408 :: 		Lcd_Out(2, 5, st_txt);
ADD	R0, SP, #9
MOV	R2, R0
MOVS	R1, #5
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,409 :: 		}
L_end_ShowPage1:
LDR	LR, [SP, #0]
ADD	SP, SP, #16
BX	LR
; end of _ShowPage1
_ShowLivePageXYZT:
;LIS2DW12TR_LCD.c,411 :: 		void ShowLivePageXYZT() {
SUB	SP, SP, #16
STR	LR, [SP, #0]
;LIS2DW12TR_LCD.c,417 :: 		xs = x_mg / 10;
MOVW	R0, #lo_addr(_x_mg+0)
MOVT	R0, #hi_addr(_x_mg+0)
LDR	R1, [R0, #0]
MOVS	R0, #10
SDIV	R0, R1, R0
; xs start address is: 16 (R4)
MOV	R4, R0
;LIS2DW12TR_LCD.c,418 :: 		ys = y_mg / 10;
MOVW	R0, #lo_addr(_y_mg+0)
MOVT	R0, #hi_addr(_y_mg+0)
LDR	R1, [R0, #0]
MOVS	R0, #10
SDIV	R0, R1, R0
; ys start address is: 32 (R8)
MOV	R8, R0
;LIS2DW12TR_LCD.c,419 :: 		zs = z_mg / 10;
MOVW	R0, #lo_addr(_z_mg+0)
MOVT	R0, #hi_addr(_z_mg+0)
LDR	R1, [R0, #0]
MOVS	R0, #10
SDIV	R0, R1, R0
; zs start address is: 36 (R9)
MOV	R9, R0
;LIS2DW12TR_LCD.c,422 :: 		ti = temp_c_x10 / 10;
MOVW	R0, #lo_addr(_temp_c_x10+0)
MOVT	R0, #hi_addr(_temp_c_x10+0)
LDR	R1, [R0, #0]
MOVS	R0, #10
SDIV	R0, R1, R0
; ti start address is: 40 (R10)
MOV	R10, R0
;LIS2DW12TR_LCD.c,424 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,426 :: 		SIntToStr(xs, num_txt);
ADD	R0, SP, #4
MOV	R1, R0
MOV	R0, R4
; xs end address is: 16 (R4)
BL	_SIntToStr+0
;LIS2DW12TR_LCD.c,427 :: 		Lcd_Out(1, 1, "X=");
MOVW	R0, #lo_addr(?lstr3_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr3_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,428 :: 		Lcd_Out(1, 3, num_txt);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #3
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,430 :: 		SIntToStr(ys, num_txt);
ADD	R0, SP, #4
MOV	R1, R0
MOV	R0, R8
; ys end address is: 32 (R8)
BL	_SIntToStr+0
;LIS2DW12TR_LCD.c,431 :: 		Lcd_Out(1, 9, "Y=");
MOVW	R0, #lo_addr(?lstr4_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr4_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #9
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,432 :: 		Lcd_Out(1, 11, num_txt);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #11
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,434 :: 		SIntToStr(zs, num_txt);
ADD	R0, SP, #4
MOV	R1, R0
MOV	R0, R9
; zs end address is: 36 (R9)
BL	_SIntToStr+0
;LIS2DW12TR_LCD.c,435 :: 		Lcd_Out(2, 1, "Z=");
MOVW	R0, #lo_addr(?lstr5_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr5_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,436 :: 		Lcd_Out(2, 3, num_txt);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #3
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,438 :: 		SIntToStr(ti, num_txt);
ADD	R0, SP, #4
MOV	R1, R0
MOV	R0, R10
; ti end address is: 40 (R10)
BL	_SIntToStr+0
;LIS2DW12TR_LCD.c,439 :: 		Lcd_Out(2, 9, "T=");
MOVW	R0, #lo_addr(?lstr6_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr6_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #9
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,440 :: 		Lcd_Out(2, 11, num_txt);
ADD	R0, SP, #4
MOV	R2, R0
MOVS	R1, #11
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,441 :: 		}
L_end_ShowLivePageXYZT:
LDR	LR, [SP, #0]
ADD	SP, SP, #16
BX	LR
; end of _ShowLivePageXYZT
_main:
;LIS2DW12TR_LCD.c,446 :: 		void main() {
;LIS2DW12TR_LCD.c,450 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;LIS2DW12TR_LCD.c,447 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;LIS2DW12TR_LCD.c,450 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;LIS2DW12TR_LCD.c,452 :: 		Lcd_Init();
BL	_Lcd_Init+0
;LIS2DW12TR_LCD.c,453 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,454 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,456 :: 		Lcd_Out(1, 1, "LIS2DW12 TEST");
MOVW	R0, #lo_addr(?lstr7_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr7_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,457 :: 		Lcd_Out(2, 1, "Init I2C...");
MOVW	R0, #lo_addr(?lstr8_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr8_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,458 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;LIS2DW12TR_LCD.c,460 :: 		I2C1_HW_Init();
BL	_I2C1_HW_Init+0
;LIS2DW12TR_LCD.c,462 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,463 :: 		Lcd_Out(1, 1, "Detect IMU...");
MOVW	R0, #lo_addr(?lstr9_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr9_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,464 :: 		Lcd_Out(2, 1, "Addr 0x19");
MOVW	R0, #lo_addr(?lstr10_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr10_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,465 :: 		delayMs(800);
MOVW	R0, #800
BL	_delayMs+0
;LIS2DW12TR_LCD.c,467 :: 		if(!LIS2DW12_Detect()) {
BL	_LIS2DW12_Detect+0
CMP	R0, #0
IT	NE
BNE	L_main85
;LIS2DW12TR_LCD.c,468 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,469 :: 		Lcd_Out(1, 1, "IMU NOT FOUND");
MOVW	R0, #lo_addr(?lstr11_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr11_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,470 :: 		Lcd_Out(2, 1, "CHK 0x19/WIRE");
MOVW	R0, #lo_addr(?lstr12_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr12_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,471 :: 		while(1);
L_main86:
IT	AL
BAL	L_main86
;LIS2DW12TR_LCD.c,472 :: 		}
L_main85:
;LIS2DW12TR_LCD.c,474 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,475 :: 		Lcd_Out(1, 1, "WHO_AM_I OK");
MOVW	R0, #lo_addr(?lstr13_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr13_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,476 :: 		Lcd_Out(2, 1, "Init IMU...");
MOVW	R0, #lo_addr(?lstr14_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr14_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,477 :: 		delayMs(800);
MOVW	R0, #800
BL	_delayMs+0
;LIS2DW12TR_LCD.c,479 :: 		if(!LIS2DW12_Init()) {
BL	_LIS2DW12_Init+0
CMP	R0, #0
IT	NE
BNE	L_main88
;LIS2DW12TR_LCD.c,480 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,481 :: 		Lcd_Out(1, 1, "IMU INIT FAIL");
MOVW	R0, #lo_addr(?lstr15_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr15_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,482 :: 		Lcd_Out(2, 1, "CTRL write err");
MOVW	R0, #lo_addr(?lstr16_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr16_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,483 :: 		while(1);
L_main89:
IT	AL
BAL	L_main89
;LIS2DW12TR_LCD.c,484 :: 		}
L_main88:
;LIS2DW12TR_LCD.c,487 :: 		if(!LIS2DW12_ReadAll()) {
BL	_LIS2DW12_ReadAll+0
CMP	R0, #0
IT	NE
BNE	L_main91
;LIS2DW12TR_LCD.c,488 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,489 :: 		Lcd_Out(1, 1, "IMU READ FAIL");
MOVW	R0, #lo_addr(?lstr17_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr17_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,490 :: 		Lcd_Out(2, 1, "CHK BUS");
MOVW	R0, #lo_addr(?lstr18_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr18_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,491 :: 		while(1);
L_main92:
IT	AL
BAL	L_main92
;LIS2DW12TR_LCD.c,492 :: 		}
L_main91:
;LIS2DW12TR_LCD.c,494 :: 		ShowPage1();
BL	_ShowPage1+0
;LIS2DW12TR_LCD.c,495 :: 		delayMs(1500);
MOVW	R0, #1500
BL	_delayMs+0
;LIS2DW12TR_LCD.c,498 :: 		while(1) {
L_main94:
;LIS2DW12TR_LCD.c,499 :: 		if(!LIS2DW12_ReadAll()) {
BL	_LIS2DW12_ReadAll+0
CMP	R0, #0
IT	NE
BNE	L_main96
;LIS2DW12TR_LCD.c,500 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;LIS2DW12TR_LCD.c,501 :: 		Lcd_Out(1, 1, "IMU READ FAIL");
MOVW	R0, #lo_addr(?lstr19_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr19_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,502 :: 		Lcd_Out(2, 1, "CHK BUS");
MOVW	R0, #lo_addr(?lstr20_LIS2DW12TR_LCD+0)
MOVT	R0, #hi_addr(?lstr20_LIS2DW12TR_LCD+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;LIS2DW12TR_LCD.c,503 :: 		while(1);
L_main97:
IT	AL
BAL	L_main97
;LIS2DW12TR_LCD.c,504 :: 		}
L_main96:
;LIS2DW12TR_LCD.c,506 :: 		ShowLivePageXYZT();
BL	_ShowLivePageXYZT+0
;LIS2DW12TR_LCD.c,507 :: 		delayMs(200);
MOVS	R0, #200
BL	_delayMs+0
;LIS2DW12TR_LCD.c,508 :: 		}
IT	AL
BAL	L_main94
;LIS2DW12TR_LCD.c,509 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
