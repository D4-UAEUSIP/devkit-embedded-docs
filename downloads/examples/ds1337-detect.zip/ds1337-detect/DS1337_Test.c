/*
   ------------------------------------------------------------
   STM32F446RE - DS1337 Detect Test
   mikroC PRO for ARM
   Register-level I2C1 access
   ------------------------------------------------------------

   DS1337:
     PB8 -> I2C1_SCL
     PB9 -> I2C1_SDA
     7-bit address = 0x68

   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5

   Function:
     Reads DS1337 registers 0x00..0x06 repeatedly
     and shows the seconds value on LCD.
*/

// LCD connections
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

// Direction declarations required by mikroC LCD library
sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

#define SLAVE_ADDR 0x68

unsigned short timeDateReadback[7];
unsigned short sec;

// --------------------------------------------------
// Delay
// --------------------------------------------------
void delayMs(unsigned int n) {
  unsigned int i;
  for(; n > 0; n--) {
    for(i = 0; i < 3195; i++) {
      asm nop;
    }
  }
}

// --------------------------------------------------
// BCD to decimal
// --------------------------------------------------
unsigned short BcdToDec(unsigned short val) {
  return ((val >> 4) * 10) + (val & 0x0F);
}

// --------------------------------------------------
// I2C1 init
// --------------------------------------------------
void I2C1_HW_Init() {
  RCC_AHB1ENR |= 0x00000002;      // GPIOB clock enable
  RCC_APB1ENR |= 0x00200000;      // I2C1 clock enable

  // PB8, PB9 -> AF4
  GPIOB_AFRH &= ~0x000000FF;
  GPIOB_AFRH |=  0x00000044;

  // PB8, PB9 alternate function mode
  GPIOB_MODER &= ~0x000F0000;
  GPIOB_MODER |=  0x000A0000;

  // open drain
  GPIOB_OTYPER |= 0x00000300;

  // pull-up
  GPIOB_PUPDR &= ~0x000F0000;
  GPIOB_PUPDR |=  0x00050000;

  // software reset
  I2C1_CR1 = 0x8000;
  I2C1_CR1 &= ~0x8000;

  // APB1 clock = 16 MHz
  I2C1_CR2 = 16;

  // 100 kHz
  I2C1_CCR = 80;

  // max rise time
  I2C1_TRISE = 17;

  // enable I2C1
  I2C1_CR1 |= 0x0001;
}

// --------------------------------------------------
// Burst read from DS1337
// Reads n bytes starting at register maddr
// data_buf must be large enough
// --------------------------------------------------
void I2C1_BurstRead(unsigned short saddr,
                    unsigned short maddr,
                    unsigned short n,
                    unsigned short data_buf[]) {

  volatile unsigned int tmp;
  unsigned short i;

  while(I2C1_SR2 & 2);            // bus busy wait

  I2C1_CR1 &= ~0x0800;            // disable POS
  I2C1_CR1 |=  0x0100;            // START
  while(!(I2C1_SR1 & 1));         // wait SB

  I2C1_DR = saddr << 1;           // address + write
  while(!(I2C1_SR1 & 2));         // wait ADDR
  tmp = I2C1_SR2;                 // clear ADDR

  while(!(I2C1_SR1 & 0x80));      // wait TXE
  I2C1_DR = maddr;                // register address
  while(!(I2C1_SR1 & 0x80));      // wait TXE

  I2C1_CR1 |= 0x0100;             // repeated START
  while(!(I2C1_SR1 & 1));         // wait SB

  I2C1_DR = (saddr << 1) | 1;     // address + read
  while(!(I2C1_SR1 & 2));         // wait ADDR
  tmp = I2C1_SR2;                 // clear ADDR

  I2C1_CR1 |= 0x0400;             // ACK enable

  for(i = 0; i < n; i++) {
    if(i == (n - 1)) {
      I2C1_CR1 &= ~0x0400;        // ACK disable
      I2C1_CR1 |=  0x0200;        // STOP
    }

    while(!(I2C1_SR1 & 0x40));    // wait RXNE
    data_buf[i] = I2C1_DR;
  }
}

// --------------------------------------------------
// Show seconds on LCD
// --------------------------------------------------
void ShowSeconds(unsigned short seconds_value) {
  char s[3];

  s[0] = (seconds_value / 10) + '0';
  s[1] = (seconds_value % 10) + '0';
  s[2] = 0;

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "DS1337 DETECTED");
  Lcd_Out(2, 1, "SEC=");
  Lcd_Out(2, 5, s);
}

void main() {
  // LCD GPIO like your previous working examples
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1, 1, "RTC TEST");
  Lcd_Out(2, 1, "Init I2C1...");
  delayMs(1000);

  I2C1_HW_Init();

  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Out(1, 1, "Reading DS1337");
  Lcd_Out(2, 1, "Please wait...");
  delayMs(1000);

  while(1) {
    I2C1_BurstRead(SLAVE_ADDR, 0, 7, timeDateReadback);

    sec = BcdToDec(timeDateReadback[0] & 0x7F);

    ShowSeconds(sec);

    delayMs(200);
  }
}