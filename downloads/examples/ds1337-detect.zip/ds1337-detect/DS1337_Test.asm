_delayMs:
;DS1337_Test.c,50 :: 		void delayMs(unsigned int n) {
; n start address is: 0 (R0)
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;DS1337_Test.c,52 :: 		for(; n > 0; n--) {
L_delayMs0:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs1
;DS1337_Test.c,53 :: 		for(i = 0; i < 3195; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs3:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
MOVW	R1, #3195
CMP	R2, R1
IT	CS
BCS	L_delayMs4
;DS1337_Test.c,54 :: 		asm nop;
NOP
;DS1337_Test.c,53 :: 		for(i = 0; i < 3195; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;DS1337_Test.c,55 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs3
L_delayMs4:
;DS1337_Test.c,52 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;DS1337_Test.c,56 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs0
L_delayMs1:
;DS1337_Test.c,57 :: 		}
L_end_delayMs:
BX	LR
; end of _delayMs
_BcdToDec:
;DS1337_Test.c,62 :: 		unsigned short BcdToDec(unsigned short val) {
; val start address is: 0 (R0)
; val end address is: 0 (R0)
; val start address is: 0 (R0)
;DS1337_Test.c,63 :: 		return ((val >> 4) * 10) + (val & 0x0F);
LSRS	R2, R0, #4
UXTB	R2, R2
MOVS	R1, #10
SXTH	R1, R1
MULS	R2, R1, R2
SXTH	R2, R2
AND	R1, R0, #15
UXTB	R1, R1
; val end address is: 0 (R0)
ADDS	R1, R2, R1
UXTB	R0, R1
;DS1337_Test.c,64 :: 		}
L_end_BcdToDec:
BX	LR
; end of _BcdToDec
_I2C1_HW_Init:
;DS1337_Test.c,69 :: 		void I2C1_HW_Init() {
;DS1337_Test.c,70 :: 		RCC_AHB1ENR |= 0x00000002;      // GPIOB clock enable
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;DS1337_Test.c,71 :: 		RCC_APB1ENR |= 0x00200000;      // I2C1 clock enable
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2097152
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;DS1337_Test.c,74 :: 		GPIOB_AFRH &= ~0x000000FF;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
AND	R1, R0, #0
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;DS1337_Test.c,75 :: 		GPIOB_AFRH |=  0x00000044;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #68
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;DS1337_Test.c,78 :: 		GPIOB_MODER &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;DS1337_Test.c,79 :: 		GPIOB_MODER |=  0x000A0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #655360
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;DS1337_Test.c,82 :: 		GPIOB_OTYPER |= 0x00000300;
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #768
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
STR	R1, [R0, #0]
;DS1337_Test.c,85 :: 		GPIOB_PUPDR &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;DS1337_Test.c,86 :: 		GPIOB_PUPDR |=  0x00050000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #327680
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;DS1337_Test.c,89 :: 		I2C1_CR1 = 0x8000;
MOVW	R1, #32768
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;DS1337_Test.c,90 :: 		I2C1_CR1 &= ~0x8000;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R1, [R0, #0]
MOVW	R0, #32767
ANDS	R1, R0
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;DS1337_Test.c,93 :: 		I2C1_CR2 = 16;
MOVS	R1, #16
MOVW	R0, #lo_addr(I2C1_CR2+0)
MOVT	R0, #hi_addr(I2C1_CR2+0)
STR	R1, [R0, #0]
;DS1337_Test.c,96 :: 		I2C1_CCR = 80;
MOVS	R1, #80
MOVW	R0, #lo_addr(I2C1_CCR+0)
MOVT	R0, #hi_addr(I2C1_CCR+0)
STR	R1, [R0, #0]
;DS1337_Test.c,99 :: 		I2C1_TRISE = 17;
MOVS	R1, #17
MOVW	R0, #lo_addr(I2C1_TRISE+0)
MOVT	R0, #hi_addr(I2C1_TRISE+0)
STR	R1, [R0, #0]
;DS1337_Test.c,102 :: 		I2C1_CR1 |= 0x0001;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;DS1337_Test.c,103 :: 		}
L_end_I2C1_HW_Init:
BX	LR
; end of _I2C1_HW_Init
_I2C1_BurstRead:
;DS1337_Test.c,113 :: 		unsigned short data_buf[]) {
SUB	SP, SP, #16
STRB	R0, [SP, #0]
STRB	R1, [SP, #4]
STRB	R2, [SP, #8]
STR	R3, [SP, #12]
;DS1337_Test.c,118 :: 		while(I2C1_SR2 & 2);            // bus busy wait
L_I2C1_BurstRead6:
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	EQ
BEQ	L_I2C1_BurstRead7
IT	AL
BAL	L_I2C1_BurstRead6
L_I2C1_BurstRead7:
;DS1337_Test.c,120 :: 		I2C1_CR1 &= ~0x0800;            // disable POS
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #2048
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_Test.c,121 :: 		I2C1_CR1 |=  0x0100;            // START
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #256
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_Test.c,122 :: 		while(!(I2C1_SR1 & 1));         // wait SB
L_I2C1_BurstRead8:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead9
IT	AL
BAL	L_I2C1_BurstRead8
L_I2C1_BurstRead9:
;DS1337_Test.c,124 :: 		I2C1_DR = saddr << 1;           // address + write
LDRB	R4, [SP, #0]
LSLS	R5, R4, #1
UXTH	R5, R5
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_Test.c,125 :: 		while(!(I2C1_SR1 & 2));         // wait ADDR
L_I2C1_BurstRead10:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead11
IT	AL
BAL	L_I2C1_BurstRead10
L_I2C1_BurstRead11:
;DS1337_Test.c,126 :: 		tmp = I2C1_SR2;                 // clear ADDR
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R4, #0]
; tmp end address is: 0 (R0)
;DS1337_Test.c,128 :: 		while(!(I2C1_SR1 & 0x80));      // wait TXE
L_I2C1_BurstRead12:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #128
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead13
IT	AL
BAL	L_I2C1_BurstRead12
L_I2C1_BurstRead13:
;DS1337_Test.c,129 :: 		I2C1_DR = maddr;                // register address
LDRB	R5, [SP, #4]
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_Test.c,130 :: 		while(!(I2C1_SR1 & 0x80));      // wait TXE
L_I2C1_BurstRead14:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #128
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead15
IT	AL
BAL	L_I2C1_BurstRead14
L_I2C1_BurstRead15:
;DS1337_Test.c,132 :: 		I2C1_CR1 |= 0x0100;             // repeated START
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #256
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_Test.c,133 :: 		while(!(I2C1_SR1 & 1));         // wait SB
L_I2C1_BurstRead16:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #1
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead17
IT	AL
BAL	L_I2C1_BurstRead16
L_I2C1_BurstRead17:
;DS1337_Test.c,135 :: 		I2C1_DR = (saddr << 1) | 1;     // address + read
LDRB	R4, [SP, #0]
LSLS	R4, R4, #1
UXTH	R4, R4
ORR	R5, R4, #1
UXTH	R5, R5
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
STR	R5, [R4, #0]
;DS1337_Test.c,136 :: 		while(!(I2C1_SR1 & 2));         // wait ADDR
L_I2C1_BurstRead18:
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #2
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead19
IT	AL
BAL	L_I2C1_BurstRead18
L_I2C1_BurstRead19:
;DS1337_Test.c,137 :: 		tmp = I2C1_SR2;                 // clear ADDR
MOVW	R4, #lo_addr(I2C1_SR2+0)
MOVT	R4, #hi_addr(I2C1_SR2+0)
; tmp start address is: 0 (R0)
LDR	R0, [R4, #0]
; tmp end address is: 0 (R0)
;DS1337_Test.c,139 :: 		I2C1_CR1 |= 0x0400;             // ACK enable
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #1024
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_Test.c,141 :: 		for(i = 0; i < n; i++) {
; i start address is: 0 (R0)
MOVS	R0, #0
; i end address is: 0 (R0)
L_I2C1_BurstRead20:
; i start address is: 0 (R0)
LDRB	R4, [SP, #8]
CMP	R0, R4
IT	CS
BCS	L_I2C1_BurstRead21
;DS1337_Test.c,142 :: 		if(i == (n - 1)) {
LDRB	R4, [SP, #8]
SUBS	R4, R4, #1
SXTH	R4, R4
CMP	R0, R4
IT	NE
BNE	L_I2C1_BurstRead23
;DS1337_Test.c,143 :: 		I2C1_CR1 &= ~0x0400;        // ACK disable
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R5, [R4, #0]
MVN	R4, #1024
ANDS	R5, R4
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_Test.c,144 :: 		I2C1_CR1 |=  0x0200;        // STOP
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
LDR	R4, [R4, #0]
ORR	R5, R4, #512
MOVW	R4, #lo_addr(I2C1_CR1+0)
MOVT	R4, #hi_addr(I2C1_CR1+0)
STR	R5, [R4, #0]
;DS1337_Test.c,145 :: 		}
L_I2C1_BurstRead23:
;DS1337_Test.c,147 :: 		while(!(I2C1_SR1 & 0x40));    // wait RXNE
L_I2C1_BurstRead24:
; i end address is: 0 (R0)
; i start address is: 0 (R0)
MOVW	R4, #lo_addr(I2C1_SR1+0)
MOVT	R4, #hi_addr(I2C1_SR1+0)
LDR	R4, [R4, #0]
AND	R4, R4, #64
CMP	R4, #0
IT	NE
BNE	L_I2C1_BurstRead25
IT	AL
BAL	L_I2C1_BurstRead24
L_I2C1_BurstRead25:
;DS1337_Test.c,148 :: 		data_buf[i] = I2C1_DR;
LDR	R4, [SP, #12]
ADDS	R5, R4, R0
MOVW	R4, #lo_addr(I2C1_DR+0)
MOVT	R4, #hi_addr(I2C1_DR+0)
LDR	R4, [R4, #0]
STRB	R4, [R5, #0]
;DS1337_Test.c,141 :: 		for(i = 0; i < n; i++) {
ADDS	R0, R0, #1
UXTB	R0, R0
;DS1337_Test.c,149 :: 		}
; i end address is: 0 (R0)
IT	AL
BAL	L_I2C1_BurstRead20
L_I2C1_BurstRead21:
;DS1337_Test.c,150 :: 		}
L_end_I2C1_BurstRead:
ADD	SP, SP, #16
BX	LR
; end of _I2C1_BurstRead
_ShowSeconds:
;DS1337_Test.c,155 :: 		void ShowSeconds(unsigned short seconds_value) {
; seconds_value start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
; seconds_value end address is: 0 (R0)
; seconds_value start address is: 0 (R0)
;DS1337_Test.c,158 :: 		s[0] = (seconds_value / 10) + '0';
ADD	R4, SP, #4
MOVS	R1, #10
UDIV	R1, R0, R1
UXTB	R1, R1
ADDS	R1, #48
STRB	R1, [R4, #0]
;DS1337_Test.c,159 :: 		s[1] = (seconds_value % 10) + '0';
ADDS	R3, R4, #1
MOVS	R2, #10
UDIV	R1, R0, R2
MLS	R1, R2, R1, R0
UXTB	R1, R1
; seconds_value end address is: 0 (R0)
ADDS	R1, #48
STRB	R1, [R3, #0]
;DS1337_Test.c,160 :: 		s[2] = 0;
ADDS	R2, R4, #2
MOVS	R1, #0
STRB	R1, [R2, #0]
;DS1337_Test.c,162 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_Test.c,163 :: 		Lcd_Out(1, 1, "DS1337 DETECTED");
MOVW	R1, #lo_addr(?lstr1_DS1337_Test+0)
MOVT	R1, #hi_addr(?lstr1_DS1337_Test+0)
MOV	R2, R1
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_Test.c,164 :: 		Lcd_Out(2, 1, "SEC=");
MOVW	R1, #lo_addr(?lstr2_DS1337_Test+0)
MOVT	R1, #hi_addr(?lstr2_DS1337_Test+0)
MOV	R2, R1
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_Test.c,165 :: 		Lcd_Out(2, 5, s);
ADD	R1, SP, #4
MOV	R2, R1
MOVS	R1, #5
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_Test.c,166 :: 		}
L_end_ShowSeconds:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _ShowSeconds
_main:
;DS1337_Test.c,168 :: 		void main() {
;DS1337_Test.c,173 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;DS1337_Test.c,170 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;DS1337_Test.c,173 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;DS1337_Test.c,175 :: 		Lcd_Init();
BL	_Lcd_Init+0
;DS1337_Test.c,176 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_Test.c,177 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;DS1337_Test.c,179 :: 		Lcd_Out(1, 1, "RTC TEST");
MOVW	R0, #lo_addr(?lstr3_DS1337_Test+0)
MOVT	R0, #hi_addr(?lstr3_DS1337_Test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_Test.c,180 :: 		Lcd_Out(2, 1, "Init I2C1...");
MOVW	R0, #lo_addr(?lstr4_DS1337_Test+0)
MOVT	R0, #hi_addr(?lstr4_DS1337_Test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_Test.c,181 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;DS1337_Test.c,183 :: 		I2C1_HW_Init();
BL	_I2C1_HW_Init+0
;DS1337_Test.c,185 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;DS1337_Test.c,186 :: 		Lcd_Out(1, 1, "Reading DS1337");
MOVW	R0, #lo_addr(?lstr5_DS1337_Test+0)
MOVT	R0, #hi_addr(?lstr5_DS1337_Test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;DS1337_Test.c,187 :: 		Lcd_Out(2, 1, "Please wait...");
MOVW	R0, #lo_addr(?lstr6_DS1337_Test+0)
MOVT	R0, #hi_addr(?lstr6_DS1337_Test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;DS1337_Test.c,188 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;DS1337_Test.c,190 :: 		while(1) {
L_main26:
;DS1337_Test.c,191 :: 		I2C1_BurstRead(SLAVE_ADDR, 0, 7, timeDateReadback);
MOVW	R3, #lo_addr(_timeDateReadback+0)
MOVT	R3, #hi_addr(_timeDateReadback+0)
MOVS	R2, #7
MOVS	R1, #0
MOVS	R0, #104
BL	_I2C1_BurstRead+0
;DS1337_Test.c,193 :: 		sec = BcdToDec(timeDateReadback[0] & 0x7F);
MOVW	R0, #lo_addr(_timeDateReadback+0)
MOVT	R0, #hi_addr(_timeDateReadback+0)
LDRB	R0, [R0, #0]
AND	R0, R0, #127
BL	_BcdToDec+0
MOVW	R1, #lo_addr(_sec+0)
MOVT	R1, #hi_addr(_sec+0)
STRB	R0, [R1, #0]
;DS1337_Test.c,195 :: 		ShowSeconds(sec);
BL	_ShowSeconds+0
;DS1337_Test.c,197 :: 		delayMs(200);
MOVS	R0, #200
BL	_delayMs+0
;DS1337_Test.c,198 :: 		}
IT	AL
BAL	L_main26
;DS1337_Test.c,199 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
