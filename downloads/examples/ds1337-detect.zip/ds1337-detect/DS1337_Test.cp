#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/DS1337_Test.c"
#line 27 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/DS1337_Test.c"
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;


sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;



unsigned short timeDateReadback[7];
unsigned short sec;




void delayMs(unsigned int n) {
 unsigned int i;
 for(; n > 0; n--) {
 for(i = 0; i < 3195; i++) {
 asm nop;
 }
 }
}




unsigned short BcdToDec(unsigned short val) {
 return ((val >> 4) * 10) + (val & 0x0F);
}




void I2C1_HW_Init() {
 RCC_AHB1ENR |= 0x00000002;
 RCC_APB1ENR |= 0x00200000;


 GPIOB_AFRH &= ~0x000000FF;
 GPIOB_AFRH |= 0x00000044;


 GPIOB_MODER &= ~0x000F0000;
 GPIOB_MODER |= 0x000A0000;


 GPIOB_OTYPER |= 0x00000300;


 GPIOB_PUPDR &= ~0x000F0000;
 GPIOB_PUPDR |= 0x00050000;


 I2C1_CR1 = 0x8000;
 I2C1_CR1 &= ~0x8000;


 I2C1_CR2 = 16;


 I2C1_CCR = 80;


 I2C1_TRISE = 17;


 I2C1_CR1 |= 0x0001;
}






void I2C1_BurstRead(unsigned short saddr,
 unsigned short maddr,
 unsigned short n,
 unsigned short data_buf[]) {

 volatile unsigned int tmp;
 unsigned short i;

 while(I2C1_SR2 & 2);

 I2C1_CR1 &= ~0x0800;
 I2C1_CR1 |= 0x0100;
 while(!(I2C1_SR1 & 1));

 I2C1_DR = saddr << 1;
 while(!(I2C1_SR1 & 2));
 tmp = I2C1_SR2;

 while(!(I2C1_SR1 & 0x80));
 I2C1_DR = maddr;
 while(!(I2C1_SR1 & 0x80));

 I2C1_CR1 |= 0x0100;
 while(!(I2C1_SR1 & 1));

 I2C1_DR = (saddr << 1) | 1;
 while(!(I2C1_SR1 & 2));
 tmp = I2C1_SR2;

 I2C1_CR1 |= 0x0400;

 for(i = 0; i < n; i++) {
 if(i == (n - 1)) {
 I2C1_CR1 &= ~0x0400;
 I2C1_CR1 |= 0x0200;
 }

 while(!(I2C1_SR1 & 0x40));
 data_buf[i] = I2C1_DR;
 }
}




void ShowSeconds(unsigned short seconds_value) {
 char s[3];

 s[0] = (seconds_value / 10) + '0';
 s[1] = (seconds_value % 10) + '0';
 s[2] = 0;

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "DS1337 DETECTED");
 Lcd_Out(2, 1, "SEC=");
 Lcd_Out(2, 5, s);
}

void main() {

 GPIO_Digital_Output(&GPIOC_BASE,
 _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
 _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
 _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

 Lcd_Init();
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Cmd(_LCD_CURSOR_OFF);

 Lcd_Out(1, 1, "RTC TEST");
 Lcd_Out(2, 1, "Init I2C1...");
 delayMs(1000);

 I2C1_HW_Init();

 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Out(1, 1, "Reading DS1337");
 Lcd_Out(2, 1, "Please wait...");
 delayMs(1000);

 while(1) {
 I2C1_BurstRead( 0x68 , 0, 7, timeDateReadback);

 sec = BcdToDec(timeDateReadback[0] & 0x7F);

 ShowSeconds(sec);

 delayMs(200);
 }
}
