_delayMs:
;i2c_test.c,51 :: 		void delayMs(unsigned int n) {
; n start address is: 0 (R0)
SUB	SP, SP, #4
; n end address is: 0 (R0)
; n start address is: 0 (R0)
; n end address is: 0 (R0)
;i2c_test.c,53 :: 		for(; n > 0; n--) {
L_delayMs0:
; n start address is: 0 (R0)
CMP	R0, #0
IT	LS
BLS	L_delayMs1
;i2c_test.c,54 :: 		for(i = 0; i < 3195; i++) {
; i start address is: 8 (R2)
MOVS	R2, #0
; i end address is: 8 (R2)
; n end address is: 0 (R0)
L_delayMs3:
; i start address is: 8 (R2)
; n start address is: 0 (R0)
MOVW	R1, #3195
CMP	R2, R1
IT	CS
BCS	L_delayMs4
;i2c_test.c,55 :: 		asm nop;
NOP
;i2c_test.c,54 :: 		for(i = 0; i < 3195; i++) {
ADDS	R2, R2, #1
UXTH	R2, R2
;i2c_test.c,56 :: 		}
; i end address is: 8 (R2)
IT	AL
BAL	L_delayMs3
L_delayMs4:
;i2c_test.c,53 :: 		for(; n > 0; n--) {
SUBS	R0, R0, #1
UXTH	R0, R0
;i2c_test.c,57 :: 		}
; n end address is: 0 (R0)
IT	AL
BAL	L_delayMs0
L_delayMs1:
;i2c_test.c,58 :: 		}
L_end_delayMs:
ADD	SP, SP, #4
BX	LR
; end of _delayMs
_HexDigit:
;i2c_test.c,63 :: 		char HexDigit(unsigned short v) {
; v start address is: 0 (R0)
SUB	SP, SP, #4
; v end address is: 0 (R0)
; v start address is: 0 (R0)
;i2c_test.c,64 :: 		if(v < 10) return '0' + v;
CMP	R0, #10
IT	CS
BCS	L_HexDigit6
ADDW	R1, R0, #48
; v end address is: 0 (R0)
UXTB	R0, R1
IT	AL
BAL	L_end_HexDigit
L_HexDigit6:
;i2c_test.c,65 :: 		return 'A' + (v - 10);
; v start address is: 0 (R0)
SUBW	R1, R0, #10
SXTH	R1, R1
; v end address is: 0 (R0)
ADDS	R1, #65
UXTB	R0, R1
;i2c_test.c,66 :: 		}
L_end_HexDigit:
ADD	SP, SP, #4
BX	LR
; end of _HexDigit
_AddrToStr:
;i2c_test.c,71 :: 		void AddrToStr(unsigned short addr, char *s) {
; s start address is: 4 (R1)
; addr start address is: 0 (R0)
SUB	SP, SP, #8
STR	LR, [SP, #0]
UXTB	R4, R0
MOV	R5, R1
; s end address is: 4 (R1)
; addr end address is: 0 (R0)
; addr start address is: 16 (R4)
; s start address is: 20 (R5)
;i2c_test.c,72 :: 		s[0] = '0';
MOVS	R2, #48
STRB	R2, [R5, #0]
;i2c_test.c,73 :: 		s[1] = 'x';
ADDS	R3, R5, #1
MOVS	R2, #120
STRB	R2, [R3, #0]
;i2c_test.c,74 :: 		s[2] = HexDigit((addr >> 4) & 0x0F);
ADDS	R2, R5, #2
STR	R2, [SP, #4]
LSRS	R2, R4, #4
UXTB	R2, R2
AND	R2, R2, #15
UXTB	R0, R2
BL	_HexDigit+0
LDR	R2, [SP, #4]
STRB	R0, [R2, #0]
;i2c_test.c,75 :: 		s[3] = HexDigit(addr & 0x0F);
ADDS	R2, R5, #3
STR	R2, [SP, #4]
AND	R2, R4, #15
; addr end address is: 16 (R4)
UXTB	R0, R2
BL	_HexDigit+0
LDR	R2, [SP, #4]
STRB	R0, [R2, #0]
;i2c_test.c,76 :: 		s[4] = 0;
ADDS	R3, R5, #4
; s end address is: 20 (R5)
MOVS	R2, #0
STRB	R2, [R3, #0]
;i2c_test.c,77 :: 		}
L_end_AddrToStr:
LDR	LR, [SP, #0]
ADD	SP, SP, #8
BX	LR
; end of _AddrToStr
_I2C1_HW_Init:
;i2c_test.c,83 :: 		void I2C1_HW_Init() {
SUB	SP, SP, #4
;i2c_test.c,84 :: 		RCC_AHB1ENR |= 0x00000002;      // GPIOB clock enable
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2
MOVW	R0, #lo_addr(RCC_AHB1ENR+0)
MOVT	R0, #hi_addr(RCC_AHB1ENR+0)
STR	R1, [R0, #0]
;i2c_test.c,85 :: 		RCC_APB1ENR |= 0x00200000;      // I2C1 clock enable
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #2097152
MOVW	R0, #lo_addr(RCC_APB1ENR+0)
MOVT	R0, #hi_addr(RCC_APB1ENR+0)
STR	R1, [R0, #0]
;i2c_test.c,88 :: 		GPIOB_AFRH &= ~0x000000FF;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
AND	R1, R0, #0
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;i2c_test.c,89 :: 		GPIOB_AFRH |=  0x00000044;
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #68
MOVW	R0, #lo_addr(GPIOB_AFRH+0)
MOVT	R0, #hi_addr(GPIOB_AFRH+0)
STR	R1, [R0, #0]
;i2c_test.c,92 :: 		GPIOB_MODER &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;i2c_test.c,93 :: 		GPIOB_MODER |=  0x000A0000;
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #655360
MOVW	R0, #lo_addr(GPIOB_MODER+0)
MOVT	R0, #hi_addr(GPIOB_MODER+0)
STR	R1, [R0, #0]
;i2c_test.c,96 :: 		GPIOB_OTYPER |= 0x00000300;
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #768
MOVW	R0, #lo_addr(GPIOB_OTYPER+0)
MOVT	R0, #hi_addr(GPIOB_OTYPER+0)
STR	R1, [R0, #0]
;i2c_test.c,99 :: 		GPIOB_PUPDR &= ~0x000F0000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R1, [R0, #0]
MVN	R0, #983040
ANDS	R1, R0
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;i2c_test.c,100 :: 		GPIOB_PUPDR |=  0x00050000;
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #327680
MOVW	R0, #lo_addr(GPIOB_PUPDR+0)
MOVT	R0, #hi_addr(GPIOB_PUPDR+0)
STR	R1, [R0, #0]
;i2c_test.c,103 :: 		I2C1_CR1 = 0x8000;
MOVW	R1, #32768
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;i2c_test.c,104 :: 		I2C1_CR1 &= ~0x8000;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R1, [R0, #0]
MOVW	R0, #32767
ANDS	R1, R0
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;i2c_test.c,107 :: 		I2C1_CR2 = 16;
MOVS	R1, #16
MOVW	R0, #lo_addr(I2C1_CR2+0)
MOVT	R0, #hi_addr(I2C1_CR2+0)
STR	R1, [R0, #0]
;i2c_test.c,110 :: 		I2C1_CCR = 80;
MOVS	R1, #80
MOVW	R0, #lo_addr(I2C1_CCR+0)
MOVT	R0, #hi_addr(I2C1_CCR+0)
STR	R1, [R0, #0]
;i2c_test.c,113 :: 		I2C1_TRISE = 17;
MOVS	R1, #17
MOVW	R0, #lo_addr(I2C1_TRISE+0)
MOVT	R0, #hi_addr(I2C1_TRISE+0)
STR	R1, [R0, #0]
;i2c_test.c,116 :: 		I2C1_CR1 |= 0x0001;
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
LDR	R0, [R0, #0]
ORR	R1, R0, #1
MOVW	R0, #lo_addr(I2C1_CR1+0)
MOVT	R0, #hi_addr(I2C1_CR1+0)
STR	R1, [R0, #0]
;i2c_test.c,117 :: 		}
L_end_I2C1_HW_Init:
ADD	SP, SP, #4
BX	LR
; end of _I2C1_HW_Init
_I2C1_DevicePresent:
;i2c_test.c,123 :: 		unsigned short I2C1_DevicePresent(unsigned short addr) {
; addr start address is: 0 (R0)
SUB	SP, SP, #4
; addr end address is: 0 (R0)
; addr start address is: 0 (R0)
;i2c_test.c,128 :: 		timeout = 50000;
; timeout start address is: 8 (R2)
MOVW	R2, #50000
; addr end address is: 0 (R0)
; timeout end address is: 8 (R2)
;i2c_test.c,129 :: 		while((I2C1_SR2 & 2) && timeout) timeout--;
L_I2C1_DevicePresent7:
; timeout start address is: 8 (R2)
; addr start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_SR2+0)
MOVT	R1, #hi_addr(I2C1_SR2+0)
LDR	R1, [R1, #0]
AND	R1, R1, #2
CMP	R1, #0
IT	EQ
BEQ	L__I2C1_DevicePresent33
CMP	R2, #0
IT	EQ
BEQ	L__I2C1_DevicePresent32
L__I2C1_DevicePresent31:
SUBS	R2, R2, #1
UXTH	R2, R2
IT	AL
BAL	L_I2C1_DevicePresent7
L__I2C1_DevicePresent33:
L__I2C1_DevicePresent32:
;i2c_test.c,130 :: 		if(timeout == 0) return 0;
CMP	R2, #0
IT	NE
BNE	L_I2C1_DevicePresent11
; addr end address is: 0 (R0)
; timeout end address is: 8 (R2)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_DevicePresent
L_I2C1_DevicePresent11:
;i2c_test.c,133 :: 		I2C1_CR1 |= 0x0100;
; addr start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #256
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;i2c_test.c,134 :: 		timeout = 50000;
; timeout start address is: 8 (R2)
MOVW	R2, #50000
; addr end address is: 0 (R0)
; timeout end address is: 8 (R2)
;i2c_test.c,135 :: 		while(!(I2C1_SR1 & 1) && timeout) timeout--;
L_I2C1_DevicePresent12:
; timeout start address is: 8 (R2)
; addr start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #1
CMP	R1, #0
IT	NE
BNE	L__I2C1_DevicePresent35
CMP	R2, #0
IT	EQ
BEQ	L__I2C1_DevicePresent34
L__I2C1_DevicePresent30:
SUBS	R2, R2, #1
UXTH	R2, R2
IT	AL
BAL	L_I2C1_DevicePresent12
L__I2C1_DevicePresent35:
L__I2C1_DevicePresent34:
;i2c_test.c,136 :: 		if(timeout == 0) return 0;
CMP	R2, #0
IT	NE
BNE	L_I2C1_DevicePresent16
; addr end address is: 0 (R0)
; timeout end address is: 8 (R2)
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_DevicePresent
L_I2C1_DevicePresent16:
;i2c_test.c,139 :: 		I2C1_DR = addr << 1;
; addr start address is: 0 (R0)
LSLS	R2, R0, #1
UXTH	R2, R2
; addr end address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_DR+0)
MOVT	R1, #hi_addr(I2C1_DR+0)
STR	R2, [R1, #0]
;i2c_test.c,141 :: 		timeout = 50000;
; timeout start address is: 0 (R0)
MOVW	R0, #50000
; timeout end address is: 0 (R0)
;i2c_test.c,142 :: 		while(timeout) {
L_I2C1_DevicePresent17:
; timeout start address is: 0 (R0)
CMP	R0, #0
IT	EQ
BEQ	L_I2C1_DevicePresent18
;i2c_test.c,143 :: 		if(I2C1_SR1 & 2) {
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #2
CMP	R1, #0
IT	EQ
BEQ	L_I2C1_DevicePresent19
; timeout end address is: 0 (R0)
;i2c_test.c,145 :: 		tmp = I2C1_SR2;         // clear ADDR
MOVW	R1, #lo_addr(I2C1_SR2+0)
MOVT	R1, #hi_addr(I2C1_SR2+0)
; tmp start address is: 4 (R1)
LDR	R1, [R1, #0]
; tmp end address is: 4 (R1)
;i2c_test.c,146 :: 		I2C1_CR1 |= 0x0200;     // STOP
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #512
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;i2c_test.c,147 :: 		return 1;
MOVS	R0, #1
IT	AL
BAL	L_end_I2C1_DevicePresent
;i2c_test.c,148 :: 		}
L_I2C1_DevicePresent19:
;i2c_test.c,150 :: 		if(I2C1_SR1 & 0x0400) {
; timeout start address is: 0 (R0)
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R1, [R1, #0]
AND	R1, R1, #1024
CMP	R1, #0
IT	EQ
BEQ	L_I2C1_DevicePresent20
; timeout end address is: 0 (R0)
;i2c_test.c,152 :: 		I2C1_SR1 &= ~0x0400;    // clear AF
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
LDR	R2, [R1, #0]
MVN	R1, #1024
ANDS	R2, R1
MOVW	R1, #lo_addr(I2C1_SR1+0)
MOVT	R1, #hi_addr(I2C1_SR1+0)
STR	R2, [R1, #0]
;i2c_test.c,153 :: 		I2C1_CR1 |= 0x0200;     // STOP
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #512
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;i2c_test.c,154 :: 		return 0;
MOVS	R0, #0
IT	AL
BAL	L_end_I2C1_DevicePresent
;i2c_test.c,155 :: 		}
L_I2C1_DevicePresent20:
;i2c_test.c,157 :: 		timeout--;
; timeout start address is: 0 (R0)
SUBS	R0, R0, #1
UXTH	R0, R0
;i2c_test.c,158 :: 		}
; timeout end address is: 0 (R0)
IT	AL
BAL	L_I2C1_DevicePresent17
L_I2C1_DevicePresent18:
;i2c_test.c,160 :: 		I2C1_CR1 |= 0x0200;         // STOP on timeout
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
LDR	R1, [R1, #0]
ORR	R2, R1, #512
MOVW	R1, #lo_addr(I2C1_CR1+0)
MOVT	R1, #hi_addr(I2C1_CR1+0)
STR	R2, [R1, #0]
;i2c_test.c,161 :: 		return 0;
MOVS	R0, #0
;i2c_test.c,162 :: 		}
L_end_I2C1_DevicePresent:
ADD	SP, SP, #4
BX	LR
; end of _I2C1_DevicePresent
_main:
;i2c_test.c,167 :: 		void main() {
SUB	SP, SP, #16
;i2c_test.c,176 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
MOVW	R1, #828
;i2c_test.c,173 :: 		GPIO_Digital_Output(&GPIOC_BASE,
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;i2c_test.c,176 :: 		_GPIO_PINMASK_8 | _GPIO_PINMASK_9);
BL	_GPIO_Digital_Output+0
;i2c_test.c,179 :: 		Lcd_Init();
BL	_Lcd_Init+0
;i2c_test.c,180 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;i2c_test.c,181 :: 		Lcd_Cmd(_LCD_CURSOR_OFF);
MOVS	R0, #12
BL	_Lcd_Cmd+0
;i2c_test.c,183 :: 		Lcd_Out(1, 1, "I2C Scanner");
MOVW	R0, #lo_addr(?lstr1_i2c_test+0)
MOVT	R0, #hi_addr(?lstr1_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;i2c_test.c,184 :: 		Lcd_Out(2, 1, "Init...");
MOVW	R0, #lo_addr(?lstr2_i2c_test+0)
MOVT	R0, #hi_addr(?lstr2_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;i2c_test.c,185 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;i2c_test.c,188 :: 		I2C1_HW_Init();
BL	_I2C1_HW_Init+0
;i2c_test.c,190 :: 		while(1) {
L_main21:
;i2c_test.c,191 :: 		found_count = 0;
MOVS	R1, #0
MOVW	R0, #lo_addr(_found_count+0)
MOVT	R0, #hi_addr(_found_count+0)
STRB	R1, [R0, #0]
;i2c_test.c,193 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;i2c_test.c,194 :: 		Lcd_Out(1, 1, "Scanning...");
MOVW	R0, #lo_addr(?lstr3_i2c_test+0)
MOVT	R0, #hi_addr(?lstr3_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;i2c_test.c,195 :: 		Lcd_Out(2, 1, "Please wait");
MOVW	R0, #lo_addr(?lstr4_i2c_test+0)
MOVT	R0, #hi_addr(?lstr4_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;i2c_test.c,196 :: 		delayMs(1000);
MOVW	R0, #1000
BL	_delayMs+0
;i2c_test.c,198 :: 		for(addr = 0x08; addr <= 0x77; addr++) {
MOVS	R0, #8
STRB	R0, [SP, #4]
L_main23:
LDRB	R0, [SP, #4]
CMP	R0, #119
IT	HI
BHI	L_main24
;i2c_test.c,199 :: 		if(I2C1_DevicePresent(addr)) {
LDRB	R0, [SP, #4]
BL	_I2C1_DevicePresent+0
CMP	R0, #0
IT	EQ
BEQ	L_main26
;i2c_test.c,200 :: 		found_count++;
MOVW	R1, #lo_addr(_found_count+0)
MOVT	R1, #hi_addr(_found_count+0)
LDRB	R0, [R1, #0]
ADDS	R0, R0, #1
STRB	R0, [R1, #0]
;i2c_test.c,202 :: 		AddrToStr(addr, addr_txt);
ADD	R0, SP, #5
MOV	R1, R0
LDRB	R0, [SP, #4]
BL	_AddrToStr+0
;i2c_test.c,204 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;i2c_test.c,205 :: 		Lcd_Out(1, 1, "Device Found");
MOVW	R0, #lo_addr(?lstr5_i2c_test+0)
MOVT	R0, #hi_addr(?lstr5_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;i2c_test.c,206 :: 		Lcd_Out(2, 1, addr_txt);
ADD	R0, SP, #5
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;i2c_test.c,207 :: 		delayMs(1200);
MOVW	R0, #1200
BL	_delayMs+0
;i2c_test.c,208 :: 		}
L_main26:
;i2c_test.c,198 :: 		for(addr = 0x08; addr <= 0x77; addr++) {
LDRB	R0, [SP, #4]
ADDS	R0, R0, #1
STRB	R0, [SP, #4]
;i2c_test.c,209 :: 		}
IT	AL
BAL	L_main23
L_main24:
;i2c_test.c,211 :: 		Lcd_Cmd(_LCD_CLEAR);
MOVS	R0, #1
BL	_Lcd_Cmd+0
;i2c_test.c,213 :: 		if(found_count == 0) {
MOVW	R0, #lo_addr(_found_count+0)
MOVT	R0, #hi_addr(_found_count+0)
LDRB	R0, [R0, #0]
CMP	R0, #0
IT	NE
BNE	L_main27
;i2c_test.c,214 :: 		Lcd_Out(1, 1, "No Device Found");
MOVW	R0, #lo_addr(?lstr6_i2c_test+0)
MOVT	R0, #hi_addr(?lstr6_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;i2c_test.c,215 :: 		Lcd_Out(2, 1, "Rescanning...");
MOVW	R0, #lo_addr(?lstr7_i2c_test+0)
MOVT	R0, #hi_addr(?lstr7_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;i2c_test.c,216 :: 		} else {
IT	AL
BAL	L_main28
L_main27:
;i2c_test.c,217 :: 		Lcd_Out(1, 1, "Scan Done");
MOVW	R0, #lo_addr(?lstr8_i2c_test+0)
MOVT	R0, #hi_addr(?lstr8_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #1
BL	_Lcd_Out+0
;i2c_test.c,219 :: 		if(found_count > 99) found_count = 99;
MOVW	R0, #lo_addr(_found_count+0)
MOVT	R0, #hi_addr(_found_count+0)
LDRB	R0, [R0, #0]
CMP	R0, #99
IT	LS
BLS	L_main29
MOVS	R1, #99
MOVW	R0, #lo_addr(_found_count+0)
MOVT	R0, #hi_addr(_found_count+0)
STRB	R1, [R0, #0]
L_main29:
;i2c_test.c,220 :: 		count_txt[0] = (found_count / 10) + '0';
ADD	R4, SP, #10
MOVW	R2, #lo_addr(_found_count+0)
MOVT	R2, #hi_addr(_found_count+0)
LDRB	R1, [R2, #0]
MOVS	R0, #10
UDIV	R0, R1, R0
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R4, #0]
;i2c_test.c,221 :: 		count_txt[1] = (found_count % 10) + '0';
ADDS	R3, R4, #1
MOV	R0, R2
LDRB	R2, [R0, #0]
MOVS	R1, #10
UDIV	R0, R2, R1
MLS	R0, R1, R0, R2
UXTB	R0, R0
ADDS	R0, #48
STRB	R0, [R3, #0]
;i2c_test.c,222 :: 		count_txt[2] = 0;
ADDS	R1, R4, #2
MOVS	R0, #0
STRB	R0, [R1, #0]
;i2c_test.c,224 :: 		Lcd_Out(2, 1, "Count=");
MOVW	R0, #lo_addr(?lstr9_i2c_test+0)
MOVT	R0, #hi_addr(?lstr9_i2c_test+0)
MOV	R2, R0
MOVS	R1, #1
MOVS	R0, #2
BL	_Lcd_Out+0
;i2c_test.c,225 :: 		Lcd_Out(2, 7, count_txt);
ADD	R0, SP, #10
MOV	R2, R0
MOVS	R1, #7
MOVS	R0, #2
BL	_Lcd_Out+0
;i2c_test.c,226 :: 		}
L_main28:
;i2c_test.c,228 :: 		delayMs(2000);
MOVW	R0, #2000
BL	_delayMs+0
;i2c_test.c,229 :: 		}
IT	AL
BAL	L_main21
;i2c_test.c,230 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
