/*
   ------------------------------------------------------------
   STM32F446RE - I2C Scanner
   mikroC PRO for ARM
   Register-level I2C1 access
   ------------------------------------------------------------

   I2C1:
     PB8 -> SCL
     PB9 -> SDA

   LCD:
     RS -> PC8
     EN -> PC9
     D4 -> PC2
     D5 -> PC3
     D6 -> PC4
     D7 -> PC5

   Function:
     Scans I2C addresses from 0x08 to 0x77
     and displays found addresses on the LCD.

   Notes:
     - Built from the same register-level I2C style
       that already worked with your DS1337.
     - Uses only address ACK detection.
*/

// LCD connections
sbit LCD_RS at GPIOC_ODR.B8;
sbit LCD_EN at GPIOC_ODR.B9;
sbit LCD_D4 at GPIOC_ODR.B2;
sbit LCD_D5 at GPIOC_ODR.B3;
sbit LCD_D6 at GPIOC_ODR.B4;
sbit LCD_D7 at GPIOC_ODR.B5;

// Direction declarations required by mikroC LCD library
sbit LCD_RS_Direction at GPIOC_MODER.B8;
sbit LCD_EN_Direction at GPIOC_MODER.B9;
sbit LCD_D4_Direction at GPIOC_MODER.B2;
sbit LCD_D5_Direction at GPIOC_MODER.B3;
sbit LCD_D6_Direction at GPIOC_MODER.B4;
sbit LCD_D7_Direction at GPIOC_MODER.B5;

unsigned short found_count;

// --------------------------------------------------
// Delay
// --------------------------------------------------
void delayMs(unsigned int n) {
  unsigned int i;
  for(; n > 0; n--) {
    for(i = 0; i < 3195; i++) {
      asm nop;
    }
  }
}

// --------------------------------------------------
// Convert nibble to hex char
// --------------------------------------------------
char HexDigit(unsigned short v) {
  if(v < 10) return '0' + v;
  return 'A' + (v - 10);
}

// --------------------------------------------------
// Convert address to "0xXX"
// --------------------------------------------------
void AddrToStr(unsigned short addr, char *s) {
  s[0] = '0';
  s[1] = 'x';
  s[2] = HexDigit((addr >> 4) & 0x0F);
  s[3] = HexDigit(addr & 0x0F);
  s[4] = 0;
}

// --------------------------------------------------
// I2C1 init
// Same style as the working DS1337 program
// --------------------------------------------------
void I2C1_HW_Init() {
  RCC_AHB1ENR |= 0x00000002;      // GPIOB clock enable
  RCC_APB1ENR |= 0x00200000;      // I2C1 clock enable

  // PB8, PB9 -> AF4
  GPIOB_AFRH &= ~0x000000FF;
  GPIOB_AFRH |=  0x00000044;

  // PB8, PB9 alternate function mode
  GPIOB_MODER &= ~0x000F0000;
  GPIOB_MODER |=  0x000A0000;

  // open drain
  GPIOB_OTYPER |= 0x00000300;

  // pull-up
  GPIOB_PUPDR &= ~0x000F0000;
  GPIOB_PUPDR |=  0x00050000;

  // software reset
  I2C1_CR1 = 0x8000;
  I2C1_CR1 &= ~0x8000;

  // APB1 clock = 16 MHz
  I2C1_CR2 = 16;

  // 100 kHz
  I2C1_CCR = 80;

  // max rise time
  I2C1_TRISE = 17;

  // enable I2C1
  I2C1_CR1 |= 0x0001;
}

// --------------------------------------------------
// Probe one I2C address
// Returns 1 if device ACKs, else 0
// --------------------------------------------------
unsigned short I2C1_DevicePresent(unsigned short addr) {
  volatile unsigned int tmp;
  unsigned int timeout;

  // wait until bus free
  timeout = 50000;
  while((I2C1_SR2 & 2) && timeout) timeout--;
  if(timeout == 0) return 0;

  // generate START
  I2C1_CR1 |= 0x0100;
  timeout = 50000;
  while(!(I2C1_SR1 & 1) && timeout) timeout--;
  if(timeout == 0) return 0;

  // send address + write
  I2C1_DR = addr << 1;

  timeout = 50000;
  while(timeout) {
    if(I2C1_SR1 & 2) {
      // ADDR set = ACK received
      tmp = I2C1_SR2;         // clear ADDR
      I2C1_CR1 |= 0x0200;     // STOP
      return 1;
    }

    if(I2C1_SR1 & 0x0400) {
      // AF = acknowledge failure -> no device
      I2C1_SR1 &= ~0x0400;    // clear AF
      I2C1_CR1 |= 0x0200;     // STOP
      return 0;
    }

    timeout--;
  }

  I2C1_CR1 |= 0x0200;         // STOP on timeout
  return 0;
}

// --------------------------------------------------
// Main
// --------------------------------------------------
void main() {
  unsigned short addr;
  char addr_txt[5];
  char count_txt[4];

  // LCD GPIO like your working examples
  GPIO_Digital_Output(&GPIOC_BASE,
      _GPIO_PINMASK_2 | _GPIO_PINMASK_3 |
      _GPIO_PINMASK_4 | _GPIO_PINMASK_5 |
      _GPIO_PINMASK_8 | _GPIO_PINMASK_9);

  // LCD init
  Lcd_Init();
  Lcd_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1, 1, "I2C Scanner");
  Lcd_Out(2, 1, "Init...");
  delayMs(1000);

  // I2C init
  I2C1_HW_Init();

  while(1) {
    found_count = 0;

    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Out(1, 1, "Scanning...");
    Lcd_Out(2, 1, "Please wait");
    delayMs(1000);

    for(addr = 0x08; addr <= 0x77; addr++) {
      if(I2C1_DevicePresent(addr)) {
        found_count++;

        AddrToStr(addr, addr_txt);

        Lcd_Cmd(_LCD_CLEAR);
        Lcd_Out(1, 1, "Device Found");
        Lcd_Out(2, 1, addr_txt);
        delayMs(1200);
      }
    }

    Lcd_Cmd(_LCD_CLEAR);

    if(found_count == 0) {
      Lcd_Out(1, 1, "No Device Found");
      Lcd_Out(2, 1, "Rescanning...");
    } else {
      Lcd_Out(1, 1, "Scan Done");

      if(found_count > 99) found_count = 99;
      count_txt[0] = (found_count / 10) + '0';
      count_txt[1] = (found_count % 10) + '0';
      count_txt[2] = 0;

      Lcd_Out(2, 1, "Count=");
      Lcd_Out(2, 7, count_txt);
    }

    delayMs(2000);
  }
}