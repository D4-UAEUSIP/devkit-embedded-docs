_main:
;Switches_LEDS.c,38 :: 		void main() {
;Switches_LEDS.c,41 :: 		GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
MOVW	R1, #3072
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
BL	_GPIO_Digital_Output+0
;Switches_LEDS.c,42 :: 		GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);
MOVW	R1, #192
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Output+0
;Switches_LEDS.c,45 :: 		GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_2);      // SW1
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOD_BASE+0)
MOVT	R0, #hi_addr(GPIOD_BASE+0)
BL	_GPIO_Digital_Input+0
;Switches_LEDS.c,46 :: 		GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_2);      // SW2
MOVW	R1, #4
MOVW	R0, #lo_addr(GPIOB_BASE+0)
MOVT	R0, #hi_addr(GPIOB_BASE+0)
BL	_GPIO_Digital_Input+0
;Switches_LEDS.c,48 :: 		_GPIO_PINMASK_12);    // SW3, SW4
MOVW	R1, #4098
;Switches_LEDS.c,47 :: 		GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_1 |
MOVW	R0, #lo_addr(GPIOC_BASE+0)
MOVT	R0, #hi_addr(GPIOC_BASE+0)
;Switches_LEDS.c,48 :: 		_GPIO_PINMASK_12);    // SW3, SW4
BL	_GPIO_Digital_Input+0
;Switches_LEDS.c,51 :: 		GPIOC_ODR.B10 = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Switches_LEDS.c,52 :: 		GPIOC_ODR.B11 = 0;
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
;Switches_LEDS.c,53 :: 		GPIOB_ODR.B6  = 0;
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Switches_LEDS.c,54 :: 		GPIOB_ODR.B7  = 0;
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
;Switches_LEDS.c,56 :: 		while(1) {
L_main0:
;Switches_LEDS.c,60 :: 		if(!GPIOD_IDR.B2)
MOVW	R0, #lo_addr(GPIOD_IDR+0)
MOVT	R0, #hi_addr(GPIOD_IDR+0)
_LX	[R0, ByteOffset(GPIOD_IDR+0)]
CMP	R0, #0
IT	NE
BNE	L_main2
;Switches_LEDS.c,61 :: 		GPIOC_ODR.B11 = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_main3
L_main2:
;Switches_LEDS.c,63 :: 		GPIOC_ODR.B11 = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
L_main3:
;Switches_LEDS.c,66 :: 		if(!GPIOB_IDR.B2)
MOVW	R0, #lo_addr(GPIOB_IDR+0)
MOVT	R0, #hi_addr(GPIOB_IDR+0)
_LX	[R0, ByteOffset(GPIOB_IDR+0)]
CMP	R0, #0
IT	NE
BNE	L_main4
;Switches_LEDS.c,67 :: 		GPIOC_ODR.B10 = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
IT	AL
BAL	L_main5
L_main4:
;Switches_LEDS.c,69 :: 		GPIOC_ODR.B10 = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOC_ODR+0)
MOVT	R0, #hi_addr(GPIOC_ODR+0)
_SX	[R0, ByteOffset(GPIOC_ODR+0)]
L_main5:
;Switches_LEDS.c,72 :: 		if(!GPIOC_IDR.B1)
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	NE
BNE	L_main6
;Switches_LEDS.c,73 :: 		GPIOB_ODR.B7 = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_main7
L_main6:
;Switches_LEDS.c,75 :: 		GPIOB_ODR.B7 = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
L_main7:
;Switches_LEDS.c,78 :: 		if(!GPIOC_IDR.B12)
MOVW	R0, #lo_addr(GPIOC_IDR+0)
MOVT	R0, #hi_addr(GPIOC_IDR+0)
_LX	[R0, ByteOffset(GPIOC_IDR+0)]
CMP	R0, #0
IT	NE
BNE	L_main8
;Switches_LEDS.c,79 :: 		GPIOB_ODR.B6 = 1;
MOVS	R1, #1
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
IT	AL
BAL	L_main9
L_main8:
;Switches_LEDS.c,81 :: 		GPIOB_ODR.B6 = 0;
MOVS	R1, #0
SXTB	R1, R1
MOVW	R0, #lo_addr(GPIOB_ODR+0)
MOVT	R0, #hi_addr(GPIOB_ODR+0)
_SX	[R0, ByteOffset(GPIOB_ODR+0)]
L_main9:
;Switches_LEDS.c,83 :: 		Delay_ms(20);   // basic debounce
MOVW	R7, #28926
MOVT	R7, #2
NOP
NOP
L_main10:
SUBS	R7, R7, #1
BNE	L_main10
NOP
NOP
NOP
;Switches_LEDS.c,84 :: 		}
IT	AL
BAL	L_main0
;Switches_LEDS.c,85 :: 		}
L_end_main:
L__main_end_loop:
B	L__main_end_loop
; end of _main
