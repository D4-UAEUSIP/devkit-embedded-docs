#line 1 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Switches_LEDS.c"
#line 38 "D:/2026/UAEU/Traning Kit/Firmwares/Test/7segments/Switches_LEDS.c"
void main() {


 GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
 GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6 | _GPIO_PINMASK_7);


 GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_2);
 GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_2);
 GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_1 |
 _GPIO_PINMASK_12);


 GPIOC_ODR.B10 = 0;
 GPIOC_ODR.B11 = 0;
 GPIOB_ODR.B6 = 0;
 GPIOB_ODR.B7 = 0;

 while(1) {



 if(!GPIOD_IDR.B2)
 GPIOC_ODR.B11 = 1;
 else
 GPIOC_ODR.B11 = 0;


 if(!GPIOB_IDR.B2)
 GPIOC_ODR.B10 = 1;
 else
 GPIOC_ODR.B10 = 0;


 if(!GPIOC_IDR.B1)
 GPIOB_ODR.B7 = 1;
 else
 GPIOB_ODR.B7 = 0;


 if(!GPIOC_IDR.B12)
 GPIOB_ODR.B6 = 1;
 else
 GPIOB_ODR.B6 = 0;

 Delay_ms(20);
 }
}
