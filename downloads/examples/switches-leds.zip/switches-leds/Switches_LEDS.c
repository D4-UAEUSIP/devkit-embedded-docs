/*
   ------------------------------------------------------------
   STM32F446RE - Switch to LED Test (FINAL MAPPING)
   mikroC PRO for ARM
   ------------------------------------------------------------
   Switches Selection:
   on Main Board:
   SW12 : DIP-EN side
   on Module Board:
   there is 4 DIP Switches Make sure it is in the I2C Side
   
   Switch inputs:
     SW4 -> PD2
     SW3 -> PB2
     SW2 -> PC1
     SW1 -> PC12

   LED outputs:
     LED4 -> PC11   (SW1)
     LED3 -> PC10   (SW2)
     LED2 -> PB7    (SW3)
     LED1 -> PB6    (SW4)

   Operation:
     Each switch directly controls its corresponding LED

   Assumption:
     - Switch pressed = logic LOW
     - LED ON = logic HIGH

*/

void main() {

  /* -------- Configure LED pins as outputs -------- */
  GPIO_Digital_Output(&GPIOC_BASE, _GPIO_PINMASK_10 | _GPIO_PINMASK_11);
  GPIO_Digital_Output(&GPIOB_BASE, _GPIO_PINMASK_6  | _GPIO_PINMASK_7);

  /* -------- Configure switch pins as inputs -------- */
  GPIO_Digital_Input(&GPIOD_BASE, _GPIO_PINMASK_2);      // SW1
  GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_2);      // SW2
  GPIO_Digital_Input(&GPIOC_BASE, _GPIO_PINMASK_1 |
                                   _GPIO_PINMASK_12);    // SW3, SW4

  /* -------- Initial state: LEDs OFF -------- */
  GPIOC_ODR.B10 = 0;
  GPIOC_ODR.B11 = 0;
  GPIOB_ODR.B6  = 0;
  GPIOB_ODR.B7  = 0;

  while(1) {

    /* SW4 (PD2) -> LED4 (PC11) */

    if(!GPIOD_IDR.B2)
      GPIOC_ODR.B11 = 1;
    else
      GPIOC_ODR.B11 = 0;

    /* SW3 (PB2) -> LED3 (PC10) */
    if(!GPIOB_IDR.B2)
      GPIOC_ODR.B10 = 1;
    else
      GPIOC_ODR.B10 = 0;

    /* SW2 (PC1) -> LED2 (PB7) */
    if(!GPIOC_IDR.B1)
      GPIOB_ODR.B7 = 1;
    else
      GPIOB_ODR.B7 = 0;

    /* SW1 (PC12) -> LED1 (PB6) */
    if(!GPIOC_IDR.B12)
      GPIOB_ODR.B6 = 1;
    else
      GPIOB_ODR.B6 = 0;

    Delay_ms(20);   // basic debounce
  }
}